# R7.8.1 — Cordis compatibility patch

基线：`DSH-Ultimate-2.0-round7-r7.8-professional-editing-director.zip`。本补丁只修复宿主 schema 合规、包版本声明、Atomstudy 本机面板端口发现、验证口径和 ZIP 文件名编码，并增加可选 compact 工具面；不删除文件/工具、不改 prompts、不新增 npm 依赖、不改宿主代码、不改变既有工具返回结构。

## 文件级变更记录

| 文件 | 改动 | 为什么改 | 是否影响行为 |
|---|---|---|---|
| `dsh-creative-orchestrator/index.js` | 在工具构造层统一剥离宿主不支持的范围 schema 关键字，将原约束写入 description，并在 execute 入口对数值/数组边界作等价夹取或拒绝；对象型 `additionalProperties` 转为布尔值；增加 `toolSurface`。 | 满足 dsh-tools 的 JSON Schema 子集，同时避免原来只靠 schema 拦截的边界失效；提供按需工具面。 | 默认 `full`，148 个原工具名逐项不变；既有返回结构不变。数值超界输入改为执行前夹取，原来 `minItems` 不满足仍拒绝；`compact` 是显式 opt-in。 |
| `dsh-creative-orchestrator/tests/apply.test.mjs` | 将 `targetIntegratedLufs.minimum === -36` 断言改为断言 schema 不再暴露 `minimum`、范围说明仍含 `minimum=-36`。 | 该断言直接检查本次移除的 schema 字段，属于允许同步调整的 schema 断言。 | 仅测试断言调整；不改变运行时行为。 |
| `dsh-svg-motion/index.js` | `svg_motion_score` 的 craft 范围约束移入 description；动态评分对象的 `additionalProperties` 改为 `true`，execute 内显式检查值必须为有限数字。 | 消除不支持关键字/对象型 additionalProperties，同时保留原评分输入类型约束；比例和计数范围仍由 `judgeCraftEvidence` 判定。 | 合法输入与输出结构不变；无效值仍拒绝/不通过。 |
| `dsh-atomstudy/index.js` | `atomstudy_review` 的 `additionalProperties` 改为 `true`，execute 内保留有限数字检查；`atomstudy_open` 通过宿主 `ctx.get()` 查询 web 服务端口，失败回退 3081。 | 满足 schema 子集并保留评分值类型；避免面板地址硬编码忽略宿主实际监听端口。 | 合法评分行为不变；无效评分仍拒绝；工具返回字段不变，只有解析到宿主端口时 URL 端口改变。目标宿主服务名/API 尚需目标机验证。 |
| `dsh-creative-orchestrator/package.json` | 增加 `engines.dsh`。 | 明确兼容宿主版本范围。 | 安装兼容性提示，不改变运行行为。 |
| `dsh-svg-motion/package.json` | 增加 `engines.dsh` 和四项宿主 peerDependencies。 | 让 link 安装能解析宿主依赖，并声明支持版本。 | 不增加依赖安装、不改变运行行为。 |
| `dsh-atomstudy/package.json` | 增加 `engines.dsh` 和四项宿主 peerDependencies。 | 同上。 | 同上。 |
| `dsh-aipj-preset/package.json` | 增加 `engines.dsh` 和四项宿主 peerDependencies。 | 同上。 | 同上。 |
| `scripts/fix-zip-utf8.py` | 新增 zipfile 重打包工具，恢复缺失 UTF-8 标志导致的 CP437 乱码文件名、重写 UTF-8 标志、重生成包内 `SHA256SUMS.txt`，并拒绝覆盖输入 ZIP。 | 修复 Atomstudy docs 文件名乱码及校验和失配。 | 仅打包工具；不会修改输入 ZIP。 |
| `README.md` | 增加“验证口径与外部依赖”和 R7.8.1 说明，区分目标 profile 记录与当前隔离环境实际结果。 | 避免把缺失外部工具/profile 的失败和跳过误报成通过。 | 仅文档。 |
| `RELEASE-R7.8.md` | 追加 R7.8.1 兼容补丁说明，保留 R7.8 原声明。 | 让补丁与历史发布边界清晰。 | 仅文档。 |
| `VALIDATION-R7.8.txt` | 追加指向新验证报告的说明，不覆盖旧结果。 | 保留历史记录。 | 仅文档。 |
| `TOOL-NAMES-R7.8.1.txt` | 新增 170 个完整工具名清单。 | 提供工具面可审计清单。 | 仅文档。 |
| `VALIDATION-R7.8.1.txt` | 新增本补丁真实输出、环境限制和验证差异。 | 区分可复现结果与未执行的宿主级验证。 | 仅文档。 |
| `SHA256SUMS.txt` | 重算源码包内文件校验和。 | 保证源码树校验和对应补丁后的文件内容。 | 仅校验元数据。 |

## 明确未修改

- `prompts/*.md` 全部保持原样。
- 没有删除任何原有文件或工具。
- 没有新增 npm dependencies / devDependencies。
- 没有修改 DSH 宿主代码。
- 没有修改任何既有工具的返回结构。
