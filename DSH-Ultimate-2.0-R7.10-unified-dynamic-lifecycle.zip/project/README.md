# DSH Ultimate 2.0

基于第一轮三插件重构候选版继续构建。第一轮插件保留：
- `dsh-svg-motion` 1.4.0
- `dsh-atomstudy` 0.1.1
- `dsh-aipj-preset` 2.9.1

第二轮新增：
- `dsh-creative-orchestrator` 2.0.4：当前 full 工具面 159 个 Creative 工具、20 条内置视频工作流，涵盖可恢复任务、宿主模型路由/规划、AI 导演、确定性视频分段渲染与 MP4 交付、多轨时间轴真实 FFmpeg 合成、哈希断点续跑、视觉证据 QA、音频时间线与混音、素材元数据、知识库、提示词实验与工作流目录。

先阅读 `docs/ULTIMATE-2.0-DIRECTION-AND-UX.md`，再阅读 `docs/INVENTORY-AND-DIFF.md`、`docs/ULTIMATE-2.0-IMPLEMENTATION-PLAN.md` 和 `docs/DEPLOY-AND-ROLLBACK.md`。

本包是源码交付，不是已安装到用户 DSH 的运行证明。测试只证明当前隔离环境内的源码契约与逻辑；真实宿主、模型、浏览器、Chromium/FFmpeg 仍需本机验收。

第三轮增量交付：执行驾驶模式/审批、配置版本回滚、任务分页和事件游标，详见 `docs/ROUND3-RELEASE-CHECKLIST.md` 与 `docs/EXECUTION-POLICY-AND-APPROVALS.md`。

第四轮 R4.1 / R4.2：长任务事件日志限额、绝对事件游标、执行输出/checkpoint 尺寸保护、128 分片任务索引、审批待办专用索引与分页，详见 `docs/ROUND4-R1-RELIABILITY.md`、`docs/ROUND4-R2-SHARDED-INDEX.md` 和 `docs/ROUND4-RELEASE-CHECKLIST.md`。本轮源码回归通过，但不代表真实 DSH 宿主或浏览器安装验收。


2026-11-14 参考吸收增量：基于 DrawAI 与 llc-pv-skill 的公开工作流设计，新增帧级导演时间轴、自然工作分段 / checkpoint、音乐章节与声音前置决策、首镜打样门禁契约，以及三轮审查记录 validator。详见 `docs/REFERENCE-ADOPTION-ANALYSIS.md`。本增量不引入 Remotion / React / Three.js 运行时，亦不代表真实宿主或视觉审查已完成。


## Motion Intelligence R2

KIRO-inspired optional motion architecture, style profiles, renderer adapter contract, evidence-based audio beat grids, deterministic procedural recipes, and resumable frame-segment manifests: see [`docs/MOTION-INTELLIGENCE-R2.md`](docs/MOTION-INTELLIGENCE-R2.md). Validation limits are recorded in [`docs/ROUND5-VALIDATION.md`](docs/ROUND5-VALIDATION.md).


## Motion Execution R3

R3 将 R2 的渲染契约落成可执行路径：内置零依赖 `svg-native` 渲染器、真实文件 SHA-256 验证与断点恢复、并发分段执行、超时/取消/停止确认、有限重试、不继承宿主任意环境变量的 Node 子进程监督器，以及 FFmpeg 分段拼接 / 可选音轨封装 / FFprobe 验证。详见 `docs/ROUND6-R3-EXECUTION.md`。R3 阶段 SVG 输出为浏览器可打开的动态 `.svg` 分段；后续 R4 已补入 Chromium WebGL 逐帧栅格化和 MP4 分段管线。原生 Canvas sidecar、真实 Three.js bundle 场景验收及音频文件 BPM/onset 分析已在 R5.1 接入，R5.2 已增加音频特征到 Motion 控制曲线的联动；真实音乐素材验证仍未完成。

## Round 6 R4：Chromium WebGL / Three.js 后端

R4 新增零依赖 `chromium-webgl` 后端：Node 内置 CDP 控制系统 Chromium，逐帧调用 `window.renderAt(t)`，捕获 PNG 并由 FFmpeg 编码为 H.264 分段 MP4；复用 R3 的真实文件哈希、断点续跑与终止控制。`threejs-webgl` 作为可选适配器注册，要求用户提供自包含 Three.js 浏览器 bundle 与场景脚本，Core 不增加第三方运行时依赖。FFmpeg finalizer 同步补上输入帧率/帧数探测与最后一帧时长校正。

R4.1 增量：Three.js 适配器增加 bundle/场景脚本尺寸上限、可选精确 REVISION 锁定、异步 `update(t, frameIndex)`、确定性帧索引传递、页面/场景 dispose 钩子与 WebGL 上下文释放；新增真实 Chromium 执行的 Three-compatible WebGL harness 集成测试。当前环境缺少上游 Three.js bundle 且 npm registry 不可达，因此没有声称真实 Three.js 生产场景验收。R4 WebGL → PNG → H.264 MP4 端到端仍通过真实 Chromium/FFmpeg/FFprobe 验证。详见 `docs/ROUND6-R4-RENDER-BACKENDS.md` 和 `docs/ROUND6-VALIDATION.md`。

R4.1 生命周期加固细节与验证边界见 `docs/ROUND6-R4.1-THREEJS-LIFECYCLE.md`。

## Round 6 R5.1 — Audio intelligence

- Added `creative_audio_analyze`: bounded FFmpeg PCM decode, RMS onset envelope, autocorrelation BPM estimate, beat offset, confidence and alternative tempo candidates.
- Media paths are confined to configured `mediaRoots`; weak or silent evidence remains `unknown`.
- See `docs/ROUND6-R5-AUDIO-INTELLIGENCE.md` and `docs/ROUND6-VALIDATION.md` for scope and reproducible checks.


## Round 6 R5.2 — Audio Motion 与渲染生命周期加固

R5.2 将音频分析特征映射为确定性 Motion 控制曲线和节拍事件，支持按全局时间采样，并由 Three.js 适配器注入 `window.audioMotionAt(t)` / `window.update(t, frameIndex, audioControls)`。分析证据指纹与风格/渲染方案指纹分离，避免切换风格时误报音频源变化。Chromium POSIX 运行时改为独立进程组，正常结束、取消和超时均清理整个浏览器进程树。详见 `docs/ROUND6-R5.2-AUDIO-MOTION-AND-LIFECYCLE.md`。本轮真实 Chromium/SwiftShader 与合成音频回归通过；上游 Three.js bundle、硬件 GPU、真实音乐和目标 DSH 宿主仍未验收。

## Audio editing projects (R5.3)

The orchestrator now exposes persistent, non-destructive audio timeline projects. Projects are stored under the orchestrator data root in `audio-projects/` through the existing atomic record store (directory mode `0700` and atomic file replacement).

New tools:

- `creative_audio_project_create`: create a schema-versioned project.
- `creative_audio_project_get`: load a project and report validation/duration.
- `creative_audio_project_edit`: add/remove tracks and clips, trim by source range, split clips, move/update clip properties, append a sequence with real timeline overlap, and change track gain/pan/mute/solo.
- `creative_audio_project_export`: render the saved project through local FFmpeg to WAV, MP3, M4A, AAC, FLAC, OGG or Opus (codec availability depends on the FFmpeg build).

Editing is immutable: every successful operation returns a new project revision and persists it. Source media is not copied or modified. The timeline stores seconds and supports mono/stereo project declarations; render/export remains a separate execution stage. Rendering uses argument-array process spawning, bounded timeout/cancellation, mediaRoots checks for every source and destination, symlink rejection, and temporary-file publication so a failed render does not leave a partial final file. The editor core deliberately does not claim browser waveform UI or audible preview yet.

## Round 6 R6.0 audio workstation consolidation

The unified audio project now includes non-destructive per-track effect racks (high-pass, low-pass, EQ, compressor, limiter, reverb, chorus and delay), bounded dB volume automation, sample-accurate timeline editing, immutable undo/redo, BPM/beat analysis, master and Stem export, and bounded offline range-preview rendering. See `docs/ROUND6-R6.0-AUDIO-WORKSTATION-CONSOLIDATION.md` for verified scope and host limitations. Live browser playback and the complete interactive DAW surface are not claimed until a supported host media/client bridge is available.


## Round 6 R6.2 — Portable audio projects & lock recovery

R6.2 adds SHA-256-verified JSON project backup/import with fresh project identity, create-only persistence, and stale-lock recovery that refuses to steal a lock from a still-live owner process. Project documents reference local media rather than embedding it. See `RELEASE-R6.2.md` and `docs/ROUND6-R6.2-PORTABLE-PROJECTS-AND-LOCK-RECOVERY.md`. Current orchestrator suite: 152/152 tests passed.


## Round 6 R6.3 — Master bus & clip automation

R6.3 adds a validated project-level master effect rack after track summing, plus clip-local dB automation that remains correctly aligned through split and trim edits. Master processing participates in project persistence and undo/redo. The schema remains v1 and older project documents remain readable. See `RELEASE-R6.3.md` and `docs/ROUND6-R6.3-MASTER-BUS-CLIP-AUTOMATION.md`. Orchestrator regression: 156/156 tests passed; standalone audio engine 11/11, SVG Motion 4/4, Atomstudy 106/106.

## Round 6 R6.4 — LUFS loudness mastering

R6.4 adds optional single-pass dynamic loudness normalization to final project export using FFmpeg `loudnorm`, with bounded integrated-LUFS, true-peak and loudness-range targets. Default target: -16 LUFS / -1.5 dBTP / 11 LU. The export response identifies the mode explicitly; this is not advertised as two-pass linear mastering. A real FFmpeg render followed by a separate loudness measurement is covered by integration tests. See `RELEASE-R6.4.md`.


## Round 6 R6.5 — Audio safety gates

R6.5 adds `creative_audio_safety_inspect` for read-only peak/RMS/DC-offset and silence-interval inspection, using FFmpeg `astats`/`silencedetect` plus FFprobe duration. It is a technical preflight, not proof of clipping or a mastering certification. See `RELEASE-R6.5.md` and `docs/ROUND6-R6.5-AUDIO-SAFETY-GATES.md`. Orchestrator regression at R6.5: 161/161 tests passed.

## Round 6 R6.6 — Bus / Aux Send & Return

R6.6 adds schema-v1-compatible auxiliary buses, direct track output routing, up to eight post-fader/post-effects sends per track, bus gain/pan/mute/effect racks, and atomic route cleanup on bus deletion. The FFmpeg graph now renders track outputs and Aux Return paths into the master mix. Bus-to-bus routing and pre-fader sends are intentionally not included; live monitoring remains a host-bridge integration task. See `RELEASE-R6.6.md` and `docs/ROUND6-R6.6-BUS-AUX-ROUTING.md`.


R6.6 validation: orchestrator 166/166 tests passed; standalone audio engine 11/11; SVG Motion 4/4; Atomstudy 106/106. The Atomstudy selfcheck reports its documented host-package integration skip in this isolated environment; static checks remain green.

## Audio Workstation R6.7 — Transport state & clock contract

R6.7 adds persistent transport sessions with play/pause/stop/seek/loop/tick commands and sample-rate-quantized playhead calculation driven by a caller-supplied monotonic clock. This is the control-plane foundation for a future host media bridge; it does not itself produce real-time audio, access a sound device, or replace offline FFmpeg preview/export. See [`RELEASE-R6.7.md`](RELEASE-R6.7.md).

## Audio Workstation R6.8 — Multi-resolution waveform cache

R6.8 adds bounded FFmpeg PCM waveform extraction, per-channel min/max/RMS peak pyramids, source-identity cache invalidation and paginated reads for future timeline waveform rendering. It is a data/cache layer only; no browser waveform UI or real-time audio bridge is claimed. See [`RELEASE-R6.8.md`](RELEASE-R6.8.md).

## Round 6 R6.9 — Video render pipeline

R6.9 puts the video production path back in the center: `creative_video_render_pipeline` now performs deterministic MP4 segment rendering, verified resume, ordered FFmpeg finalization, optional audio muxing and a final SHA-256 delivery receipt in one operation. It accepts only renderers that actually advertise `video/mp4`; `svg-native` remains a vector/SVG output path and is not misrepresented as an MP4 renderer. Final output replacement requires explicit `overwrite=true`. See `RELEASE-R6.9.md`.


## Round 7 R7.0 — Video workflows, style & animation presets

R7.0 adds eight ready-to-compile video workflows (short-form hook, music video, explainer, product showcase, reference-to-style, anime MV, multi-platform repurpose, and release quality gate), seven visual style presets, and fourteen reusable animation presets. New tools expose the workflow catalog/compiler, persist user-authored manifests in a dedicated `workflows/` store namespace, compile a workflow into a durable task queue entry, resolve style/animation parameters, and provide a categorized video toolbox. `creative_director_plan_with_presets` attaches resolved preset data to a deterministic director plan for the renderer scene to consume. Workflow compilation is plan-only; task creation queues work but does not start a worker or execute arbitrary tool names. Human approval gates remain explicit. See `RELEASE-R7.0.md` and `docs/ROUND7-VIDEO-WORKFLOWS-AND-PRESETS.md`.


## Round 7 R7.1 — DrawAI × LLC PV companion integration

R7.1 adds explicit companion integration contracts for `fourzkw/dsh-drawai` and `Youtich-A/llc-pv-skill`. DrawAI's existing tools (`diagram_read`, `diagram_apply`, `shotcraft_search`, `motion_project`, `motion_preview`, `motion_render`, `motion_qa`, `motion_assets`, `motion_export`, and audio-post tools) are referenced as external provider tools rather than reimplemented or copied. The LLC PV skill is represented as a skill invocation plus its observation, dense shot-script, asset-rights, production and three-round evidence-review gates. New workflows: `drawai-motion-production`, `llc-pv-high-fidelity`, and `hybrid-pv-drawai`.

`creative_companion_integrations_catalog` lists the integration contracts; `creative_companion_integrations_check` checks only caller-supplied observed tool/skill/local-capability names and never guesses installation state. Task records preserve provider, tool/skill ID, and input bindings. External execution still requires an explicit Worker adapter and actual host-visible tools. DrawAI keeps its native `.drawai` / Remotion project format; no format conversion or duplicate renderer is imposed. LLC PV remains an alpha skill; AE MCP, video-watch dependencies and L2D are optional and must be independently verified. See `docs/ROUND7.1-COMPANION-INTEGRATIONS.md`.

## Round 7 R7.2 — Unified provider dispatch and dataflow

R7.2 adds one explicit execution bridge for built-in DSH workflow tools and registered companion providers. The plugin exposes `registerToolAdapter()` and an opt-in `createWorker()` factory; no worker starts automatically. Exact provider/tool/skill handlers are required, native DSH workflow tools are allowlisted, manual gates require persisted human approval, and completed step outputs can be passed forward using safe `$ref` bindings. Side-effecting adapters must declare idempotency support or explicitly opt into at-least-once delivery. See `docs/ROUND7.2-UNIFIED-DISPATCH.md` for the adapter contract and limitations.



## Round 7 R7.3 — Production operations and workflow expansion

R7.3 adds explicit Worker controls, lifecycle telemetry, provider input/output validation and health hooks, persisted workflow dependencies, a read-only production board, and five production workflow templates (podcast, documentary montage, localization/dubbing, screen demo, and clip factory). Workers remain opt-in and external services still require explicit adapter registration. See `docs/ROUND7.3-PRODUCTION-OPERATIONS.md`.


## Round 7 R7.4 — Project registry, asset lineage, render jobs & Production Studio UI

R7.4 adds a durable project registry with optimistic revisions, content hashes and retained snapshots; project-to-task links; asset provenance and lineage auditing; and a separate render-job lifecycle bound to a fixed project revision. `creative_video_render_pipeline` can bind a Render Job and report live segment progress, checkpoints and final output receipt. Capability-aware Workers can share the durable queue without claiming tasks outside their declared tool/provider scope. Task event replay is exposed through a cursor-based tool. New tool families include `creative_project_*`, `creative_render_job_*`, and `creative_task_replay`. The orchestrator now exposes 98 public tools.

A dependency-free dark liquid-glass Production Studio dashboard is included at `ui/production-dashboard.html`. It has restrained ambient animation, responsive task/phase/project/render views and task event replay. It is read-only and uses the plugin's explicit `createDashboardBridge()` adapter through `window.DSHDashboardBridge`; target-host embedding still requires the host to inject the returned adapter. See `RELEASE-R7.4.md`, `docs/ROUND7.4-PROJECT-ASSETS-RENDER-OBSERVABILITY-AND-UI.md`, and `ui/README.md`.

Validation record: `VALIDATION-R7.4.txt`.

## Round 7 R7.5 — External ecosystem, project graph, asset branches & render operations

R7.5 grows the effective tool surface without bloating the dependency-free core. The orchestrator now exposes 118 public tools. Optional local runtimes (FFmpeg/FFprobe, Chromium, Python, Blender, ImageMagick, SoX, Rubber Band, yt-dlp, Whisper, eSpeak NG) are discoverable through bounded executable probes; optional services include ComfyUI, Ollama, compatible model APIs, Stable Diffusion, speech services, Resolve, After Effects, Audacity, Hugging Face and GitHub. Catalog entries are not treated as installed or connected services.

Project collaboration now includes validated project dependencies, explicit critical-path analysis using only supplied `metadata.estimatedWorkSec`, a unified activity feed, and immutable asset version branches pinned by project links. Render operations add capability-aware resource scheduling, explicit concurrency limits, durable leases/heartbeats, stale-lease recovery and a pipeline handoff that consumes/releases a matching lease. Completed renders can submit evidence to technical quality gates; failed/incomplete evidence blocks release, review verdicts require a human note, and final release approval is explicit.

See `RELEASE-R7.5.md` and `dsh-creative-orchestrator/docs/EXTERNAL-ECOSYSTEM-R7.5.md`. The core plugin still has no third-party runtime dependencies; optional external tools and service adapters must be installed/registered separately. R7.5 validation and host-integration limitations are recorded in `VALIDATION-R7.5.txt`.


## R7.6 provider connectivity update

R7.6 adds real, bounded HTTP adapters for local Ollama and ComfyUI: Ollama model discovery and non-streaming chat, ComfyUI workflow submission and prompt-history retrieval. Four public tools expose these operations. Localhost is the default and remote endpoints require an explicit `allowRemote: true`; embedded URL credentials, redirects, non-HTTP schemes and oversized responses are rejected. Requests have bounded timeouts. ComfyUI submission is explicitly an external generation side effect and returns a provider job ID rather than claiming a finished artifact.

OpenAI-compatible chat is available through the provider client API, but its API key can only be supplied by an explicitly registered host-owned secret provider (`registerExternalSecretProvider`). The plugin never persists or accepts raw API keys in tool arguments. The DSH host's secret-store API is not assumed or modified.


## Round 7 R7.7 — Native media production capabilities

R7.7 intentionally does not add model providers. It expands deterministic media capability instead: 12 new public tools for FFprobe metadata, bounded media-library inventory and optional SHA-256 duplicate detection, FFmpeg scene-cut candidates, sampled luma/saturation signal metrics, black-frame and freeze-frame interval detection, contact sheets, frame extraction, silence detection, two-pass EBU R128 loudness normalization, H.264/H.265/VP9 transcode, audio extraction, and embedded subtitle extraction to SRT. Three workflows compose these tools: video preflight, audio mastering, and media proxy/transcode. Write steps are approval-gated when compiled to durable workflow tasks. All source/output files remain confined to `mediaRoots`; no third-party Node runtime dependency is introduced. See `docs/MEDIA-TOOLKIT-R7.7.md`, `RELEASE-R7.7.md` and `VALIDATION-R7.7.txt`.

## R7.8 — Professional video editing foundation

R7.8 adds a revision-guarded multi-track video timeline, clip split/move/ripple editing, track lock/mute/solo, keyframes, undo/redo, frame-quantized EDL compilation, director-shot-to-timeline assembly with explicit asset bindings, and an SRT/WebVTT subtitle workbench. R7.8.9 extends the real FFmpeg timeline renderer to consume visual keyframes for opacity (0–1), scale (0.05–8×), rotation (degrees), and centered position offsets (pixels), using linear/hold/ease interpolation. Volume keyframes remain owned by the audio renderer; timeline video rendering explicitly rejects them. See `RELEASE-R7.8.9.md`, `VALIDATION-R7.8.9.txt`, and `docs/ROUND7.8-VIDEO-EDITING-AND-SUBTITLES.md` for exact scope and limitations. No model providers or npm dependencies were added.

## 验证口径与外部依赖

历史发布说明中的测试数字是各轮当时记录，保留原文不代表在每一种运行环境下都能复现。验证必须同时记录工具可用性、profile 状态和跳过原因，不能把外部依赖缺失导致的失败/跳过折算成通过：

- **Creative Orchestrator（历史声明 276/276）**：完整渲染集成验证需要 FFmpeg、FFprobe 与 Chromium 均可执行且版本兼容。缺少其中任一工具时，该批次记录为 **242 pass / 22 fail / 12 skip**；22 项按依赖分为 FFmpeg 9、FFprobe 9、Chromium 4；12 项是显式 FFmpeg 依赖门控跳过（11 个音频渲染用例 + 1 个媒体检查用例），逐条测试名见 `VALIDATION-R7.8.1.txt`。这些不是 schema / compact 改动引起的回归。不得将此结果写成 276 项全部通过。
- **Atomstudy（历史声明 106/106）**：目标 profile 的独立实测记录为 **93 pass / 4 fail**；失败项必须保留并单独定位，不能用旧版汇总数字覆盖。当前隔离沙箱运行 `tools/selfcheck.sh` 的实际输出另见下方补丁复测记录。
- **AIPJ Preset（历史声明 37/37）**：目标 profile 的独立实测记录为 **44 项：39 pass / 3 fail / 2 skip**；3 项失败依赖目标 profile 已安装，2 项为环境跳过。未安装 profile 时不得宣称完整宿主验收通过。当前隔离沙箱 `verify.sh` 的实际输出另见下方补丁复测记录。
- **Standalone Audio Engine（历史声明 11/11）**：缺少 FFmpeg 的环境记录为 **10 pass / 1 skip**；跳过项不能计入通过。当前沙箱存在 FFmpeg，因此本轮实际运行结果为 11 pass / 0 skip。

以上数字用于解释既有记录与当前口径的差异；每次发布仍应附上该次运行的原始 stdout、工具探测结果和环境说明。没有实际运行的宿主 `assertSupportedJsonSchema`、真实 DSH profile 安装或浏览器 E2E 检查必须明确标为未执行。

### R7.8.1 Cordis schema / package compatibility patch

R7.8.1 keeps the default `toolSurface: "full"` registration surface unchanged (148 Creative tools). The optional `compact` surface registers eight common tools plus `creative_catalog_search` and `creative_tool_describe`; the latter can register an additional catalogued tool on demand. Parameter schemas use only the `dsh-tools` supported keyword subset. Former numeric/collection limits are retained in property descriptions and enforced by the tool execution wrapper; SVG Motion and Atomstudy retain their own runtime value checks. Four plugin packages declare the DSH compatibility range `>=0.2.2-rc.1 <0.3.0`; SVG Motion, Atomstudy and AIPJ declare host packages as peer dependencies. See `PATCH-R7.8.1.md` and `VALIDATION-R7.8.1.txt`.

R7.8.1 validation note: this sandbox had FFmpeg, FFprobe and Chromium available, so the Creative suite actually ran **276 pass / 0 fail / 0 skip**; the audio engine ran **11 pass / 0 fail / 0 skip**. Atomstudy selfcheck actually ran **106 pass / 0 fail**. AIPJ `verify.sh` actually reported **37 pass / 0 fail**, with three environment skips (target profile absent, install-copy check skipped, and `dsh web` unavailable on port 3081). These local outputs differ from the separate target-profile records described above (Atomstudy 93/4; AIPJ 39/3/2; audio 10/1 when FFmpeg is absent). Do not merge those environment-specific records into one aggregate or present a skipped host check as passed.


## R7.8.2 — Non-destructive color grading & shot matching

R7.8.2 extends the R7.8 editing foundation with a validated per-clip grade model (exposure, master/RGB curves, temperature/tint, contrast, saturation and gamma), 3D `.cube` LUT inspection with SHA-256 identity, FFmpeg preview-frame and H.264 render paths that share the same canonical grade graph, and a review-only sampled-luma/saturation shot-match suggestion. Clip grade metadata is stored in the revisioned video timeline and frame EDL, so it participates in undo/redo without rewriting source media. A `color-match-grade` workflow adds explicit preview/review/render gates. It adds six Creative tools, one Node built-in-only module, and no model/provider or npm dependency. The match suggestion is a heuristic—not a color-science or skin-tone matcher—and the whole multi-track EDL renderer does not yet consume per-clip grades automatically. See `RELEASE-R7.8.2.md`, `VALIDATION-R7.8.2.txt`, and `docs/ROUND7.8.2-COLOR-GRADING.md`.


## Round 7 R7.8.3 — Executed subtitle burn-in

R7.8.3 adds a real, media-root-guarded SRT/WebVTT burn-in render path using the installed FFmpeg libass filter. Timed cues and safe-area settings are validated against the probed source duration; ASS style fields are normalized through a strict allowlist; caption text is sanitized and staged in a private generated temp directory; the output is locked, rendered to a sibling temporary file, checked by FFprobe, and atomically published with SHA-256 evidence. The old plan-only tool remains available. Workflow task compilation classifies the render as a filesystem side effect with an always-required approval gate. No model/provider or npm dependency was added. See `RELEASE-R7.8.3.md`, `VALIDATION-R7.8.3.txt`, and `docs/ROUND7.8.3-SUBTITLE-BURNIN.md`.


## R7.8.4 — Task-driven art direction and visual preset workbench

R7.8.4 builds on the verified R7.8.3 archive and strengthens the existing SVG Motion capability rather than adding model providers. It adds a deterministic `svg_motion_art_direction` tool that classifies visual tasks into eight families, returns subject/composition/background/palette/typography/material/motion/sound guidance, and creates stable `art-direction:*` checkpoints with evidence and gate criteria. The toolchain is conditional: storyboard is recommended only for longer/multi-shot motion, prompts only when assets are needed, transitions only when adjacent shots require continuity, and visual scoring only after an actual preview/render exists. The checkpoint payload is a generic persistence/mapping contract; no Kilo runtime or external checkpoint service is claimed as connected.

The SVG Motion settings page now renders 20 selectable local-SVG style thumbnails and exposes the preset's actual palette, typography, layout, motion, post and transition parameters. The thumbnails are structural previews, not generated source artwork. The aesthetic skill now includes an eight-step task decision tree, task-family guidance, preset selection rules, tool invocation conditions and fail-back checkpoint rules. Automatic media inference was refined so static character art does not acquire motion gates while auto-detected long explainer videos receive storyboard guidance. One additional SVG Motion tool is registered (13 total within that plugin); the Creative Orchestrator inventory remains 155. No model provider, external generation service, or npm dependency was added.

See `RELEASE-R7.8.4.md`, `VALIDATION-R7.8.4.txt`, `TOOL-NAMES-R7.8.4.txt`, and `docs/ROUND7.8.4-ART-DIRECTION.md`.


## R7.8.6 — 多轨时间线修剪与波纹插入

R7.8.6 在 R7.8.5 基础上补齐视频片段左右边缘修剪、关键帧边界重映射、转场时长保护和全轨道波纹插入。波纹插入会对跨越插入点的片段进行确定性分割，并将右侧内容整体后移；锁定轨道将 fail-closed。时间线重叠验证改为滚动最大结束时间检测，避免长片段被短片段遮挡后漏报。新增 `creative_video_clip_trim` 与 `creative_video_timeline_ripple_insert`，Orchestrator 版本升至 2.0.4。详见 `RELEASE-R7.8.6.md`、`docs/ROUND7.8.6-TIMELINE-TRIM-RIPPLE.md`。

## R7.8.7 — Speed Curve Timeline Engine

Added deterministic piecewise-linear speed envelopes, integrated timeline-to-source mapping, speed-aware split/trim/ripple preservation, and the revision-guarded `creative_video_clip_speed_curve` operation. See `RELEASE-R7.8.7.md`, `docs/ROUND7.8.7-SPEED-CURVE-ENGINE.md`, and `VALIDATION-R7.8.7.txt`. The EDL exposes speed-map semantics, but the FFmpeg segment renderer does not yet apply speed ramps; no rendered-ramp parity is claimed.


## R7.9.0 — Unified final timeline export

The multi-track video timeline renderer can now optionally consume an independent validated audio-edit project, burn in an explicitly bound subtitle file, and apply a `.cube` LUT whose SHA-256 matches the clip's stored grade metadata. Audio is rendered through the existing audio-project engine to a temporary WAV and muxed with the video; the final MP4 is probed for video dimensions, exact frame count, and the requested audio stream before publication. Subtitle and LUT paths must resolve inside configured `mediaRoots`. The original media and project inputs remain unchanged.

Native wipe-left/right transitions are now compiled as per-frame alpha masks in the final timeline renderer. Direct volume keyframes on video clips and a single shared interactive-preview/final-render graph remain explicitly unsupported; preview/final parity is not claimed.


## R7.9.1 — Native wipe transition rendering

R7.9.1 extends the R7.9.0 unified final timeline renderer with native `wipe-left` and `wipe-right` alpha-mask transitions for clip in/out boundaries. The wipe mask is evaluated per frame in FFmpeg and composes multiplicatively with the clip's existing alpha; it does not substitute a fade. Both directions are exercised across both transition-in and transition-out paths in a real FFmpeg export test. The existing R7.9.0 audio-project mixdown, subtitle burn-in, SHA-256-bound LUT verification, output probe and atomic publication remain intact. Direct volume keyframes on video clips and one shared interactive-preview/final-render graph remain out of scope.


### R7.9.2 — Embedded clip-audio automation

The native video timeline renderer now applies `volume` keyframes to the embedded audio stream of video/overlay clips. Automation is evaluated in clip-local output time and remains synchronized with piecewise-linear clip speed changes through segmented `atempo` processing. Keyframe gain is bounded to 0–4 linear gain. Clips with volume keyframes but no bound audio stream fail explicitly. When requested, clip audio is mixed with the independent audio project in the same final mux; subtitles, LUT verification, output frame checks and atomic publication remain in the existing render path.

The `creative_video_timeline_preview` tool reuses the final render pipeline and trims the result on frame boundaries, avoiding a second independently maintained preview filter graph. It is deliberately slower than proxy-only preview because parity is prioritized.

### R7.9.3 — 代理预览、导演生产包与 QA 修复闭环

R7.9.3 将此前的全时间线预览扩展为可显式传入代理素材映射的 `creative_video_timeline_preview`：通过 `proxyAssetPaths` 使用与原素材相同 `assetId` 的代理文件，降低解码负载；仍走最终渲染编译器，保持转场、调色/LUT、字幕与音频处理一致。当前预览仍需渲染完整时间线后按帧裁切，因此是代理辅助的精确区间预览，不是交互式实时播放。

新增 `creative_video_proxy_set`，一次最多生成四种 360p/540p/720p/1080p H.264 代理；保持比例、保留可用音轨、输出逐个 FFprobe/SHA-256 核验。代理转码改为同目录临时文件验证后原子发布；多代理任务失败时回滚本次已发布的代理，且不覆盖既有文件。

新增 `creative_media_quality_report`，组合真实 FFprobe、黑帧/冻结检测、亮度/饱和度采样、场景候选、音频 LUFS/真峰和安全检查；报告明确列出 OCR 字幕碰撞、语义视觉审查、音画同步等未执行项目。`creative_quality_repair_plan` 将问题映射为建议，`creative_quality_repair_tasks_create` 可把建议转为持久化逐步审批任务；不会自动执行修复或越过审批。

导演闭环新增素材元数据候选匹配、逐镜生产包，以及从项目已关联素材库生成生产包的 `creative_project_director_packet`。候选基于可解释的元数据词项重合，不假称已观看素材；素材绑定、许可确认、首镜样片审批仍需人工完成。

新增 `media.asset`、`video.storyboard`、`render.job`、`quality.report` 四类版本化跨插件数据契约及 `creative_ecosystem_handoff_validate`。契约校验不代表 DrawAI、llc-pv-skill 或其他插件已安装/在线；外部调用仍需显式适配器和宿主授权。
