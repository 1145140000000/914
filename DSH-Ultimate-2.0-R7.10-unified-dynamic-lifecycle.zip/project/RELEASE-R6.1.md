# DSH Ultimate 2.0 — Round 6 R6.1 Audio Reliability & Stem Delivery

R6.1 builds on the R6.0 audio workstation consolidation and closes the most important persistence race while adding a practical multi-track delivery path.

## Delivered

- `store.updateRecord()` adds a cross-process locked read/modify/write transaction for persisted records.
- `creative_audio_project_edit` now performs edit, history snapshot, undo and redo inside that transaction. Concurrent edits no longer rely on a stale read followed by a separate write.
- `creative_audio_stems_export` batch-exports 1–64 selected tracks with unique output-path validation and per-track success/failure reporting.
- The standalone CommonJS `engine/dsh-audio-engine` package is included in the source archive as a companion/reference package. It remains independently testable and is not falsely described as imported into the Cordis plugin; the canonical plugin audio path remains `dsh-creative-orchestrator`.

## Verification

- `dsh-creative-orchestrator`: **146/146 tests passed**.
- Standalone audio engine: **11/11 tests passed**, including real FFmpeg integration.
- SVG Motion selfcheck: **4/4 test files passed**, plus plan-shots and role lint checks.
- Atomstudy selfcheck: **106/106 checks passed**, including syntax, analysis, WebUI, credential/tunnel and assembly checks.
- Audio renderer integration covers all eight effect processors using real FFmpeg; range preview, source-path boundaries, symlink output rejection and atomic overwrite behavior are tested.
- The R6.1 archive is checked with `unzip -t`; the detached SHA-256 checksum is verified after packaging.

## Still requires the actual DSH host

This source release does not claim a complete browser DAW surface, waveform interaction widgets or real-time audio-device transport. Those require the host's supported client/media bridge and device lifecycle contracts. The implemented preview remains an offline FFmpeg render. No guessed host API or fake real-time playback is included.

Source audio remains non-destructive; exports are confined to configured `mediaRoots` and are atomically published.
