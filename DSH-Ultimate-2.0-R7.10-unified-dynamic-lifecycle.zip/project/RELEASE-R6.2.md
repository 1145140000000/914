# DSH Ultimate 2.0 — Round 6 R6.2 Portable Projects & Lock Recovery

R6.2 extends the R6.1 workstation reliability baseline with portable project documents and safer stale-lock recovery.

## Delivered

- Added `creative_audio_project_document_export`: emits a bounded (8 MiB) JSON project document with SHA-256 integrity metadata. Audio sources remain path references and are not embedded.
- Added `creative_audio_project_document_import`: verifies document format/version, byte limit, digest and project invariants, then imports under a fresh project ID. Edit history is reset for the new identity; existing projects are never overwritten.
- Added store-level `createRecord()` for cross-process locked create-only persistence. Audio project creation and document import use this path.
- Hardened stale lock recovery: an old lock is no longer reclaimed while its recorded owner PID is still alive, protecting long synchronous operations and delayed event-loop heartbeats. Dead owners remain recoverable after the stale threshold.
- Added optional `createStore(root, { lockTimeoutMs, lockStaleMs })` tuning for controlled deployments and deterministic lock tests; defaults remain 15 s and 120 s.

## Verification

- `dsh-creative-orchestrator`: **152/152 tests passed**.
- Standalone `engine/dsh-audio-engine`: **11/11 tests passed**, including real FFmpeg rendering.
- `dsh-svg-motion` selfcheck: **4/4 test files passed**, plus syntax, profile, plan-shots and role-lint checks.
- `dsh-atomstudy` selfcheck: **106/106 checks passed**, including syntax, analysis, WebUI, credential/tunnel and assembly checks.
- Root `SHA256SUMS.txt`: every listed source/document checksum verified.
- New tests cover document round-trip, tampering, unsupported format/version, oversized documents, unsafe IDs, create-only persistence, live-owner lock protection and dead-owner lock recovery.
- Existing real FFmpeg tests still cover the full eight-effect matrix, multi-clip rendering, automation, offline range preview, full-duration Stem output and media-root boundaries.
- The archive is checked with `unzip -t`; detached SHA-256 is verified after packaging.

## Important boundaries

- Project documents do not contain audio bytes. They preserve local source path references; those files must exist and be reachable under configured `mediaRoots` on the importing machine.
- Import does not rewrite source paths or copy media. A future media-bundle workflow must explicitly implement safe collection, collision handling and size limits.
- This still does not claim a full browser DAW, waveform UI or real-time audio-device transport. Those require the actual DSH host client/media bridge and device lifecycle contracts. Preview is an offline FFmpeg render.
- The independent `engine/dsh-audio-engine` remains a separately tested companion/reference package; the canonical Cordis implementation is `dsh-creative-orchestrator`.
