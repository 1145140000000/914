# DSH Ultimate 2.0 — R6.4 Audio Loudness Mastering

R6.4 builds on R6.3 and adds optional LUFS loudness normalization to final audio project export.

## Added
- Optional FFmpeg `loudnorm` single-pass dynamic normalization.
- Configurable integrated loudness, true-peak ceiling and loudness range targets.
- Export result reports the selected target and explicitly identifies the mode as `single-pass-dynamic`.
- Bounds validation happens before rendering; source files remain untouched.

## Defaults
- Integrated loudness: -16 LUFS
- True peak: -1.5 dBTP
- Loudness range: 11 LU

## Important limitation
This is single-pass dynamic loudness normalization, not two-pass linear mastering. For strict broadcast/music delivery specifications, measure the rendered result and use a separately verified two-pass mastering workflow where required.

## Verification
- Real FFmpeg render and post-render loudness measurement.
- Invalid target rejection before FFmpeg execution.
- Full project test suite recorded in the release handoff.

## Test results
- Creative Orchestrator: 158/158 passed.
- Standalone audio engine: 11/11 passed.
- SVG Motion: 4/4 passed.
- Atomstudy selfcheck: 106/106 passed (including syntax and static contract checks; runtime host dependency checks are explicitly skipped where the host package is unavailable).
- Package SHA-256 manifest: 699/699 files verified.
- ZIP archive integrity and external SHA-256 verification: passed.
