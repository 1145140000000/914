# DSH Ultimate 2.0 — R6.5 Audio Safety Gates

R6.5 adds a read-only audio safety inspection tool alongside the existing LUFS measurement.

## Added
- `creative_audio_safety_inspect`: reports overall peak/RMS level, DC offset, flat factor and sample count from FFmpeg `astats`.
- Detects configurable silence intervals with `silencedetect`, including trailing silence when FFprobe duration is available.
- Emits bounded warnings for low peak headroom, DC offset and silence.
- Exposes `./audio-quality` as a package subpath.
- Preserves mediaRoots path confinement and source immutability.

## Important interpretation limits
- Peak near 0 dBFS is a headroom warning, not proof of clipping.
- Silence detection depends on the configured threshold and minimum duration; intentional pauses may be reported.
- This is a technical preflight report, not subjective listening, codec compliance or mastering certification.
- LUFS/true-peak measurement remains a separate tool.

## Verification
- Creative Orchestrator: 161/161 passed.
- Real FFmpeg synthetic-signal safety inspection passed.
- Path traversal/outside-mediaRoots rejection passed.
- Standalone audio engine, SVG Motion and Atomstudy checks are reported separately in the final release handoff.
