# DSH Ultimate 2.0 — R6.6 Bus / Aux Send & Return

R6.6 extends the non-destructive audio project model with optional `buses` and per-track routing while retaining schema version 1. Existing projects without `buses`, `outputBusId`, or `sends` remain readable and render as before.

## Delivered

- Add, update and remove auxiliary buses through `creative_audio_project_edit` (`add-bus`, `update-bus`, `remove-bus`).
- Route a track's direct output to a bus, or leave `outputBusId: null` to feed the master directly (`track-routing`).
- Add up to 8 unique post-fader/post-track-effects sends per track. Sends duplicate the processed track signal and feed an auxiliary bus; they do not replace the direct output.
- Bus gain, pan, mute and ordered effect rack are applied before the bus joins the master mix.
- Bus IDs, track output references, send references, gain bounds and effect-rack limits are validated. Removing a bus atomically clears all track references to it.
- Bus and routing edits are immutable project revisions and participate in existing persistence and undo/redo history.
- Real FFmpeg integration test exercises direct bus routing plus a separate Aux Return send.

## Explicit limits

- Bus-to-bus routing is intentionally not supported; this prevents feedback/cyclic routing graphs.
- Sends are post-fader only in this release. Pre-fader sends and per-send mute/automation are not claimed.
- This is offline FFmpeg rendering, not real-time monitoring or hardware transport. The browser DAW surface still depends on a supported DSH host media/client bridge.

## Validation

See the R6.6 test summary in the release package. FFmpeg-backed tests are skipped only when FFmpeg is unavailable.

- Orchestrator suite: 166/166 passed (including real FFmpeg bus/Aux integration and portable-document round trip).
- Standalone audio engine: 11/11 passed.
- SVG Motion selfcheck: 4/4 passed.
- Atomstudy selfcheck: 106/106 passed. Host-only `@deepseek-ai/schemastery` runtime integration is unavailable in this isolated environment; static and source-level checks passed.
- The full DSH host installation, browser UI, live device playback and hardware monitoring have not been claimed as tested.
