# DSH Ultimate 2.0 — R6.7 Audio Transport State & Clock Contract

R6.7 adds a persistent transport state machine for the existing non-destructive audio project model. It provides a deterministic control-plane contract for a DSH client/media bridge without claiming that a Node tool can itself emit live audio or drive a hardware device.

## Delivered

- `creative_audio_transport_create`: create a transport session bound to an existing audio project and persist it in a dedicated `audio-transports` store area.
- `creative_audio_transport_command`: `play`, `pause`, `stop`, `seek`, `set-loop`, `clear-loop`, and `tick` transitions, serialized through the store's cross-process update lock.
- `creative_audio_transport_get`: read transport state and calculate the current playhead from a caller-supplied monotonic millisecond clock.
- Playhead positions are quantized to the project sample rate. Loop ranges are validated and wrap deterministically; seek targets outside an active loop are moved to its start.
- Natural end-of-project stops the transport at the project duration. Resume, stop-reset, and loop boundaries are covered by tests.
- Store directory follows the existing private-directory permissions and atomic JSON persistence behavior.

## Clock and host boundary

- The caller/host supplies `nowMs` from a monotonic clock. The module does not use wall-clock time to advance audio, start background timers, or schedule browser frames.
- These tools manage transport state only. They do not decode/stream PCM, create an AudioContext, access an audio device, or provide live monitoring.
- A real-time client bridge must consume the transport contract and provide its own monotonic clock, audio buffer scheduling, device lifecycle, and underrun handling. This is not verified without the DSH host media/client bridge.
- Offline FFmpeg preview/export remains unchanged and is not represented as real-time playback.

## Validation

- Creative Orchestrator: 171/171 tests passed, including tool-level persistence, play/pause/seek/loop integration and existing real FFmpeg render tests.
- The suite verifies state transitions and persistence, not live audio output or device latency.
