# DSH Ultimate 2.0 — R6.8 Multi-resolution Waveform Data & Cache

R6.8 adds the waveform data layer needed by a future audio timeline. It deliberately stops at verified PCM analysis and cached peak data; no browser UI or live audio playback is implied.

## Delivered

- `creative_audio_waveform_generate` decodes audio through FFmpeg to 11.025 kHz float PCM and builds a multi-resolution pyramid. Level 0 uses 256-sample buckets; each following level groups four adjacent buckets.
- Each bucket is computed independently per channel and contains `min`, `max`, `rms`, and `sampleCount`. Mono and stereo sources are supported; sources with more than two channels are rejected rather than silently downmixed.
- `creative_audio_waveform_read` supports level selection and bounded pagination (1–4096 buckets per call), returning offsets and `nextOffset` for incremental UI reads.
- Source files are canonicalized and confined to configured `mediaRoots`. Cache identity includes version, canonical path, file size, mtime, device/inode, analysis sample rate and base bucket size. A changed source produces a new cache key; identity is rechecked after decoding to avoid caching a source modified mid-analysis.
- Cache entries are JSON, SHA-256 named, atomically replaced, and stored under the private DSH data root with 0700 directory / 0600 file permissions. A 24 MiB cache-entry cap prevents unbounded cache writes.
- Maximum source duration is 30 minutes. The source is never modified.

## Host and UI boundary

- This release provides data and cache APIs only. A browser timeline still needs a DSH client integration to request pages, draw the min/max envelope, map zoom levels to pyramid levels, and synchronize selection/seek with the transport contract.
- No waveform UI, AudioContext, sound-device access, PCM streaming, or real-time monitoring is claimed.
- FFmpeg and FFprobe must be installed and configured/available to the plugin process.

## Validation

- Added real FFmpeg decode tests for stereo channel separation, min/max/RMS invariants, multi-level generation, cache hits, paginated reads, source-change invalidation, and media-root path rejection.
- Full plugin and cross-plugin regression results are recorded in the delivery summary accompanying this release archive.
