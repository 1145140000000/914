# DSH Ultimate 2.0 — Round 6 R6.9 Video Render Pipeline

R6.9 restores the video plugin as the primary delivery path. Audio remains an integrated post-production subsystem; it is not the product's center of gravity.

## Delivered

- Added `creative_video_render_pipeline`: one operation now validates a registered video renderer, creates or resumes a deterministic frame-range manifest, renders MP4 segments, verifies each segment through the render executor's real SHA-256 receipts, and finalizes the ordered segments into one H.264 MP4.
- Optional `audioPath` muxes an existing audio mix into the final video; alternatively `audioProjectId` renders a saved non-destructive audio project to a temporary mix and automatically cleans it up after muxing. Audio inputs and final output remain constrained to configured `mediaRoots`; intermediate render segments and manifests remain under the private orchestrator data root.
- Resume is bound to renderer ID, project content hash, frame rate, duration and segment size. A mismatched manifest is rejected rather than silently reused.
- Existing output files are protected by default. Replacing a final video requires explicit `overwrite=true`.
- SVG-native is intentionally rejected by this MP4 pipeline because it emits SVG documents, not MP4 segments. Use `chromium-webgl` or `threejs-webgl` for video output.
- Added a final-output receipt to the manifest: path, SHA-256, byte size, frame count, duration and audio-mux status.

## Validation

- Creative Orchestrator: 178/178 tests passed.
- Real Chromium + FFmpeg + FFprobe smoke render: two 160×90 frames at 5 fps, two independently rendered MP4 segments, final 2-frame H.264 MP4, 0.4 s duration, output hash verified.
- The smoke render used a deterministic self-contained HTML `window.renderAt(t)` scene. It does not claim a production Three.js bundle, target DSH host installation or hardware-GPU identity.

## Boundaries

This release adds an executable video production path, not a visual editor UI. Timeline UI, live browser editing and real host-side media integration still require supported DSH client/media bridge contracts. The pipeline does not execute untrusted workflow code or fetch external assets.
