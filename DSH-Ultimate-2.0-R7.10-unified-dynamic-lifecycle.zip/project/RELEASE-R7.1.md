# DSH Ultimate 2.0 — R7.1 Companion integrations

R7.1 connects DrawAI and LLC PV skill as optional companion providers without merging their code into the orchestrator.

- Added `lib/external-integrations.js` with explicit DrawAI tool contracts and LLC PV skill / local capability contracts.
- Added `creative_companion_integrations_catalog` and `creative_companion_integrations_check`.
- Added `drawai-motion-production`, `llc-pv-high-fidelity`, and `hybrid-pv-drawai` workflows.
- Extended custom workflow schema with `skill` steps, integration providers and tool input bindings.
- Durable workflow task steps preserve external tool/skill capabilities and classify write/network effects for approval.
- DrawAI native project format and async render lifecycle are preserved; LLC PV remains a skill with optional independently verified AE MCP / L2D capabilities.

Validation: see `docs/ROUND7.1-COMPANION-INTEGRATIONS.md`. Companion installation and target-host E2E remain environment-specific and are not claimed by unit tests.

## Validation

- Creative Orchestrator: 198/198 tests passed.
- SVG Motion: 4/4 tests passed; selfcheck and planner/role lint passed.
- Atomstudy: S4 selfcheck 106 pass / 0 fail.
- AI-PJ preset verification: 37 pass / 0 fail. The verification script reported that no target profile was present and `dsh web` was not responding on port 3081, so installed-copy and live-host checks were skipped.
- All Orchestrator `.js` / `.mjs` files passed `node --check`.
- No third-party runtime dependency was added.

The above validates the source package and its tests, not installation of DrawAI or LLC PV skill in the user's target DSH profile. Companion end-to-end execution remains dependent on the user's host-visible tools, skill directory, local dependencies and explicit Worker dispatch adapter.
