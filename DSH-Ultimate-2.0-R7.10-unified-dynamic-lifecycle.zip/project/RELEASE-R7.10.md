# DSH Ultimate 2.0 — R7.10 统一动态配置与生命周期发行版

## 版本定位

在 R7.9.9 动态配置专项重构的基础上，R7.10 将四个插件包（`dsh-aipj-preset`、`dsh-atomstudy`、`dsh-svg-motion`、`dsh-creative-orchestrator`）与设置桥（`bridge.js`）、渲染器及工具面统一到同一套动态配置与生命周期模型下，形成单一可发布基线。

## R7.10 增量优化

1. **结构化深比较防抖**（`lib/dynamic-config.js` 及四插件同步副本）：`diffKeys` 采用 `deepEqual` 替代 `Object.is`，避免 `mediaRoots` 等数组/对象字段在 `.volatile().get()` 返回新引用但内容未变时触发无效版本递增与监听器重算。
2. **设置桥与动态配置即时同步**（`dsh-aipj-preset/bridge.js`、`dsh-atomstudy/bridge.js`、`dsh-svg-motion/bridge.js`）：`create*Bridge(settings, { onMutated })` 在 `settings.mutate` 成功后立即把变更补丁同步到 `dynamicConfig`，即使宿主延迟或未发出 `loader/volatile-update` 也能即时生效。
3. **编排器幂等激活与热扩展**（`dsh-creative-orchestrator/index.js`）：
   - 通过 `WeakMap` 保证同一 `ctx` 上重复 `apply()` 幂等返回已有实例，不重复初始化 `store`/`dispatcher`/`tools`。
   - 支持 `toolSurface` 从 `compact` 热切换至 `full` 时动态补齐注册剩余工具。
   - 支持 `chromiumPath` / `ffmpegPath` 更新时热刷新 `rendererRegistry` 中的渲染适配器。
4. **新增自动化测试**：
   - `dsh-creative-orchestrator/tests/dynamic-config-lifecycle.test.mjs`：扩充至 10 项（新增数组深比较防抖、编排器幂等 `apply` 与 `compact -> full` 热扩展）。
   - `tests/simulated-host-plugins.test.mjs`：扩充至 4 项（新增设置桥 `mutate` 无事件直通同步测试）。

## 交付清单

- 统一源码树（含四插件自包含 `dynamic-config.js`）
- `RELEASE-R7.10.md`
- `VALIDATION-R7.10.txt`
- `SHA256SUMS-R7.10.txt`
- `DSH-Ultimate-2.0-R7.10-unified-dynamic-lifecycle.zip`
