# DSH Ultimate 2.0 — R7.4

R7.4 expands the production system from task/workflow tracking into project-level production operations.

## Added

- Dedicated durable project registry with revisions, content hashes, immutable snapshots and optimistic concurrency.
- Project-to-task links and safe project version restoration.
- Asset provenance records and project lineage links with source asset IDs, rights/license metadata and optional SHA-256.
- Asset lineage audit for missing source references, missing hashes, duplicate content hashes and cycles.
- Durable render-job records bound to a specific project revision, with legal state transitions, monotonic frame progress, checkpoints, output receipts and explicit retry attempts. `creative_video_render_pipeline` can bind a `renderJobId` and automatically report segment events/progress/final output; checkpointed renders resume through the existing verified segment manifest, with the job pinned to the original outputName and outputPath.
- Capability-aware Worker pool routing: Workers can declare exact capabilities and atomically claim only tasks whose unfinished steps fit their scope, while sharing the same durable queue.
- Task event replay with cursor and retention/truncation metadata.
- Dependency-free Production Studio HTML dashboard with responsive layout, glass UI, restrained motion, task/phase/project/render views and read-only host bridge contract.

## New tools

- `creative_task_replay`
- `creative_project_create`, `creative_project_list`, `creative_project_get`, `creative_project_update`
- `creative_project_restore_version`, `creative_project_task_link`
- `creative_project_asset_link`, `creative_project_assets`, `creative_project_asset_audit`
- `creative_render_job_create`, `creative_render_job_update`, `creative_render_job_list`

The orchestrator now registers 98 public tools.

## Safety and compatibility

- No third-party runtime dependencies were added.
- Store namespaces are additive: `projects/` and `render-jobs/`; prior task, workflow, audio-project and asset records remain readable.
- Project updates require `expectedRevision`; stale writes fail rather than silently overwrite.
- Render jobs require explicit lifecycle updates and do not auto-start a renderer.
- Asset registration stores metadata only; it does not copy or modify media files.
- UI uses a documented injected bridge and never guesses host APIs. It is read-only by design.
- External DrawAI / LLC PV execution continues to require explicitly registered adapters.

See `docs/ROUND7.4-PROJECT-ASSETS-RENDER-OBSERVABILITY-AND-UI.md` and `ui/README.md`.
