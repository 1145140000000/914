# DSH Ultimate 2.0 — R7.5 Ecosystem & Production Reliability

R7.5 extends R7.4 without modifying the R7.4 release artifact. The core Cordis plugin remains Node-builtins-only; optional programs and services are discovered or connected through explicit adapters rather than bundled into the plugin.

## Delivered

### Optional external runtime discovery
- Local runtime catalog: FFmpeg, FFprobe, Chromium, Python, Blender, ImageMagick, SoX, Rubber Band, yt-dlp, Whisper, eSpeak NG and active Node runtime.
- Bounded executable probes use `shell:false`, timeout limits and capped output. Results distinguish `available`, `not-installed`, `timeout`, `unavailable` and `error`.
- Probes run version/help commands only. They do not install software, download models, make network requests or read credentials.

### External service ecosystem
- Catalog: ComfyUI, Ollama, OpenAI-compatible APIs, Stable Diffusion WebUI, speech services, DaVinci Resolve, After Effects, Audacity, Blender, Hugging Face and GitHub.
- Endpoint syntax validation rejects unsupported schemes and embedded credentials. It is not a connectivity check; real connections require explicit provider adapters and host-side secrets.

### Project collaboration and asset versioning
- Project-to-project dependencies are revisioned and checked for missing nodes, self-dependencies and cycles.
- Project activity feed combines project, linked task and render-job events.
- Dependency analysis returns topological order and a critical path only when every project has an explicit `metadata.estimatedWorkSec`; missing durations remain unknown.
- Task linking now changes the project revision and immutable snapshot.
- Assets retain immutable version history; project links pin a specific `versionId`, so branching a new asset version does not silently change older project references.

### Render resource scheduling
- Renderer resources declare capabilities and explicit concurrency capacity; no hardware capacity is guessed.
- Durable render leases support fair oldest-first job claims, worker ownership, heartbeats, release and stale-lease recovery.
- The video pipeline can consume a claimed lease and releases it after completion/failure. Rendering itself remains the responsibility of the registered Renderer adapter.
- Stale running jobs are marked failed for explicit review/requeue; they are not silently rerun.

### Visual quality and release gates
- Completed render jobs can receive structured technical evidence evaluated by the existing visual-quality rules.
- Failed or incomplete evidence blocks release. A `review` verdict requires a human reviewer note; a passing verdict still requires explicit release approval.
- Evidence is hashed and attached to the Render Job event history. This verifies the submitted evidence record, not that a model or human actually watched the footage.

## New public tools

- `creative_external_runtime_catalog`
- `creative_external_runtime_probe`
- `creative_external_service_catalog`
- `creative_external_service_endpoint_validate`
- `creative_project_dependencies_set`
- `creative_project_activity`
- `creative_project_dependency_analyze`
- `creative_project_asset_version_branch`
- `creative_render_resource_register`
- `creative_render_job_claim`
- `creative_render_job_heartbeat`
- `creative_render_job_lease_release`
- `creative_render_lease_recover`
- `creative_render_scheduler_status`
- `creative_render_quality_evaluate`
- `creative_render_release_approve`

The orchestrator registers **114 public tools** in the isolated Cordis test harness.

## Validation
- Creative Orchestrator suite: 241 tests passed, 0 failed.
- SVG Motion: 4 tests passed; selfcheck passed with host-dependent checks explicitly skipped where the host package/profile was unavailable.
- Atomstudy: 106 selfcheck assertions passed.
- Standalone audio engine: 11 tests passed, including real FFmpeg WAV rendering.
- Live DSH host integration, external service authentication and target-profile installation remain deployment checks; catalog entries are not represented as connected services.

## Dependency policy

Do not add large libraries to the core plugin merely to increase archive size. Keep the core dependency-free, expose optional external runtimes and adapters, and install only the tools required by a selected workflow. This keeps the base package portable while greatly expanding its effective capability surface.
