# DSH Ultimate 2.0 — R7.6 Provider Connectivity

## What changed

- Added `lib/external-providers.js`, a zero-third-party-dependency HTTP client using Node's built-in `fetch`.
- Added real Ollama model discovery (`/api/tags`) and non-streaming chat (`/api/chat`).
- Added ComfyUI workflow submission (`/prompt`) and prompt history lookup (`/history/{prompt_id}`).
- Added four public tools: `creative_ollama_models`, `creative_ollama_chat`, `creative_comfyui_submit`, `creative_comfyui_history`.
- Exposed `externalProviders` and `registerExternalSecretProvider` from `apply()` for explicit integration by host-owned secret storage.
- Added OpenAI-compatible chat support through the client API. It accepts a secret reference, never a raw key, and only retrieves the credential through a caller-registered secret provider.
- Added endpoint restrictions: localhost by default, explicit remote opt-in, no embedded credentials/query/fragment, no redirects, bounded response size and request timeout.
- Exported `./external-providers` from the orchestrator package.

## Behavior and safety boundaries

- Local Ollama defaults to `http://127.0.0.1:11434`; ComfyUI defaults to `http://127.0.0.1:8188`.
- Remote access is disabled unless the caller explicitly sets `allowRemote: true`.
- ComfyUI submit starts a generation job and returns `promptId`; it does not claim that generation has completed or that output files have been imported.
- API credentials are not accepted as tool arguments or stored in plugin settings. OpenAI-compatible calls require `registerExternalSecretProvider()` to be supplied by an integrator that owns the secret store.
- No provider is automatically registered as a Worker adapter. Tool dispatch remains explicit through `registerToolAdapter`; this avoids silently granting external side effects.
- The core remains Node-builtins-only. External software/services are not bundled or auto-installed.

## Validation

- Orchestrator suite: 245 tests passed in the initial R7.6 full run; after adding apply-level assertions, rerun the full suite and record the final count in `VALIDATION-R7.6.txt`.
- Provider-specific tests cover Ollama, ComfyUI, remote opt-in, URL credential rejection and host-owned secret injection.
- Live Ollama/ComfyUI endpoints were not available in this build environment; adapter tests use deterministic mocked HTTP responses. Live service connectivity must be verified in the target DSH installation.
