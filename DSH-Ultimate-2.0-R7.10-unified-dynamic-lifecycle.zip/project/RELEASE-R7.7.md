# DSH Ultimate 2.0 — R7.7 Native Media Capabilities

## Release focus

R7.7 follows the user's direction to prioritize capability over additional model providers. No new model/provider integration is added in this round. The existing R7.6 external-provider code is retained unchanged as part of the baseline.

The orchestrator now exposes **130 public tools**, adding 12 media-production tools over R7.6. The new tools are native Node.js wrappers around optional FFmpeg/FFprobe executables; no third-party Node runtime dependency is introduced.

## New capabilities

- Probe audio/video/image container and stream metadata; frame counting is optional.
- Inventory authorized media folders with bounded traversal, symlink skipping and optional SHA-256 duplicate detection.
- Analyze sampled video luma/saturation and candidate luma jumps.
- Detect black-frame and freeze-frame intervals with duration ratios. If a freeze marker remains open at end-of-file, the report closes it against probed duration and labels the end as inferred.
- Detect scene-cut candidates and produce half-open shot intervals.
- Generate a contact sheet and extract an exact timestamp frame.
- Detect audio silence intervals.
- Perform two-pass EBU R128 loudness normalization and verify the output stream.
- Transcode to MP4/H.264, MP4/H.265 or WebM/VP9 with bounded quality and dimensions.
- Extract audio to WAV/FLAC/MP3 and extract an existing embedded subtitle stream to SRT.

Three built-in workflows compose the tools: `video-preflight`, `audio-mastering-chain`, and `media-proxy-transcode`. The video preflight includes black/freeze integrity evidence before luma/saturation analysis, scene candidates, contact sheet generation and human editorial review.

## Safety and execution semantics

- Inputs and outputs must resolve inside configured `mediaRoots`.
- Output parent directories must already exist. Existing outputs are not overwritten unless `overwrite=true`; output symlinks are rejected.
- Child processes use `spawn` with argument arrays and `shell:false`; execution time and captured output are bounded.
- File-writing workflow steps carry filesystem side-effect metadata and require explicit approval before execution.
- Creating a workflow task does not start a Worker. Worker creation and execution remain explicit.
- No media program is installed automatically. Deployments must provide FFmpeg/FFprobe and configure `mediaRoots`, `ffmpegPath` and `ffprobePath`.
- Signal, scene, black-frame and freeze-frame findings are technical candidates. They do not establish semantic scene boundaries, artistic intent, subtitle collisions or subjective visual quality.
- Subtitle extraction only extracts an existing embedded track. It does not perform speech recognition, translation or subtitle generation.

## Verification

See `VALIDATION-R7.7.txt` for the exact final test counts, binary versions and environment limitations. The orchestrator suite includes a real FFmpeg integration test that creates source video/audio and verifies media probing, sampled signal analysis, black/freeze detection, contact sheet, frame extraction, two-pass loudness normalization, transcode, audio extraction, subtitle extraction and library scanning.
