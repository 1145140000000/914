# DSH Ultimate 2.0 — R7.8.2

**主题：专业剪辑 / 非破坏性调色 / 参考镜头匹配**

## 基线与兼容范围

- 源码基线：R7.8.1 Cordis compatibility source tree（沿 R7.7 → R7.8 → R7.8.1 增量链延续）。R7.7、R7.8 和 R7.8.1 原始归档均保持不变。
- 本次只改动 `dsh-creative-orchestrator`、其测试与发布文档；SVG Motion、Atomstudy、AIPJ 和独立音频引擎源码未改。
- 没有新增模型、Provider、联网搜索服务、远程 API 或第三方 npm 依赖；不修改 DSH/Cordis 宿主源码。
- Orchestrator package version：2.0.1。

## 新增能力

1. **非破坏性片段调色**：时间线 clip 增加规范化 `colorGrade` 参数；支持曝光、master/RGB 曲线、色温、色调、对比度、饱和度和 gamma。参数参与 revision、编辑历史、undo/redo 与帧级 EDL。
2. **3D LUT 元数据与身份验证**：读取 mediaRoots 内 `.cube` LUT，校验 3D 尺寸、域范围、条目数、文件大小和 SHA-256；拒绝符号链接。持久化 grade 只存 LUT 身份，不保存可执行路径。
3. **真实预览与调色渲染**：单帧 PNG 预览和 H.264 MP4 输出由同一规范化 FFmpeg filter 模板编译；LUT 在私有临时目录中二次哈希确认。正式输出经 FFprobe 验证和 SHA-256 计算；同一目标有独占锁，临时文件失败不会破坏旧成片。异常中断留下的锁会 fail-closed，确认 PID 已退出后再人工清理。
4. **参考镜头匹配建议**：对两段真实视频做 FFmpeg signalstats 采样，按中位亮度与平均饱和度生成有界的初始建议；结果只读、带证据和人工复核提示。
5. **调色工作流**：新增 `color-match-grade`，按“匹配建议 → 预览 → 人工审查 → 正式渲染 → FFprobe 核验”编排；仍是 plan-only，文件写入步骤要求显式审批。
6. **导入数据边界修复**：轨道 `locked` / `muted` / `solo` / `allowOverlap` 必须为真实布尔值；不再把字符串 `"false"` 当成 `true`。
7. **工具目录计数修复**：compact 模式 `creative_catalog_search` 描述改为动态读取真实 full 工具数，不再硬编码 148。

## 新增工具（6）

- `creative_video_clip_color_grade`
- `creative_video_color_grade_validate`
- `creative_video_lut_inspect`
- `creative_video_color_grade_preview`
- `creative_video_color_grade_render`
- `creative_video_color_match_suggest`

Orchestrator full tool surface：148 → **154**。包含 SVG Motion、Atomstudy、AIPJ 的总工具名清单：**176 个，176 唯一**。默认 full 工具面没有删除旧工具；compact 仍是显式 opt-in。

## 验证

- Orchestrator 全量测试：**292 pass / 0 fail / 0 skip**（实际使用 FFmpeg 7.1.5、FFprobe 7.1.5）。
- 真实 FFmpeg 调色集成：合成视频 + `.cube` LUT，执行预览帧与 MP4 渲染，验证同一 canonical filter template、LUT SHA-256、H.264 输出和最终 SHA-256。
- SVG Motion：4/4 tests，selfcheck 通过。
- Atomstudy：selfcheck 106/106，通过；宿主 Schemastery 运行时导入按环境限制跳过。
- AIPJ Preset：37/37 通过；无目标 profile，安装登记、宿主 Schemastery apply、安装副本和 live `dsh web` 检查跳过。
- 独立音频引擎：11/11 通过，真实 FFmpeg 渲染用例执行。
- 全仓 JS/MJS/CJS 语法检查与 Production Studio inline script 检查结果见 `VALIDATION-R7.8.2.txt`。
- ZIP CRC、UTF-8 文件名标记、包内 SHA256SUMS 和外部 SHA-256 结果见验证报告。

## 明确限制

- clip grade 已进入 EDL，但现有 renderer-neutral 多轨合成路径还没有自动消费每个 clip 的 grade 并完成整片多轨合成；本轮真实执行的是单源视频调色预览/渲染。
- 镜头匹配只比较采样中位亮度和平均饱和度；不识别肤色、白平衡、色域/传递函数或语义风格，不自动套用。
- 当前 LUT 仅支持 3D `.cube`，不支持 1D LUT / 混合 LUT。
- 不支持 HDR/10-bit/ACES 色彩管理、示波器 UI 或浏览器调色面板。
- 调色渲染输出 H.264/yuv420p；有音轨时转 AAC，不保留内嵌字幕流。源媒体默认不覆盖。
- 没有目标 DSH profile，因此没有声称宿主 Cordis 激活、真实设置页或浏览器 E2E 通过。

## 发布文件

- 源码包：`DSH-Ultimate-2.0-round7-r7.8.2-color-grading.zip`
- 文件清单：`TOOL-NAMES-R7.8.2.txt`
- 差异补丁：`PATCH-R7.8.2.diff`
- 验证报告：`VALIDATION-R7.8.2.txt`
- 包内逐文件校验：`SHA256SUMS.txt`
