# DSH Ultimate 2.0 — R7.8.3

**主题：专业剪辑 / 字幕工作站真实烧录执行**

## 基线

- 延续实际源码链：R7.7 → R7.8 → R7.8.1 → R7.8.2 → R7.8.3。
- 本次工作从已交付的 R7.8.2 完整源码 ZIP 解压建立独立工作副本；另行取回并检查 R7.7 原始归档。此前所有发布归档均未覆盖。
- 只修改 Creative Orchestrator、对应测试、工具目录和发布文档；SVG Motion、Atomstudy、AIPJ、独立音频引擎没有源码改动。
- 不新增模型、Provider、远程服务、宿主补丁或第三方 npm 依赖。Orchestrator package version：2.0.1 → **2.0.2**。

## 新增能力

1. **真实 SRT/WebVTT 字幕烧录**：新增 `creative_subtitle_burnin_render`，使用已安装 FFmpeg 的 libass `subtitles` filter 输出新的 H.264/AAC MP4。
2. **字幕入口校验**：输入路径必须位于配置的 `mediaRoots`；只接受 `.srt` / `.vtt`，文件上限 2 MiB；字幕时间码与源视频时长校验，重叠、行数和行宽以警告返回。
3. **样式安全**：ASS 样式采用白名单；数值限制在安全范围，布尔字段严格检查，颜色字段限定为 8 位 ASS 色值；文本清理 ASS override block 与非白名单标签。
4. **安全输出**：字幕转成规范 SRT 后写入私有 `0600` 临时目录；输出使用独占锁、同目录临时文件、FFprobe 验证、原子发布和 SHA-256 回执。默认不覆盖旧输出，绝不覆盖源视频。
5. **审批联动**：工作流任务编译将该工具识别为 filesystem side effect，并设置 `approvalPolicy=always`；任务创建仍只排队、不自动执行。
6. **保留兼容**：原 `creative_subtitle_burnin_plan` 继续只生成计划；扩展后的样式计划和真实执行共用同一白名单序列化器。
7. **工具清单纠错**：重新按实际分组工具名计算，Creative 为 155，四插件总数为 177 且唯一；修正上一版工具清单尾部总数与分组和不一致的问题。

## 新增工具

- `creative_subtitle_burnin_render`

Creative Orchestrator full tool surface：154 → **155**，未删除既有工具。完整四插件工具清单：**177 个，177 唯一**。

## 验证

- Orchestrator：**298/298 pass，0 fail，0 skip**。
- SVG Motion：**4/4 pass**；Atomstudy：**106/106 pass**；AIPJ Preset：**37/37 pass**；独立音频引擎：**11/11 pass**。
- 真实 FFmpeg 7.1.5 / libass WebVTT 烧录集成通过；FFprobe 验证视频流与时长；抽帧摘要确认烧录后像素变化。
- 负向测试覆盖越界字幕、mediaRoots 越权、失败覆盖保留旧文件、输出锁并发冲突与锁释放。
- 全仓 **153** 个 JS/MJS/CJS 文件通过 `node --check`；Production Dashboard 1 个 inline script 通过；5 个 package.json 均可解析。
- Creative 工具 **155/155 唯一**，支持的 JSON Schema 子集检查 0 项违规；`npm pack --dry-run` 通过，105 个包文件；dependencies/devDependencies 均为空。
- 四插件工具清单 **177/177 唯一**。
- ZIP CRC、UTF-8 文件名标记、包内 SHA256SUMS 和外部 SHA-256 结果见验证报告。

完整命令、环境限制和归档校验数据见 `VALIDATION-R7.8.3.txt`。

## 明确限制

- WebVTT cue positioning / line / region 等设置不会被转换到 SRT 烧录；返回 ignoredCueSettings 计数。
- 当前只提供全局 ASS 样式，不提供逐条字幕样式、字体安装、卡拉 OK 字幕和多语言轨道封装。
- safeArea 只验证百分比边界；实际位置由 ASS margin/alignment 决定，不是自动避脸或避 UI 的视觉保证。
- 该工具对单个源视频执行烧录；尚未把 R7.8 多轨 EDL、每片段调色、转场和关键帧整合为整片合成渲染。
- 需要 FFmpeg 编译包含 libass subtitles filter；本插件不安装外部程序。
- 无目标 DSH profile / Schemastery / 3081 web 服务，宿主安装与浏览器 E2E 不在本次验证范围内。

## 发布文件

- 源码包：`DSH-Ultimate-2.0-round7-r7.8.3-subtitle-burnin.zip`
- SHA-256：`SHA256-R7.8.3.txt`
- 工具清单：`TOOL-NAMES-R7.8.3.txt`
- 差异补丁：`PATCH-R7.8.3.diff`
- 验证报告：`VALIDATION-R7.8.3.txt`
