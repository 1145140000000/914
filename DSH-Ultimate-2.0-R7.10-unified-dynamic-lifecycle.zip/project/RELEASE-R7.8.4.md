# DSH Ultimate 2.0 — R7.8.4

## Task-driven art direction, selective toolchains and visual preset workbench

**Base:** verified `DSH-Ultimate-2.0-round7-r7.8.3-subtitle-burnin.zip` (SHA-256: `d3f3f07f73d526db12fa37fb98a787a2609c98b8ab5d6f699a9d6f857adb8355`).

**Scope:** this increment builds on the R7.8.3 source archive. It does not replace the R7.8.3 release and does not add or configure model providers.

## Added

### 1. Deterministic art direction

- Added `dsh-svg-motion/art-direction.js` and public tool `svg_motion_art_direction`.
- Classifies a brief into eight visual families: anime/character illustration, product UI, data explainer, kinetic typography, product film, music video, documentary video, and general visual.
- Returns task-specific guidance for subject, composition, background, palette, typography, material, motion, sound and anti-patterns.
- Distinguishes user-provided/observed source facts from unknown details. Missing source facts remain review items; the tool does not invent a character, product, scene, or dataset description.
- Deterministic, local-only implementation: no model call, provider registration, filesystem write, network request, or new npm dependency.

### 2. Conditional toolchain guidance

- Always begins with art direction for a new visual task, then recommends the design brief.
- Recommends the storyboard only for longer or multi-shot motion work (over 15 seconds in the current deterministic rule set).
- Recommends prompt preparation only when a task actually needs assets.
- Recommends transitions only when multi-shot work has an adjacent-shot continuity need.
- Recommends visual scoring only after an actual preview/render exists.
- States that the prompt tool produces a structured handoff, not an external image/video generation call.

### 3. Stable checkpoints and review gates

- Adds stable checkpoint IDs `art-direction:01-intent` through `art-direction:08-motion-continuity`.
- Each checkpoint has `status`, `evidence` and a gate criterion; status enum is `pass / review / pending / blocked`.
- Auto media inference distinguishes static character artwork from long explainer video, so the former does not receive irrelevant motion gates and the latter can receive storyboard guidance.
- Provides a generic contract that can be mapped by a future workflow adapter. It explicitly reports `externalRunner: not-connected`; no Kilo or external checkpoint runtime integration is claimed.

### 4. Visual style-preset workbench

- The settings page now displays 20 selectable local SVG structural thumbnails.
- The selected style exposes the actual preset palette, typography, layout/focus, motion/motifs, post-processing and transition fields.
- Thumbnail colors are validated before rendering; safe `#RRGGBB` and bounded `rgb()/rgba()` values are supported.
- No external image URLs, generated preview images, font CDN, or remote service is used. Thumbnails are visual structure/palette previews, not finished artwork.
- Rhythm presets are unchanged.

### 5. Skill and tool inventory

- Adds the eight-step task-driven aesthetic decision tree and task-family guidance to `dsh-svg-motion/skill/SVG_Motion_AI_Workflow_Master_Skill.md`.
- Documents when to use each tool, when not to invoke tools, evidence requirements, checkpoint semantics and targeted rework.
- SVG Motion tool inventory is now 13; Creative Orchestrator remains 155. Total listed public tools across the four bundled plugins is 178.
- Updated the SVG Motion load-test expected count and root tool inventory.

## Compatibility and safety

- No new model provider or external service connection.
- No new `dependencies` or `devDependencies` in any of the five package manifests; host peer dependencies are unchanged.
- Existing settings bridge and host approval boundaries are unchanged.
- The art-direction tool is read-only and deterministic. It does not execute the suggested tools itself.
- R7.8.3 files are preserved in the baseline archive; this release is an incremental source copy.

## Validation

See `VALIDATION-R7.8.4.txt` for command-level results and environment limits. In summary: Orchestrator 298/298; SVG Motion 16/16; Atomstudy 106/106; AIPJ Preset 37/37 (host/profile checks skipped because the target profile is absent); standalone audio engine 11/11. The DSH-host registration smoke test is skipped because `@deepseek-ai/schemastery`, the target DSH profile and the DSH web service are absent in this sandbox.
