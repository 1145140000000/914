# DSH Ultimate 2.0 — R7.8.5

## Setup observability and truthful capability status

**Base:** R7.8.4 Art Direction release. This increment does not replace prior archives.

### Added / changed

- Expanded `creative_setup_diagnose` to report environment binaries, media-root validity, host LLM stream presence, non-secret AI role-route configuration presence, renderer-adapter configuration presence, and explicitly registered companion adapter status.
- Route status is classified as `configured-not-probed` or `not-configured`; it never claims provider connectivity from configuration fields.
- Renderer status is classified as `configured-not-verified` or `not-configured`; configuration presence is not an adapter handshake or successful render.
- Added status semantics for `available`, `configured`, and `verified` so setup guidance does not collapse distinct states.
- Added actionable next steps for missing FFmpeg/FFprobe, inaccessible media roots, missing renderer adapter and absent AI role routes.
- Adapter health output is reduced to provider ID and status; arbitrary health payloads and error strings are not copied into this diagnostic response.
- The diagnostic never reads, serializes, or exports provider credentials. Existing provider credentials remain owned by the DSH host.
- Orchestrator package version advanced from 2.0.2 to 2.0.3.

### Compatibility

- No model provider was added or changed.
- No third-party npm dependency was added.
- Existing execution approval, media-root and adapter registration boundaries are unchanged.
- No automatic installation or credential scanning is performed.

### Validation

See `VALIDATION-R7.8.5.txt`. Orchestrator tests: 299 passed / 0 failed / 0 skipped, run in seven bounded batches. Host DSH E2E remains unavailable in this sandbox.
