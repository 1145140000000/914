# DSH Ultimate 2.0 — R7.8.6

## Focus

Professional multi-track editing: precise clip trim, safe timeline ripple insertion and overlap invariant hardening. Based on the delivered R7.8.5 source archive. Earlier release archives and release notes are preserved.

## Added

- `creative_video_clip_trim`: left/right edge trim with playback-rate-aware source-time mapping.
- `creative_video_timeline_ripple_insert`: inserts a gap across unlocked tracks; splits clips crossing the insertion point and shifts right-side content.
- Keyframe boundary values are sampled and rebased during trim/split; linear, hold and ease interpolation are handled deterministically.
- Transition lengths are clamped to the new clip duration envelope after trim/split.
- Deterministic IDs for the right half of clips split by ripple insertion.
- Added a dedicated `video-editing` group to `creative_video_toolbox_catalog`; existing tool names are preserved.
- Locked-track preflight rejects the complete ripple operation before any commit.
- Fixed overlap validation to compare each clip against the furthest end among all preceding clips, not only the immediately preceding sorted clip.
- Package version: `@local/dsh-creative-orchestrator` 2.0.4.

## Compatibility and safety

- No new model or model Provider.
- No third-party npm dependency; the orchestrator remains Node built-ins only.
- Existing project revision guard, snapshot history, undo/redo and project registry persistence are reused.
- No source media files are changed; these are timeline metadata operations.
- Existing R7.8.5 archive and its checksums remain unchanged.

## Validation

See `VALIDATION-R7.8.6.txt`. Orchestrator: 303/303; SVG Motion: 16/16; Atomstudy: 106/106; AIPJ verify: 37/37; standalone audio engine: 11/11. The final archive passed ZIP CRC and a 796/796-file clean-extraction comparison; the archive SHA-256 is in `SHA256-R7.8.6.txt`.

## Not claimed

- The compiled video EDL remains a renderer-neutral plan (`plan-only-not-rendered`); this increment does not provide a complete multi-track FFmpeg compositor.
- Speed-ramp curves and per-clip speed-map rendering remain deferred.
- No live DSH host/browser E2E was available in the isolated environment.
