# DSH Ultimate 2.0 — R7.8.7

## Focus

Professional clip speed curves and source-time mapping, built on the delivered R7.8.6 source tree.

## Added

- Added normalized piecewise-linear speed envelopes with 2–64 points and bounded multipliers (0.25×–4×).
- Added deterministic instantaneous speed sampling and integrated timeline-to-source mapping.
- Clip duration now accounts for the mean speed envelope.
- Split, trim and ripple-generated splits preserve source continuity and rebase the curve into the resulting clip ranges.
- Compiled EDL now carries the curve, timebase and mapping contract.
- Added `creative_video_clip_speed_curve`, with revision guard, track lock, persistence and undo/redo behavior.
- Updated the Creative tool inventory to 158.

## Compatibility and safety

- No model Provider added, changed or connected.
- No third-party npm dependency added; Creative Orchestrator remains Node built-ins only.
- R7.8.6 source archive was used as the base and is retained unchanged.

## Validation

See `VALIDATION-R7.8.7.txt` and `SHA256-R7.8.7.txt`.

## Not claimed

- The EDL exposes a renderer-neutral speed-map contract, but the existing FFmpeg segment renderer does not yet consume it. Rendered speed-ramp output and preview/final-render parity remain unfinished.
- No live DSH host/browser E2E was available in this environment.
