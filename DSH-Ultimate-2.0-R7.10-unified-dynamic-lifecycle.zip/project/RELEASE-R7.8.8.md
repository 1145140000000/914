# DSH Ultimate 2.0 — R7.8.8

## Focus

Connect the editable multi-track video timeline and piecewise-linear speed curves to a real, deterministic FFmpeg composition path. Base: R7.8.7.

## Added

- Added `lib/video-timeline-renderer.js` with deterministic EDL-to-FFmpeg filtergraph compilation and an explicit execution adapter.
- Added `creative_video_timeline_render`: reads a persisted project timeline, requires explicit assetId→path bindings, enforces configured `mediaRoots`, writes to a temporary output, verifies output dimensions/frame count with FFprobe, then atomically publishes and SHA-256 hashes the MP4.
- Composites multiple video/overlay tracks in deterministic track/time/clip order.
- Consumes piecewise-linear speed curves by splitting source ranges at curve knots and mapping each interval to its integrated timeline duration.
- Applies normalized non-destructive grade filters and fade/dissolve alpha transitions.
- Registers the render action as a filesystem write for worker approval policy.
- Added four tests, including a real FFmpeg/FFprobe multi-track render and path/binding rejection.
- Creative Orchestrator inventory: 159 unique tools.

## Explicit current renderer limits

This renderer currently emits video-only MP4. It deliberately rejects clips with keyframes rather than silently ignoring animation. LUT file resolution, non-fade wipe transitions, and audio-track mixing are not yet implemented in this timeline renderer. Audio projects and the existing audio render pipeline remain separate. No preview/final parity claim is made for keyframes or LUTs.

## Compatibility and safety

- No model Provider added, changed or connected.
- No third-party npm dependencies added; the Orchestrator remains Node built-ins only.
- FFmpeg and FFprobe are explicit external executables; this release does not install them or infer availability.
- All media paths require explicit bindings and configured allowed roots. Source assets are never overwritten.
- R7.8.7 archive remains unchanged.

## Validation

See `VALIDATION-R7.8.8.txt` and `SHA256-R7.8.8.txt`.
