# DSH Ultimate 2.0 — R7.8.9

## Focus

Make the existing editable visual keyframes execute in the real multi-track FFmpeg timeline renderer. Base: R7.8.8 source archive; R7.8.8 release archive remains unchanged.

## Added

- `creative_video_timeline_render` now consumes visual clip keyframes instead of refusing all animated clips.
- Supported properties: `opacity` (0–1), `scale` (0.05–8×), `rotation` (degrees), `positionX` and `positionY` (pixel offsets from the composition center).
- `linear`, `hold`, and smoothstep `ease` interpolation are compiled into deterministic FFmpeg expressions.
- Position expressions are evaluated against composition time with clip-start offset; scale, rotation and opacity use clip-local timestamps.
- Explicit bounds reject unsafe/extreme transform values before FFmpeg execution.
- `volume` keyframes are rejected with a clear handoff boundary because audio automation belongs to the audio timeline renderer, not the video-only MP4 renderer.
- Added three tests: deterministic expression compilation, real FFmpeg/FFprobe animated render, and explicit volume-keyframe rejection.
- Updated tool description and project README to reflect the actual renderer capability boundary.

## Renderer scope after R7.8.9

Supported: multi-video/overlay tracks, constant and piecewise-linear speed curves, non-destructive base grade filters (when no unresolved LUT is referenced), fade/dissolve alpha, and visual keyframes for opacity/scale/rotation/position.

Not yet supported by this timeline renderer: audio-track mixing and volume keyframes, LUT path resolution/application, wipe transitions, subtitle-track compositing, and a unified live preview/final-render implementation. Unsupported features fail closed where they are encountered; no preview/final parity is claimed for unsupported paths.

## Compatibility and safety

- No model Provider added, changed or connected.
- No third-party npm dependencies added; the Orchestrator remains Node built-ins only.
- FFmpeg/FFprobe remain explicit external executables; nothing is auto-installed.
- Asset paths require explicit bindings and configured `mediaRoots`; source assets are not overwritten.
- Render output is written to a temporary file, checked with FFprobe, then atomically published with a SHA-256 receipt.
- R7.8.8 archive is preserved unchanged.

## Validation

See `VALIDATION-R7.8.9.txt` and `SHA256-R7.8.9.txt`.
