# DSH Ultimate 2.0 — R7.8

## Focus

Professional video editing and director-to-timeline capability. This release does not add models or model providers.

## Delivered

### Multi-track video editing core

- Added `dsh-creative-orchestrator/lib/video-edit-project.js`.
- Versioned video timeline schema with project fps/duration, video/audio/subtitle/overlay tracks, clips, transitions and keyframes.
- Track lock, mute and solo state.
- Clip add, split, move/cross-track move and project-wide ripple delete.
- Source-time split conversion honors playback rate.
- Ripple delete rejects operations that would cut through other clips or shift locked tracks.
- Clip keyframes support opacity, scale, rotation, position X/Y and volume with bounded local-time points.
- Bounded undo/redo history; each edit advances timeline revision.
- Frame-quantized EDL compiler uses start-inclusive/end-exclusive frame ranges and clearly labels output as a plan, not a render.
- Project persistence goes through the existing project registry and `expectedProjectRevision` optimistic concurrency check.

### Director bridge

- `creative_director_timeline_assemble` converts a deterministic director shot plan into an editable video timeline only when every shot has an explicit `assetId` binding.
- Missing bindings are reported; no placeholder assets are fabricated.
- Shot frame ranges must be contiguous and cover the complete plan duration.

### Subtitle workbench

- Added SRT/WebVTT parsing and export, including multiline captions and WebVTT cue settings.
- Validation covers malformed/empty cues, duplicate cue IDs, overlaps, media-duration overflow, recommended line count/width, and safe-area bounds.
- Subtitle burn-in filter-plan generation bounds font size, margin and outline, but intentionally does not execute FFmpeg. Execution still needs a separate approved, media-root-guarded render integration.

### Public tools

- 18 new public tools: 14 video timeline/director tools and 4 subtitle tools.
- Total public tool count: 148 unique tool names.

## Validation

- Orchestrator: 276/276 tests pass.
- SVG Motion: 4/4.
- Atomstudy: 106/106 selfcheck.
- AIPJ preset: 37/37 verify checks; target-profile install and live DSH checks skipped because no target profile was available and `dsh web` did not respond on port 3081.
- Standalone audio engine: 11/11.
- JavaScript/MJS/CJS syntax checks: 149 files.
- Production dashboard inline script: `node --check` passed.
- New video timeline and subtitle tests include tool-level persistence, stale revision rejection, concurrent edit race, undo/redo, EDL compilation and explicit director asset binding.

## Not claimed / remaining

- No full browser or live-host E2E run was possible in this environment.
- Subtitle burn-in is a bounded FFmpeg filter plan only, not an executed render operation.
- Non-destructive color grading and LUT application are not part of this increment.
- The video EDL is a renderer-neutral plan; this release does not claim a complete multi-track FFmpeg video compositor.
- Director timeline assembly requires explicit, already-registered asset IDs and does not generate media.
- R7.7 archive and source tree are unchanged; R7.8 is an isolated copy.

## Runtime and dependencies

- Main plugin remains Node built-ins only; no new npm dependencies or model providers.
- Rendering remains subject to existing renderer registration, media-root constraints, process supervision and execution approvals.

## R7.8.1 — Cordis schema and package compatibility patch

This is a compatibility-only patch over R7.8. It does not change prompt payloads, add dependencies, remove tools or change existing tool result shapes. The full tool surface remains the default and preserves all 148 Creative tool names. Optional `toolSurface: "compact"` registers ten entry tools and supports on-demand registration from the complete tool catalog. Unsupported JSON Schema range keywords are moved into descriptions and their existing execution-time limits are enforced at runtime. See `PATCH-R7.8.1.md` and `VALIDATION-R7.8.1.txt` for the file-level change log and environment-specific test outputs.
