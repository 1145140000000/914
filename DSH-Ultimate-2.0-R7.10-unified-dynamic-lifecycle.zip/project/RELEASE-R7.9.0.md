# DSH Ultimate 2.0 — R7.9.0

## Scope

Extend the existing multi-track video timeline export so the final MP4 can optionally include the independently authored audio-edit project, a validated subtitle file, and verified clip LUTs. Base: the actual R7.8.9 Library archive. R7.8.9 and earlier release archives remain unchanged.

## Delivered

- Optional `audioProject` input to `creative_video_timeline_render`; it is schema-validated and rendered through the existing audio-project engine to a temporary WAV, then muxed with the video.
- Optional subtitle burn-in from explicit SRT/VTT file paths. The file must be within `mediaRoots`, no larger than 2 MiB, contain parseable cues, and all cue end times must fit the final timeline duration.
- Subtitle styling uses the existing allowlisted ASS style compiler; arbitrary style keys are rejected.
- Optional `lutPaths` binding by video asset ID. Every used LUT must resolve within `mediaRoots` and its SHA-256 must exactly match the immutable LUT metadata stored on the timeline clip.
- Final mux output is probed again: exact video dimensions, exact frame count, and audio stream presence when audio was requested are required before publication.
- Final output uses a same-directory temporary file and atomic no-clobber link or overwrite rename. Temporary audio/video files are removed on success or failure; source assets and project inputs are not modified.
- Tool description and README updated to reflect actual support.
- 4 new timeline renderer tests cover audio+subtitle MP4 output, LUT execution/hash mismatch, subtitle duration validation, and explicit wipe-transition fail-closed behavior.

## Actual capability boundary

Supported by the timeline renderer: multi-video/overlay tracks, piecewise-linear speed curves, visual keyframes (opacity/scale/rotation/position), fade/dissolve, base grading, SHA-256-bound 3D LUTs, optional independent audio-project mixdown, and optional SRT/VTT subtitle burn-in.

Still not complete: native wipe-left/right compositor, volume keyframes directly on video clips, and a single shared interactive-preview/final-render graph. These remain explicitly unsupported or separate; this release does not claim preview/final parity. Existing audio-track automation in the audio project remains available through the audio engine.

## Compatibility and safety

- No model provider was added, changed, or connected.
- No third-party npm dependencies were added; the Orchestrator continues to use Node built-ins and existing explicit FFmpeg/FFprobe executables.
- No executable auto-installation or approval bypass was added.
- All media, subtitle, LUT, and output paths are constrained to configured `mediaRoots`.
- Existing R7.8.9 source archive and prior release archives are preserved unchanged.

## Validation

See `VALIDATION-R7.9.0.txt`, `SHA256-R7.9.0.txt`, and `SHA256SUMS-R7.9.0.txt`. Host-level DSH profile/E2E validation was not available in this sandbox and is not claimed.
