# DSH Ultimate 2.0 — R7.9.1

## Scope

Continue the verified R7.9.0 unified final timeline renderer. This increment implements the two directional wipe transitions that R7.9.0 explicitly rejected. The R7.9.0 archive and all earlier release archives remain unchanged.

## Delivered

- `wipe-left` and `wipe-right` now compile to per-frame FFmpeg alpha masks.
- Wipe-in and wipe-out are both supported; the direction is consistent across both boundaries.
- Wipe masks multiply with the clip's existing alpha, preserving visual opacity and compositing behavior.
- The compositor uses clip-local frame timestamps and deterministic expressions; no random or wall-clock values are involved.
- The tool description and README now accurately advertise wipe support.
- The prior fail-closed test was replaced by a real FFmpeg render test that exercises both directions on both transition boundaries and verifies exact output frame count.

## Renderer capability boundary

Supported: multi-video/overlay tracks, piecewise-linear speed curves, visual keyframes (opacity/scale/rotation/position), fade/dissolve, wipe-left/right, base grade filters, SHA-256-bound 3D LUTs, optional independent audio-project mixdown, and optional SRT/VTT subtitle burn-in.

Still not complete: direct volume keyframes on video clips and a single shared interactive-preview/final-render UI graph. The offline preview/final rendering parity claim is not made for an interactive host preview. Audio automation remains available in the independent audio-edit project renderer.

## Compatibility and safety

- No model provider was added, changed, or connected.
- No third-party npm dependency was added.
- FFmpeg/FFprobe remain explicit external executables; no auto-installation or execution-approval bypass was added.
- Explicit media-root path authorization, LUT hash verification, subtitle validation, output probing, atomic publication, and source immutability are retained.
- R7.9.0 and earlier release archives are preserved unchanged.

## Validation

See `VALIDATION-R7.9.1.txt`, `SHA256-R7.9.1.txt`, and `SHA256SUMS-R7.9.1.txt`.
