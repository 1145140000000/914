# DSH Ultimate 2.0 — R7.9.2

## Focus

Complete the next two timeline gaps left explicitly open in R7.9.1: embedded video-clip audio automation and a preview entry point that reuses the final-render path.

## Added

- `volume` keyframes (linear gain 0–4) now control the embedded audio stream of video/overlay clips.
- Clip audio follows the same piecewise-linear speed segmentation as the rendered picture using matching `atempo` segments, so the audio and picture remain aligned under the renderer's existing speed-curve model.
- Embedded clip audio is mixed with the separately rendered audio project in the final mux. A requested volume automation on a source with no audio stream fails explicitly instead of silently disappearing.
- `creative_video_timeline_preview` and `renderVideoTimelinePreview()` render through the same final composition path (video tracks, visual keyframes, transitions, LUT validation, subtitles, clip audio automation and independent audio project), then trim the verified result on exact frame boundaries.
- Preview output validates frame count, dimensions and audio-stream parity; refuses out-of-range preview ranges, source/LUT/subtitle/audio-source overwrite, symlink/special-file destinations and writes outside configured `mediaRoots`.
- Preview is deliberately parity-first rather than fast: it renders the complete timeline at the requested preview dimensions and extracts the selected frame range. It does not maintain a second divergent filter graph.
- Added real FFmpeg/FFprobe tests for clip volume automation, non-flat speed curves, no-audio failure, simultaneous clip-audio + independent-audio mix, subtitles, and exact-range preview.

## Compatibility and safety

- No model providers added, connected or modified.
- No third-party npm dependencies added. Orchestrator package version: 2.0.5.
- FFmpeg/FFprobe remain explicit external executables; no installation or approval bypass is performed.
- Source media remains non-destructive. File writes continue through bounded media roots and temporary outputs.
- R7.9.1 archive remains unchanged.

## Remaining known limits

- Preview currently renders the full timeline before extracting the selected range; this is slower than proxy/segment preview but keeps composition behavior aligned with final output.
- Embedded audio automation is supported for video/overlay clip sources; dedicated audio tracks and advanced routing continue to use the independent audio-project subsystem.
- Real DSH host/profile browser E2E was not available in this environment.

## Validation

See `VALIDATION-R7.9.2.txt`, `SHA256-R7.9.2.txt`, and `SHA256SUMS-R7.9.2.txt`.
