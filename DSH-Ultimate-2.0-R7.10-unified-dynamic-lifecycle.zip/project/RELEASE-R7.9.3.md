# DSH Ultimate 2.0 — R7.9.3 Release

## Scope

R7.9.3 advances all five requested tracks: proxy-assisted timeline preview, video/audio QA evidence and approval-gated repair tasks, director-to-project asset matching, versioned cross-plugin handoff contracts, and integrated workflows that connect these capabilities.

## Delivered

1. **Proxy-assisted preview**
   - Added `creative_video_proxy_set` for up to four H.264 proxies: 360p, 540p, 720p, and 1080p.
   - Preserves source aspect ratio and optional source audio; each output is FFprobe-verified and SHA-256 receipted.
   - Multi-output generation rolls back this run's already-published outputs if a later variant fails.
   - Transcodes now write to a same-directory temporary file, verify it, and atomically publish; failed overwrite does not damage the previous output.
   - `creative_video_timeline_preview` accepts `proxyAssetPaths` keyed by the same timeline asset IDs. It reuses the final renderer graph, then trims on frame boundaries.
   - **Known limitation:** preview still renders the complete timeline before trimming. Proxy inputs reduce decode/scale load, but this is not interactive real-time playback.

2. **Audio/video QA and repair loop**
   - Added `creative_media_quality_report`: FFprobe, black/freeze detection, sampled luma/saturation, scene candidates, LUFS/true peak, and audio safety.
   - Reports distinguish measured findings from missing checks; OCR subtitle collision, semantic vision review, and A/V sync are not inferred.
   - Added `creative_quality_repair_plan` and `creative_quality_repair_tasks_create`. Repair tasks are durable, approval-gated tool intents; no media changes are executed automatically.
   - Added `quality-repair-loop` and upgraded `release-quality-gate` workflow.

3. **Director production loop**
   - Added explainable metadata-only shot-to-asset matching, director production packets, and `creative_project_director_packet` using project-linked assets.
   - Each shot remains unbound until a human selects an asset and reviews its license. The system does not claim to have viewed the media.

4. **Plugin ecosystem contracts**
   - Added versioned `media.asset`, `video.storyboard`, `render.job`, and `quality.report` contracts.
   - Added `creative_ecosystem_contracts` and `creative_ecosystem_handoff_validate`.
   - Contract availability does not imply companion plugin installation or connectivity; external writes still require explicit adapters and host approvals.

5. **Workflow integration**
   - Upgraded `media-proxy-transcode` to use the proxy-set tool.
   - Added `quality-repair-loop`; updated release QA workflow to use the consolidated report.
   - Tool inventory is 169 unique tools. Orchestrator package version is 2.0.6.

## Compatibility and security

- No host source changes, new runtime dependencies, model-provider additions, credential reads, or approval bypasses.
- Media inputs/outputs remain restricted to configured `mediaRoots`.
- Proxy source media remains immutable; transcode publication is atomic.
- Previous R7.9.0–R7.9.2 archives remain untouched.

## Validation summary

See `VALIDATION-R7.9.3.txt` for exact commands, test counts, environment limits, and skipped host checks.
