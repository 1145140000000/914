# DSH Ultimate 2.0 — R7.9.4 工具生态扩展

## 本轮目标

继续扩充可直接调用的媒体工具，并允许可选外部运行时/服务进入能力目录；核心包不强制捆绑大模型、系统软件或云端依赖。

## 新增 DSH 工具

1. `creative_video_trim`：指定起点/时长裁切视频，FFprobe 验证输出流与时长。
2. `creative_video_rotate`：90/180/270 度旋转并保留可用音轨。
3. `creative_video_crop`：按像素坐标裁剪，越界拒绝。
4. `creative_video_gif_create`：使用 palettegen/paletteuse 生成 GIF，限制区间、帧率和宽度。
5. `creative_image_convert`：PNG/JPG/WebP 格式转换。
6. `creative_audio_fade`：音轨淡入/淡出，导出 WAV/FLAC/MP3。
7. `creative_comfyui_queue`：查询 ComfyUI 运行/等待队列。
8. `creative_comfyui_node_catalog`：读取实际安装的节点类型。
9. `creative_comfyui_interrupt`：明确请求中断当前 ComfyUI 执行。

## 外部生态扩展

- 本机运行时新增 WhisperX、Demucs、PySceneDetect、Real-ESRGAN、RIFE、Inkscape、Krita、Natron、OpenTimelineIO、Docker、Git。
- 服务目录新增 DeepSeek、OpenRouter、Gemini、Anthropic、Replicate、fal.ai、ElevenLabs、Stability AI。
- DeepSeek/OpenRouter 可通过已有 OpenAI-compatible chat 适配器使用；其他服务仍需独立 provider adapter。
- ComfyUI 新增 queue、object_info 和 interrupt API 操作。

## 安全/可靠性

- 媒体输入/输出继续限制在配置的 `mediaRoots`。
- FFmpeg 子进程使用参数数组，不使用 shell。
- 新增写操作禁止覆盖源文件；默认不覆盖现有目标。
- 视频操作先写同目录临时文件，验证后原子发布。
- 外部运行时探测仅执行版本/帮助命令；不安装软件、不读取凭据。
- 远程 provider 默认拒绝，必须显式启用；API 密钥仅从宿主 secret provider 获取。
- ComfyUI interrupt 是有副作用操作，只能在用户明确要求停止时调用。

## 兼容性

- Orchestrator package version：`2.0.7`
- DSH host patch / dependency model：未增加运行时 npm 依赖；宿主 API 未修改。
- Tool count：178 个 `makeTool` 注册项。

## 仍需外部适配

Gemini/Anthropic 多模态、Replicate/fal.ai 云端推理、ElevenLabs TTS、AE/Resolve/Audacity 自动化、RIFE/Real-ESRGAN 推理编排尚未实现完整 provider adapter；外部目录不代表服务已连接。真实 DSH 宿主浏览器 E2E 未在本环境执行。
