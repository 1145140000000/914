# DSH Ultimate 2.0 — R7.9.9 动态配置生命周期专项重构

## 本轮目标

解决插件 `.volatile()` 配置在运行时修改后，已注册工具、闭包、提示词（`systemPrompt`）与设置桥（`bridge` / `webui`）仍然使用 `apply()` 阶段旧配置快照的问题，建立可追踪、可回滚、可串行化、可卸载的统一动态配置与插件生命周期管理层。

## 修改文件清单

1. `lib/dynamic-config.js`（新增）：统一动态配置与插件生命周期管理模块，同步内置于各独立插件包中：
   - `dsh-aipj-preset/lib/dynamic-config.js`
   - `dsh-atomstudy/src/dynamic-config.js`
   - `dsh-svg-motion/lib/dynamic-config.js`
   - `dsh-creative-orchestrator/lib/dynamic-config.js`
2. `dsh-aipj-preset/index.js` & `dsh-aipj-preset/package.json`：接入 `createDynamicConfig` 与 `createPluginLifecycle`，动态化 `aipj:memory` / `aipj:kernel` / `aipj:reinforce` 槽位与 `aipj_profile` / `aipj_memory` 工具及 `session/event` 清洗通道。
3. `dsh-atomstudy/index.js`：接入 `createDynamicConfig` 与 `createPluginLifecycle`，动态化 `atomstudy:skill` 槽位、8 个稳定代理工具、`deps` 路由依赖与 `enableWebUI` 门禁。
4. `dsh-svg-motion/index.js` & `dsh-svg-motion/package.json`：接入 `createDynamicConfig` 与 `createPluginLifecycle`，动态化 `svg-motion:skill` / `svg-motion:distill` 槽位、13 个稳定代理工具与配置版本追踪。
5. `dsh-creative-orchestrator/index.js`：接入 `createDynamicConfig` 与 `createPluginLifecycle`，动态化 `activeConfig`、`externalProviders` 超时重建、工具注册去重与卸载时 Worker 清理。
6. 新增测试文件：
   - `dsh-creative-orchestrator/tests/dynamic-config-lifecycle.test.mjs`（8 项单元测试 + 编排器集成测试）
   - `tests/helpers/mock-schemastery-loader.mjs`（模拟宿主测试专用 Schemastery ESM 桩）
   - `tests/simulated-host-plugins.test.mjs`（3 项三插件模拟宿主生命周期测试）
7. 发布与校验文档：
   - `RELEASE-R7.9.9.md`
   - `VALIDATION-R7.9.9.txt`
   - `SHA256SUMS-R7.9.9.txt`

## 核心机制与 API 兼容性依据

- **稳定配置引用与按需读取**：保留宿主传入 `config` 对象的稳定引用，通过 `tryUnwrapConfigValue` 解包 Schemastery/Cosmokit volatile cell（`{ get() }`），并提供 `get()` 与 `getLiveProxy()` 实时读取当前已校验配置。
- **事件监听与并发串行化**：自动订阅 `ctx.on('loader/volatile-update', ...)`（兼容无参、单参补丁、`[target, payload]` 签名），所有更新通过串行队列执行；校验失败、非法非对象写入或 `.get()` 抛错时自动回滚并保留上一版有效配置与版本号。
- **无 `unregisterTool()` 约束下的安全生命周期**：不假设宿主存在 `unregisterTool()`；每个工具通过 `lifecycle.registerTool()` 注册唯一**稳定代理**，调用时实时读取 `dynamicConfig.get()` 检查 `masterEnabled` 与模块开关（关闭时返回结构化 `module-off`，卸载后返回 `plugin-disposed`），避免重复注册与半更新状态。
- **Prompt 动态更新**：`registerPromptSection` / `registerPromptContext` 在宿主返回 disposer 时按 `enabled`/`order`/`text` 变化安全销毁并重建槽位；对仅注册一次的宿主则通过函数式 `text()` 实时求值。
- **异常隔离与卸载清理**：监听器异常被逐个隔离捕获，不会导致插件白屏；`ctx.on('dispose', ...)` 触发时统一释放监听器、定时器、路由 disposer 与 Worker，并忽略迟到的 `loader/volatile-update` 事件。
- **兼容性边界**：未修改 DSH Host 上游源码，未增加 npm 运行时依赖，未改变已有工具名、参数 Schema 与默认配置。

## 风险与未解决问题

1. 当前沙箱环境为 Node.js `v18.20.4` 且未安装 `@deepseek-ai/schemastery` 与 DSH Host 运行时，因此**真实 Schemastery 测试、真实 DSH Host 测试与真实浏览器 E2E** 尚未在本机执行；`dsh-creative-orchestrator` 中依赖 Node 22+ 全局 `WebSocket` 的既有 Chromium WebGL/Three.js 测试在 Node 18 下失败（与基线一致）。
2. `dsh-atomstudy/tools/selfcheck.sh` 存在 3 项既有的环境依赖检查失败（目标 profile 未安装），与本轮改动无关。
