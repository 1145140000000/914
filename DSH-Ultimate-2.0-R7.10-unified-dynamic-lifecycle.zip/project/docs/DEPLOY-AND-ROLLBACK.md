# DSH Ultimate 2.0 — 部署与回滚

## 部署前

1. 备份当前三个插件目录和活动 profile 的 Cordis bundle 配置。
2. 保留 atomstudy 用户数据、凭据存储、素材输出目录和本机配置；不要用本包覆盖这些数据。
3. 将 `dsh-creative-orchestrator/` 放入插件目录，并把其 `cordis.patch.yml` 中的 `- insert` 行合并到活动 profile 的现有 bundle patch。**不要用该片段替换整个 profile patch**。
4. 以 DSH 原有 bundle 管理流程安装/刷新 `@local/dsh-creative-orchestrator`，再重启宿主。

## 验证

- 检查 24 个 `creative_*` 工具均已注册。
- `creative_task_create` → `creative_task_claim` → `creative_task_step_update(running)` → `creative_task_checkpoint` → `creative_task_heartbeat` → `creative_task_release`，检查租约所有权、暂停和检查点持久化。
- 通过显式注入 `executeStep` 的 `createWorker()` 运行时跑通无副作用测试任务；checkpoint 任务必须提供 `resumeStep` 才能恢复。
- 用明确配置的 provider/model 调用 `creative_director_decide`；确认真实请求返回 `planned`，不可用时必须是 `degraded`。
- 配置 `mediaRoots` 为明确允许访问的本地媒体目录，调用 `creative_media_inspect` 获取 ffprobe/ffmpeg 证据，再把返回的真实 evidence 交给 `creative_visual_qa`；缺失字段应保持 incomplete，不要手工编造指标。
- 用 `creative_timeline_validate` 检查轨道区间，用 `creative_prompt_version` 保存提示词版本。

## 数据目录

默认 `~/.dsh/creative-orchestrator/`，包含 `jobs/`、`knowledge/`、`prompts/`、`assets/` 和写锁目录。目录权限 0700、JSON 文件权限 0600。可通过插件 `dataRoot` 覆盖，但必须指向用户可控且权限受限的目录。媒体访问需另行设置 `mediaRoots: ["/absolute/path/to/media"]`；不要把整个系统根目录作为允许根。

## 回滚

1. 停用并移除 `dsh-creative-orchestrator` 对应 bundle 行。
2. 恢复部署前备份的 profile patch 和插件目录。
3. 不删除 `~/.dsh/creative-orchestrator/`，除非用户明确决定清除任务/知识/提示词/素材元数据；回滚代码不应自动删除数据。
4. 第一轮三个插件独立保留，若只回滚第二轮，不需要覆盖它们。

## 未完成的现场验证

本交付环境没有用户的真实 DSH profile、运行中的 3081 Web 服务、浏览器 DOM、真实 provider 凭据或 FFmpeg/Chromium 工作进程。因此部署、真实路由、自动渲染和视觉检测器必须在用户环境验收；本包不会将模拟测试冒充现场联调。
