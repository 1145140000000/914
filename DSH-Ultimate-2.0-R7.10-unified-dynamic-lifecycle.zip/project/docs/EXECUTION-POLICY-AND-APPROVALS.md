# DSH Ultimate 2.0 — 执行驾驶模式与审批策略

日期：2026-11-14

## 驾驶模式

| 模式 | Worker 行为 | 授权边界 |
|---|---|---|
| `manual` | `runOnce()` 返回 `manual-mode`，不领取任务、不执行步骤 | 由用户/执行 Agent 查看任务与建议，并通过已有步骤工具进行人工操作 |
| `copilot` | 自动执行低风险、无副作用且不要求额外能力的步骤；遇到外部副作用、medium 及以上风险、或声明 requiredCapabilities 的步骤时暂停并创建审批请求 | 一次审批只授权当前步骤定义；批准后任务重新入队，执行开始时审批即被消费 |
| `autopilot` | 仅执行显式授权范围内的步骤 | 必须 `execution.autopilot.enabled=true`，且 sideEffect、riskLevel、requiredCapabilities 均在授权范围内；未授权时转入审批，不会降级放行 |

Quick / Balanced / Studio 默认均为 `copilot`，Auto Pilot 授权默认关闭。

## 步骤元数据

创建任务时每个步骤可提供：

- `sideEffect`: `none`、`filesystem`、`network`、`external`。
- `riskLevel`: `low`、`medium`、`high`、`critical`。
- `approvalPolicy`: `on-risk`、`always`、`never`。硬性风险门禁优先于 `never`，它不能绕过副作用/风险检查。
- `requiredCapabilities`: 最多 32 个能力标识。

省略时分别默认为 `none`、`low`、`on-risk` 和空能力集。

## 审批闭环

1. Worker 在执行步骤前评估当前配置与步骤元数据。
2. 不满足策略时，持久化 `pending` 审批、原因和步骤范围指纹，并把任务暂停、释放租约。
3. `creative_task_approval_list` 返回全部待处理审批；`creative_task_approval_page` 从专用待办分片分页读取；`creative_task_approval_decide` 批准或拒绝。
4. 批准后任务回到队列；重新领取时校验步骤范围指纹，执行启动时标记为 `consumed`。
5. 步骤动作、风险、副作用或能力要求变化后，旧批准不再有效。

相关任务事件包括 `approval-requested`、`approval-approved` 和 `approval-rejected`。

## 重要身份边界

当前 DSH 工具上下文没有向本插件提供可验证的用户身份/授权签名接口。`reviewer` 只是审批调用方提交的审计标签，不代表已认证身份。因此审批工具应由用户明确触发；不能把模型自行填写的 reviewer 字段当作身份验证。后续要做真正不可伪造的 UI 审批按钮，需要宿主提供可验证 actor/confirmation 上下文或由受信任的本地控制面代理审批。

## 未声称完成的能力

- 还没有 Creative Studio 可视化驾驶模式切换器与审批收件箱 UI。
- 还没有宿主身份认证、签名审批凭据或角色权限系统。
- `maxConcurrentTasks` 仍需要独立 Worker 监督器才能成为强制并发限制。
- 手动模式不会由插件 Worker 执行；它提供持久任务/步骤/校验接口，实际手动执行仍由外部执行 Agent 或用户操作完成。
- Auto Pilot 仍依赖调用方注入的显式 `executeStep`；插件不自动执行 shell、浏览器或任意工作流。
