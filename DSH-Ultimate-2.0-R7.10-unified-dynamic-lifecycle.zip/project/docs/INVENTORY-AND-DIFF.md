# DSH Ultimate 2.0 — 实际文件盘点与差异

盘点日期：2026-11-13。基线仅采用本轮实际检出的文件，不把此前对话中的 sandbox 路径或测试口述当作文件证据。

## 实际找到的输入

| 文件 | 实际大小 | 内容 |
|---|---:|---|
| `DSH-refactor-2026-11-13.zip` | 4,529,224 B | 第一轮重构包，588 个 ZIP 条目 |
| `pkg.tgz` | 27,829 B | 原始插件快照：`index.js`、`client.js`、`config-excerpt.js` |
| `atomstudy-gpt-package-20261108.zip` | 19,666,891 B | 719 个条目，含三插件源码、知识库、工具、素材/需求材料 |
| `图片提示词.zip` | 86,059,837 B | 23 张需求/视觉提示词图片材料（第一轮索引已有记录） |

## 第一轮交付包含

- `dsh-svg-motion` 1.3.0：planner、quality-gate、reference-card、A–J transitions、客户端和桥接。
- `dsh-atomstudy` 0.1.1：视频学习、styleCard、todo、skill pack、review、tunnel、credentials、web UI。
- `dsh-aipj-preset` 2.9.1：双层提示词、memory、bridge、client 和 42 题评测材料。
- `docs/`：第一轮报告、需求映射、集成契约、部署回滚、素材索引。

## 基线与第一轮包的差异

三插件源码并非简单复制。逐目录 `diff -qr` 确认：

- SVG Motion：第一轮新增 `planner.js`、`quality-gate.js`、`reference-card.js`、`transitions.js` 与测试；`index.js`、`client.js`、`package.json`、`README.md`、配置和 selfcheck 与 11/08 材料包存在差异。原始包保留若干 `.bak-*` 文件，第一轮包不包含这些备份。
- Atomstudy：第一轮 `index.js`、`client.js`、`package.json` 和多个 selfcheck 与材料包不同；第一轮包的修订版自检结果为 106/106。
- AI-PJ：第一轮 `index.js`、`package.json`、评分器测试和 `verify.sh` 与材料包不同；材料包中的黑盒探针、回滚目录和历史备份不进入运行包。
- `pkg.tgz` 只有三个顶层 JS 文件，不包含可完整安装的三插件 monorepo 或宿主 profile。

## 采用策略

第一轮包作为当前三插件主干；11/08 原始材料仅作为追溯/对照，不以旧文件覆盖第一轮修复。第二轮只增加独立 `dsh-creative-orchestrator`，三插件原有目录不做大规模破坏性重写。这样能回滚新编排层而不影响第一轮稳定基线。
