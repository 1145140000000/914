# R7.7 — Native media capabilities (no new model providers)

R7.7 freezes model-provider expansion and spends the round on deterministic media-processing capability. The orchestrator remains zero third-party runtime dependencies; optional FFmpeg/FFprobe binaries are invoked only when installed and explicitly configured/available.

## New public tools

- `creative_media_probe`: inspect audio/video/image stream metadata with FFprobe. Frame counting is opt-in because `-count_frames` may require a full decode.
- `creative_media_library_scan`: bounded recursive inventory of configured media roots. Skips symlinks, limits depth/file count/concurrency and optionally computes SHA-256. Hashing defaults off and skips files over `maxHashBytes` (default 2 GiB).
- `creative_video_signal_analyze`: samples real frames with `signalstats`; returns mean/median/p05/p95 luma, saturation, frame luma range, dark/bright average-frame ratios and luma-jump candidates.
- `creative_video_integrity_analyze`: runs FFmpeg `blackdetect` and `freezedetect`, returning black/freeze intervals, durations and ratios. An open freeze at end-of-file is closed against the probed media duration and marked `endInferredFromMediaDuration`.
- `creative_video_scene_detect`: extracts FFmpeg scene-change cut candidates and half-open shot intervals. It is a pixel-change heuristic, not semantic shot classification.
- `creative_video_contact_sheet`: produces a contact-sheet image from sampled frames.
- `creative_video_frame_extract`: extracts one frame at a precise timestamp.
- `creative_audio_silence_detect`: returns silence intervals, total duration and ratio.
- `creative_audio_loudness_normalize`: uses two-pass EBU R128 `loudnorm` measurements, then produces a normalized output and verifies its audio stream.
- `creative_video_transcode`: converts to MP4/H.264, MP4/H.265 or WebM/VP9 with bounded CRF, dimensions and encoder preset.
- `creative_media_audio_extract`: extracts/converts an existing audio stream to WAV, FLAC or MP3.
- `creative_video_subtitle_extract`: extracts an existing embedded subtitle stream to SRT. It does not transcribe speech or generate captions.

## Workflow templates

- `video-preflight`: probe -> black/freeze integrity evidence -> sampled luma/saturation analysis + scene-cut candidates -> contact sheet -> human editorial review.
- `audio-mastering-chain`: silence analysis -> explicit approval -> two-pass loudness normalization -> quality measurement + safety inspection -> human listening/acceptance.
- `media-proxy-transcode`: source probe -> explicit approval -> proxy/delivery transcode -> output probe -> human review.

The workflow task compiler binds downstream inputs to completed step outputs with the existing safe `$ref` dataflow. Write-producing operations are marked `filesystem` and receive an `always` approval policy in workflow tasks. Creating a workflow task only queues it; it does not start a Worker.

## Safety and boundaries

- Every source and output path must resolve inside configured `mediaRoots`. Output parent directories must already exist; existing outputs are rejected unless `overwrite=true`; output symlinks are rejected.
- Child processes use `spawn(..., { shell: false })`, argument arrays, timeouts and bounded captured output. No user-provided command fragment or arbitrary filter string is accepted; filters are assembled from validated numeric options and fixed templates.
- Library scan skips symlinks, limits depth to 8, files to 1,000 and probe concurrency to 4. Optional hashing is capped per file.
- File operations return SHA-256 receipts and/or post-write FFprobe verification. This is technical verification, not subjective visual QA.
- `signalstats` metrics describe sampled pixel values. Luma jumps can be ordinary cuts or lighting changes; they are not by themselves a flicker diagnosis.
- Scene detections are candidate cuts only. No semantic understanding, OCR, subtitle-collision detection, face/character identity checks, transcription, translation, speech synthesis or generative model was added in this round.
- The plugin does not install FFmpeg or any other external program. Configure `mediaRoots`, `ffmpegPath` and `ffprobePath`; then check runtime availability in the deployment environment.

## Verification

The unit/contract suite covers path confinement, symlink handling, overwrite rules, argument construction, parsing, bounds, output receipts, workflow bindings and approval metadata. A separate integration test creates real media with the installed FFmpeg binary, including an intentional black lead and frozen tail, then verifies black/freeze detection as well as probe, signal analysis, contact sheet, frame extraction, two-pass loudness normalization, H.264 transcode, audio extraction and embedded subtitle extraction.
