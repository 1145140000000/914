# DSH Ultimate 2.0 — Motion Intelligence R2

## Scope

This increment adopts the architecture patterns observed in KIRO Motion Studio without copying its repository implementation or adding its runtime dependencies to the Orchestrator core. The core remains Node-built-in-only. Canvas, SVG, Three.js/WebGL, Chromium, Playwright, and native canvas packages remain optional external renderer adapters/sidecars; no such backend is bundled or claimed as operational in this increment.

## Added modules

- `motion-style-profile.js`: selectable `restrained`, `kinetic`, `collage`, `chrome3d`, and `vj` profiles. Overrides are bounded; palettes and transitions are validated.
- `renderer-contract.js`: adapter shape, capability negotiation, project validation, frame rendering, segment rendering, and optional disposal contract. This defines the boundary; it does not itself render pixels.
- `audio-analysis.js`: BPM beat-grid construction, beat phase, and evidence-preserving section validation. Missing BPM remains `unknown`; section labels retain source/confidence.
- `motion-recipes.js`: deterministic seeded procedural particle coordinates and bounded reusable transition/particle/camera recipes.
- `render-manifest.js`: frame-exact, half-open segment ranges, project fingerprint, completion receipts and progress summaries. A marker alone is not accepted as proof; completion requires matching frame range, project hash, and input/output hashes.

## New Orchestrator tools

`creative_motion_style_profiles`, `creative_motion_style_resolve`, `creative_audio_beat_grid`, `creative_audio_sections_validate`, `creative_motion_recipe_resolve`, `creative_render_manifest_create`, and `creative_render_progress`.

## Determinism and safety

- No random or wall-clock calls in render-time functions; procedural values are derived from SHA-256 seeds.
- Audio data must be measured or explicitly user-supplied; the engine does not invent BPM or song sections.
- Segment intervals are `[startFrame, endFrame)` to prevent duplicate or missing boundary frames.
- External renderers are negotiated by declared capabilities and project validation; no arbitrary package loading or shell execution is introduced.
- No credentials are read or stored by these modules.

## Not yet implemented / not verified

- No Canvas/Three.js/Chromium backend is included yet.
- No ffmpeg render executor, parallel process supervisor, cancellation/timeout/kill confirmation, or actual segment file hash verification is added here.
- No real DSH host installation, browser UI test, model call, audio-file BPM extraction, or end-to-end video render was run. The current audio module consumes supplied analysis evidence; it is not an audio analyzer.
- The adapter contract's `renderFrame` / `renderSegment` methods require a separately installed backend implementation.

## Validation

See `ROUND5-VALIDATION.md` for exact test and self-check results.
