# 三插件与 Orchestrator 集成流程

## 推荐任务链

1. `atomstudy_learn_video` 学习参考片，产出 styleCard 与来源证据。
2. `creative_task_create` 建立项目任务，步骤使用稳定 ID 与 idempotencyKey。
3. `creative_director_decide` 使用显式 provider/model 经宿主 `ctx.llm.stream` 生成结构化执行计划；若返回 `degraded`，按 fallback plan 执行并标记未使用强模型。
4. 将 styleCard 交给 `svg_motion_brief.referenceCard`，再调用 `svg_motion_storyboard` 与 `svg_motion_transition`。
5. 将时间轴结构交给 `creative_timeline_validate`；每个执行节点开始/结束后更新状态并写入 `creative_task_checkpoint`。
6. 当前 Agent 执行浏览器可预览 SVG/HTML、Chromium 逐帧渲染和 FFmpeg 合成。执行器必须将副作用节点设计成幂等或在重试前检查已有产物。
7. 真实渲染器/检测器输出 evidence，交给 `creative_visual_qa`；再交给 `svg_motion_score` 做原有审美与 craft 门。规则 QA 通过不代表主观审美通过。
8. 通过后把有来源、有适用范围的经验保存到 `creative_knowledge_save`；素材只登记 metadata 到 `creative_asset_register`。
9. 提示词使用 `creative_prompt_version` 固定版本；在相同测试集与参数下执行 A/B，再用 `creative_prompt_compare` 比较。

## 工具职责分离

- Orchestrator：任务生命周期、状态恢复、计划、元数据、证据汇总、工作流目录。
- SVG Motion：设计简报、分镜、转场、视觉风格与审美/craft gate。
- Atomstudy：参考片学习、风格证据、知识任务和学习资料。
- AI-PJ：提示词层约束，不承担任务执行、模型调度或渲染。

## 恢复约定

`paused` 任务可经 `creative_task_transition` 转回 `running`。读取任务后，只从最后一个已验证 checkpoint 之后继续。对于发送消息、发布、上传、删除、付费、外部生成请求等副作用步骤，不得只因缺少 checkpoint 就盲目重放；先用 idempotencyKey、产物 hash 或目标系统状态核实。
