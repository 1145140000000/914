# DSH Ultimate 2.0：DrawAI 与 llc-pv-skill 参考吸收记录

日期：2026-11-14  
基线：DSH Ultimate 2.0 Round 4 R2（任务索引 128 分片）

## 1. 参考源与审查范围

| 仓库 | 审查版本 | 重点材料 | 对 DSH 的价值 |
|---|---|---|---|
| [fourzkw/dsh-drawai](https://github.com/fourzkw/dsh-drawai) | `master` tree `2f3d6a80a3f4477904c74d5b1f28a68efa6051d3` | README、`docs/motion-video-playbook.md`、`docs/performance-baseline.md`、`docs/performance-queue-plan.md`、`docs/visual-quality-plan.md`、motion planner / worker / film-review 实现 | 制作阶段门禁、首镜打样、真实成片检查、分阶段性能数据、资源预算与背压 |
| [Youtich-A/llc-pv-skill](https://github.com/Youtich-A/llc-pv-skill) | `main` tree `772466971f8828f7ee03a0c2b2f1c674418f1d55`（0.4.0-alpha.2） | `SKILL.md`、`references/segment_workflow.md`、`references/review.md`、`references/review_execution.md`、`references/music_sections.md`、`references/script_standard.md`、`references/feedback_and_handoff.md`、`scripts/validate_review.py` | 长片自然分段、全局音乐相位、逐镜任务文件、三轮证据审查、问题闭环及版本绑定用户肯定 |

本轮通过 GitHub 仓库文件与目录树审查设计和实现；不是对两个仓库的完整构建、部署或端到端制作验收。源码许可及其第三方组件许可需要按各自仓库的 LICENSE / notices 进一步逐文件核对。

## 2. 设计选择

### 2.1 吸收进 Creative Orchestrator

1. **导演计划从“时间比例草图”升级为帧级制作契约。** 镜头使用半开帧区间 `[startFrame,endFrameExclusive)`，由帧区间作为权威，避免逐秒四舍五入造成重叠或漏帧。
2. **工作分段与剪辑分段严格区分。** 默认约 20 秒，最长默认 25 秒；可由调用方提供的自然边界候选优先切分（候选本身仍标记为未验证）。没有可靠切点时产生内部 checkpoint，并携带父级变换、相机状态、运动相位、实例 ID 与音频 PTS。`editorialCut:false` 表示这只是制作/上下文分段，不能擅自变成硬切。
3. **音乐章节必须有证据。** `intro / verse / chorus / interlude / bridge / outro / unknown` 独立于工作段；没有听校/用户提供证据时回落 `unknown`。前奏、间奏、副歌可提高 QA 优先级，但不能免除主歌检查。
4. **声音前置决定。** 声音模式未确定时是 `undecided`，不是静音；音频 cue 与 loudness 约束进入分镜确认门禁。
5. **首镜打样和用户批准成为显式门禁。** P4 必须绑定首镜预览版本和用户肯定；模型输出成功、规则 QA 通过或用户沉默都不能替代授权。后续量产门禁依赖该版本的明确批准。
6. **性能比较要有基准和资源背压。** 固定输入摘要、渲染器版本、分辨率、帧率和质量参数；至少 3 次报告 wall time / 阶段耗时 / 内存 / 帧速率 / 输出体积。阶段计时有包含关系时不能简单求和；缓存和 in-flight 缓冲必须有界，不能通过丢帧或静默降质提速。

### 2.2 新增的三轮审查记录契约

`creative_review_validate` 对结构化记录进行检查：

- 精确覆盖参考范围与当前授权输出范围（半开区间）；
- 恰好三轮、按 1→2→3 顺序，且每轮都绑定最新输出版本；
- 镜头 ID 全覆盖且无重复；
- 每轮有本轮 reference invocation、完整问题列表、引用/输出/manifest 证据；
- 区分 `viewed` 与 `measured`，仅生成（`generated`）不算已审查；
- 未关闭问题不能通过；`accepted_difference` 必须记录用户授权；修复问题需附回归证据；
- 最终用户肯定必须引用精确的最新 render version 和用户原话；
- 证据路径必须是项目内相对路径，阻断 `..`、绝对路径和盘符路径。

最小记录骨架（每轮都要分别填本轮调用、覆盖范围、完整镜头列表与证据，不应直接复用同一轮的“已观看”声明）：

```json
{
  "schemaVersion": 1,
  "referenceRange": [0, 1200],
  "segmentRange": [0, 600],
  "latestRender": { "version": "render-v4", "sha256": "<64位实际SHA-256>" },
  "shotIds": ["S001"],
  "rounds": [
    {
      "number": 1,
      "status": "passed",
      "outputVersion": "render-v4",
      "referenceInvocation": "本轮实际 video-watch 调用记录",
      "referenceViewedRanges": [[0, 1200]],
      "outputViewedRanges": [[0, 600]],
      "shotIds": ["S001"],
      "issues": [],
      "evidence": [
        { "role": "reference", "state": "viewed", "path": "evidence/reference.png", "sha256": "<实际摘要>" },
        { "role": "output", "state": "viewed", "path": "evidence/output.png", "sha256": "<实际摘要>" },
        { "role": "manifest", "state": "measured", "path": "evidence/manifest.json", "sha256": "<实际摘要>" }
      ]
    }
  ],
  "userAcceptance": { "status": "accepted", "renderVersion": "render-v4", "quote": "用户对该版本的明确肯定原话" }
}
```

上例 `rounds` 为展示字段结构，实际必须有 `number:1/2/3` 的三条记录；摘要占位符必须替换成实际 64 位 SHA-256。调用 `creative_review_validate({record})`。

校验器返回 `declarationConsistent` 与 `releaseEligible`，**不返回“视觉质量 pass”**。它不真实打开文件、不重算 SHA-256、不证明文件已被人类或视觉模型观看，也无法证明用户原话真实性；这些仍需真实执行器、证据采集与宿主确认。

## 3. 本轮代码改动

| 文件 | 改动 |
|---|---|
| `dsh-creative-orchestrator/lib/director.js` | 新增帧级连续镜头区间、自然边界优先的工作分段、长镜 checkpoint 连续性字段、显式音乐章节状态、前置 audio plan、P0–P7 production gates、固定基准与背压要求 |
| `dsh-creative-orchestrator/lib/review.js` | 新增三轮审查声明校验、覆盖区间合并、证据状态/摘要/相对路径约束、问题闭环和版本绑定用户批准 |
| `dsh-creative-orchestrator/index.js` | 扩展 `creative_director_plan` 参数；新增 `creative_review_validate` 工具 |
| `dsh-creative-orchestrator/lib/workflow-market.js` | 更新内置视频导演、参考学习、发布 QA 工作流步骤目录 |
| `dsh-creative-orchestrator/tests/director.test.mjs` | 覆盖帧区间、自然切点、checkpoint、音乐章节、音频门禁和范围边界 |
| `dsh-creative-orchestrator/tests/review.test.mjs` | 覆盖三轮顺序、时间缺口、镜头漏项、过期 render、证据状态、越界路径、未解决问题和用户批准绑定 |

仍保持 Creative Orchestrator 仅依赖 Node.js 内置模块；未复制 DrawAI 的 React / Remotion / Three.js 代码或运行时，也未安装远程 workflow。

## 4. 尚未完成 / 不能宣称完成的事项

- `naturalBoundariesSec` 必须由真实视频观察工具或用户提供；本轮没有新增镜头切点检测器；候选边界来源会标记为 `caller-provided-candidate-not-verified`，不能直接当作机器检测通过。
- `musicSections` 必须由真实听校或来源证据提供；本轮没有新增 ASR、音乐结构模型或音频播放器。
- P0–P7 当前是导演计划中的显式契约，不是 Worker 层不可绕过的强制状态机。真正阻止跳过 P4，需要将审批/门禁状态持久化并绑定 task step / render hash 后才能开放量产执行器。
- 三轮 validator 当前检查声明完整性和格式，不读取项目证据文件、不核验文件摘要实际值、不证明实际观看；宿主/视觉模型/人工审查流程仍需接入。
- 视觉像素 QA 仍缺少原尺寸图像解码、色带/抗锯齿、字体覆盖与字幕空间检测的真实证据适配器；不能凭分镜计划填充通过数据。
- 性能计划是测量契约，不代表已经跑过 3 次真实媒体基准；需接入渲染器后才可报告吞吐改善。
- 真实 DSH host profile、客户端界面、Chromium/FFmpeg 渲染及真实模型/视觉复核未在本轮验收。

## 5. 不直接照搬的内容

- DrawAI 的可编辑画布、侧栏 UI、`.drawai` 文件结构与 DSH 宿主补丁：属于不同插件架构，当前项目优先保持 Orchestrator 作为上层编排。
- DrawAI 的 Remotion、React、Three.js、WebGL 与字体/素材运行环境：体积、依赖和运行时边界不符合本插件 zero-dependency 约束。
- Shotcraft 的整套镜头卡/风格包库与具体 demo：可以作为用户资产/参考数据，但不应把未经许可核对的实现代码或字体/纹理直接复制到工程。
- llc-pv-skill 的 AE MCP、PSD2Live、ImageMagick、Python 扩展量测等具体集成：都应在独立适配器且获得用户同意后接入，不能成为基础插件的强制依赖。
- “三轮”不能被解释为三次自动模型调用即可发布；必须真实覆盖最新版本，并保持人工/用户验收边界。

## 6. 建议后续顺序

1. **R4.3**：Worker 执行器生命周期：取消/超时/退出确认、租约心跳、重试退避、幂等副作用和崩溃恢复；在任务 step 上加入基于 render hash 的生产门禁。
2. **R4.4**：为渲染/审查产物建立 content-addressed evidence manifest；受限媒体 root 内实际校验路径、大小、SHA-256、ffprobe/ffmpeg 元数据。
3. **R4.5**：引入真实帧抽样与原尺寸局部证据、字幕/字体/像素 QA；分离机器检测、视觉模型复核与人工结论。
4. **R5**：固定素材的端到端基准、共享资源预算与有界队列背压；用中位数和内存峰值报告收益，任何降级明确写入 deviation。

所有新增能力应保留“未配置 / 未执行 / 未核验”状态，不用默认值伪装成已通过。
