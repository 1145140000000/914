# DSH Ultimate 2.0 — 第二轮持续开发记录

日期：2026-11-14

## 本次实际修改

### 可靠性与任务状态
- 为任务、知识、提示词和素材写入增加跨进程目录锁 `.write.lock`。
- 锁等待具备超时；超过陈旧阈值的锁先通过原子 rename 隔离，再清理；持锁期间以 owner token 保护心跳和释放，避免误删其他进程的新锁。
- 新增步骤状态更新工具 `creative_task_step_update`。
- 新增 Worker 原子领取、心跳续租和主动释放工具。
- 新增可选 `createWorker()` 运行时：执行器注入、轮询、心跳、步骤执行、失败落盘、优雅停止；checkpoint 恢复必须显式提供 `resumeStep`，否则安全暂停。
- 新增 `inspectMedia()` 和 `creative_media_inspect`：在 `mediaRoots` 白名单内调用真实 ffprobe/ffmpeg，采集媒体元数据、黑帧和冻结帧证据。
- 支持租约过期的 running 任务被新 Worker 接管；租约持有者校验覆盖步骤更新、检查点和任务状态迁移。
- 步骤支持 `pending -> running -> checkpointed/completed/failed`，并支持失败重试、跳过。
- `attempts` 在步骤进入 running 时递增，不再在写 checkpoint 时递增。
- 禁止仍有未完成步骤的任务被标记为 completed。
- 创建任务时拒绝重复步骤 ID 和重复幂等键。

### 测试
- 新增两个独立 Node 子进程共享同一 dataRoot 的并发写测试。
- 新增 Worker 并发领取唯一性、续租、释放和租约所有权测试。
- 新增重复步骤 ID / 幂等键校验测试。
- 更新任务生命周期测试，覆盖步骤状态与任务完成门禁。

## 本次验证结果

- `dsh-creative-orchestrator`: 22 tests passed, 0 failed；包含真实 ffmpeg 生成测试视频并检测黑帧，以及路径白名单拒绝测试。
- `dsh-svg-motion` selfcheck: planner / quality gate / reference card / transitions 测试通过；宿主依赖装载测试因隔离环境未安装 `@deepseek-ai/schemastery` 而跳过；profile 组合未找到目标插件登记。
- `dsh-atomstudy` selfcheck: 106 pass, 0 fail；宿主 Schemastery 运行时导入因隔离环境缺依赖而跳过。
- `dsh-aipj-preset` verify: 37 pass, 0 fail；目标 profile 不存在，安装副本与 3081 Web 服务检查跳过。

## 尚未完成，不得宣称已完成

- 插件托管的常驻后台调度器、Worker 进程监督和系统级自动恢复扫描。
- 真实宿主模型路由及 provider fallback 联调。
- Chromium 截帧、FFmpeg 渲染/合成执行器及完整端到端生产管线。
- 字幕 OCR/碰撞、帧差、平均亮度曲线、场景数和语义视觉复核。
- 视觉模型语义复核与自动修复闭环。
- 工作流签名、权限审批、沙箱和远程市场。
- 真实 DSH profile 安装、浏览器 UI 和端到端视频生产验收。

## 重要边界

本次已实现共享 dataRoot 的跨进程写互斥和 Worker 租约原语，但尚不等于完整分布式任务队列：没有常驻调度器、Worker 进程监督或自动恢复扫描。租约过期只允许新 Worker 接管任务，不会自动重放步骤；外部副作用仍必须由执行器根据幂等键和实际结果决定是否重试。

## 体验方向与一键配置（追加）

- 新增 `docs/ULTIMATE-2.0-DIRECTION-AND-UX.md`，明确流畅度、一键化、自由度、可解释智能四个体验支柱，以及 Auto Pilot / Co-pilot / Manual 三种驾驶模式。
- 新增 Quick / Balanced / Studio 配置档案，支持白名单覆盖；配置持久化到 `settings.json`，复用原子写入、权限与跨进程锁。
- 新增 `creative_setup_profiles`、`creative_setup_apply`、`creative_setup_status` 三个工具。
- Director 可读取 `routing.roles.director` 角色配置。
- 配置验证覆盖非法字段、非法路由属性、档案默认值、持久化和工具调用。

- 追加 `creative_setup_diagnose`：实测 FFmpeg/FFprobe 是否可执行、宿主是否暴露 `ctx.llm.stream`、媒体目录是否存在且可访问；明确区分“工具可用”和“渲染器已集成”。
- 本轮编排器测试更新为 29 tests passed / 0 failed；SVG Motion 4 suites passed；Atomstudy selfcheck 106 pass / 0 fail；AI-PJ verify 37 pass / 0 fail。

- Worker 空闲轮询增加有上限的自适应退避；应用 Quick/Balanced/Studio 档案后自动读取持久化轮询间隔与租约时长。新增测试验证配置继承与退避上限。
- `maxConcurrentTasks` / `retryPolicy` 明确标记为策略元数据，待多 Worker 监督器和副作用安全策略接入后再强制执行。


## 第三轮增量：驾驶模式执行策略与审批闭环

### 实际修改
- 新增 `lib/execution-policy.js`：纯函数评估 manual / copilot / autopilot，校验 sideEffect、riskLevel、requiredCapabilities 和单步审批指纹。
- 扩展任务步骤元数据：`sideEffect`、`riskLevel`、`approvalPolicy`、`requiredCapabilities`，创建时严格校验枚举与能力标识。
- Store 新增审批请求、批准/拒绝、待审批列表；审批记录进入任务事件，批准只对当前步骤定义有效，执行开始后消费。
- Worker 在每次 `runOnce()` 时重新读取配置；manual 不领取任务；copilot 对外部副作用/medium 及以上风险步骤暂停；autopilot 仅在显式授权的副作用、风险级别和能力范围内执行。
- 新增 `creative_task_approval_list` 与 `creative_task_approval_decide`，编排器公共工具数由 28 增至 30。
- Quick / Balanced / Studio 默认使用 copilot，autopilot 授权默认关闭。

### 安全与能力边界
- 审批作用域指纹覆盖步骤 action、副作用类型、风险等级、审批策略及所需能力；定义变化后旧审批不能使用。
- 审批在步骤进入 running 时标记为 consumed，避免一次批准在失败恢复时被重复利用。
- 当前宿主未提供可验证 actor/confirmation 接口；`reviewer` 仅为调用方审计标签，不是认证身份。审批决策工具应由用户明确触发。
- 尚未实现可视化控制面、真实身份认证/签名审批、自动启动 Worker、并发监督器或外部执行器。

### 本轮新增验证
- execution-policy 单测覆盖三种驾驶模式、autopilot deny-by-default、sideEffect/risk/capability 授权及审批范围指纹。
- Worker 集成测试覆盖 manual 不领取任务、copilot 审批请求与一次性批准、autopilot 授权边界、越权暂停、拒绝审计。
- Store 测试覆盖非法步骤策略元数据、审批范围变化拒绝。


## 第四轮增量：配置版本、变更摘要与回滚

### 实际修改
- Store 新增 `settings-history.json`、`settings-versions/`，每次配置有实质变化时保存快照与递增版本号。
- 历史只返回版本、时间、原因和字段路径摘要，不返回配置值；最多保留最近 40 个版本。
- 新增 `creative_setup_history` / `creative_setup_rollback`；回滚读取历史快照，并把目标内容写成新的当前版本（内容已相同则作为 no-op）。
- 配置写入拒绝 token、secret、password、API key、cookie、session、credential、auth 等凭据类字段；仍不接触宿主凭据。
- Worker 增加单实例 single-flight 保护，避免同一 Worker 对象被并发 `runOnce()` 时同时运行多个任务。每个步骤边界重新读取授权，确保运行中的长任务能响应权限撤销。

### 本轮新增验证
- 配置版本测试覆盖变更路径、版本快照、回滚生成新版本、重复应用 no-op、凭据字段拒绝。
- Worker 测试覆盖授权在步骤之间撤销后的即时拦截、同一 Worker 实例并发调用保护。


## 第五轮增量：任务分页与事件游标

### 实际修改
- Store 新增 `listTasksPage({status, limit, cursor})`，支持状态筛选、最多 100 条/页和 offset cursor。
- 新增 `readTaskEvents(id, {after, limit})`，最多 200 条/次，返回 `nextCursor`、`hasMore`、revision 与 eventCount。
- 新增 `creative_task_page` / `creative_task_events` 两个工具，公共工具数增至 34。

### 诚实边界
- 当前分页与事件游标减少调用方单次接收的数据量，但 Store 仍需扫描任务 JSON 文件；事件仍保存在任务 JSON 内部，因此底层磁盘读取和任务记录重写仍不是常数复杂度。下一阶段可在保证旧任务迁移和崩溃恢复的前提下引入状态摘要索引与独立 append-only 事件日志。

## 第三轮交付验证汇总

- Creative Orchestrator：49 passed / 0 failed。
- SVG Motion：4 suites passed / 0 failed；selfcheck 通过（宿主 Schemastery 与目标 profile 缺失，因此宿主装载/安装环节 skip）。
- Atomstudy：106 passed / 0 failed（宿主 Schemastery 导入因隔离环境缺依赖而 skip）。
- AI-PJ：37 passed / 0 failed（无目标 profile / 3081 服务，相关宿主检查 skip）。
- 全工程 JS/MJS 语法检查通过。
- 详细范围与边界见 `docs/ROUND3-RELEASE-CHECKLIST.md`、`docs/EXECUTION-POLICY-AND-APPROVALS.md`。
