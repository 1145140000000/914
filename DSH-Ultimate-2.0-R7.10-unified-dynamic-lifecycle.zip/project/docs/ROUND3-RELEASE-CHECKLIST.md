# DSH Ultimate 2.0 — 第三轮增量交付说明

日期：2026-11-14

## 本轮落地

1. **执行权限策略**：manual / copilot / autopilot 进入 Worker 核心；步骤元数据包括 sideEffect、riskLevel、approvalPolicy、requiredCapabilities；策略异常时 fail-closed。
2. **审批闭环**：审批请求和结果持久化；批准绑定步骤定义指纹；执行启动即消费；拒绝留在 paused；相关事件可追溯。
3. **动态授权撤销**：Worker 每个步骤边界重新读取执行设置；撤销 Auto Pilot 授权会拦截任务后续步骤。
4. **配置可回退**：设置版本快照、字段级变更摘要、最近 40 版保留、回滚入口；配置持久化拒绝凭据类字段。
5. **任务读取接口**：新增摘要分页与事件游标读取；降低单次响应数据量，但底层全文件扫描/事件内嵌尚未优化。
6. **Worker 单实例保护**：同一个 Worker 对象不允许并发执行两个 `runOnce()`。

## 新增工具

- `creative_setup_history`
- `creative_setup_rollback`
- `creative_task_approval_list`
- `creative_task_approval_decide`
- `creative_task_page`
- `creative_task_events`

公共工具数：34。

## 验证

- Creative Orchestrator：49 passed / 0 failed。
- SVG Motion：4 suites passed / 0 failed；selfcheck 通过。因隔离环境缺少宿主 Schemastery 包和目标 profile，宿主集成/安装检查按脚本规则 skip。
- Atomstudy：106 passed / 0 failed；宿主 Schemastery 导入按隔离环境限制 skip。
- AI-PJ：37 passed / 0 failed；未安装目标 profile 与 web 服务检查按环境限制 skip。
- 全工程 JS/MJS `node --check`：通过。

## 已知边界

- 没有真实 DSH profile，因此本轮不是宿主安装验收，也没有浏览器页面验收。
- 审批 `reviewer` 是调用方输入的审计标签，不是通过宿主验证的身份。真实审批 UI/签名需宿主 actor/confirmation 能力。
- 没有内置常驻 Worker 监督器；Worker 仍由调用方显式创建并注入执行器。
- `maxConcurrentTasks` 仍是配置策略元数据，不是多进程并发强制限制。
- 任务分页目前降低返回 payload，但底层仍扫描 JSON；事件仍内嵌 task JSON。下一阶段应引入状态索引和独立 append-only event log。
- Chromium 渲染器、FFmpeg 生产执行器、字幕 OCR、帧差/亮度完整 QA、语义视觉复核仍未端到端接入。
