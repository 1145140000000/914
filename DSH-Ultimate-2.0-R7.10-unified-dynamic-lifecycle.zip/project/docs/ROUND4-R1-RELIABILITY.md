# DSH Ultimate 2.0 — 第四轮 R4.1：长任务可靠性

## 本轮目标

控制任务记录增长，修复历史事件裁剪后的游标错位风险，减少普通任务分页时对每个任务 JSON 的逐一读取，并避免执行器返回超大对象破坏任务持久化。

## 变更

### 1. 有界事件日志

- 默认保留上限：500 条。
- 保留事件 JSON 总量上限：256 KiB。
- 当任一上限超出时，从最旧端裁剪；`eventOffset` 增加裁剪条数。
- 旧任务没有 `eventOffset` 时按 0 兼容；首次追加事件时会自动初始化。
- 任务记录的 1 MiB 原子写入保护仍保留。

### 2. 稳定绝对游标

`readTaskEvents(id, { after, limit })` 将 `after` 解释为绝对事件序号，而不是当前数组下标。响应字段：

- `eventOffset`：第一条保留事件的绝对序号。
- `eventCount` / `totalEventCount`：已知绝对事件总数（`eventOffset + retainedEventCount`）。
- `retainedEventCount`：当前保留事件数量。
- `requestedCursor`：调用方请求的游标。
- `cursor`：本页实际起点；若请求游标已过期，会自动移动到 `eventOffset`。
- `truncated`：请求游标早于 `eventOffset` 时为 true。
- `nextCursor`：下一页的绝对序号，没有更多事件时为 null。

客户端不得把 `truncated: true` 当作无损增量读取；需要提示历史部分已被裁剪，并从返回游标继续。

### 3. 可恢复任务摘要索引

- 新增 `tasks-index.json`，内含全局排序摘要和按任务状态分桶的排序摘要。
- `listTasks()` / `listTasksPage()` 从索引读取，不再在每次列表请求时逐个解析任务文件。
- Worker claim 使用按 `createdAt` 升序维护的 queued / 有租约 running 候选桶，再只读取最终命中的任务文件；过期时间在读取时动态判断，避免全量打开所有任务文件寻找可领取任务。
- 所有任务写入使用统一 `writeTaskLocked()` 路径。
- 写任务之前先创建 `.tasks-index.dirty`；任务文件和索引成功更新后才移除标记。
- 若进程中断、索引损坏或索引丢失，下一次列表读取会在跨进程写锁内从任务 JSON 重建索引。
- 任务 JSON 是事实来源；索引是可以丢弃的派生数据。

**性能边界**：这是单文件物化摘要索引，不是 SQLite/B-tree。常规分页避免 N 个任务文件的读取和解析，但仍需加载/解析索引 JSON；索引更新会重写索引文件。首次重建、dirty marker 存在或损坏时仍会扫描任务目录。`listPendingApprovals()` 当前仍逐项检查任务文件。

### 4. 执行结果尺寸保护

- 单步 output JSON 序列化后最多 256 KiB。
- checkpoint payload JSON 序列化后最多 256 KiB。
- 对增加 output/checkpoint 的任务，完整 pretty JSON 记录还必须不超过 900 KiB；任务文件物理写入上限仍为 1 MiB，额外预留空间用于后续事件和状态元数据。
- 超限或不可 JSON 序列化时，在写入任务文件之前拒绝。
- Worker 收到超大输出时将当前步骤与任务标记为 failed，不持久化该输出。

## 验证

- 事件数量裁剪与绝对游标续读。
- 大体积旧事件裁剪与字节上限。
- 缺失 `eventOffset` 的旧任务兼容。
- 超大 output/checkpoint 拒绝且原状态不变。
- Worker 超大输出失败路径。
- 任务状态分页、索引损坏重建、dirty marker 中断恢复。
- 跨进程并发写入与任务列表正确性。

测试结果以本轮 `ROUND4-RELEASE-CHECKLIST.md` 为准。

## 未包含 / 后续方向

- 独立 append-only 事件日志与快照压缩。
- 按文件分片或数据库化的任务索引，降低大索引全量 JSON 解析与重写成本。
- `listPendingApprovals()` 的专用待审批索引。
- Worker 执行超时和安全终止语义（不能仅 Promise.race 后假装外部副作用已停止）。
- 真实 DSH profile、浏览器和宿主模型端到端验收。
