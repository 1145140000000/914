# DSH Ultimate 2.0 — 第四轮 R4.2：分片任务索引与审批待办

## 目标

R4.1 将任务摘要放在单个 JSON 文件中，虽然避免逐条打开任务记录，但索引仍会随任务量线性增长；每次任务写入还要重写整个索引。审批待办列表也仍要扫描所有任务记录。R4.2 保留任务 JSON 为唯一事实来源，将摘要索引拆成确定性分片，并为审批待办提供独立读取路径。

## 数据布局

```text
dataRoot/
├── jobs/                         # 唯一权威任务记录
├── task-index-v2/
│   ├── manifest.json             # schemaVersion=2、revision、计数、分片 SHA-256
│   └── shards/
│       ├── 000.json
│       ├── 001.json
│       └── ... 127.json
└── .task-index-v2.dirty          # 多文件任务写入/重建期间的恢复标记
```

任务 ID 通过 SHA-256 映射到 128 个固定分片。每个分片包含：全量预排序摘要、各任务状态摘要桶、Worker 可领取候选桶，以及审批待办桶。manifest 记录每个分片的摘要哈希、全局计数、状态计数、claimable 数量、pending approval 数量和索引 revision。

## 更新和崩溃恢复

任务 JSON 是唯一事实来源，分片均为可丢弃派生数据。正常任务更新的顺序为：

1. 在写锁内读取 manifest 和目标分片，并验证分片 SHA-256。
2. 写入 `.task-index-v2.dirty`。
3. 原子替换任务 JSON。
4. 仅重写任务 ID 对应的分片。
5. 更新 manifest 中的计数、revision 和该分片 SHA-256。
6. 清除 dirty marker。

如果进程在任意中间步骤退出，dirty marker 会保留；下一次索引读取在跨进程写锁内扫描权威 `jobs/` 记录并重建 128 个分片，最后原子写 manifest 并清除 marker。单个分片缺失、JSON 损坏或 SHA-256 不匹配时也触发完整重建。成功迁移后会移除 R4.1 的 `tasks-index.json` 和 `.tasks-index.dirty`。

## 查询路径

- `creative_task_page`：读取分片中的 all / byStatus 有序数组，使用 k-way merge 返回有限页。
- `creative_task_claim`：从各分片 claimable 数组做有序合并，只读取最终命中的任务 JSON；过期租约仍在读取命中任务后动态校验。
- `creative_task_approval_list`：从审批待办分片合并返回全部待办。
- `creative_task_approval_page`：分页读取审批待办，支持 limit / cursor / nextCursor。

## 复杂度与边界

- 单任务更新：任务记录 + 1 个分片 + manifest；不会重写所有摘要分片。
- 分片重建：O(N) 读取任务 JSON；这是首次迁移、dirty marker 或索引损坏时的恢复路径。
- 分页/claim：读取 128 个摘要分片并执行 k-way merge，摘要遍历总成本仍随任务总量增长；没有声称其为数据库/B-tree 或严格 O(log N)。
- 每个分片有 8 MiB 写入上限；固定 128 分片达到容量上限时会明确失败，不会悄悄丢弃任务。后续可以按容量做在线再分片或迁移至内置 SQLite（需单独验证宿主 Node 版本/编译能力后再决定）。
- 数字 offset 游标在索引 revision 变化后不承诺跨版本快照稳定；分页响应带 `indexRevision`，调用方在 revision 改变时应从第一页重新读取。

## 验证

- 6,000 条原始任务记录的首次重建、全局分页、状态筛选和审批分页。
- 分片 JSON 有效但内容被篡改时，SHA-256 校验能检测并从任务记录重建。
- 单任务状态迁移只改变一个分片 digest。
- R4.1 单体索引和旧 dirty marker 会在成功迁移后清理。
- 审批从真实 Worker 租约持有者请求，批准后从待办索引中移除。
- 保留原跨进程写入、Worker claim、lease、approval 与事件/结果容量回归。
