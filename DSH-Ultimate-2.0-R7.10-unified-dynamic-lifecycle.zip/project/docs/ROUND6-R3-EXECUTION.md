# DSH Ultimate 2.0 — Round 6 / Motion Execution R3

## Delivered

R3 turns the R2 renderer contract and render manifest into a file-backed execution path.

- `dsh-creative-orchestrator/lib/render-executor.js`: bounded concurrent segment execution, timeout/abort propagation, confirmed-stop checks, bounded retries with exponential backoff, atomic manifest persistence, output-root confinement, SHA-256 output receipts, and resume verification against the actual on-disk output.
- `lib/ffmpeg-finalizer.js`: safe FFmpeg segment concat + optional audio mux, trusted-media-root confinement, temporary output + atomic rename, ffprobe validation, and streaming SHA-256.
- `lib/process-supervisor.js`: optional Node built-in child-process supervisor. It never invokes a shell, bounds stdout/stderr, uses an explicit minimal environment instead of inheriting arbitrary host environment variables, sends SIGTERM then SIGKILL, and reports whether process closure was confirmed.
- `lib/svg-renderer.js`: first built-in zero-dependency renderer. It supports deterministic frame previews and browser-openable animated SVG segment outputs for rect/circle/text primitives, with strict input bounds and XML escaping.
- Orchestrator runtime exposes `registerRenderer(adapter)`, `creative_renderer_list`, and `creative_render_execute`. The native `svg-native` adapter is registered by default. Third-party renderers remain opt-in adapters; no Three.js, Chromium, Playwright, Canvas native package, or FFmpeg dependency is loaded by the core.

## Execution invariants

- Project data must hash to the `projectHash` in the manifest; renderer identity must match.
- Segment intervals remain half-open `[startFrame, endFrame)`.
- A completion marker is not trusted on resume. The output file must exist, be inside the configured output root, be non-empty, and match its SHA-256 digest and stable input fingerprint.
- Timeout first aborts the adapter. If the adapter promise does not settle within the termination grace period, the executor reports `terminationUnconfirmed`, stops scheduling additional segments, and does not retry that segment.
- Retries occur only after the previous adapter promise has settled. Attempts are bounded and use exponential backoff.
- Renderer execution writes only under the DSH data root through the public tool. Adapter output paths are checked again after resolving symlinks.
- Child processes run without `shell:true`; arbitrary inherited environment variables are not passed through by default.

## Tool usage

1. `creative_renderer_list` — inspect registered renderer capabilities.
2. `creative_render_manifest_create` — create a manifest with `fps`, `durationSec`, `segmentFrames`, `rendererId: "svg-native"`, and the exact project object.
3. `creative_render_execute` — pass the same project object and manifest, plus `rendererId: "svg-native"` and a safe `outputName`. Outputs are stored under the Orchestrator data root in `renders/<outputName>/`; the persisted manifest is in `render-manifests/<outputName>.json`.
4. `creative_render_progress` — inspect verified segment progress.
5. `creative_video_finalize` — concatenate completed video segments, optionally mux an audio track, and validate the resulting MP4. Input and output paths must be inside configured `mediaRoots`; the destination directory must already exist.

The SVG backend creates browser-openable animated `.svg` files, not MP4. FFmpeg finalization is now implemented for video segments produced by an external raster/video renderer; SVG-to-video rasterization is not implicit. Audio-file BPM/onset analysis, Canvas, and Chromium/Three.js adapters remain later integrations.

## Validation boundary

The Orchestrator suite has 97 passing tests, including successful rendering, output hashing, tamper detection and resume, retry behavior, timeout/abort confirmation, no-retry on unconfirmed stop, path escape rejection, process exit/timeout/SIGKILL handling, environment isolation, SVG rendering/validation, and finalizer path/probe/hash checks. A real FFmpeg + FFprobe smoke run also concatenated two 160×90 H.264 segments, muxed a generated WAV track, and verified a 2-second MP4. Plugin self-checks also run. The current sandbox does not contain the target DSH web profile or `@deepseek-ai/schemastery`, so real host installation, browser UI, model streaming, and production video export are not claimed.
