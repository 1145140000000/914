# Round 6 R4 — Chromium WebGL / Three.js rendering backend

## What is implemented

- `chromium-webgl` is a zero-dependency renderer adapter. It launches the system Chromium binary, connects through the Chrome DevTools Protocol (CDP), and renders a self-contained HTML document that implements `window.renderAt(t)`.
- The page is installed into an `about:blank` target with `Page.setDocumentContent`. This avoids navigating to `file:`, `data:` or localhost URLs, which are blocked by the managed Chromium policy in this runtime.
- A restrictive CSP is injected: scripts/styles must be inline or embedded; images, fonts and media must be data/blob-backed; network connections, frames and plugins are denied. Bundle media/assets into the HTML.
- WebGL is enabled with ANGLE/SwiftShader flags for headless software rendering. `renderFrame` returns PNG bytes; `renderSegment` captures the exact half-open frame interval `[startFrame, endFrame)` and encodes H.264 MP4 with FFmpeg.
- Temporary browser profiles and frame directories are private and removed after each render. Chromium is terminated on normal completion, errors and cancellation. Segment output remains confined by the existing render executor, which verifies file presence, size and SHA-256 before resume.
- `threejs-webgl` wraps the same Chromium backend. It accepts an explicitly supplied self-contained browser bundle exposing the `THREE` global plus a scene script. The scene script receives `THREE`, `scene`, `camera`, `renderer`, and a bounded `project` descriptor; it may set `window.update(t, frameIndex)` for deterministic time-dependent state. The adapter generates `window.renderAt(t, frameIndex)`, awaits asynchronous updates, and calls `window.dispose()` before closing the browser target. Scene and renderer resources are disposed best-effort, including WebGL context loss. Optional `project.threeRevision` enforces an exact `THREE.REVISION` match. Bundle and scene-script sizes are capped at 8 MiB and 1 MiB.
- FFmpeg finalization now probes each input segment's frame rate and decoded frame count, rejects mixed frame rates, pads the final presentation interval by one frame where needed, and caps output to the exact total frame budget. This prevents the concat demuxer from shortening the final video by the final frame duration.

## Minimal Chromium/WebGL project contract

```js
{
  width: 1920,
  height: 1080,
  fps: 30,
  durationFrames: 900,
  html: `<!doctype html><html><body>
    <canvas id="c" width="1920" height="1080"></canvas>
    <script>
      // Initialize WebGL and all assets here.
      // Must be deterministic for the same t and project inputs.
      window.renderAt = (t) => { /* update and draw one frame */ };
    </script>
  </body></html>`
}
```

The renderer samples time at `t = frame / fps`; segments use inclusive start and exclusive end. Avoid `Math.random()`, `Date.now()`, timers, wall-clock animation, external fetches and external assets. Use a seeded PRNG and derive all motion from `t`.

## Three.js scene script contract

The plugin does not vendor or install Three.js. Supply an audited, self-contained browser bundle from the user's approved Three.js version as `project.threeBundle`, and the scene initializer as `project.threeSceneScript`. The adapter creates a WebGLRenderer, Scene and PerspectiveCamera, then evaluates the scene script in the same inline script scope. Example scene script:

```js
const geometry = new THREE.TorusKnotGeometry(1.1, 0.28, 160, 20);
const material = new THREE.MeshNormalMaterial();
const mesh = new THREE.Mesh(geometry, material);
scene.add(mesh);
camera.position.set(0, 0, 5);
window.update = (t, frameIndex) => {
  mesh.rotation.x = t * 0.22;
  mesh.rotation.y = t * 0.37;
};
window.dispose = () => {
  geometry.dispose();
  material.dispose();
};
```

No network access is permitted in the render page. Do not put credentials, browser session data or host API keys in scene bundles or assets.

## Tests and verification

- `tests/chromium-webgl-renderer.test.mjs` is an actual Chromium/WebGL smoke test. It compiles and draws a WebGL shader, checks same-time PNG byte determinism, renders two MP4 segments, resumes from verified on-disk SHA-256 receipts, and finalizes an 8-frame 160×90 MP4. FFprobe checks dimensions, frame count and exact duration.
- `tests/threejs-renderer.test.mjs` validates bundle bounds, revision pinning, scene contract, and executes a minimal Three-compatible WebGL test harness through real Chromium to exercise bundle injection, deterministic frame capture and lifecycle. This harness is not the upstream Three.js library; it does **not** claim a real Three.js release or production scene was executed.
- `tests/ffmpeg-finalizer.test.mjs` covers path confinement and finalizer behavior using a controlled process runner.
- Full regression command: `npm test` from `dsh-creative-orchestrator`.

## Explicit limitations

- The current environment has Chromium 144 and FFmpeg 7.1 but no upstream Three.js package/bundle, Playwright or Puppeteer. The adapter's Three-compatible integration path is exercised with a test harness; a real upstream Three.js scene render is not yet verified. npm registry access was unavailable during this run, so no unverified bundle was downloaded or vendored.
- Rendering is headless software WebGL via SwiftShader in this test environment. GPU acceleration and cross-machine pixel identity are not guaranteed.
- `renderAt(t)` determinism is scene-dependent. The renderer cannot make nondeterministic user code deterministic automatically.
- This is a browser raster/MP4 backend, not a browser editor UI. UI integration and a live DSH host install still require validation in the target DSH profile.
