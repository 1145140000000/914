# Round 6 R4.1 — Three.js adapter lifecycle hardening

Date: 2026-11-14

## Changes

- Three.js browser bundle is explicitly supplied by the caller; no package install, network fetch, or vendored upstream source is introduced.
- Bundle size is limited to 8 MiB and scene script size to 1 MiB.
- Optional `project.threeRevision` enforces exact `THREE.REVISION` matching.
- Generated `window.renderAt(t, frameIndex)` awaits `window.update(t, frameIndex)` and then renders. The Chromium adapter now supplies the global frame index for both stills and half-open video segments.
- Generated `window.dispose()` invokes the scene's optional disposal hook, traverses scene geometry/material resources, disposes renderer render lists and renderer state, and requests WebGL context loss. Chromium invokes page disposal and closes the target before terminating the browser.
- Scene code remains responsible for deterministic, time-derived state and disposing resources it owns outside the scene graph.

## Verification

- Orchestrator: 101 tests passed, 0 failed.
- Three.js integration test executes a minimal Three-compatible WebGL harness in real Chromium/SwiftShader and checks byte-identical PNG output for repeated time samples. This verifies the adapter's injection/render path, not the upstream Three.js implementation.
- Chromium WebGL end-to-end test still renders two MP4 segments, verifies SHA-256 receipts, resumes without rerender, and FFprobe validates the final 8-frame / 2-second MP4.
- Full source syntax checks: 88 passed.
- SVG Motion: 4 suites passed and selfcheck passed; host-dependent checks skipped because the host package/profile are absent.
- Atomstudy: 106 passed / 0 failed.
- AI-PJ: 37 passed / 0 failed.

## Not verified

- No upstream Three.js distribution was available in the environment and npm registry DNS access failed. No third-party bundle was fabricated, downloaded, or embedded.
- Hardware GPU acceleration, a production Three.js scene, target DSH installation/browser UI, and native Canvas backend remain unverified/unimplemented.
