# Round 6 R5.1 — Evidence-backed audio tempo analysis

## Delivered

- Added `creative_audio_analyze` and the exported `audio-analyzer` module.
- Uses FFprobe for source metadata and FFmpeg to decode bounded mono float PCM (11,025 Hz).
- Computes a 512-sample RMS envelope, positive onset flux, normalized autocorrelation, a tempo estimate, phase offset, confidence, and the top tempo alternatives.
- Returns `unknown` when duration/evidence is insufficient; does not infer musical sections or downbeats.
- Resolves symlinks and confines source files to configured `mediaRoots` before invoking media tools.
- Bounds maximum duration (6–1,800 seconds), decode timeout, and in-memory envelope size. Uses `spawn` with `shell:false`.
- The output carries explicit provenance: `ffmpeg-rms-onset-autocorrelation`.

## Verification

- Synthetic 120 BPM click WAV is generated in the test, decoded by the installed FFmpeg, and tempo estimated within 3 BPM.
- Path traversal/out-of-root and duration-bound rejection are tested.
- Full Orchestrator test suite includes tool registration and analyzer integration.

## Known limitations

- RMS onset autocorrelation is a lightweight estimator, not a state-of-the-art perceptual beat tracker.
- Half-time/double-time ambiguity is possible; inspect returned alternatives and confidence.
- It does not infer musical sections, downbeats, key, mood, or source separation.
- A low-confidence result remains unknown; do not force a beat grid into director plans.
