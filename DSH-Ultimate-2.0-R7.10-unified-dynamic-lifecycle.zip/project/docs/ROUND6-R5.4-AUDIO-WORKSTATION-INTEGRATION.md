# Round 6 · R5.4 — Audio Workstation Integration

## Unified architecture

The R5.3 `dsh-creative-orchestrator` audio project is the authoritative DSH integration layer. The standalone `DSH Audio Engine 0.1.0` remains a reference for its Node built-in-only project/editor abstractions; it is not shipped as a second editor or a parallel project store. The standalone engine's unique helper concepts (`probe`, `makeClip`, `appendFiles`, and stem export) are candidates for adapter-level reuse, not reasons to fork project state. The DSH project store, analyzer, renderer and motion director share the existing `mediaRoots`, FFmpeg/FFprobe configuration and persistent `audio-projects` records.

## R5.4 implemented in this increment

- PCM waveform envelope from the same bounded FFmpeg decode used by analysis: per-window minimum, maximum and RMS, aggregated to at most `waveformPoints` (32–10,000; default 2,000).
- Waveform points include seconds and normalized mono amplitude bounds. This is a display envelope, not a sample-accurate editable waveform cache or a multichannel phase display.
- Immutable edit history with Undo/Redo, bounded to 50 entries and 512 KiB serialized history per project. Undo/Redo increments the project revision and never mutates source media. A new edit after Undo clears the redo branch.
- Existing R5.3 project schema remains version 1; legacy projects without `editHistory` are read as empty-history projects and gain history on their next edit.
- DSH tool `creative_audio_project_edit` accepts `undo` and `redo`; responses include `canUndo`, `canRedo`, and history depth.
- `creative_audio_analyze` returns `analysis.waveform` and accepts a bounded `waveformPoints` option.
- The separate engine's duplicate project model is not copied into DSH; the R5.3 project format and renderer remain canonical.

## Validation

Run from `dsh-creative-orchestrator`:

```sh
npm test
```

R5.3 baseline: 125 tests passed. R5.4 added waveform and edit-history coverage. R5.5/R5.6 extend the suite to 138 passing tests, including timeline viewport/snap/quantization, move/trim, stronger imported-project validation, DSH tool dispatch, atomic render-output preservation, and aligned Stem export.

## Explicit capability boundaries

This increment does not claim a finished browser DAW UI, realtime playback engine, scrubbing/audio preview, multichannel waveform visualization, effect rack, automation lanes, or DSH-host end-to-end browser validation. The current audio project is a durable non-destructive timeline model rendered through local FFmpeg. Source media remains unchanged.
