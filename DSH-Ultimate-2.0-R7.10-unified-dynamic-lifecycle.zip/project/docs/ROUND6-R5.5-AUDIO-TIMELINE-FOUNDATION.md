# DSH Ultimate 2.0 — Round 6 R5.5 Audio Timeline Foundation

## Consolidation decision

`dsh-creative-orchestrator/lib/audio-edit-project.js` is the single canonical project/edit model. The standalone `dsh-audio-engine 0.1.0` remains a historical prototype/reference and is not imported as a second runtime engine. Its useful capabilities (FFmpeg graph rendering, probing, codec selection and track export concepts) are represented by the canonical orchestrator modules. This avoids two competing project schemas and two undo histories.

## R5.5 implemented

- Timeline viewport conversion: seconds ↔ pixels using one immutable viewport mapping.
- Pixel-tolerance snapping to an optional grid and explicit markers.
- Sample-rate quantization for clip placement.
- Clip move across tracks while preserving source in/out, gain and fades.
- Left/right trimming in timeline coordinates while maintaining source-time alignment and clamping fades.
- Automatic timeline sorting after a clip's `at` value changes.
- Unified project validation now checks sample rate, channels, duration, revision, track gain/pan, clip gain/fades/fade curve in addition to IDs and source ranges.
- DSH `creative_audio_project_edit` exposes `move-clip` and `trim-clip`; these use the same immutable revision and undo snapshot path as existing edits.
- Renderer publication is safer: overwrite uses same-directory atomic rename without deleting the previous output first; no-overwrite publication uses an atomic hard link to close the exists-check race.

## Contracts

- Timeline coordinates are seconds; display coordinates are pixels; conversion always goes through `createAudioTimelineViewport`.
- Clip `at` is timeline start. `sourceIn`/`sourceOut` remain source-media coordinates.
- Moving a clip changes timeline position and optionally track only; trimming changes source bounds and aligned timeline edge.
- Snap tolerance is measured in screen pixels, not a fixed number of milliseconds, so zoom level does not change perceived snap distance.
- Placement can be quantized to the project's sample rate. No edit mutates source media.
- Render output is staged beside the destination. Existing output is preserved until a successful replacement can be atomically published.

## Verification

`npm test` — 138 tests pass after the R5.5/R5.6 additions. R5.6 adds aligned single-track Stem export and a real FFmpeg duration test.

This remains the editing-engine foundation, not a completed graphical DAW. The next UI phase must bind waveform, playhead, ruler, clip body and trim handles to this shared viewport/timebase and command API.
