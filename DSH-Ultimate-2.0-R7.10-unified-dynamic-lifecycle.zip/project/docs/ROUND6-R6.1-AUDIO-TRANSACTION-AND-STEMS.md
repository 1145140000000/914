# Round 6.1 — Audio project transactions and batch stems

## Delivered

- Added `store.updateRecord(area, id, updater)`: a cross-process locked read/modify/write transaction using the existing atomic record writer.
- Routed `creative_audio_project_edit` through that transaction. Add/remove/move/trim/split, track state, effects, automation, undo and redo now serialize against the latest persisted project instead of racing separate reads and writes.
- Added `creative_audio_stems_export`, accepting 1–64 `{trackId, outputPath}` entries. Paths must be unique; each track uses the same media-root checks, effect chain, automation, full-project duration and atomic output publication as single-stem export.
- Batch results report requested/succeeded/failed counts, partial success and a bounded per-item error message. One failed stem does not erase successful outputs.

## Verification

- Same-process concurrent update test: 40 simultaneous increments preserve all 40 updates.
- Cross-process concurrent update test: two independent Node processes perform 20 updates each; final value is 40.
- Cordis tool test verifies concurrent audio project edits persist both tracks and revision advances twice.
- Duplicate stem output paths are rejected before rendering.
- Full test suite and archive integrity checks are run for the R6.1 package; results are recorded in the release note.

## Boundaries

- Batch export is sequential to avoid uncontrolled FFmpeg process fan-out and disk pressure. A future concurrency setting should be tied to measured memory/CPU budgets.
- A failed item can leave already-published successful stems in place by design; callers should inspect the per-item result list before retrying.
- This does not add a browser DAW interface or live audio-device transport. Those require the actual host client/media bridge contract.
