# Round 6.2 — Portable audio projects and safer lock recovery

## Project document format

`creative_audio_project_document_export` returns a JSON document with format `dsh-audio-project`, document version 1, export timestamp, an explicit local-media-reference policy, the project snapshot and a SHA-256 digest over a canonical key-sorted serialization of the project object. Documents are capped at 8 MiB.

`creative_audio_project_document_import` checks size before processing, verifies format/version and digest, then runs the existing audio project invariant validator. A new project UUID is assigned, revision resets to zero, timestamps are renewed and undo/redo history is dropped. The store's create-only transaction ensures an existing ID cannot be replaced by a racing import.

Audio source paths remain references; this is a project-document portability feature, not a media packager. Moving a project between machines still requires the referenced source files to be available and permitted by `mediaRoots`.

## Lock recovery

The store's cross-process directory lock already had an atomic mkdir acquisition, owner token, heartbeat and quarantine rename for stale directories. R6.2 closes a stale-heartbeat race: after the stale age threshold, recovery reads the owner PID and probes process liveness. A live or permission-protected PID is not stolen; an absent process may be reclaimed. This intentionally favors waiting/timeouts over simultaneous writers when ownership cannot be disproved.

`createStore` accepts optional lock timeout/stale thresholds for controlled environments and tests; production defaults are unchanged (15,000 ms timeout and 120,000 ms stale threshold).

## Tests

- Project document round-trip preserves tracks, clips and media path references while changing identity.
- Digest tampering, unsupported versions/formats, oversized documents and unsafe IDs are rejected.
- Create-only storage preserves an existing record.
- A live process lock remains protected even after its directory timestamp is stale.
- A stale lock owned by a dead PID is recovered.
