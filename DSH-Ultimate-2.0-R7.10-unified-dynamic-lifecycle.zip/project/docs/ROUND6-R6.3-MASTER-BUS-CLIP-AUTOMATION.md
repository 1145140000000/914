# Round 6.3 — Master bus and clip automation

## Master bus processing

Audio projects now support an ordered `masterEffects` rack after all audible tracks are summed and before final padding/limiting. It uses the same eight validated effect types as track racks: high-pass, low-pass, parametric EQ, compressor, limiter, reverb, chorus and delay. The rack is bounded to 16 effects, each effect's parameters are normalized, IDs must be unique, and arbitrary FFmpeg filter text is not accepted.

The `creative_audio_project_edit` tool exposes the `master-effects` operation. Master rack edits are immutable project revisions and participate in the existing serialized persistence and undo/redo history. The field is optional when reading legacy schema-v1 projects, preserving backward compatibility.

## Clip-local volume automation

Each clip may now contain up to 2,000 dB automation points in clip-local seconds. Points are normalized, sorted, unique and bounded to -96..+24 dB. During rendering the clip is trimmed and its PTS reset before the envelope is evaluated, so automation time zero is the beginning of the clip, independent of its timeline placement.

Split and trim operations preserve the envelope: split creates interpolated boundary points and rebases the right-hand segment; left trim shifts points and inserts the interpolated new start value; right trim clips the envelope and inserts the interpolated end value. This avoids abrupt gain jumps or automation being replayed from the wrong time after edits.

## Validation

- Unit tests cover master rack bounds, immutability, project validation and clip automation invariants.
- Real FFmpeg integration tests render master EQ/compression and clip-local gain automation.
- The final renderer mixes an explicit duration-bounded silence bed, so projects with a declared tail keep their exact project duration even when the last audible clip ends earlier. Filter-complex execution is serialized for stable EOF handling.
- Existing project-document export/import continues to validate the project model and preserve optional master/clip processing fields.
- Existing track-level effects, automation, Stem export, preview rendering and media-root protections remain in place.

## Scope boundary

This adds offline renderer functionality and project data semantics. It does not implement real-time audio-device playback, browser waveform editing, plugin hosting/VST, or a full interactive DAW surface. Those require the target DSH host's client/media bridge and device lifecycle contract.

## R6.4 补充：LUFS 母带响度目标

工程导出工具新增可选单遍动态响度归一化（FFmpeg `loudnorm`）：
- `normalizeLoudness=true` 启用；默认目标为 -16 LUFS integrated、-1.5 dBTP true peak、11 LU LRA。
- 可分别指定 `targetIntegratedLufs`（-36..-5）、`targetTruePeakDbtp`（-9..0）和 `targetLraLu`（1..20）。
- 未启用时保持原渲染链不变；启用时在主总线效果和安全 limiter 后执行 loudnorm。
- 返回结果明确标注 `mode: single-pass-dynamic`。这是单遍动态归一化，不冒称两遍线性母带；对严格交付规范，仍建议先测量、再按测量值做两遍线性处理并复测。
- 该功能只生成新文件，不改写任何源素材。目标越界会在启动 FFmpeg 前拒绝。

## R6.4 补充：LUFS 母带响度目标

工程导出工具新增可选单遍动态响度归一化（FFmpeg `loudnorm`）：
- `normalizeLoudness=true` 启用；默认目标为 -16 LUFS integrated、-1.5 dBTP true peak、11 LU LRA。
- 可分别指定 `targetIntegratedLufs`（-36..-5）、`targetTruePeakDbtp`（-9..0）和 `targetLraLu`（1..20）。
- 未启用时保持原渲染链不变；启用时在主总线效果和安全 limiter 后执行 loudnorm。
- 返回结果明确标注 `mode: single-pass-dynamic`。这是单遍动态归一化，不冒称两遍线性母带；对严格交付规范，仍建议先测量、再按测量值做两遍线性处理并复测。
- 该功能只生成新文件，不改写任何源素材。目标越界会在启动 FFmpeg 前拒绝。
