# R6.5 — Audio safety inspection

R6.5 adds a read-only preflight/QA tool for rendered audio and source media.

## Tool

`creative_audio_safety_inspect` runs FFmpeg `astats` and `silencedetect`, and FFprobe duration inspection. It reports:

- Overall DC offset, peak level in dBFS, RMS level in dBFS, flat factor and sample count when FFmpeg exposes them.
- Silence intervals at a configurable threshold and minimum duration, including trailing silence when duration metadata is available.
- Warnings for low peak headroom, DC offset and detected silence.

All input paths are resolved and confined to configured `mediaRoots`. The tool does not alter the source file. Peak level close to 0 dBFS is reported as a headroom warning, not automatically labelled as proven clipping; a peak reading alone cannot establish clipped waveform history.

## Default thresholds

- Silence: -60 dBFS for at least 0.25 seconds.
- Peak headroom warning: at or above -1 dBFS.
- DC offset warning: absolute normalized offset at or above 0.01.

Thresholds are configurable per call and bounded. `status` is a triage result, not a mastering certification. LUFS/true-peak measurement remains available through `creative_audio_quality_measure`.

## Verification

The integration test generates synthetic audio with leading/trailing silence and a near-full-scale tone, then verifies measured fields, warnings, silence intervals, path confinement and source immutability. No live playback or browser UI is implied.
