# R6.6 — Bus / Aux routing

The project schema remains version 1 and adds optional `buses: []`. Tracks gain optional `outputBusId` and `sends` fields. Missing fields are interpreted as the original direct-to-master behavior.

## Tool operations

Use `creative_audio_project_edit`:

- `add-bus` with `bus: { id, name, gainDb, pan, mute, effects }`.
- `update-bus` with `busId` and `patch`.
- `remove-bus` with `busId`; references are removed from every track in the same immutable edit.
- `track-routing` with `trackId` and `routing: { outputBusId, sends }`.

A track with `outputBusId: null` feeds the master directly. A non-null `outputBusId` replaces that direct route with the selected bus. Each send is `{ busId, gainDb }`; sends are post-track-fader and post-track-effects, and preserve the track's direct route. Up to eight unique sends per track are accepted, with send gain bounded to -96..+12 dB.

Each bus sums direct track outputs and auxiliary sends, then applies bus gain (-96..+24 dB), pan (-1..1), mute and the same bounded effect rack used by tracks. Bus outputs are summed with direct-to-master tracks and then pass through the existing master effects, limiter and optional loudness normalization.

No bus-to-bus sends exist in this release, so the routing graph cannot contain bus cycles. Bus edits and routing edits are normal project revisions, persisted atomically and covered by the existing edit history. Project documents retain these optional fields without changing the schema version; older documents continue to load.

This path is offline rendering through FFmpeg. It does not provide low-latency live monitoring, pre-fader sends, or a browser routing console.
