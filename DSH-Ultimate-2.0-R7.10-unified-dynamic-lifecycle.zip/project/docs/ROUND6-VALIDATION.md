# Round 6 validation record

Date: 2026-11-14

## Core Orchestrator

- Orchestrator non-browser regression: **113 passed / 0 failed / 3 browser tests skipped** with `DSH_CHROMIUM_TEST=0`; browser integration separately: **5/5 passed**. Across these runs, all 116 unique test cases were exercised; two non-browser cases overlap the browser run.
- JavaScript / MJS syntax checks across the full source tree: **93 passed**.
- Coverage across R3/R4: renderer registration, SVG segments, Chromium CDP/WebGL shader rendering, deterministic PNG capture at a fixed time, two-segment H.264 encoding, SHA-256 resume, bounded retries, timeout/cancellation/termination confirmation, output path confinement, child-process environment isolation, FFmpeg finalizer frame-count/duration correction, FFprobe validation and hash checks. Three.js adapter bounds/revision/scene contract tests and a Chromium integration test using a minimal Three-compatible WebGL harness pass; no upstream Three.js bundle is installed in this environment.

## Plugin regressions

- `dsh-svg-motion`: 4 test suites passed; selfcheck passed source syntax, style preset consistency, planner, quality gate, reference card, and transition tests. Host package `@deepseek-ai/schemastery` and target profile are unavailable in this sandbox, so host assembly check was skipped.
- `dsh-atomstudy`: main selfcheck **106 passed / 0 failed**; S1 **28/28**, S2 **18/18**, S3 **7/7**. Local tunnel service and local browser login databases were absent; corresponding checks reported skips/no-database and did not attempt credential export.
- `dsh-aipj-preset`: **37 passed / 0 failed**, including **24 scorer cases**. Target profile and live DSH web server were unavailable, so host-dependent checks were skipped.

## Real media smoke tests

- Chromium 144 + SwiftShader executed a real WebGL shader. Repeated rendering at the same timestamp produced byte-identical PNG captures.
- The Chromium backend rendered two adjacent half-open frame segments into H.264 MP4, executor verified both files by SHA-256, a second run reused both outputs without rendering, and FFmpeg finalized the two segments. FFprobe verified 160×90, 8 frames, and 2.0 seconds.
- FFmpeg + FFprobe separately concatenated two generated H.264 clips and muxed a generated WAV track; final output was 2.0 seconds with audio. Apostrophe-containing source paths also passed.
- These tests validate real Chromium WebGL and FFmpeg in this sandbox; they do not establish target DSH host installation, GPU acceleration, upstream Three.js execution, or cross-machine pixel identity.

## Not verified

- No target DSH profile at `/home/oai/.dsh/profiles/web` and no `@deepseek-ai/schemastery` package were present.
- No live DSH installation, browser settings UI, model stream, native Canvas backend, upstream Three.js release/production scene, GPU-accelerated rendering, or audio BPM/onset analysis against real production music was tested. Synthetic click-track audio was decoded with FFmpeg and used to verify tempo estimation; silent audio correctly remains unknown. Chromium WebGL and the Three-compatible harness were exercised via CDP + SwiftShader; Playwright/Puppeteer were not used.
- The core remains Node-built-in-only; optional renderer adapters and external binaries are not silently installed or downloaded.


## R4 render backend verification

- `chromium-webgl-renderer.js` and `threejs-renderer.js` are registered as optional renderers; the renderer implementations use Node built-ins and system Chromium/FFmpeg only.
- Managed Chromium blocks `file:`, `data:` and localhost navigation. The renderer uses CDP `Page.setDocumentContent` on an `about:blank` target instead; no local HTTP server or external URL is required.
- Render HTML receives a restrictive CSP: no network connections, frames, plugins or external assets; scene bundles must be self-contained.
- Three.js adapter now enforces bundle/script bounds, optional exact revision pinning, deterministic update(frame/time) and disposal hooks. A minimal Three-compatible WebGL harness was rendered through real Chromium, but it is not upstream Three.js. The sandbox has no Three.js distribution and npm registry access failed; do not report a production Three.js scene as complete until an approved upstream bundle is supplied and rendered end-to-end.


## R5.1 audio intelligence verification

- `creative_audio_analyze` is registered as the 47th Orchestrator tool and exported from `./audio-analyzer`.
- The analyzer confines inputs to configured `mediaRoots`, resolves symlinks, and bounds duration (6–1,800 seconds), PCM envelope memory, and process timeout. FFmpeg is invoked with `shell:false`.
- A generated 12-second 120 BPM click WAV was decoded by the installed FFmpeg; estimated BPM passed within 3 BPM and returned source provenance/confidence/alternatives.
- A generated silent WAV correctly returned `unknown`; no fabricated BPM. Out-of-root and over-duration files were rejected.
- At the R5.1 checkpoint: Orchestrator full suite 104 passed / 0 failed; full repository JS/MJS syntax checks 90 passed. SVG Motion: 4 suites passed. Atomstudy: 106/106 plus S1 28/28, S2 18/18, S3 7/7. AI-PJ scorer: 24/24.
- No real production music track was analyzed; the estimator is RMS-onset autocorrelation and may have half-time/double-time ambiguity. It does not infer sections or downbeats.


## R5.2 audio-motion and Chromium lifecycle

- `creative_audio_motion_plan` maps measured audio features into bounded, deterministic motion controls and beat events; `creative_audio_motion_sample` samples by global time to preserve phase across render segments. Three.js receives controls through `window.audioMotionAt(t)` and `window.update(t, frameIndex, audioControls)`.
- Audio evidence fingerprint is now independent from style/render-plan fingerprint. Changing restrained/kinetic profiles changes the plan fingerprint but leaves the source analysis fingerprint stable.
- Chromium is launched in a dedicated POSIX process group; normal close, abort and timeout signal the process tree to avoid orphaned GPU/renderer children. Windows process-tree cleanup is not yet verified.
- Orchestrator: 113 non-browser passed / 0 failed / 3 skipped plus 5/5 browser integration tests (all 116 unique cases exercised); full-tree syntax: 93/93; SVG Motion: 4 suites; Atomstudy: 106/106 plus S1 28/28, S2 18/18, S3 7/7; AI-PJ verify: 37/37 (24 scorer cases).
- These checks still use synthetic audio fixtures and a Three-compatible WebGL test harness, not production music or an upstream Three.js bundle.
