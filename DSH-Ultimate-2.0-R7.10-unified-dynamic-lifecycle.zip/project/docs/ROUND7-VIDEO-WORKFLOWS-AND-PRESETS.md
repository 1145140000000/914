# Round 7 — Video workflows, visual styles, animation presets

## Workflow library

| Workflow ID | Purpose | Default style | Default animation |
|---|---|---|---|
| `short-video-hook` | Vertical short-form opening hook and delivery | neon | kineticTypography |
| `music-video` | Music chapters, emotional arc, beat-aware motion | anime | impactBurst |
| `explainer-motion` | Knowledge / educational motion graphics | documentary | titleCinematic |
| `product-showcase` | Product and brand showcase | luxury | logoReveal |
| `reference-rebuild` | Evidence-led reference analysis and differentiated style card | editorial | softParallax |
| `anime-mv` | Character-consistent anime music video | anime | impactBurst |
| `social-repurpose` | Adapt an approved master for multiple aspect ratios | cinematic | gentleDrift |
| `release-quality-gate` | Technical inspection, visual evidence, review and acceptance | cinematic | gentleDrift |

Every workflow compiles to ordered steps and explicit gates. The compiler never runs tools. `creative_workflow_task_create` writes a durable queued task. A deployment must provide an explicit Worker `executeStep` adapter that maps `dsh-tool-intent` records to approved tool invocations; this package does not infer a Cordis tool invocation API.

## Visual style presets

- `cinematic`: restrained contrast, warm material accents, deliberate camera and typography.
- `anime`: cool blue palette, expressive kinetic movement and impact transitions.
- `luxury`: quiet palette, generous tracking, slow controlled reveals.
- `editorial`: paper-like palette, collage transitions and print-inspired rhythm.
- `documentary`: low-intensity movement, readable typography and unobtrusive cuts.
- `retro`: warm film palette and grain-oriented motion treatment.
- `neon`: high-energy neon palette, VJ-compatible rhythm and stronger motion response.

The resolved style object includes `presetId`, palette, motion, typography, transition preferences, audio reactivity and render hints. It is renderer-consumable metadata, not a guarantee that every custom renderer applies every field.

## Animation presets

`titleCinematic`, `kineticTypography`, `softParallax`, `particleAtmosphere`, `impactBurst`, `gentleDrift`, `logoReveal`, `loopParticles`, `speedLines`, `filmBurn`, `radialBurst`, `lightSweep`, `typewriter`, `cameraPush`.

All animation presets resolve to deterministic recipes with explicit seeds. Recipe values are bounded. Seamless loop closure, typography layout, actual particle drawing and camera transforms remain renderer-scene responsibilities.

## Custom workflows

Custom manifests are validated and stored under the dedicated `workflows/` namespace. They are plain JSON-like records; no JavaScript, shell, expressions, dynamic imports or arbitrary source code is executed. Step IDs must be unique. Saved workflows can be compiled to a task draft and queued; filesystem side effects and manual steps carry explicit approval policies.

## Tool groups

Director/storyboard, workflow orchestration, visual styles/motion, assets/prompts/knowledge, rendering/delivery, quality review, and audio post-production are surfaced through `creative_video_toolbox_catalog`. Audio remains a video post-production subsystem.

## Companion integration extension (R7.1)

See [`ROUND7.1-COMPANION-INTEGRATIONS.md`](ROUND7.1-COMPANION-INTEGRATIONS.md) for the DrawAI external-tool contract, LLC PV skill contract, capability check and three additional companion workflows.
