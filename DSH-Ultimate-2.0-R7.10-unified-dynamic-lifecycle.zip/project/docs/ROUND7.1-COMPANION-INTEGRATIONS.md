# Round 7.1 — DrawAI × LLC PV companion integrations

## Integration model

This release integrates companion projects through explicit provider contracts and workflow references. It does not copy either repository into the core plugin, replace their native engines, or install third-party code automatically.

### DrawAI (`fourzkw/dsh-drawai`)

- Role: external DSH tool provider for canvas, shot cards, native motion projects, previews, rendering, QA and delivery.
- Required core tool IDs: `diagram_read`, `diagram_apply`, `shotcraft_search`, `motion_project`, `motion_preview`, `motion_render`, `motion_qa`.
- Optional tool IDs include `diagram_export`, `motion_assets`, `motion_export`, `motion_audio`, `motion_sync`, `motion_audio_verify`, `motion_sfx`, `motion_voice`.
- All tool IDs described by the integration contract: `diagram_read`, `diagram_apply`, `diagram_export`, `shotcraft_search`, `motion_project`, `motion_preview`, `motion_assets`, `motion_render`, `motion_qa`, `motion_export`, `motion_audio`, `motion_sync`, `motion_audio_verify`, `motion_sfx`, `motion_voice`.
- Workflow order: read canvas → search shot cards and read recipe/preservation → map shot cards to video node → create native DrawAI project/storyboard/timeline → gather licensed assets → render styleframe → obtain pilot approval → start background render and retain `jobId` → QA → apply finished render to video node → export edit package.
- Preserve DrawAI's `.drawai` project, `timeline.json`, `scene-*.tsx`, assets and job lifecycle. Do not translate its project into the orchestrator's renderer manifest as if the formats were equivalent.
- `motion_render start` is asynchronous; use `status`, do not sleep-poll. Pilot output belongs on a separate pilot node. Read selected Shotcraft recipe and preservation data before implementing a shot.

### LLC PV skill (`Youtich-A/llc-pv-skill`)

- Role: external skill provider for high-fidelity PV / character hand-drawn / MV production methodology and review gates.
- Skill activation: `$llc-pv-skill` or “使用 llc-pv-skill”.
- Core method: environment and rights check → full-reference observation and music-section evidence → natural segments around 20 seconds (prefer <=25 seconds) → dense per-shot script → asset provenance check → per-segment production → three evidence-backed full comparison rounds → fix and regression → user acceptance and segment handoff.
- Skill package version inspected for this integration: `0.4.0-alpha.2`. It is an alpha skill package, not a renderer or bundled generation model.
- Local video-watch scripts, Python, FFmpeg/ffprobe, ImageMagick and fonts need independent local checks. NumPy/Pillow, OCR/ASR, AE MCP and L2D/PSD2Live are optional and must not be assumed installed.
- AE setup must discover the actual `ae_catalog` schema and verify the selected instance; tool visibility, read success, write success and render success are separate states.
- The three-round validator checks record consistency; it cannot prove that a model actually watched footage.

## New workflows

| Workflow ID | Purpose | Companion |
|---|---|---|
| `drawai-motion-production` | Canvas-to-motion-project production with preview, render, QA and apply | DrawAI |
| `llc-pv-high-fidelity` | High-density PV / character MV workflow with three-round review | LLC PV skill |
| `hybrid-pv-drawai` | LLC PV methodology + DrawAI canvas, native motion engine and render tools | Both |

All three compile as plans. User approval gates remain explicit. `creative_workflow_task_create` preserves external provider IDs, skill IDs and tool input bindings in durable steps. A deployment must provide an explicit Worker adapter to execute those records; the orchestrator does not infer a Cordis tool invocation API.

## New tools

- `creative_companion_integrations_catalog`: list the contracts, tools, install notes and limitations.
- `creative_companion_integrations_check`: compare caller-supplied observed `availableTools`, `installedSkills` and `localCapabilities` with the contract. It does not independently inspect the host, install packages or claim readiness without evidence.

## Security and compatibility

- No arbitrary shell commands, dynamic code, JavaScript snippets or untrusted manifests are executed by the workflow compiler.
- DrawAI tools with write/network effects are marked for explicit approval in durable task records.
- LLC PV skill invocation is represented as a skill step; local commands and optional AE MCP operations are not falsely exposed as built-in orchestrator tools.
- No external project source, credentials, media, AE project or private asset is copied into this release.
- Companion tool availability and versions may change upstream; validate current host-visible tools and schemas before execution.

## Validation scope

Unit tests cover companion catalog metadata, caller-observed capability checking, DrawAI workflow bindings, hybrid workflow gates, skill-step validation and durable task serialization. These tests do not install either companion project or prove a real DSH host can see its tools. Full host E2E requires installing DrawAI into the active profile, installing the LLC PV skill into the active skill directory, and separately verifying local video-watch / AE MCP capabilities.
