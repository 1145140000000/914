# Round 7.2 — Unified provider dispatch and cross-step dataflow

## What changed

R7.2 adds a single explicit dispatch path for native DSH workflow tools and registered companion providers.

- `lib/tool-dispatcher.js` resolves only exact, pre-registered provider/tool/skill/prompt handlers. It does not inspect arbitrary modules, call undocumented Cordis APIs, evaluate strings, or execute shell commands.
- `apply()` now exposes `registerToolAdapter(providerId, adapter)`, `dispatcher`, and an opt-in `createWorker({ workerId, ...options })` factory. Creating the plugin does not start a worker or execute queued work.
- A deliberately allowlisted set of tools already used by built-in workflows is registered as the `native` provider. Administrative task/configuration/approval tools are excluded from this provider.
- External providers such as `dsh-drawai` and `llc-pv-skill` must register exact JavaScript handlers. The LLC PV prompt phases route through the registered `llc-pv-skill` skill handler and retain the phase identifier in `context.promptId`.
- `creative_tool_adapter_status` and `creative_tool_dispatch_inspect` expose actual adapter registrations and per-step readiness without guessing that a companion is installed.
- Input bindings can reference completed earlier step outputs with `{ "$ref": "steps.<stepId>.output.<path>" }`. Resolution rejects missing/incomplete steps, unsafe path segments and unresolved references. Worker updates its in-memory task snapshot after each completed step so downstream bindings see the persisted result.
- Manual workflow gates require a persisted human approval and then complete as an approval record; they are never dispatched as tools.
- Adapter handlers receive a child `AbortSignal` (aborted on worker cancellation or timeout), idempotency key, checkpoint/resume data, provider/tool identity, and delivery guarantee. Side-effecting handlers must either declare `supportsIdempotency: true` or explicitly opt into `allowAtLeastOnce: true`. The latter is visibly reported as at-least-once, never misrepresented as exactly-once.
- Optional per-handler timeout is bounded to 100 ms–1 hour; default is 30 minutes. Tool inputs are size-bounded.

## Adapter contract

```js
const registration = app.registerToolAdapter('dsh-drawai', {
  label: 'DrawAI',
  tools: {
    motion_project: {
      execute: async (input, context) => {
        // Call the host-verified DrawAI tool implementation here.
        // Forward context.signal and context.idempotencyKey when supported.
        return await verifiedMotionProject(input, context)
      },
      supportsIdempotency: true,
      timeoutMs: 300000,
    },
    motion_render: {
      execute: async (input, context) => await verifiedMotionRender(input, context),
      resume: async (input, context) => await verifiedMotionRenderResume(input, context),
      supportsIdempotency: true,
      timeoutMs: 3600000,
    },
  },
  skills: {
    'llc-pv-skill': async (input, context) => await invokeInstalledLlcPvSkill(input, context),
  },
})

// Explicitly opt in; this does not start a background loop.
const worker = app.createWorker({ workerId: 'creative-worker-1' })
await worker.runOnce() // or worker.start(); stop with await worker.stop()
```

The function names above illustrate the contract only. `verifiedMotionProject`, `verifiedMotionRender`, `verifiedMotionRenderResume`, and `invokeInstalledLlcPvSkill` are supplied by the deployment after verifying its actual host APIs; they are not bundled or guessed by this plugin.

## Workflow input dataflow

A task can pass an earlier result to a later step:

```json
{
  "assetId": { "$ref": "steps.asset-search.output.result.assetId" }
}
```

Only a completed step's persisted output is readable. References are data paths, not JavaScript expressions or executable templates.

## Safety and delivery semantics

- Provider registration is explicit and process-local. Restarting the plugin requires the host integration layer to register adapters again.
- `createWorker()` is opt-in and never starts itself.
- The existing execution policy remains authoritative: manual / copilot / autopilot, persisted approval fingerprint, risk, side effects and capabilities are evaluated before dispatch.
- External side effects are not claimed to be exactly-once. An adapter marked `supportsIdempotency` is responsible for honoring the forwarded key in the target system. `allowAtLeastOnce` means retries or crash recovery may repeat the operation.
- The native provider only exposes tools referenced by built-in workflow definitions; it does not expose task administration, settings mutation or arbitrary tools. Native write tools explicitly declare at-least-once delivery; they are not presented as exactly-once.
- The plugin still cannot call other Cordis plugins through an undocumented `ctx.tools.call` API. A deployment-specific bridge must supply the actual handler functions.

## Tests

`tests/tool-dispatcher.test.mjs` covers explicit provider registration, exact capability matching, skill and prompt routing, idempotency requirements, checkpoint resume, manual gates, native allowlisting, input-reference resolution, unresolved references and an end-to-end fake-provider Worker run.

## Open-source design references

The design borrows concepts rather than importing runtime dependencies: [OpenWOP](https://github.com/openwop/openwop) for durable interrupt/resume, replay and idempotency envelopes; [OpenMontage](https://github.com/pvpuno/openmontage) for staged video production and review/repair queues; and [Hatchet](https://github.com/hatchet-dev/hatchet) for durable task orchestration and worker lifecycle. DSH retains its own Node built-in-only runtime and Cordis integration boundary.
