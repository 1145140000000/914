# R7.3 — Production operations, DAG dependencies and workflow expansion

## What changed

R7.3 builds on the R7.2 explicit provider dispatcher and adds operational controls around it:

- `creative_worker_list`, `creative_worker_run_once`, `creative_worker_start`, and `creative_worker_stop` expose only Workers that the host explicitly created through the plugin API. These tools cannot create a provider adapter, grant permissions, or start an unregistered Worker.
- Worker lifecycle events are emitted through the optional `onEvent` callback (`task-claimed`, `step-started`, `step-checkpointed`, `step-completed`, approval, blocked dependency, task completion/failure). Observer exceptions are isolated from task execution.
- Worker status includes bounded in-memory counters and current execution settings. Durable task state and event history remain in the store; metrics are observational, not a replacement for durable records.
- Provider adapters may declare `validateInput`, `validateOutput`, and `health` hooks. Validation runs around each invocation; provider health is explicitly checked and reported rather than inferred from registration.
- Custom workflow manifests may declare `dependsOn`. Dependencies must reference earlier steps, are persisted on task records, and are checked again by the Worker before execution. This gives custom flows an explicit, validated DAG subset without silently scheduling parallel side effects.
- `creative_production_board` and `creative_production_board_task` provide a read-only production board derived from durable tasks: progress, current phase, approvals, failures, leases and recent events.
- Five built-in production templates extend the catalog: podcast/interview repurposing, documentary montage, localization/dubbing, screen-demo production, and long-video clip factory.

## Tool contracts

### Provider hooks

```js
registerToolAdapter('provider-id', {
  label: 'Provider label',
  health: async () => ({ connected: true }),
  tools: {
    'exact-tool-name': {
      execute: async (input, context) => ({ /* JSON-safe result */ }),
      resume: async (input, context) => ({ /* resumed result */ }),
      validateInput: input => true,
      validateOutput: output => true,
      supportsIdempotency: true,
      timeoutMs: 120000
    }
  }
})
```

`validateInput` / `validateOutput` may return `true` or `undefined` to accept, or a string to reject with a readable reason. `health` is optional and runs only when `creative_tool_adapter_status` is called. Provider registration does not prove that the remote service is reachable unless its health hook verifies that.

### Worker controls

```js
const worker = plugin.createWorker({
  workerId: 'video-worker-1',
  onEvent: event => logger.info(event)
})
```

The Worker remains opt-in. Use the four `creative_worker_*` tools to inspect, run once, start polling, or stop it. The worker factory requires a real registered provider/handler for every executable step. A host should register provider adapters before creating or starting workers.

### Workflow dependencies

```json
{
  "id": "render",
  "type": "tool",
  "tool": "creative_video_render_pipeline",
  "dependsOn": ["storyboard", "asset-check"]
}
```

For deterministic execution and easy recovery, dependencies must reference earlier steps in the manifest. The current Worker processes a task's declared step order sequentially; `dependsOn` is a correctness gate, not a parallel execution promise.

## Production board

The board derives its view from the task record and does not create a second source of truth. Progress counts completed and skipped steps. Pending approvals and failures are surfaced as blockers. It intentionally does not invent ETA or percent-complete from wall-clock time.

## Expanded workflow templates and capability boundaries

- Podcast/interview repurposing includes audio evidence, a transcript review gate, highlight planning, video render, and audio/video QA. ASR and speaker diarization are not claimed as built-in.
- Documentary montage includes rights confirmation, source inspection, asset provenance registration, narrative/timeline planning, review, and render.
- Localization/dubbing includes transcript, translation and voice approval gates, audio analysis/mix, synchronization review, render and inspection. Translation and TTS require external providers.
- Screen demo includes capture/privacy review, script, director/timeline planning, prototype approval, render and text legibility QA.
- Clip factory includes source rights, transcript/manual highlight selection, platform-aware planning, batch render and per-version QA. Automatic semantic ranking requires an external transcript/search adapter.

## Open-source design references

These projects were reviewed for architectural patterns, not copied as runtime dependencies or vendored code:

- [OpenMontage](https://github.com/m-fyi/openmontage): stage-oriented production pipelines, review loops, rework queues and a live production board.
- [OpenChatCut](https://github.com/0xsline/OpenChatCut): separation of editor core, command layer, agent tools, timeline, persistence and render pipeline.
- [AI Video Production Editor](https://github.com/LudwigKienle/ai-video-production-editor): script-to-storyboard-to-filming continuity loop and re-film queue.
- [Hatchet](https://github.com/hatchet-dev/hatchet): durable workflow concepts, Worker observability, retry boundaries and task execution status.

The implementation remains Node built-ins only. DSH host APIs are not guessed: cross-plugin execution still depends on explicit adapter registration by the deployment.

## Validation

The release test suite covers provider validation and health, Worker lifecycle observers and controls, DAG dependency validation and execution, production-board derivation, all built-in workflow tool references, and the existing render/audio/plugin regression tests.
