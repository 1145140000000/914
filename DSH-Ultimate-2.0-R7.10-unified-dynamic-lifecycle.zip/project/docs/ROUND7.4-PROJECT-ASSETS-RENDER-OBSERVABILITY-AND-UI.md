# Round 7.4 — Project registry, asset lineage, render jobs and Production Studio UI

## Project registry

The orchestrator now has a dedicated `projects/` namespace, isolated from workflow manifests and audio-edit projects. Project records carry a stable ID, revision, content hash, bounded immutable snapshots, project metadata, timeline/settings payloads, linked asset IDs, linked task IDs, and a bounded event history.

- `creative_project_create` creates a versioned project.
- `creative_project_list` returns compact project summaries.
- `creative_project_get` returns a project and its linked assets.
- `creative_project_update` uses mandatory `expectedRevision` optimistic concurrency and rejects stale writes.
- `creative_project_restore_version` restores editable project fields by creating a new revision; it does not delete later history.
- `creative_project_task_link` associates a durable workflow task with a project.

## Asset lineage

`creative_project_asset_link` registers metadata and attaches an asset to a project. Asset records include kind, title, URI, SHA-256 (when supplied), MIME type, size, duration, source, license, tags, source asset IDs, and caller-supplied provenance. The tool does not copy, upload, inspect or modify the underlying media file. Reusing an asset ID with a conflicting non-null SHA-256 is rejected; create a new asset ID for changed content.

`creative_project_asset_audit` detects missing source references, missing hashes, duplicate hashes and lineage cycles. Duplicate hashes are surfaced as review candidates, not silently merged. Asset linking advances the project revision and stores a new snapshot; repeated identical links are idempotent.

## Render job lifecycle

A dedicated `render-jobs/` namespace stores project-bound render jobs. Each job captures the project revision at creation, renderer ID, output URI, idempotency key, attempt count, progress, checkpoint, output receipt, error and bounded event history.

- `creative_render_job_create` creates a queued job only; it does not start a renderer.
- `creative_render_job_update` enforces legal transitions and mandatory `expectedRevision`.
- Frame progress is monotonic and bounded by total frames.
- `creative_render_job_list` supports project/status filtering.

This is the durable control-plane record. `creative_video_render_pipeline` accepts optional `renderJobId`. When supplied, it verifies the job's project ID, fixed project revision/content hash and renderer ID, then streams segment events into durable job checkpoints and monotonic frame progress before recording the final output receipt. The first run binds the job to an `outputName` (resume-manifest identity) and exact `outputPath`; a checkpointed job can be resumed only with those same values. A failed job requires an explicit transition back to `queued` before retry. The renderer itself must still be registered and actually produce MP4 segments.

## Capability-aware Worker pool

Workers may be created with an explicit `capabilities` array. The durable task index summarizes the capabilities still required by unfinished steps, and `claimNextTask` skips tasks outside that Worker’s declared scope while preserving global oldest-first ordering among eligible work. Multiple Workers can share the same durable queue without repeatedly claiming work they cannot execute. Omitting the option preserves the legacy unrestricted-claim behavior; an empty array claims only tasks with no outstanding capability requirements. This is task-level routing: a single Worker must still possess all capabilities required by one task.

## Event replay

`creative_task_replay` exposes the existing durable task event stream with cursor pagination and explicit truncation information. It does not synthesize events that have expired from the bounded retention window.

## Production Studio UI

`ui/production-dashboard.html` is a dependency-free, responsive dashboard with a dark liquid-glass visual system, restrained ambient motion, task progress, production phase rollups, project inventory, render job monitoring, task detail and event replay. It respects `prefers-reduced-motion` and uses no external fonts, CDNs or analytics.

The plugin exposes `createDashboardBridge()` as a read-only adapter with `getProductionBoard`, `listProjects`, `listRenderJobs` and `getTaskEvents`. The embedding host can inject this object as `window.DSHDashboardBridge`; the HTML does not guess Cordis APIs. The bridge does not initiate Worker runs, approvals, project mutations or rendering. Until the host injects the bridge, the page accurately displays a waiting-for-bridge state.

## Validation boundaries

- Project, asset and render-job metadata are persisted in private store namespaces with the store's existing atomic writes and cross-process lock.
- The project registry is metadata/control-plane functionality; media bytes remain in configured media roots or external asset providers.
- Render jobs are not automatically coupled to `creative_video_render_pipeline` because that would imply an execution lifecycle and host callback contract not yet proven. A future renderer adapter can connect them explicitly.
- Real target-host UI embedding and Cordis bridge wiring require deployment verification.
