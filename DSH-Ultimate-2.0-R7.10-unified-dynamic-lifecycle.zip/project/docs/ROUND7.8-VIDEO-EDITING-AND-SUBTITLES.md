# Round 7.8 — Video Editing and Subtitle Workbench

## Architecture

The video timeline is embedded in the existing `projects.timeline` field, so project snapshots, content hashes, activity events and optimistic revision checks remain owned by the project registry. Timeline-specific edits are pure transformations. The tool layer reads the current project, checks the caller's `expectedProjectRevision`, applies one transformation, validates the resulting timeline and writes it through `updateCreativeProject`.

## Video timeline schema

- `schemaVersion: 1`
- `fps`, `durationSec`, `revision`
- `tracks[]`: `video`, `audio`, `subtitle`, `overlay`
- Track state: `locked`, `muted`, `solo`, `allowOverlap`
- `clips[]`: stable clip ID, registered asset ID, source in/out, timeline start, playback rate, transition metadata and keyframes
- `editHistory`: bounded immutable snapshots for undo/redo

Timeline intervals are interpreted as start-inclusive and end-exclusive when compiled to frames. The EDL compiler rounds timeline and source seconds to the nearest output frame and reports `renderStatus: plan-only-not-rendered`.

## Editing invariants

- Clip IDs and track IDs must be unique safe identifiers.
- Playback rate is bounded to 0.25–4.
- Locked tracks cannot be modified or moved from/to.
- Split points must lie strictly inside the timeline clip range; source split time is computed using playback rate.
- Ripple delete shifts later clips on unlocked tracks, but rejects any operation that cuts through another clip or would alter a locked track.
- Keyframes use clip-local seconds and a bounded property allowlist.
- Every edit increments timeline revision. The persisted project revision is independently protected by `expectedProjectRevision`.

## Director assembly

`buildVideoTimelineFromDirectorPlan` accepts the existing deterministic director plan plus a map of explicit shot-to-asset bindings. It verifies contiguous frame coverage and refuses partial bindings. It creates an editable timeline but does not render or invent missing media.

## Subtitle workbench

The parser accepts SRT and WebVTT text under a 2 MiB cap and at most 20,000 cues. The validator checks timestamp ranges, empty text, duplicate IDs, overlap, media duration, line-count/width recommendations and safe-area bounds. Export supports SRT and WebVTT. Burn-in currently creates a bounded FFmpeg subtitles filter plan only; a future increment must connect it to the existing supervised, media-root-guarded render path with approval.

## Tool names

Video/timeline:
- `creative_video_timeline_init`
- `creative_video_track_add`
- `creative_video_clip_add`
- `creative_video_clip_split`
- `creative_video_clip_move`
- `creative_video_clip_ripple_delete`
- `creative_video_track_state`
- `creative_video_clip_keyframes`
- `creative_video_timeline_undo`
- `creative_video_timeline_redo`
- `creative_video_timeline_validate`
- `creative_video_timeline_history`
- `creative_video_timeline_compile`
- `creative_director_timeline_assemble`

Subtitle:
- `creative_subtitle_parse`
- `creative_subtitle_validate`
- `creative_subtitle_export`
- `creative_subtitle_burnin_plan`

## Deferred

A later R7.8 increment should add approved subtitle burn-in execution, non-destructive color grading/LUT support, richer transition rendering, cross-track audio/video composition and release quality gates.
