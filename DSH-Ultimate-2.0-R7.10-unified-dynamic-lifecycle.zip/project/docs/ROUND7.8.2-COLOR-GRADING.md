# R7.8.2 — Non-destructive color grading and shot matching

## Scope

This increment extends the R7.8 / R7.8.1 source tree. It does not add a model, model provider, remote service, host patch, or npm dependency. The implementation uses Node built-ins and the already-configured FFmpeg/FFprobe executables only.

## Non-destructive clip model

`video-edit-project.js` now stores an optional `colorGrade` object on each clip. The grade is schema-versioned and normalized before it enters the timeline. `setVideoClipColorGrade` is a normal immutable timeline edit: it checks the expected revision, respects track lock, records a snapshot, increments revision, and can be undone/redone. A `null` grade clears the setting. `compileVideoTimeline` carries the normalized grade object into the renderer-neutral EDL.

Supported controls:

| Parameter | Range |
|---|---:|
| exposureEV | -3 to +3 stops |
| contrast | 0.5 to 2.0 |
| saturation | 0 to 2.5 |
| gamma | 0.5 to 2.0 |
| temperature / tint | -100 to +100 |
| master / red / green / blue curve | 2–17 points per channel; X strictly increasing from 0 to 1; Y 0 to 1 |

No arbitrary FFmpeg expression or filter string is accepted. Unknown grade fields are rejected.

## LUT contract

`creative_video_lut_inspect` accepts only a regular `.cube` file inside configured `mediaRoots`. Symlinks are rejected. The parser accepts a 3D LUT with `LUT_3D_SIZE` 2–65, optional `TITLE`, `DOMAIN_MIN` and `DOMAIN_MAX`, and exactly `size^3` RGB rows. Files larger than 32 MiB, 1D LUTs, malformed numeric rows and inconsistent domain ranges are rejected. The response includes size, domain, title and SHA-256.

A persisted clip grade stores LUT identity metadata (SHA-256, size, title/file name and interpolation), not an executable path. Preview/render requires the actual `lutPath`; its SHA-256 and size must match the stored metadata. After validation the LUT is copied to a private generated temp directory and hashed again before FFmpeg opens it. This prevents path escaping and avoids relying on FFmpeg's inconsistent filtergraph escaping for user-controlled filenames.

## Preview and render

- `creative_video_color_grade_preview` renders one PNG frame at `atSec`.
- `creative_video_color_grade_render` renders a new MP4 using H.264/yuv420p; optional audio is mapped and encoded to AAC.
- Both operations compile from the same normalized grade and return the same canonical `filterGraphTemplate` and `filterGraphHash`. Preview adds a scale stage after the grade; the grade operations themselves are identical.
- Inputs and outputs are confined to `mediaRoots`; symlink outputs are refused. Source and output may not be the same path.
- Render takes an exclusive per-output lock, writes a unique temporary MP4, probes it with FFprobe, then publishes with atomic rename when overwrite is explicitly enabled or atomic hard-link creation when overwrite is false. Failed overwrites preserve the previous output. An interrupted operation leaves a fail-closed lock record; after confirming its PID is no longer alive, an operator may remove that stale lock manually.
- Results include output SHA-256 and actual probed stream metadata.

## Shot-match suggestion

`creative_video_color_match_suggest` samples both videos with the existing FFmpeg `signalstats` analyzer. It estimates only a bounded exposure adjustment from median luma ratio and saturation adjustment from mean saturation ratio. It returns sample counts, confidence based on sample quantity, and an explicit human-review disclaimer. It does not infer white balance, color primaries, transfer functions, skin tone, semantic scene intent or artistic style. It never modifies media.

## Workflow and tools

Six new Creative tools are registered:

1. `creative_video_clip_color_grade`
2. `creative_video_color_grade_validate`
3. `creative_video_lut_inspect`
4. `creative_video_color_grade_preview`
5. `creative_video_color_grade_render`
6. `creative_video_color_match_suggest`

The `color-match-grade` built-in workflow composes match suggestion → preview → manual review → render → FFprobe verification. Workflow compilation remains plan-only; preview/render filesystem writes require explicit approval through the existing task execution policy.

## Known limitations

- The clip grade is stored and exported in the EDL, but the current renderer-neutral multi-track EDL pipeline does not yet consume every clip's grade automatically during whole-timeline composition. Use the single-source preview/render tools for actual grade application in this increment.
- No browser color-grading UI, waveform/vectorscope, HDR/10-bit path, ACES/color-management transforms, 1D LUTs, or professional automatic shot matching is claimed.
- H.264 output is a delivery copy; source media is never overwritten by default.
- Subtitle streams are not preserved by the grade render path; export or remux them separately if required.
