# R7.8.3 — Executed subtitle burn-in

## Scope

This increment completes the R7.8 subtitle workbench's previously plan-only burn-in path. It adds one public tool, `creative_subtitle_burnin_render`, while retaining `creative_subtitle_burnin_plan` unchanged as a non-executing preview of the filter intent.

## Execution path

1. Resolve the video and `.srt` / `.vtt` subtitle files through canonical `mediaRoots`; reject files outside those roots and reject unsupported extensions.
2. Enforce the 2 MiB subtitle-file bound, probe the source video, parse timed cues, and validate cue ranges against source duration. Overlap, line-count and line-width conditions remain explicit warnings; malformed cues, duplicate IDs, invalid safe-area bounds and duration overflow are errors.
3. Normalize ASS style fields through an allowlist: font size, vertical/horizontal margins, outline, shadow, alignment, bold/italic and 8-digit ASS colours. Unknown style keys and non-boolean emphasis flags are rejected; numeric values are clamped to documented safe bounds.
4. Strip ASS override blocks and unsupported markup from cue text, preserve only basic `i/b/u/s` emphasis tags, convert the normalized cue list to SRT, and stage it under a generated private temporary directory with mode `0600`. The user-supplied subtitle path is never embedded directly into the FFmpeg filter graph.
5. Acquire an exclusive output lock, render to a generated sibling temporary MP4 with FFmpeg's libass `subtitles` filter, encode H.264/AAC, and verify the temporary output with FFprobe. The final file is atomically published only after verification; existing outputs require `overwrite=true`, and the source video is never an allowed destination.
6. Return the output SHA-256, file size, FFprobe media summary, cue count, style, validation warnings, a path-neutral filter-graph template and its hash.

## Public tool

`creative_subtitle_burnin_render` required inputs: `inputPath`, `subtitlePath`, `outputPath`. Optional inputs include `style`, `safeArea`, `maxLines`, `maxCharsPerLine`, `crf`, `preset`, `audioBitrate`, `overwrite` and `timeoutMs`. The output is a new MP4; it does not mutate the source video or subtitle file.

This is a filesystem side effect. Workflow task compilation marks this tool as `sideEffect=filesystem` and `approvalPolicy=always`; creating a workflow task still queues it and does not execute it. Direct tool use is an explicit render invocation and must follow the host's approval policy.

## Verification

- Unit tests cover style allowlisting, bounded values, deterministic ASS force-style serialization and the retained plan-only contract.
- Real FFmpeg/libass integration creates a synthetic source video, burns a WebVTT cue, verifies the output with FFprobe, and confirms the decoded frame digest differs from the source frame.
- Negative integration checks reject subtitle cues beyond source duration and subtitle paths outside configured `mediaRoots` without publishing an output.
- A workflow contract test confirms the new render step is a filesystem side effect with an always-required approval gate.

## Explicit limits

- WebVTT cue-position/line/region settings are not preserved in the rendered SRT conversion; the result reports how many cue settings were ignored.
- Global ASS style is applied to the whole file; per-cue styling, custom font installation, karaoke timing, RTL shaping review and platform-specific subtitle packaging are not provided.
- `safeArea` validates percentage bounds; actual rendered placement is controlled by explicit ASS margins and alignment. It is not a computer-vision guarantee that text avoids every face, logo or UI element.
- Burn-in operates on one source video file. It does not yet render the R7.8 multi-track EDL or automatically consume per-clip grade, transition and keyframe data.
- FFmpeg must be present with the libass `subtitles` filter. The plugin does not install it.
