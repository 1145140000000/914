# R7.8.4 — Art direction and selective toolchains

## Purpose

Turn the existing aesthetic skill and style library into an actionable, reviewable decision workflow. Style presets remain optional parameter starting points; the task's subject, facts, audience and deliverable type take priority.

## Runtime shape

`svg_motion_art_direction` is a deterministic pure computation in `art-direction.js`.

Input fields:

- `task` (required, bounded string)
- `mediaType` (`auto`, `video`, `motion-graphics`, `illustration`, `ui`, `poster`, `explainer`, `audio-visual`)
- `assetDescription` (only facts known from user input or inspected material)
- `audience`, `platform`, `mood`
- `styleHint` or a real existing `styleId`
- `durationSec` (used to gate long-form storyboard suggestions)

Output sections:

- `classification` and `visualFamily`
- `direction`: subject, composition, background, palette, typography, material, motion, sound and anti-patterns
- `styleRecommendation`: match status, candidates and a non-destructive `presetOverlay` when a valid card is selected
- `checkpoints`: stable IDs, status, evidence and gate criteria
- `checkpointContract`: schema version, ID prefix, status enum and explicit external-runner connection state
- `toolchain` and `toolUsageRules`
- `reviewItems` and `nextAction`

## Decision logic

1. Classify the task using bounded, deterministic keyword rules and declared media type.
2. Keep the confidence and classification evidence visible; low confidence is reviewable, not silently treated as user intent.
3. Match style cards only when there is a useful direct match or explicit user style. Anime/character illustration does not inherit a generic card solely because the task contains words like “cute” or “character”.
4. Preserve the task-specific direction when there is no direct card match.
5. For `mediaType=auto`, infer whether the task is static character art or long-form video/motion from explicit task wording. Static illustration does not receive motion continuity gates; an auto-detected long explainer short film can receive storyboard guidance.
6. Do not mark preview or quality checkpoints as passed before an inspectable preview/render and corresponding evidence exist.

## Toolchain policy

- `svg_motion_art_direction`: new visual task, or when the upstream task assumptions materially change.
- `svg_motion_brief`: before drawing/coding when purpose, metaphor, reading order, composition or motion intent needs to be fixed.
- `svg_motion_style`: when the user specified a style or a meaningful style candidate comparison is needed; use match before get/apply.
- `svg_motion_storyboard`: motion work longer than 15 seconds or multiple shots.
- `svg_motion_prompts`: missing image/audio assets or an explicit material handoff requirement. It creates prompts/handoff only.
- `svg_motion_transition`: when adjacent shots require a defined continuity relation, not for every cut.
- `svg_motion_score`: only after a real preview or rendered output is available.
- `svg_motion_plan`: reserve for multi-stage, dependency-heavy or risky work; do not re-plan simple tasks.

The new tool returns recommendations; it does not execute them. The agent must continue to respect each downstream tool's approval and path-permission behavior.

## Checkpoint contract

Stable IDs:

- `art-direction:01-intent`
- `art-direction:02-subject`
- `art-direction:03-visual-family`
- `art-direction:04-style`
- `art-direction:05-composition`
- `art-direction:06-first-preview`
- `art-direction:07-quality-review`
- `art-direction:08-motion-continuity` (omitted for static output)

Allowed states are `pass`, `review`, `pending`, and `blocked`. `pass` must be evidence-backed; `review` requires human confirmation; `pending` is unfinished design work; `blocked` means an evidence or prerequisite gate is not satisfied. Rework should restart at the first failed or affected checkpoint and preserve unaffected upstream work.

`checkpointContract.externalRunner` is `not-connected`. This stable data contract can later be mapped to Kilo or another orchestrator through an explicit adapter, but this release does not ship or claim such an adapter.

## Settings UI

`compactStyles()` returns bounded style metadata for all 20 cards, including the actual palette and the typography/layout/motion/post/transition fields needed by the visual picker. `client.js` draws each thumbnail with local inline SVG elements. There are no remote assets or user-controlled SVG path strings. The preview is structural and comparative, not a rendered artwork sample.

## Known limits

- Classification is deterministic keyword/media-type guidance, not semantic model reasoning; ambiguous tasks stay reviewable.
- No visual source asset is inspected by this tool. `assetDescription` is a caller-supplied/previously inspected fact field.
- Checkpoints are returned as data; this release does not persist them in a durable DSH timeline or connect Kilo.
- Toolchain recommendations are advisory; the agent must check actual tool availability and execution approvals before calling downstream tools.
- No browser E2E was available in this sandbox, so the new settings-page cards are syntax- and source-tested, not host-render-tested.
