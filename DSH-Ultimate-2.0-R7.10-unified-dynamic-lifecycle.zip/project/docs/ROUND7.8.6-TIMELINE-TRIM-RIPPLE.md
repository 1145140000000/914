# R7.8.6 — Timeline Trim & Ripple Insert

## Scope

Incremental video-editing core work over R7.8.5. No model/provider changes, no third-party npm runtime dependency, and no host API assumptions.

## Delivered

- `trimVideoClip(project, clipId, { edge, to }, { expectedRevision })` trims the left or right edge in timeline seconds.
- Left trim advances `sourceInSec` by `delta * playbackRate`, moves the clip start to the requested edge, and rebases clip-local keyframes.
- Right trim recomputes `sourceOutSec` from the retained timeline duration and playback rate.
- Keyframe trimming preserves the sampled value at the new boundary for linear, hold and smoothstep-style ease segments; keyframes outside the retained range are removed/rebased.
- Incoming/outgoing transitions are clamped to no more than half the new clip duration so a valid edit does not leave an invalid transition envelope.
- `rippleInsertVideoGap(project, atSec, durationSec, { expectedRevision })` inserts a gap across all unlocked tracks. Clips beginning at/after the insertion point shift right; clips crossing the insertion point split into left/right clips with source continuity and keyframe boundary preservation.
- Right-side split IDs are deterministic from the source clip ID and project revision; repeated application to the same immutable input produces identical IDs.
- Any locked track containing a clip at/after or crossing the insertion point causes the entire edit to fail before commit.
- Track overlap validation now tracks the furthest prior clip end, catching a long earlier clip overlapped by a later clip even when an intervening short clip has already ended.
- Both operations use the existing immutable snapshot history, monotonic timeline revision, project `expectedProjectRevision`, and atomic project update path.
- Added a dedicated `video-editing` group to `creative_video_toolbox_catalog`, exposing the full timeline editing tool family rather than leaving it buried in the general catalog.

## Public tools

- `creative_video_clip_trim`
- `creative_video_timeline_ripple_insert`

The full Creative Orchestrator tool surface is now 157 unique names (two added, zero removed). The bundled four-plugin tool inventory is 180 unique names. Existing tool names remain present.

## Validation boundaries

- These operations edit the renderer-neutral timeline and compile into the existing frame-quantized EDL.
- The EDL still reports `plan-only-not-rendered`; this increment does not claim a complete multi-track video compositor or speed-ramp rendering.
- Ripple insertion deliberately fails closed on locked tracks rather than silently moving locked media.
- Trim is non-ripple: it may leave a gap; use the existing ripple-delete or the new ripple-insert operations for explicit timeline-wide changes.
- No model provider, external service, executable installation, credential access or approval bypass was introduced.
