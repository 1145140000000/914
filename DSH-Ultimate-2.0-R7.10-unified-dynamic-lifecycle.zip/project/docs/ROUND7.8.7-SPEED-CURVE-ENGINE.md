# R7.8.7 — Speed Curve Timeline Engine

## Scope

Adds deterministic, piecewise-linear clip speed envelopes to the native video edit timeline. This increment does not add or change any model Provider and adds no third-party npm dependency.

## Data model and semantics

- `speedCurve` is an ordered array of 2–64 points `{ progress, rate }`.
- `progress` is normalized clip timeline progress in `[0, 1]`; points must start at 0, end at 1 and be strictly increasing.
- `rate` is a speed multiplier in `[0.25, 4]`, linearly interpolated between points.
- The trapezoidal integral of the speed envelope participates in clip duration calculation. This allows average speed to alter clip duration rather than silently forcing every ramp to retain its original duration.
- `mapVideoClipProgressToSource` maps normalized timeline progress through the normalized integral of the envelope; `sampleVideoClipSpeed` samples the instantaneous multiplier.

## Editing behavior

- `setVideoClipSpeedCurve` is immutable, revision guarded, lock aware and undoable.
- Split, trim and ripple-gap splitting calculate source boundaries from the integrated speed map and slice/rebase the curve for each resulting clip.
- Compiled EDL carries the curve plus `normalized-clip-progress` timebase and `piecewise-linear-rate-integral` mapping contract.
- The new public tool is `creative_video_clip_speed_curve`.

## Render boundary

The EDL contains enough deterministic curve semantics for a renderer adapter to consume, but the existing FFmpeg segment pipeline does not yet apply this speed curve to source media. The release does not claim rendered speed ramps or preview/final-render parity. That remains a next-stage compositor integration task.

## Tests

Covers curve validation, instantaneous speed sampling, source-time integration, variable duration, EDL serialization, project persistence, revision conflicts, locked tracks, undo, and speed-map continuity after split and both trim edges.
