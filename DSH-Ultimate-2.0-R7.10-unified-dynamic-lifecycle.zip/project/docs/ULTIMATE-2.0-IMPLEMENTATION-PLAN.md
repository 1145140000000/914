# DSH Ultimate 2.0 — 实施方案与状态

## 总体架构

```mermaid
flowchart TD
  U[用户目标 / 参考素材] --> O[Creative Orchestrator]
  O --> T[任务状态 / 检查点 / 幂等键]
  O --> R[模型路由与导演规划]
  O --> P[提示词版本 / A-B 评估]
  O --> A[素材元数据 / 多轨时间线]
  O --> W[工作流目录与 manifest 校验]
  R --> S[SVG Motion]
  S --> X[执行 Agent / Chromium / FFmpeg]
  X --> Q[真实渲染证据]
  Q --> V[规则视觉 QA + 人工/视觉模型评审]
  V --> K[Atomstudy 知识沉淀]
  K --> O
  J[AI-PJ 提示词约束] -.-> R
```

## 本轮实际落地

| 模块 | 本轮实现 | 当前边界 |
|---|---|---|
| 可靠性/断点续跑 | 新增任务 JSON 持久化、状态机、revision、步骤状态/attempts、checkpoint、幂等键；原子写入；目录 0700、文件 0600；1 MiB 任务文件上限；跨进程目录锁；Worker claim/heartbeat/release 与过期租约接管；R4.1 增加事件数量/字节双上限、绝对事件游标、可恢复摘要索引、output/checkpoint 尺寸与任务记录安全线 | 已具备跨进程写互斥、租约原语和可选 Worker 运行时；摘要索引为可重建单 JSON 派生缓存，索引读取/写入仍随任务量增长；没有由插件自动托管的常驻进程监督、系统级自动恢复扫描；不自动重放有副作用步骤 |
| 多模型路由 | 按 role/provider/model 解析；宿主提供 route capability 列表时强制匹配；可选 fallback resolver；导演 planner 通过 `ctx.llm.stream` 调宿主 | 真实可用性由宿主请求决定；不读凭据、不猜测可用模型、不声称 provider 已联通 |
| AI 自动导演/视频生产 | 结构化导演初稿、时长/fps/帧数、叙事段落、镜头目的、转场意图、`renderAt(t)` 确定性约束；另有强模型 JSON planner 与 fallback | 生成计划，不代替 Chromium/FFmpeg；不声称已渲染视频或自动调度外部生成服务 |
| 视觉质量评审 | 规则 gate；新增真实 `ffprobe`/`ffmpeg` 适配器，采集流元数据、帧数、时长、黑帧与冻结帧证据；媒体路径受 `mediaRoots` 限制 | 平均亮度、字幕 OCR/碰撞、场景数、帧哈希和视觉语义复核仍未接入；缺失证据保持 incomplete，不填假值 |
| 知识库/自进化 | 结构化知识记录、关键词检索、提示词版本持久化；原子 JSON、来源/置信度可追溯 | 当前是轻量本地 JSON 知识库，不是向量数据库；没有自动从每次对话抽取知识，需显式调用保存工具 |
| 素材/时间轴 | 素材元数据登记/列出；多轨 clip 时间区间、ID、重叠和镜头目的检查 | 不复制大文件、不转码、不生成缩略图；真实媒体探测需接入 ffprobe/宿主执行器 |
| 提示词实验室 | body SHA-256 版本 ID、模型目标、变量、评分 rubric、A/B 分数差值 | 比较结果要求同一测试集/模型参数/评分规程；尚未内置模型批量执行器 |
| 工作流市场 | 4 个内置流程目录；本地 manifest schema 校验；只允许受限步骤类型和受限工具名 | 不执行不可信工作流；签名、权限审批、沙箱、版本分发和远程市场服务未实现 |

## 阶段推进

1. **P0 已落地（本包）**：可恢复任务底座、跨进程写锁、步骤状态机、planner 接入、路由核验、时间线和证据 QA、提示词/知识/素材持久化、工作流目录。
   - 第二轮持续开发增量：`creative_task_step_update`、`creative_task_claim/heartbeat/release`、跨进程写锁、租约所有权校验、重复步骤/幂等键校验、任务完成前步骤完整性校验。
2. **P1 待宿主联调**：Worker 常驻进程托管/监督、系统级自动恢复扫描、子 Agent 分工、模型 fallback 实际调用、执行器生命周期监督。跨进程写锁、worker 租约原语和可选 Worker 运行时已在本轮源码中落地，但仍需真实宿主环境验证。
3. **P2 部分落地**：ffprobe/ffmpeg 元数据、黑帧/冻结帧检测适配器已落地；待接入 Chromium 帧采集、字幕 OCR/碰撞检测、帧差/亮度曲线、视觉模型复核。
4. **P3 待权限与信任设计**：工作流签名、权限声明、审批门、沙箱、市场安装/更新/回滚。

### 第四轮增量（R4.1 / R4.2）

- 已落地：任务事件最多保留 500 条且总 JSON 字节不超过 256 KiB；`eventOffset` + 绝对游标使历史裁剪可见、可恢复读取。
- R4.1 已落地：单步 output / checkpoint 各 256 KiB，带结果的完整任务 JSON 安全线 900 KiB。
- R4.2 已落地：`task-index-v2/` 下 128 个确定性摘要分片、SHA-256 分片校验、所属分片增量更新、任务摘要 k-way merge 分页、claim 候选分片和审批待办专用分片/分页工具；旧单体索引会在成功迁移后清理。
- 仍待后续：独立 append-only 事件分段日志、数据库/B-tree 式 keyset 索引、Worker 执行器生命周期监督，以及真实 DSH profile / 浏览器端到端验收。


### 外部参考吸收（2026-11-14）

- 参考 DrawAI 的 P0–P7 制作门禁、首镜真实视频打样、真实成片元数据/音频检查与有界性能基准；参考 llc-pv-skill 的约 20 秒自然工作分段、音乐章节证据、逐镜高密度记录、三轮完整覆盖与版本绑定用户肯定。
- `creative_director_plan` 当前输出帧级半开区间、work-only segments、跨段全局相位、音频前置决策和 P0–P7 gate 契约；无切点证据时只建内部 checkpoint，不制造剪辑切点。
- 新增 `creative_review_validate` 检查三轮时间/镜头覆盖、最新 render version、证据声明、问题闭环及用户批准绑定。该工具只校验记录声明，不能证明真实观看、文件哈希内容、视觉正确或真实用户授权。
- 未复制 DrawAI 的 React/Remotion/Three.js 运行时，Orchestrator 仍为 Node.js 内置模块 zero-dependency；未引入 AE/PSD2Live 等强制外部依赖。
- 详细来源 revision、吸收映射、测试范围与后续边界见 `REFERENCE-ADOPTION-ANALYSIS.md`。

## 安全和兼容约束

- 不修改 DSH 宿主源码；新能力作为独立 Cordis 插件。
- 新插件只使用 Node.js 内置模块；无运行时第三方依赖。
- 不读取、不保存、不导出宿主 API key、OAuth token、Cookie 或浏览器登录态。
- 对外部工作流只做静态校验，不执行任意代码。
- 外部副作用步骤必须由执行 Agent 显式执行；检查点不等于可安全重放。
