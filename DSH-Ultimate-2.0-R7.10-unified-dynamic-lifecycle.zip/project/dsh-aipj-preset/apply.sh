#!/usr/bin/env bash
# AI-PJ v2.1 — 载荷重载：自检通过后重启 dsh web，让末端双层载荷生效。
#
# 为什么必须重启：载荷在 index.js 模块加载时 readFileSync 一次，config HMR
# 只重挂插件行、不重读文件。改动 prompts/*.md 后必须重启进程。
#
# 用法： bash ~/dsh-plugins/dsh-aipj-preset/apply.sh
#
# 注意：本脚本必须由文件执行（bash apply.sh），不要写成 `bash -c '...pkill -f "dsh web"...'`
#  —— 那样命令行自身含关键字，pkill -f 会把自己杀掉。
set -uo pipefail

PLUGIN_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROFILE_DIR="${DSH_PROFILE_DIR:-$HOME/.dsh/profiles/web}"
PORT=3081
LOG=/tmp/dsh-web.log

say() { printf '\033[1m%s\033[0m\n' "$1"; }
ok()  { printf '  \033[32m✓\033[0m %s\n' "$1"; }
bad() { printf '  \033[31m✗\033[0m %s\n' "$1"; }

say "1. 载荷预检（失败即中止，不重启）"
fail=0
for f in index.js prompts/aipj-kernel.md prompts/aipj-reinforce.md; do
  [[ -f "$PLUGIN_DIR/$f" ]] || { bad "缺 $f"; fail=1; }
done
[[ $fail -eq 0 ]] && ok "三个核心文件齐备"
node --check "$PLUGIN_DIR/index.js" 2>/dev/null || { bad "index.js 语法错误"; fail=1; }
[[ $fail -eq 0 ]] && ok "index.js 语法通过"
awk '/SECTION_ORDER_KERNEL = /{k=$NF+0} /SECTION_ORDER_REINFORCE = /{r=$NF+0} END{exit (k>10200 && r>10200)?0:1}' \
  "$PLUGIN_DIR/index.js" || { bad "槽位未落在末位区（应 > 10200）"; fail=1; }
[[ $fail -eq 0 ]] && ok "两槽位均在 10200 之后（末端区）"
[[ $fail -eq 0 ]] && ok "kernel $(sha256sum "$PLUGIN_DIR/prompts/aipj-kernel.md" | cut -c1-16)…  reinforce $(sha256sum "$PLUGIN_DIR/prompts/aipj-reinforce.md" | cut -c1-16)…"
if [[ $fail -ne 0 ]]; then
  printf '\033[31m预检未通过，已中止（dsh web 未动）。\033[0m\n'; exit 1
fi

say "2. 重启 dsh web"
old_pid=$(pgrep -f 'bin/dsh web' | head -1 || true)
if [[ -n "${old_pid:-}" ]]; then
  ok "旧进程 PID $old_pid"
  kill "$old_pid" 2>/dev/null || true
  for _ in $(seq 1 20); do kill -0 "$old_pid" 2>/dev/null || break; sleep 0.5; done
  kill -0 "$old_pid" 2>/dev/null && { kill -9 "$old_pid" 2>/dev/null || true; sleep 1; }
  ok "旧进程已退出"
else
  ok "未发现运行中的 dsh web（仅执行启动）"
fi

setsid nohup dsh web >"$LOG" 2>&1 < /dev/null &
disown 2>/dev/null || true
ok "已拉起新进程，stdout → $LOG"

say "3. 等待端口 ${PORT} 就绪"
up=0
for i in $(seq 1 60); do
  if curl -s -m 2 -o /dev/null "http://127.0.0.1:${PORT}"; then up=1; break; fi
  sleep 1
done
if [[ $up -eq 1 ]]; then
  ok "dsh web 在 ${PORT} 响应（等待 ${i}s）"
else
  bad "60s 内未就绪 —— 看 $LOG"
  tail -20 "$LOG" 2>/dev/null
  exit 1
fi

new_pid=$(pgrep -f 'bin/dsh web' | head -1 || true)
[[ -n "${new_pid:-}" ]] && ok "新进程 PID $new_pid"

say "完成"
printf '  新载荷已装载。会话内调用 \033[1maipj_profile\033[0m 应返回 pluginVersion 2.1.0、\n'
printf '  injection order 10300/10400。界面若显示重连，刷新页面即可。\n'
