/**
 * AI-PJ 设置桥（bridge.js）
 *
 * 为什么自建：本 profile 里宿主不会给 `plugins.row.config` 的行下发 `form`
 * （`PluginManagerPage.tsx:1255` 的 `formFor(id)` 要求客户端 settings 快照里存在
 * `ns === rowId` 的命名空间，实测本部署拿不到），因此配置面板改成打这条自建
 * 路由。做法与 `dsh-free-search` 的 `/api/dsh-free-search-settings` 同构——那是
 * 本 profile 里已被验证能跑通的模式。
 *
 * 数据面全部落在宿主 `settings` 服务上，插件本身不落盘：
 *   describe → `settings.describe({ redactSecrets: true })`
 *   mutate   → `settings.mutate(ns, ops, expectedRevision)`
 *
 * 安全边界：路由经宿主 `connection.fetch.register` 注册，请求已由 connection 的
 * `/api` 前置路由做过同源/Host 校验与 owner 鉴权；只接受 POST；请求体上限
 * 64 KiB；只暴露本插件的条目，不代理其它命名空间。
 *
 * @module dsh-aipj-preset/bridge
 */

/** 路由前缀。 */
export const BRIDGE_PREFIX = '/api/dsh-aipj-settings'

/** patch 行 id；命名空间可能带 `include:` 前缀，故按后缀匹配。 */
export const NS_ROW_ID = 'dsh-aipj-preset'

const MAX_JSON_BODY_BYTES = 64 * 1024

/** 构造 JSON 响应（Fetch 路由直接返回 Response，不再写 node:http res）。 */
function jsonResponse(status, body) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'content-type': 'application/json; charset=utf-8', 'referrer-policy': 'no-referrer' },
  })
}

async function readJsonBody(request) {
  const text = await request.text()
  if (Buffer.byteLength(text, 'utf8') > MAX_JSON_BODY_BYTES) return undefined
  try {
    return JSON.parse(text)
  } catch {
    return undefined
  }
}

/** 在 describe 结果里定位本插件的条目；允许 `include:` 之类的前缀。 */
function resolveDescriptor(descriptors) {
  if (!Array.isArray(descriptors)) return undefined
  return descriptors.find((d) => String(d.ns) === NS_ROW_ID)
    ?? descriptors.find((d) => String(d.ns).endsWith(':' + NS_ROW_ID))
    ?? descriptors.find((d) => String(d.ns).endsWith(NS_ROW_ID))
}

/** 只保留客户端渲染需要的字段，勿把整个 descriptor 原样透出。 */
function toView(descriptor) {
  return {
    ns: String(descriptor.ns),
    value: descriptor.value,
    revision: descriptor.revision,
    ...(descriptor.base === undefined ? {} : { base: descriptor.base }),
    ...(descriptor.user === undefined ? {} : { user: descriptor.user }),
  }
}

/**
 * 生成本插件的设置路由。
 *
 * @param settings 宿主 `settings` 服务。
 * @returns 可直接交给 `webServer.register` 的路由数组。
 */
export function createAipjBridge(settings, options = {}) {
  const descriptorOf = () => {
    const descriptors = settings.describe({ redactSecrets: true })
    return resolveDescriptor(descriptors)
  }

  const describe = async () => {
    const descriptor = descriptorOf()
    if (descriptor === undefined) {
      return { ok: false, code: 'namespace-missing', message: `settings descriptor for "${NS_ROW_ID}" not found` }
    }
    return { ok: true, value: { ...toView(descriptor), writable: settings.writable !== false } }
  }

  const mutate = async (body) => {
    if (body === null || typeof body !== 'object' || !Array.isArray(body.ops)) {
      return { ok: false, code: 'malformed', message: 'expected { ops: SettingsPathOp[] }' }
    }
    const descriptor = descriptorOf()
    if (descriptor === undefined) {
      return { ok: false, code: 'namespace-missing', message: `settings descriptor for "${NS_ROW_ID}" not found` }
    }
    const ns = String(descriptor.ns)
    // 只接受本插件的字段，杜绝把任意路径写进别的命名空间。
    const allowed = new Set(Object.keys(descriptor.value ?? {}))
    const ops = []
    for (const op of body.ops) {
      if (op === null || typeof op !== 'object' || op.op !== 'set') {
        return { ok: false, code: 'unsupported-op', message: 'only { op: "set" } is accepted' }
      }
      if (!Array.isArray(op.path) || op.path.length !== 1 || !allowed.has(op.path[0])) {
        return { ok: false, code: 'unknown-field', message: `field not editable: ${JSON.stringify(op.path)}` }
      }
      ops.push({ op: 'set', path: [op.path[0]], value: op.value })
    }
    const revision = Number.isInteger(body.revision) ? body.revision : undefined
    try {
      await settings.mutate(ns, ops, revision)
    } catch (error) {
      return { ok: false, code: 'settings-rejected', message: String(error && error.message ? error.message : error) }
    }
    if (typeof options.onMutated === "function") {
      try {
        const patch = Object.fromEntries(ops.map((o) => [o.path[0], o.value]))
        await options.onMutated(patch)
      } catch { /* bridge response stays authoritative */ }
    }
    const after = descriptorOf()
    return { ok: true, value: after === undefined ? undefined : { ...toView(after), writable: settings.writable !== false } }
  }

  const guard = (request) => {
    if (request.method !== 'POST') {
      return jsonResponse(405, { ok: false, code: 'method', message: `method not allowed: ${request.method}` })
    }
    return undefined
  }

  const route = (suffix, run) => ({
    path: `${BRIDGE_PREFIX}/${suffix}`,
    methods: ['POST'],
    requestBody: 'buffered',
    fetch: async (request) => {
      const rejection = guard(request)
      if (rejection !== undefined) return rejection
      const body = await readJsonBody(request)
      if (body === undefined) {
        return jsonResponse(400, { ok: false, code: 'malformed', message: 'malformed JSON body' })
      }
      return jsonResponse(200, await run(body))
    },
  })

  return [
    route('describe', () => describe()),
    route('mutate', (body) => mutate(body)),
  ]
}
