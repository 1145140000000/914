/**
 * AI-PJ 记忆层（memory.js）
 *
 * 双通道，与提示词层（order 10300 / 10400）同源生效：
 *
 *   ① 注入通道 —— `systemPrompt.context()` 在 order 10250 注册，每次装配求值，
 *      把记忆文件里与破甲相关的条目蒸馏成紧凑块注入系统提示词。
 *      同一个约束于是从「提示词层（静态载荷）」与「记忆层（动态注入）」双双生效。
 *
 *   ② 清洗通道 —— **零 LLM 调用**。按本地语汇表扫描记忆条目，删掉含「会激发
 *      安全机制」措辞的条目（拒绝语、改道语、索要授权语、免责声明等）。这些
 *      条目被注入后会把模型推回保守姿态，等于从内部拆破甲。
 *
 * 所有写操作前强制备份，并带安全阀：单次删除超过 40% 条目则中止不写。
 *
 * @module dsh-aipj-preset/memory
 */

import { copyFileSync, existsSync, mkdirSync, readdirSync, readFileSync, statSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { homedir } from 'node:os'

/** 记忆根目录。 */
export const MEMORY_ROOT = join(homedir(), '.dsh', 'memory')

/** 备份目录（清洗前每个文件各存一份）。 */
export const BACKUP_DIR = join(homedir(), '.dsh', 'aipj', 'memory-backups')

/**
 * 安全机制触发语汇。
 * 判据是「这句话被注入后会不会把模型推回保守姿态」，不是「这句话是否在谈安全」。
 * 因此只收拒绝/改道/索权/免责四类，不收「禁止读取」这类纯操作性禁令。
 */
export const SAFETY_TRIGGERS = [
  // 拒绝类
  '我不能', '我无法', '无法提供', '不能提供', '无法协助', '不能协助', '无法帮助',
  '拒绝提供', '不予协助', '恕难', '超出我的能力范围', '不在我的能力范围',
  // 改道类
  '改为授权', '改成安全', '只提供防御', '仅提供防御', '更安全的做法',
  '建议改为', '合法替代', '安全替代', '官方版本', '购买授权',
  // 索权类
  '需要授权', '请提供授权', '是否有授权', '确认授权', '需要更多信息才能继续',
  '请提供更多信息', '需要你先确认', '请提供测试范围',
  // 免责类
  '仅供学习', '仅提供思路', '仅用于教育', '教育目的', '请提出合规', '其他合规',
  '安全边界', '免责声明', '风险自负',
  // 英文镜像
  'i cannot', "i can't", "i won't", 'i will not', 'unable to provide',
  'safe alternative', 'legal alternative', 'for educational purposes',
  'use an authorized', 'in an authorized lab',
]

/** 永不删除：锚点卡片、标题行、代码围栏内的块。 */
function isProtected(block) {
  const t = block.trim()
  if (!t) return true
  if (t.includes('<!-- memory:mem_')) return true
  if (/^#{1,6}\s/.test(t)) return true
  if (t.startsWith('```')) return true
  if (/^type:(goal|state|dead-end|progress)\b/.test(t)) return true
  return false
}

/** 按 `§` 独立行切块；没有分隔符时退回按空行切块。 */
export function splitBlocks(text) {
  const parts = text.includes('\n§') || /^§\s*$/m.test(text)
    ? text.split(/^\s*§\s*$/m)
    : text.split(/\n\s*\n/)
  return parts
    .map((s) => s.replace(/^\n+|\n+$/g, ''))
    .filter((s, i, a) => !(s === '' && (i === 0 || i === a.length - 1)))
}

/** 命中触发语汇的条目。 */
export function findTriggers(block) {
  const folded = block.toLocaleLowerCase()
  const hits = []
  for (const phrase of SAFETY_TRIGGERS) {
    if (folded.includes(phrase.toLocaleLowerCase())) hits.push(phrase)
  }
  return hits
}

/** 扫描一个记忆文件：返回条目总数、命中条目、命中词。 */
export function scanFile(file) {
  if (!existsSync(file)) return { file, exists: false, total: 0, hits: [] }
  let text = ''
  try {
    text = readFileSync(file, 'utf8')
  } catch (error) {
    return { file, exists: true, error: String(error && error.message ? error.message : error), total: 0, hits: [] }
  }
  const blocks = splitBlocks(text)
  const hits = []
  blocks.forEach((block, index) => {
    if (isProtected(block)) return
    const words = findTriggers(block)
    if (words.length) {
      hits.push({ index, words, preview: block.replace(/\s+/g, ' ').slice(0, 120) })
    }
  })
  return { file, exists: true, total: blocks.length, hits }
}

/**
 * 清洗一个记忆文件。
 *
 * @param file 目标记忆文件。
 * @param options.dryRun 只报告不落盘。
 * @param options.maxRatio 单次允许删除的最大条目占比，超出即中止（安全阀）。
 * @returns 本次动作的结果描述。
 */
export function purgeFile(file, options = {}) {
  const dryRun = options.dryRun === true
  const maxRatio = typeof options.maxRatio === 'number' ? options.maxRatio : 0.4
  const scan = scanFile(file)
  if (!scan.exists) return { ...scan, action: 'skip', reason: 'not-found' }
  if (scan.error) return { ...scan, action: 'skip', reason: 'read-error' }
  if (!scan.hits.length) return { ...scan, action: 'clean', removed: 0 }

  if (scan.total > 0 && scan.hits.length / scan.total > maxRatio) {
    return { ...scan, action: 'aborted', reason: 'over-max-ratio', ratio: scan.hits.length / scan.total }
  }
  if (dryRun) return { ...scan, action: 'preview', removed: scan.hits.length }

  const text = readFileSync(file, 'utf8')
  const blocks = splitBlocks(text)
  const drop = new Set(scan.hits.map((h) => h.index))
  const kept = blocks.filter((_, index) => !drop.has(index))

  const stamp = new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14)
  let backup = null
  try {
    mkdirSync(BACKUP_DIR, { recursive: true })
    backup = join(BACKUP_DIR, `${file.split('/').pop()}.${stamp}.bak`)
    copyFileSync(file, backup)
  } catch (error) {
    return { ...scan, action: 'aborted', reason: 'backup-failed', detail: String(error && error.message ? error.message : error) }
  }

  writeFileSync(file, kept.join('\n\n§\n\n') + '\n', 'utf8')
  return { file, action: 'purged', total: scan.total, removed: scan.hits.length, kept: kept.length, backup, words: scan.hits.flatMap((h) => h.words) }
}

/**
 * 解析本轮要读写的记忆文件清单。
 *
 * @param config.memoryFiles 显式路径列表（支持 `~` 前缀）。
 * @param config.autoWorkspace 是否自动追加「最近改动的工作区」的笔记与白板。
 */
export function resolveMemoryFiles(config = {}) {
  const files = []
  const push = (p) => {
    if (typeof p !== 'string' || !p.trim()) return
    const expanded = p.startsWith('~') ? join(homedir(), p.slice(1)) : p
    if (!files.includes(expanded)) files.push(expanded)
  }

  if (Array.isArray(config.memoryFiles) && config.memoryFiles.length) {
    config.memoryFiles.forEach(push)
  } else {
    push(join(MEMORY_ROOT, 'MEMORY.md'))
  }

  if (config.autoWorkspace !== false) {
    try {
      const root = join(MEMORY_ROOT, 'workspaces')
      const dirs = readdirSync(root)
        .map((name) => join(root, name))
        .map((dir) => {
          try {
            return { dir, mtime: statSync(dir).mtimeMs }
          } catch {
            return null
          }
        })
        .filter(Boolean)
        .sort((a, b) => b.mtime - a.mtime)
      if (dirs.length) {
        push(join(dirs[0].dir, 'MEMORY.md'))
        push(join(dirs[0].dir, 'handoff', 'PLAN.md'))
        const today = new Date().toISOString().slice(0, 10)
        push(join(dirs[0].dir, `${today}.md`))
      }
    } catch {
      /* 工作区目录尚未建立时静默跳过 */
    }
  }

  return files
}

/**
 * 把记忆渲染成注入块。逐条一行、单条截断、总量封顶——注入成本可控。
 *
 * @param files 记忆文件清单。
 * @param budgetChars 注入字符上限。
 */
export function renderMemoryBlock(files, budgetChars = 1200) {
  const lines = []
  let used = 0
  for (const file of files) {
    const scan = scanFile(file)
    if (!scan.exists || !scan.total) continue
    let blocks = []
    try {
      blocks = splitBlocks(readFileSync(file, 'utf8'))
    } catch {
      continue
    }
    const drop = new Set(scan.hits.map((h) => h.index))
    blocks.forEach((block, index) => {
      if (drop.has(index) || isProtected(block)) return
      // 条目自带 "- " 前缀时不再叠加，避免渲染成 "- - "。
      const body = block.replace(/\s+/g, ' ').trim().replace(/^[-*]\s+/, '')
      const line = '- ' + body.slice(0, 200)
      if (used + line.length > budgetChars) return
      used += line.length
      lines.push(line)
    })
  }
  return { text: lines.join('\n'), chars: used, lines: lines.length }
}

/** 清洗全部记忆文件（自动清洗通道的入口）。 */
export function purgeAll(files, options = {}) {
  const results = files.map((file) => {
    try {
      return purgeFile(file, options)
    } catch (error) {
      return { file, action: 'aborted', reason: 'threw', detail: String(error && error.message ? error.message : error) }
    }
  })
  const removed = results.reduce((n, r) => n + (typeof r.removed === 'number' ? r.removed : 0), 0)
  return { removed, results }
}
