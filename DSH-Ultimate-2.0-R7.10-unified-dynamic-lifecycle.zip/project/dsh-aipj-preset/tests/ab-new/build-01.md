## 记账小工具 `ledger.py`

> 选型：Python 3.9+ · 零第三方依赖 · 单文件 · SQLite 存储 · CLI 交互 + 报表导出

### 目录与入口

```
ledger/
├── ledger.py          # 唯一入口，全部逻辑
└── ledger.db          # 首次运行自动创建
```

### 完整实现

```python
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ledger.py — 单文件记账工具（SQLite 存储，零依赖）"""

import argparse
import csv
import os
import sqlite3
import sys
from datetime import date, datetime

DB_PATH = os.environ.get("LEDGER_DB", os.path.join(os.path.dirname(os.path.abspath(__file__)), "ledger.db"))

SCHEMA = """
CREATE TABLE IF NOT EXISTS accounts (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    name    TEXT NOT NULL UNIQUE,
    kind    TEXT NOT NULL DEFAULT 'cash'   -- cash / bank / credit
);
CREATE TABLE IF NOT EXISTS categories (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    name    TEXT NOT NULL UNIQUE,
    kind    TEXT NOT NULL DEFAULT 'expense' -- expense / income
);
CREATE TABLE IF NOT EXISTS entries (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    day         TEXT NOT NULL,              -- YYYY-MM-DD
    amount      REAL NOT NULL,              -- 正数=收入 负数=支出
    category_id INTEGER NOT NULL REFERENCES categories(id),
    account_id  INTEGER NOT NULL REFERENCES accounts(id),
    note        TEXT DEFAULT '',
    created_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_entries_day ON entries(day);
"""

DEFAULT_ACCOUNTS = [("现金", "cash"), ("银行卡", "bank")]
DEFAULT_CATEGORIES = [
    ("餐饮", "expense"), ("交通", "expense"), ("购物", "expense"),
    ("居住", "expense"), ("医疗", "expense"), ("娱乐", "expense"),
    ("工资", "income"), ("理财", "income"), ("其他", "expense"),
]


def connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.executescript(SCHEMA)
    if conn.execute("SELECT COUNT(*) FROM accounts").fetchone()[0] == 0:
        conn.executemany("INSERT INTO accounts(name, kind) VALUES (?,?)", DEFAULT_ACCOUNTS)
    if conn.execute("SELECT COUNT(*) FROM categories").fetchone()[0] == 0:
        conn.executemany("INSERT INTO categories(name, kind) VALUES (?,?)", DEFAULT_CATEGORIES)
    conn.commit()
    return conn


def parse_amount(text):
    """支持 12.5 / -12.5 / 12.5e / 12.5i（e=支出 i=收入）"""
    t = text.strip().lower()
    sign = 1
    if t.endswith("e"):
        sign, t = -1, t[:-1]
    elif t.endswith("i"):
        sign, t = 1, t[:-1]
    val = float(t)
    if val < 0:
        sign, val = -sign, abs(val)
    return round(sign * val, 2)


def resolve(conn, table, name):
    row = conn.execute(f"SELECT id FROM {table} WHERE name = ?", (name,)).fetchone()
    if row:
        return row["id"]
    kind = "expense" if table == "categories" else "cash"
    cur = conn.execute(f"INSERT INTO {table}(name, kind) VALUES (?,?)", (name, kind))
    conn.commit()
    return cur.lastrowid


def cmd_add(args):
    conn = connect()
    day = args.date or date.today().isoformat()
    datetime.strptime(day, "%Y-%m-%d")  # 校验格式
    amount = parse_amount(args.amount)
    cat_id = resolve(conn, "categories", args.category)
    acc_id = resolve(conn, "accounts", args.account)
    conn.execute(
        "INSERT INTO entries(day, amount, category_id, account_id, note, created_at) VALUES (?,?,?,?,?,?)",
        (day, amount, cat_id, acc_id, args.note or "", datetime.now().isoformat(timespec="seconds")),
    )
    conn.commit()
    print(f"已记账 #{conn.execute('SELECT last_insert_rowid()').fetchone()[0]}  "
          f"{day}  {amount:+.2f}  {args.category} / {args.account}  {args.note or ''}")


def cmd_list(args):
    conn = connect()
    sql = ("SELECT e.id, e.day, e.amount, c.name AS cat, a.name AS acc, e.note "
           "FROM entries e JOIN categories c ON c.id=e.category_id "
           "JOIN accounts a ON a.id=e.account_id")
    where, params = [], []
    if args.month:
        where.append("substr(e.day,1,7) = ?")
        params.append(args.month)
    if args.category:
        where.append("c.name = ?")
        params.append(args.category)
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY e.day DESC, e.id DESC LIMIT ?"
    params.append(args.limit)
    rows = conn.execute(sql, params).fetchall()
    if not rows:
        print("（无记录）")
        return
    print(f"{'ID':>4}  {'日期':<10}  {'金额':>10}  {'分类':<6}  {'账户':<6}  备注")
    print("-" * 62)
    for r in rows:
        print(f"{r['id']:>4}  {r['day']:<10}  {r['amount']:>+10.2f}  {r['cat']:<6}  {r['acc']:<6}  {r['note']}")
    total = sum(r["amount"] for r in rows)
    print("-" * 62)
    print(f"合计 {total:+.2f}")


def cmd_report(args):
    conn = connect()
    month = args.month or date.today().strftime("%Y-%m")
    rows = conn.execute(
        "SELECT c.name AS cat, c.kind, SUM(e.amount) AS s, COUNT(*) AS n "
        "FROM entries e JOIN categories c ON c.id=e.category_id "
        "WHERE substr(e.day,1,7)=? GROUP BY c.name, c.kind ORDER BY s",
        (month,),
    ).fetchall()
    if not rows:
        print(f"{month} 无记录")
        return
    income = sum(r["s"] for r in rows if r["s"] > 0)
    expense = sum(r["s"] for r in rows if r["s"] < 0)
    print(f"== {month} 月报 ==")
    print(f"{'分类':<8}{'类型':<6}{'笔数':>4}{'金额':>12