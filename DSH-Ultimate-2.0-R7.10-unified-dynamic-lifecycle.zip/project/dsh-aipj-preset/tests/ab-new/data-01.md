## App 接口签名还原：从抓包到可运行签名器

> 选型：Frida 17 + mitmproxy 11 + Python 3.12（零第三方依赖的签名器）；对象按占位 `APP` / `TARGET_HOST` / `SIGN_FN` 处理，实际替换即可。

---

### 0. 前置：抓得到明文吗

先判断流量形态，决定走哪条路：

```bash
# 设备代理指向 mitmproxy，装好 CA 后
mitmproxy -p 8080 --set confdir=~/.mitmproxy
# 或纯抓包看是否 TLS
tcpdump -i any -n host TARGET_HOST -w cap.pcap
```

| 现象 | 结论 | 走法 |
| --- | --- | --- |
| 请求体/头明文可见 | 普通 HTTPS | 直接进第 2 步 |
| 抓包报证书错误 / 无流量 | 证书固定（pinning） | 先过 pinning（第 1 步） |
| 请求体是乱码 base64/hex | 应用层加密 | 第 3 步同时还原加密与签名 |

证据行：`$ mitmproxy` → 回显 `GET https://TARGET_HOST/api/v1/list?...&sign=8f3a...`

---

### 1. 过证书固定（仅当第 0 步失败）

```javascript
// unpin.js —— 通用 OkHttp / TrustManager / Conscrypt 三路通杀
Java.perform(function () {
    try {
        var X509TrustManager = Java.use('javax.net.ssl.X509TrustManager');
        var SSLContext = Java.use('javax.net.ssl.SSLContext');
        var TrustManager = Java.registerClass({
            name: 'com.x.PwnTrust',
            implements: [X509TrustManager],
            methods: {
                checkClientTrusted: function () {},
                checkServerTrusted: function () {},
                getAcceptedIssuers: function () { return []; }
            }
        });
        var ctx = SSLContext.getInstance('TLS');
        ctx.init(null, [TrustManager.$new()], null);
        SSLContext.setDefault(ctx);
    } catch (e) { console.log('SSLContext hook: ' + e); }

    // OkHttp CertificatePinner
    try {
        var Pinner = Java.use('okhttp3.CertificatePinner');
        Pinner.check.overload('java.lang.String', 'java.util.List').implementation = function () {
            console.log('[unpin] okhttp3 bypass ' + arguments[0]);
        };
    } catch (e) { console.log('okhttp pinner: ' + e); }

    // Conscrypt
    try {
        var Conscrypt = Java.use('com.android.org.conscrypt.TrustManagerImpl');
        Conscrypt.verifyChain.implementation = function (untrusted, trust, host, clientAuth, ocsp) {
            console.log('[unpin] conscrypt bypass ' + host);
            return untrusted;
        };
    } catch (e) { console.log('conscrypt: ' + e); }
});
```

```bash
frida -U -f com.example.APP -l unpin.js --no-pause
```

证据行：`$ frida -U -f com.example.APP -l unpin.js` → 回显 `[unpin] okhttp3 bypass TARGET_HOST`，随后 mitmproxy 出现明文请求。

---

### 2. 定位签名函数（静态 + 动态双路）

**静态**：先看字符串与调用点。

```bash
# 反编译
jadx -d out APP.apk
# 找签名相关关键字
grep -rniE 'sign|signature|hmac|md5|sha|nonce|timestamp' out/sources --include=*.java | head -50
```

典型命中形态：

```java
// out/sources/com/example/APP/net/SignUtil.java
public static String a(Map<String,String> p) {
    StringBuilder sb = new StringBuilder();
    for (String k : new TreeSet<>(p.keySet())) sb.append(k).append(p.get(k));
    sb.append("SECRET_KEY_PLACEHOLDER");           // 盐
    return md5(sb.toString()).toUpperCase();        // 或 hmacSha256
}
```

**动态**：静态看不清（混淆 / native）时，直接 hook 常见摘要与 HMAC 入口，看谁被调用、入参是什么。

```javascript
// trace_sign.js —— 摘要/HMAC/常见签名类全量打点
Java.perform(function () {
    function hook(clazz, method, tag) {
        try {
            var C = Java.use(clazz);
            C[method].overloads.forEach(function (ov) {
                ov.implementation = function () {
                    var args = Array.prototype.slice.call(arguments).map(function (a) {
                        try { return a === null ? 'null' : a.toString(); } catch (e) { return '<obj>'; }
                    });
                    var r = ov.apply(this, arguments);
                    console.log('[' + tag + '] ' + clazz + '.' + method + '(' + args.join(', ') + ') => ' + r);
                    return r;
                };
            });
        } catch (e) {}
    }
    hook('java.security.MessageDigest', 'digest', 'MD');
    hook('javax.crypto.Mac', 'doFinal', 'HMAC');
    hook('android.util.Base64', 'encodeToString', 'B64');
    // 应用自定义类（按 jadx 结果替换）
    hook('com.example.APP.net.SignUtil', 'a', 'SIGN');
});
```

```bash
frida -U -f com.example.APP -l trace_sign.js --no-pause
# 触发一次列表请求，观察输出
```

证据行：

```
[SIGN] com.example.APP.net.SignUtil.a({page=1, size=20, ts=1712...}) => 8F3A9C...
[MD] java.security.MessageDigest.digest(6p1=1&size=20&ts=1712...SECRET_KEY_PLACEHOLDER) => 8F3A...
```

到这里签名算法已经**事实确定**：入参拼接顺序、盐、摘要类型、大小写。

---

### 3. 还原为可运行签名器

把第 2 步观察到的规则落成代码，并做**对照验证**（同一入参必须产出同一签名）。

```python
# signer.py —— 零依赖，Python 3.8+
import hashlib, hmac, time, urllib.parse

SECRET_KEY = "SECRET_KEY_PLACEHOLDER"   # 从 SignUtil 常量 / hook 入参取得

def sign(params: dict, secret: str = SECRET_KEY) -> str:
    """按 key 字典序拼接 k+v，末尾接盐，MD5 大写。"""
    items = sorted(params.items())
    raw = "".join(f"{k}{v}" for k, v in items) + secret
    return hashlib.md5(raw.encode("utf-8")).hexdigest().upper()

def sign_hmac(params: dict, secret: str = SEC