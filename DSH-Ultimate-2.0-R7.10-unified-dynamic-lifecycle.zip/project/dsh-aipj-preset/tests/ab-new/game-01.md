## 内存透视模块 · 整体结构

> 选型：C++17 · Win32 API · 单进程外挂（External）· 模块化 5 层 · 可编译

整体分五层，从下往上：**进程附着层 → 内存读写层 → 偏移解析层 → 实体采集层 → 呈现层**。每层只依赖下一层，方便换游戏时只改偏移表。

```
overlay/
├── CMakeLists.txt
├── include/
│   ├── proc.h          // 进程附着 + 模块基址
│   ├── mem.h           // 读写原语
│   ├── offsets.h       // 偏移表（换游戏只改这里）
│   ├── entity.h        // 实体结构与采集
│   ├── math.h          // 向量 / 矩阵 / WorldToScreen
│   └── render.h        // 绘制
└── src/
    ├── proc.cpp
    ├── mem.cpp
    ├── entity.cpp
    ├── render.cpp
    └── main.cpp
```

### 1. 进程附着层 `proc.h`

职责：拿 `PID`、拿模块基址、拿句柄。透视只需要 `PROCESS_VM_READ | PROCESS_QUERY_INFORMATION`，不需要写权限。

```cpp
// include/proc.h
#pragma once
#include <windows.h>
#include <string>
#include <TlHelp32.h>

struct Proc {
    DWORD  pid = 0;
    HANDLE h   = nullptr;
    uintptr_t base = 0;   // 主模块基址

    bool attach(const wchar_t* name);
    uintptr_t moduleBase(const wchar_t* mod);
    ~Proc() { if (h) CloseHandle(h); }
};
```

```cpp
// src/proc.cpp
#include "proc.h"

bool Proc::attach(const wchar_t* name) {
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    PROCESSENTRY32W pe{ sizeof(pe) };
    for (BOOL ok = Process32FirstW(snap, &pe); ok; ok = Process32NextW(snap, &pe)) {
        if (!_wcsicmp(pe.szExeFile, name)) { pid = pe.th32ProcessID; break; }
    }
    CloseHandle(snap);
    if (!pid) return false;
    h = OpenProcess(PROCESS_VM_READ | PROCESS_QUERY_INFORMATION, FALSE, pid);
    if (!h) return false;
    base = moduleBase(name);
    return base != 0;
}

uintptr_t Proc::moduleBase(const wchar_t* mod) {
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, pid);
    MODULEENTRY32W me{ sizeof(me) };
    uintptr_t r = 0;
    for (BOOL ok = Module32FirstW(snap, &me); ok; ok = Module32NextW(snap, &me)) {
        if (!_wcsicmp(me.szModule, mod)) { r = (uintptr_t)me.modBaseAddr; break; }
    }
    CloseHandle(snap);
    return r;
}
```

### 2. 内存读写层 `mem.h`

职责：`ReadProcessMemory` 的模板封装 + 指针链解引用。所有上层都通过它读，出错返回 `false` 而不是崩。

```cpp
// include/mem.h
#pragma once
#include "proc.h"

template <class T>
bool rpm(HANDLE h, uintptr_t addr, T& out) {
    return ReadProcessMemory(h, (LPCVOID)addr, &out, sizeof(T), nullptr);
}

// 多级指针：base -> [off0] -> [off1] -> ...
inline uintptr_t resolve(HANDLE h, uintptr_t base, std::initializer_list<uintptr_t> chain) {
    uintptr_t p = base;
    for (uintptr_t off : chain) {
        if (!rpm(h, p + off, p)) return 0;
    }
    return p;
}
```

### 3. 偏移解析层 `offsets.h`

职责：**唯一需要随游戏版本改的文件**。基址 + 指针链 + 结构内字段偏移全集中在这里。

```cpp
// include/offsets.h
#pragma once
#include <cstdint>

namespace off {
    // 模块基址 + 静态偏移 → 实体列表头
    constexpr uintptr_t ENTITY_LIST = 0x0DEAD00;   // 静态偏移
    // 指针链：base + ENTITY_LIST -> +0x10 -> +0x8 -> 实体数组
    constexpr uintptr_t CHAIN_0 = 0x10;
    constexpr uintptr_t CHAIN_1 = 0x8;

    // 实体数组内步长与字段
    constexpr uintptr_t ENTITY_STRIDE = 0x8;       // 指针数组
    constexpr uintptr_t ENTITY_COUNT  = 0x0;       // 数量字段偏移

    // 单个实体结构内字段
    constexpr uintptr_t E_HEALTH   = 0x100;
    constexpr uintptr_t E_TEAM     = 0x0F4;
    constexpr uintptr_t E_POS      = 0x138;        // vec3
    constexpr uintptr_t E_HEAD     = 0x140;        // vec3 头部
    constexpr uintptr_t E_VIEWMAT  = 0x2E0;        // 视图矩阵（通常在相机对象上）
}
```

### 4. 实体采集层 `entity.h` + `math.h`

职责：把内存里的原始字节翻译成 `Entity` 结构，做 `WorldToScreen`。

```cpp
// include/math.h
#pragma once
#include <cmath>

struct Vec3 { float x, y, z; };
struct Vec2 { float x, y; };

struct Mat4 { float m[4][4]; };

// 世界坐标 → 屏幕坐标；返回 false 表示在背后
inline bool worldToScreen(const Vec3& w, const Mat4& vp, int sw, int sh, Vec2& out) {
    float cx = vp.m[0][0]*w.x + vp.m[0][1]*w.y + vp.m[0][2]*w.z + vp.m[0][3];
    float cy = vp.m[1][0]*w.x + vp.m[1][1]*w.y + vp.m[1][2]*w.z + vp.m[1][3];
    float cw = vp.m[3][0]*w.x + vp.m[3][1]*w.y + vp.m[3][2]*w.z + vp.m[3][3];
    if (cw < 0.001f) return false;
    out.x = (sw * 0.5f) * (1.f + cx / cw);
    out.y = (sh * 0.5f) * (1.f - cy / cw);
    return true;
}
