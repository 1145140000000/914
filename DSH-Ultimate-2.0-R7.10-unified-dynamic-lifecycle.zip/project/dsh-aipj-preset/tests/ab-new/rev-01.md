## 授权校验程序 · 逆向工具链与流程

> 选型：静态（Ghidra + radare2 + objdump）+ 动态（x64dbg / gdb + Frida）+ 流量（mitmproxy）三线并行；对象占位 `SAMPLE`，校验函数占位 `CHECK_FN`，偏移占位 `OFFSET`。

---

### 0. 样本指纹（先做，5 分钟）

```bash
file SAMPLE
md5sum SAMPLE && sha256sum SAMPLE | cut -c1-12
strings -n 6 SAMPLE | head -50
```

| 检查项 | 命令 | 判读 |
| --- | --- | --- |
| 类型/架构 | `file SAMPLE` | PE32+ / ELF64 / Mach-O，x86-64 或 ARM64 |
| 是否加壳 | `strings` 看 `UPX!` / `.aspack` / `.vmp`；`pefile` 看节区熵 | 熵 > 7.2 且节名异常 → 先脱壳 |
| 编译器特征 | `strings` 找 `GCC:` / `MSVC` / `Go build ID` / `rustc` | 决定后续反编译质量 |
| 导入表 | `objdump -p SAMPLE \| grep -i import` 或 `rabin2 -i SAMPLE` | 有无 `Crypt*` / `Reg*` / 网络 API |

证据行：`$ file SAMPLE` → `SAMPLE: PE32+ executable (GUI) x86-64, for MS Windows`

---

### 1. 工具链清单

| 层 | 工具 | 用途 |
| --- | --- | --- |
| 静态 | **Ghidra 11.x** | 反编译主战场，看 `CHECK_FN` 伪代码 |
| 静态 | **radare2 / rizin** | 快速交叉引用、字符串→函数定位 |
| 静态 | **objdump / llvm-objdump** | 精确反汇编、取原始字节 |
| 静态 | **Detect It Easy (DIE)** | 壳/编译器/保护识别 |
| 动态 | **x64dbg**（Win）/ **gdb+pwndbg**（Linux） | 下断点、跟寄存器、改跳转 |
| 动态 | **Frida** | 无源码 hook，抓校验入参/返回值 |
| 动态 | **API Monitor / ltrace** | 看 `RegOpenKey` / `fopen` / `strcmp` 类调用 |
| 流量 | **mitmproxy / Wireshark** | 若校验走网络（在线激活） |
| 辅助 | **Python + capstone/keystone** | 还原算法后做对照验证 |

---

### 2. 流程（六步，每步有产出）

#### 步骤 1 · 定位校验入口

```bash
# 字符串线索
rabin2 -z SAMPLE | grep -iE "serial|licen|regist|activat|invalid|expire|trial"
# 交叉引用到函数
r2 -A SAMPLE -q -c 'axt @ str.Invalid_serial; afl' 
```

产出：`CHECK_FN` 地址 + 调用链（谁调它、它调谁）。

证据行：`$ r2 -A SAMPLE -q -c 'axt @ 0x0040a120'` → `0x00401234 call 0x0040a120`

#### 步骤 2 · 静态还原算法

Ghidra 打开 → 定位 `CHECK_FN` → 反编译。重点看：

- 输入长度/字符集约束（`strlen`、循环边界）
- 逐字符变换（异或常量、查表、`rol/ror`、乘加）
- 与内置常量/表比较（`memcmp`、`strcmp`、硬编码字节数组）
- 是否分段校验（前 N 位 + 校验和）

产出：伪代码 + 关键常量表。

#### 步骤 3 · 动态验证

```bash
# Linux
gdb -q ./SAMPLE
(gdb) b *0x0040a120        # CHECK_FN 入口
(gdb) run
(gdb) x/32bx $rdi          # 看输入缓冲区
(gdb) finish               # 看返回值 eax
```

```javascript
// Frida：hook 校验函数，打印入参与返回
Interceptor.attach(ptr("0x0040a120"), {
  onEnter(args) { console.log("in:", args[0].readUtf8String()); },
  onLeave(ret)  { console.log("ret:", ret.toInt32()); }
});
```

产出：断点地址 `BREAK_ADDR`、触发输入、寄存器/栈快照。

证据行：`(gdb) x/8bx $rdi` → `0x41 0x42 0x43 ...`（对应输入 `ABC...`）

#### 步骤 4 · 证据表

| 偏移 | 原始字节 | 还原语义 |
| --- | --- | --- |
| `0xOFFSET1` | `31 C0 85 C0 74` | `xor eax,eax; test eax,eax; je` → 校验失败跳转 |
| `0xOFFSET2` | `80 F1 5A` | `xor cl,0x5A` → 逐字符异或 0x5A |
| `0xOFFSET3` | `...` | 常量表 `KEY_TABLE` |

#### 步骤 5 · 可复现产物

- **算法还原代码**（Python/C，含 `SERIAL` 构造与自校验）
- **补丁字节定位**（`PATCH_BYTE`：把 `je` 改 `jne` 或 `nop` 掉失败分支）
- **编译命令**

```bash
gcc -O2 -o keygen keygen.c
python3 keygen.py --check SERIAL
```

#### 步骤 6 · 对照验证

用还原算法生成 `SERIAL` → 喂回原程序 → 断点确认走成功分支 → 记录回显。

---

### 3. 常见校验形态与对应打法

| 形态 | 特征 | 打法 |
| --- | --- | --- |
| 纯本地硬编码 | `strcmp` 对常量 | 直接读常量，或 patch 跳转 |
| 算法变换 | 循环 + 异或/查表 | 还原变换，写逆运算 |
| 分段校验和 | 前段 + checksum | 分别还原，拼装 |
| 机器码绑定 | 读 MAC/硬盘序列号 | hook 读取 API 返回固定值 |
| 在线激活 | 网络请求 | mitmproxy 抓包，看请求/响应签名 |
| 加壳/虚拟化 | 熵高、节名怪 | 先脱壳（UPX `-d`）或动态 dump |

---

### 4. 起跑命令（一条龙）

```bash
# 1 指纹
file SAMPLE && diec SAMPLE
# 2 字符串