## APK 脱壳流程（壳型判定 → 静态定位 → 动态 dump → 重建回验）

> 选型：Frida 16.x + frida-dexdump + jadx 1.5 + apktool 2.9；目标占位 `SAMPLE.apk`，包名 `com.example.app`，入口 `com.example.app.MainActivity`

---

### 0. 环境与样本指纹

```bash
# 工具就位
pip install frida-tools frida-dexdump
# 设备侧
adb push frida-server-16.x-android-<arch> /data/local/tmp/frida-server
adb shell "su -c 'chmod 755 /data/local/tmp/frida-server && /data/local/tmp/frida-server &'"

# 样本指纹
apkid SAMPLE.apk
# 期望回显形如：
# [*] APKiD 2.1.1
# [*] com.example.app
# [*] DEX
# [*]   packer : 360Jiagu / Tencent Legu / Bangcle / ijiami / Naga / 无壳
# [*]   anti_vm : 有/无
# [*]   anti_debug : 有/无
```

```bash
# 结构速览
unzip -l SAMPLE.apk | grep -E 'assets/|lib/|classes.*dex'
# 典型壳特征：
#   assets/libjiagu*.so / assets/ijiami.dat / assets/0OO00l111l1l / lib/arm64-v8a/libshella-*.so
#   classes.dex 极小（<100KB）且 Application 指向壳类
```

证据行：`$ apkid SAMPLE.apk` → `packer : <壳名>`；`$ unzip -l SAMPLE.apk` → `classes.dex 81920 bytes`（壳 dex 特征）

---

### 1. 壳型判定与脱壳策略选择

| 壳型 | 判定特征 | 策略 |
| --- | --- | --- |
| 一代壳（DEX 整体加密） | `classes.dex` 小、`assets/` 有加密 dex | 内存 dump + dex 修复 |
| 二代壳（类抽取 / VMP） | `libjiagu.so`、方法体 `nop`/`throw` | dump + 方法体回填（FART / Youpk） |
| 加固 + 反调试 | `anti_debug` 命中 | 先过反调试再 dump |
| 无壳 | `apkid` 无 packer | 直接 jadx |

```bash
# 确认 Application 是否被壳接管
jadx -d out_stub SAMPLE.apk
grep -r "android:name" out_stub/resources/AndroidManifest.xml | head
# 壳接管时形如：android:name="com.stub.StubApp"
```

证据行：`AndroidManifest.xml` → `android:name="com.stub.StubApp"`（壳入口）

---

### 2. 静态定位（壳 dex 里能看的部分）

```bash
# 反编译壳 dex，找 Application.attachBaseContext / onCreate
jadx -d out_stub SAMPLE.apk
# 关键点：
#   StubApp.attachBaseContext()  -> 加载 libxxx.so、解密真实 dex
#   StubApp.onCreate()           -> 反射调用真实 Application
```

```bash
# native 层看壳 so 的导出
unzip -o SAMPLE.apk 'lib/*' -d libs
nm -D libs/lib/arm64-v8a/libjiagu.so | grep -iE 'dex|load|decrypt|attach'
# 或
readelf -sW libs/lib/arm64-v8a/libjiagu.so | grep FUNC | head -40
```

证据行：`$ nm -D libjiagu.so` → `Java_com_stub_StubApp_...` 导出符号（JNI 入口）

---

### 3. 动态脱壳（核心）

#### 3.1 起进程并挂起等待

```bash
adb shell am start -D -n com.example.app/com.stub.StubApp
# 或直接普通启动后 attach
adb shell monkey -p com.example.app 1
frida-ps -U | grep example
```

#### 3.2 过反调试（若 apkid 命中 anti_debug）

```javascript
// bypass_anti.js
Java.perform(function () {
    var Debug = Java.use('android.os.Debug');
    Debug.isDebuggerConnected.implementation = function () { return false; };

    // 常见 ptrace 检测
    var Process = Java.use('android.os.Process');
    // native 侧 ptrace 需 hook libc
});
```

```javascript
// hook libc ptrace（native 反调试）
var ptrace = Module.findExportByName('libc.so', 'ptrace');
Interceptor.attach(ptrace, {
    onEnter: function (args) { this.req = args[0].toInt32(); },
    onLeave: function (retval) {
        if (this.req === 0) retval.replace(ptr(0)); // PTRACE_TRACEME 返回 0
    }
});
```

证据行：`frida -U -f com.example.app -l bypass_anti.js` → `Spawned`，进程不退出

#### 3.3 内存 dump（frida-dexdump，一代/二代通用）

```bash
# 方式 A：frida-dexdump 自动扫内存中的 dex
frida-dexdump -U -f com.example.app -d 3000 -o dump_out
# 回显形如：
# [*] Searching DEX files...
# [*] Found 3 dex files
# [*] Saved to dump_out/xxxx.dex
```

```bash
# 方式 B：手动枚举内存 dex（更可控）
```

```javascript
// dump_dex.js —— 遍历 /proc/self/maps 找 dex 魔数
var ranges = Process.enumerateRanges('r--');
ranges.forEach(function (r) {
    try {
        var m = Memory.scanSync(r.base, r.size, '64 65 78 0a 30 33 35 00'); // dex\n035\0
        m.forEach(function (hit) {
            console.log('[DEX] ' + hit.address + ' size=' + r.size);
        });
    } catch (e) {}
});
```

```bash
frida -U -f com.example.app -l dump_dex.js --no-pause
```

证据行：`$ frida-dexdump -U -f com.example.app` → `Found 3 dex files`，`dump_out/` 下生成 `*.dex`

#### 3.4 二代壳方法体回填（类抽取场景）

若 dump 出的 dex 方法体为 `nop` / `throw new RuntimeException("Stub!")`：

```bash
# 用 FART / Youpk 方案：在 ART 解释器入口 dump 方法体
# 或 frida hook ArtMethod::Invoke