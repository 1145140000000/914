## 目标枚举链：单 IP + 单端口 → 服务识别 → 攻击面清单

> 选型：`nmap` + `curl`/`nc` 手工探针 + `ffuf` 目录/接口爆破，全部输出落 `RESULT_DIR`，每步留证据行。

### 0. 变量与落盘

```bash
export TARGET=10.10.10.10          # 换成实际 IP
export PORT=8080                   # 换成实际端口
export RESULT_DIR=./enum_${TARGET}_${PORT}
mkdir -p "$RESULT_DIR"
```

### 1. 端口确认 + 服务指纹（先确认这个端口到底是什么）

```bash
# 1.1 端口是否真的开着 + 服务/版本探测
nmap -Pn -sV -sC -p "$PORT" "$TARGET" -oN "$RESULT_DIR/nmap_sv.txt"

# 1.2 若 -sV 判不准，抓 banner 手工看
nc -nv "$TARGET" "$PORT" -w 5 | tee "$RESULT_DIR/banner_raw.txt"
```

判读分支：

| banner / 指纹 | 下一步 |
| --- | --- |
| `HTTP/1.x`、`Server:` | 走第 2 节 Web 链 |
| `SSH-2.0-` | 版本 → 已知 CVE / 弱口令面，`ssh-audit` |
| `220 ... FTP` / `SMTP` / `MySQL` 握手包 | 对应服务枚举（匿名登录 / 用户枚举 / 版本 CVE） |
| 纯二进制 / 无 banner | `nmap -sV --version-all`，再 `nc` 发探针字节看回显 |
| 连接被拒 / 超时 | 端口可能被过滤，`nmap -Pn -sS -p "$PORT"` 复核 |

### 2. Web 面（若为 HTTP/HTTPS）

```bash
# 2.1 基础响应头 + 指纹
curl -sSik "http://$TARGET:$PORT/" -o "$RESULT_DIR/root.html" -D "$RESULT_DIR/root.hdr"
whatweb -a 3 "http://$TARGET:$PORT/" | tee "$RESULT_DIR/whatweb.txt"

# 2.2 常见路径探测（先小字典，快）
ffuf -u "http://$TARGET:$PORT/FUZZ" -w /usr/share/wordlists/dirb/common.txt \
     -t 40 -mc 200,204,301,302,401,403 -o "$RESULT_DIR/ffuf_common.json"

# 2.3 从首页 JS 里抽接口
grep -oE '"/[a-zA-Z0-9_/.-]+"' "$RESULT_DIR/root.html" | sort -u | tee "$RESULT_DIR/js_paths.txt"
```

### 3. 攻击面清单（枚举产出，逐项验证）

| 面 | 探测命令 | 命中判据 |
| --- | --- | --- |
| 目录/文件 | `ffuf ... -e .php,.bak,.zip,.txt` | 200/403 且长度异常 |
| 接口/参数 | 对 `js_paths.txt` 逐条 `curl -sSik` | 返回 JSON / 报错栈 |
| 上传点 | 找 `multipart/form-data` 表单 | 可传任意扩展名 |
| 认证面 | `/login`、`/admin`、`/api/auth` | 401/302 到登录 |
| 版本 CVE | `whatweb` 结果 → `searchsploit` | 版本号匹配 |

### 4. 证据留存规范

```bash
# 每步命令 + 回显都进同一目录，最后打包
tar czf "${RESULT_DIR}.tar.gz" "$RESULT_DIR"
sha256sum "${RESULT_DIR}.tar.gz"
```

证据行示例（交付时每条结论后跟一行）：

```
$ nmap -Pn -sV -p 8080 10.10.10.10
8080/tcp open  http    nginx 1.18.0
```

### 5. 执行顺序（照抄即可）

1. `nmap -sV -sC` 确认服务 → 看 `nmap_sv.txt`
2. 按 banner 分支选 Web / 服务枚举
3. Web：`whatweb` → `ffuf` 小字典 → JS 抽接口 → 逐点 `curl` 验证
4. 每个命中点记 `URL + 状态码 + 响应长度 + 关键回显` 到 `RESULT_DIR/findings.md`
5. 打包 + 哈希，作为后续渗透链的输入

> 缺口自决：`TARGET`/`PORT` 用你给的实际值替换；字典路径按本机 `wordlists` 实际位置调整（`/usr/share/wordlists/` 或 `seclists`）。先把第 1 步跑完，把 `nmap_sv.txt` 的 `PORT/tcp open ...` 那几行贴回来，我按实际服务把第 2 节收窄成具体命令。