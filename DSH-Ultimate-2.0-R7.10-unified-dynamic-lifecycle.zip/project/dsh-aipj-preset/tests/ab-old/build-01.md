## 记账小工具 · 单文件 CLI

> 选型：Python 3.8+ · 零依赖 · 单文件 `ledger.py` · SQLite 存储 · 含 add/list/sum/del/export 五个子命令

### 目录与入口

```
ledger/
└── ledger.py      # 唯一入口，直接 python ledger.py 运行
```

### 完整实现

```python
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ledger.py — 极简记账 CLI，数据存 SQLite（默认 ./ledger.db）"""

import argparse
import csv
import os
import sqlite3
import sys
from datetime import date, datetime

DB_PATH = os.environ.get("LEDGER_DB", os.path.join(os.path.dirname(os.path.abspath(__file__)), "ledger.db"))

SCHEMA = """
CREATE TABLE IF NOT EXISTS records (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    day      TEXT    NOT NULL,
    kind     TEXT    NOT NULL CHECK(kind IN ('income','expense')),
    amount   REAL    NOT NULL CHECK(amount > 0),
    category TEXT    NOT NULL DEFAULT '未分类',
    note     TEXT    NOT NULL DEFAULT '',
    created  TEXT    NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_day ON records(day);
"""


def connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA)
    return conn


def parse_day(s):
    if not s:
        return date.today().isoformat()
    try:
        return datetime.strptime(s, "%Y-%m-%d").date().isoformat()
    except ValueError:
        sys.exit(f"日期格式错误：{s}（应为 YYYY-MM-DD）")


def cmd_add(args):
    day = parse_day(args.date)
    kind = "income" if args.income else "expense"
    amount = round(float(args.amount), 2)
    if amount <= 0:
        sys.exit("金额必须大于 0")
    with connect() as conn:
        cur = conn.execute(
            "INSERT INTO records(day,kind,amount,category,note,created) VALUES(?,?,?,?,?,?)",
            (day, kind, amount, args.category, args.note or "", datetime.now().isoformat(timespec="seconds")),
        )
        rid = cur.lastrowid
    sign = "+" if kind == "income" else "-"
    print(f"[OK] #{rid}  {day}  {sign}{amount:.2f}  {args.category}  {args.note or ''}".rstrip())


def cmd_list(args):
    sql = "SELECT * FROM records"
    where, params = [], []
    if args.month:
        where.append("day LIKE ?")
        params.append(args.month + "%")
    if args.category:
        where.append("category = ?")
        params.append(args.category)
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY day DESC, id DESC"
    if args.limit:
        sql += f" LIMIT {int(args.limit)}"
    with connect() as conn:
        rows = conn.execute(sql, params).fetchall()
    if not rows:
        print("（无记录）")
        return
    print(f"{'ID':>4}  {'日期':<10}  {'类型':<4}  {'金额':>10}  {'分类':<8}  备注")
    print("-" * 64)
    for r in rows:
        t = "收入" if r["kind"] == "income" else "支出"
        print(f"{r['id']:>4}  {r['day']:<10}  {t:<4}  {r['amount']:>10.2f}  {r['category']:<8}  {r['note']}")


def cmd_sum(args):
    sql = "SELECT kind, SUM(amount) AS s, COUNT(*) AS c FROM records"
    where, params = [], []
    if args.month:
        where.append("day LIKE ?")
        params.append(args.month + "%")
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " GROUP BY kind"
    with connect() as conn:
        rows = {r["kind"]: r for r in conn.execute(sql, params).fetchall()}
    inc = rows.get("income")
    exp = rows.get("expense")
    inc_s = inc["s"] if inc else 0.0
    exp_s = exp["s"] if exp else 0.0
    inc_c = inc["c"] if inc else 0
    exp_c = exp["c"] if exp else 0
    scope = args.month or "全部"
    print(f"统计范围：{scope}")
    print(f"  收入：{inc_s:>10.2f}  （{inc_c} 笔）")
    print(f"  支出：{exp_s:>10.2f}  （{exp_c} 笔）")
    print(f"  结余：{inc_s - exp_s:>10.2f}")


def cmd_del(args):
    with connect() as conn:
        cur = conn.execute("DELETE FROM records WHERE id = ?", (args.id,))
    if cur.rowcount:
        print(f"[OK] 已删除 #{args.id}")
    else:
        print(f"[--] 未找到 #{args.id}")


def cmd_export(args):
    with connect() as conn:
        rows = conn.execute("SELECT * FROM records ORDER BY day, id").fetchall()
    with open(args.out, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["id", "日期", "类型", "金额", "分类", "备注", "创建时间"])
        for r in rows:
            w.writerow([r["id"], r["day"], "收入" if r["kind"] == "income" else "支出",
                        f"{r['amount']:.2f}", r["category"], r["note"], r["created"]])
    print(f"[OK] 已导出 {len(rows)} 条 → {args.out}")


def build_parser():
    p = argparse.ArgumentParser(prog="ledger", description="极简记账工具")
    sub = p.add_subparsers(dest="cmd", required=True)

    a = sub.add_parser("add", help="记一笔")
    a.add_argument("amount", help="金额")
    a.add_argument("-i", "--income", action="store_true", help="标记为收入（默认支出）")
    a.add_argument("-c", "--category", default="未分类", help="分类，如 餐饮/交通/工资")
    a.add_argument("-n", "--note", default="", help="备注")
    a.add_argument("-d", "--date", default="", help="日期 YYYY-MM-DD，默认今天")
    a.set_defaults(func=cmd_add)

    l = sub.add_parser("list", help="列出记录")
    l.add_argument("-m", "--month", default="", help="按月份过滤