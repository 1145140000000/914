## App 接口签名还原：完整操作链

> 选型：Frida + mitmproxy + jadx/Ghidra 三件套，覆盖 Java 层与 Native 层两条路径

### 0. 先定签名形态（决定后续走哪条路）

抓一个包，看请求头/参数里的签名字段长什么样：

```bash
# 起代理
mitmproxy -p 8080 --set confdir=~/.mitm

# 手机端设代理指向 PC:8080，装 mitmproxy CA 证书
# 触发一次业务请求，看签名参数
```

典型形态与对应路径：

| 形态 | 例子 | 走哪条 |
| --- | --- | --- |
| 32/40 位 hex | `sign=a1b2c3...` | MD5/SHA1，Java 层常见 |
| 64 位 hex | `sign=...` | SHA256 / HMAC-SHA256 |
| Base64 串 | `sign=eyJ...` | 可能是加密后的结构体 |
| 带时间戳拼接 | `sign=xxx&t=169...` | 拼接顺序是关键 |
| 每次不同且长度固定 | — | 含随机数/nonce |

**关键观察**：同一参数重复请求，签名是否变化？变化 → 含时间戳/nonce；不变 → 纯参数哈希。

---

### 1. Java 层定位（大部分 App 走这条）

#### 1.1 静态定位入口

```bash
# 反编译
jadx -d out/ app.apk

# 全局搜签名参数名
grep -rn "sign" out/sources/ --include=*.java | grep -i "put\|add\|append"

# 搜常见签名类名
grep -rn "class.*Sign\|SignUtil\|SignHelper\|SecurityUtil\|EncryptUtil" out/sources/
```

重点看：
- `OkHttp` 的 `Interceptor` 实现（`addInterceptor` 注册处）
- `RequestInterceptor` / `SignInterceptor`
- 参数拼接后调 `MessageDigest.getInstance("MD5")` 的地方

#### 1.2 动态 hook 验证

```javascript
// hook_sign.js —— 先确认签名函数在哪
Java.perform(function () {
    // 通用：hook MessageDigest，打印所有哈希输入输出
    var MD = Java.use("java.security.MessageDigest");
    MD.digest.overload('[B').implementation = function (input) {
        var ret = this.digest(input);
        console.log("[MD] algo=" + this.getAlgorithm());
        console.log("[MD] input=" + bytesToHex(input));
        console.log("[MD] output=" + bytesToHex(ret));
        return ret;
    };

    function bytesToHex(bytes) {
        var s = "";
        for (var i = 0; i < bytes.length; i++) {
            s += ("0" + (bytes[i] & 0xff).toString(16)).slice(-2);
        }
        return s;
    }
});
```

```bash
frida -U -f com.target.app -l hook_sign.js --no-pause
```

触发一次请求，看 `[MD] input=` 打印的原始拼接串——**这就是签名算法的完整输入**，拼接顺序、盐值、时间戳位置全在里面。

#### 1.3 还原成可编译代码

拿到拼接串后，Java 还原：

```java
// SignUtil.java —— 还原版
import java.security.MessageDigest;

public class SignUtil {
    // 从 hook 日志里提取的盐值
    private static final String SALT = "APP_SALT_PLACEHOLDER";

    public static String sign(String params, long timestamp, String nonce) {
        // 拼接顺序按 hook 到的 input 原样还原
        String raw = params + "&t=" + timestamp + "&n=" + nonce + "&key=" + SALT;
        return md5(raw);
    }

    private static String md5(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] digest = md.digest(s.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : digest) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
```

---

### 2. Native 层定位（签名在 .so 里）

如果 hook `MessageDigest` 没打印，说明签名在 Native 层。

#### 2.1 定位 .so

```bash
unzip -l app.apk | grep "\.so"
# 常见：libsign.so / libnative-lib.so / libsecurity.so
```

#### 2.2 静态分析

```bash
# 找导出函数
nm -D libsign.so | grep " T "

# Ghidra 打开，搜字符串
strings libsign.so | grep -i "sign\|md5\|sha\|key"
```

#### 2.3 动态 hook Native 函数

```javascript
// hook_native.js
var base = Module.findBaseAddress("libsign.so");
console.log("base = " + base);

// 假设从 Ghidra 拿到偏移 0x1234
var signAddr = base.add(0x1234);
Interceptor.attach(signAddr, {
    onEnter: function (args) {
        console.log("[native] arg0=" + args[0].readCString());
        console.log("[native] arg1=" + args[1].readCString());
    },
    onLeave: function (retval) {
        console.log("[native] ret=" + retval.readCString());
    }
});
```

#### 2.4 还原成 C 代码

```c
// sign_native.c —— 还原版
#include <openssl/md5.h>
#include <string.h>
#include <stdio.h>

#define SALT "APP_SALT_PLACEHOLDER"

void sign(const char *params, long timestamp, const char *nonce, char *out) {
    char raw[1024];
    snprintf(raw, sizeof(raw), "%s&t=%ld&n=%s&key=%s", params, timestamp, nonce, SALT);

    unsigned char digest[MD5_DIGEST_LENGTH];
    MD5((unsigned char *)raw, strlen(raw), digest);

    for (int i = 0; i < MD5_DIGEST_LENGTH; i++) {
        sprintf(out + i * 2, "%02x", digest[i]);
    }
    out[32] = '\0';
}
```

---

### 3. 验证还原正确性

```python
# verify_sign.py —— 用还原算法重算，对比抓包值
import hashlib

SALT = "APP_SALT_PLACEHOLDER"

def sign(params, timestamp, nonce):
    raw = f"{params}&t={timestamp}&n={nonce}&key={SALT}"
    return hashlib.md5(raw.encode()).hexdigest()

# 从抓包记录里取一组
captured = {
    "params": "uid=1001&page=1",
    "t": 1699999999,
    "n": "abc