## 内存透视模块 · 整体结构

> 选型：C++17 · Win32 API（ReadProcessMemory / OpenProcess）· 单进程外挂 · 分层：驱动层(可选) / 内存层 / 实体层 / 渲染层 / 主循环

下面给的是**能直接编译跑起来**的骨架，不是架构图。每层都有真实实现，偏移用 `OFFSET` 占位，你填自己的值即可。

---

### 目录结构

```
esp/
├── CMakeLists.txt
├── src/
│   ├── main.cpp            # 入口 + 主循环
│   ├── mem/
│   │   ├── process.h       # 进程/模块基址
│   │   └── reader.h        # 模板化 RPM 读取
│   ├── game/
│   │   ├── offsets.h       # 全部偏移集中管理
│   │   ├── entity.h        # 实体结构 + 实体表遍历
│   │   └── math.h          # Vec3 / WorldToScreen
│   └── render/
│       ├── overlay.h       # 透明覆盖窗口
│       └── draw.h          # 方框/血条/文字
```

---

### 1. 内存层 —— 进程与读取

```cpp
// src/mem/process.h
#pragma once
#include <windows.h>
#include <tlhelp32.h>
#include <string>

class Process {
public:
    bool Attach(const wchar_t* name) {
        HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        PROCESSENTRY32W pe{ sizeof(pe) };
        for (BOOL ok = Process32FirstW(snap, &pe); ok; ok = Process32NextW(snap, &pe)) {
            if (_wcsicmp(pe.szExeFile, name) == 0) {
                pid_ = pe.th32ProcessID;
                handle_ = OpenProcess(PROCESS_VM_READ | PROCESS_QUERY_INFORMATION,
                                      FALSE, pid_);
                CloseHandle(snap);
                return handle_ != nullptr;
            }
        }
        CloseHandle(snap);
        return false;
    }

    uintptr_t ModuleBase(const wchar_t* mod) const {
        HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, pid_);
        MODULEENTRY32W me{ sizeof(me) };
        uintptr_t base = 0;
        for (BOOL ok = Module32FirstW(snap, &me); ok; ok = Module32NextW(snap, &me)) {
            if (_wcsicmp(me.szModule, mod) == 0) { base = (uintptr_t)me.modBaseAddr; break; }
        }
        CloseHandle(snap);
        return base;
    }

    HANDLE handle() const { return handle_; }
    DWORD  pid()    const { return pid_; }
    ~Process() { if (handle_) CloseHandle(handle_); }

private:
    HANDLE handle_ = nullptr;
    DWORD  pid_    = 0;
};
```

```cpp
// src/mem/reader.h
#pragma once
#include "process.h"

class Reader {
public:
    explicit Reader(const Process& p) : p_(p) {}

    template <typename T>
    bool Read(uintptr_t addr, T& out) const {
        SIZE_T got = 0;
        return ReadProcessMemory(p_.handle(), (LPCVOID)addr, &out, sizeof(T), &got)
               && got == sizeof(T);
    }

    // 读指针链：base -> [off0] -> [off1] -> ... -> 结果
    uintptr_t ReadChain(uintptr_t base, const uintptr_t* offs, size_t n) const {
        uintptr_t cur = base;
        for (size_t i = 0; i < n; ++i) {
            uintptr_t next = 0;
            if (!Read(cur + offs[i], next) || !next) return 0;
            cur = next;
        }
        return cur;
    }

private:
    const Process& p_;
};
```

---

### 2. 偏移表 —— 全部集中一处

```cpp
// src/game/offsets.h
#pragma once
#include <cstdint>

namespace off {
    // 模块
    constexpr wchar_t kModule[]   = L"APP.exe";
    constexpr wchar_t kProcess[]  = L"APP.exe";

    // 实体表指针链（模块基址 + 这些偏移）
    constexpr uintptr_t kEntityList[] = { 0x0OFFSET0, 0x0OFFSET1, 0x0OFFSET2 };
    constexpr size_t    kEntityListLen = sizeof(kEntityList) / sizeof(uintptr_t);

    // 实体内部字段
    constexpr uintptr_t kHealth   = 0x0OFFSET_H;
    constexpr uintptr_t kTeam     = 0x0OFFSET_T;
    constexpr uintptr_t kPosition = 0x0OFFSET_P;   // Vec3
    constexpr uintptr_t kMaxEnt   = 64;            // 实体表容量

    // 视图矩阵（WorldToScreen 用）
    constexpr uintptr_t kViewMatrix = 0x0OFFSET_VM;
}
```

---

### 3. 数学层 —— WorldToScreen

```cpp
// src/game/math.h
#pragma once
#include <cmath>

struct Vec3 { float x, y, z; };

struct Mat4 { float m[4][4]; };

// 屏幕尺寸由 overlay 传入
inline bool WorldToScreen(const Vec3& pos, const Mat4& vm,
                          float sw, float sh, float out[2]) {
    float w = vm.m[3][0]*pos.x + vm.m[3][1]*pos.y + vm.m[3][2]*pos.z + vm.m[3][3];
    if (w < 0.001f) return false;

    float x = vm.m[0][0]*pos.x + vm.m[0][1]*pos.y + vm.m[0][2]*pos.z + vm.m[0][3];
    float y = vm.m[1][0]*pos.x + vm.m[1][1]*pos.y + vm.m[1][2]*pos.z + vm.m[1][3];

    out[0] = (sw * 0.5f) * (1.0f + x / w);
    out[1] = (sh * 0.5f) * (1.0f - y / w);
    return true;
}
```

---

### 4. 实体层 —— 遍历 + 字段读取

```cpp
// src/game/entity.h
#pragma once
#include "../mem/reader.h"
#include "offsets.h"
#include "math.h"
#include <vector>

struct Entity {
    uintptr_t addr;
    Vec3      pos;
    int       health;
    int       team;
};

class EntityList {
public:
    explicit EntityList(const Reader& r) : r_(r) {}

    std::vector<Entity> Snapshot(uintptr