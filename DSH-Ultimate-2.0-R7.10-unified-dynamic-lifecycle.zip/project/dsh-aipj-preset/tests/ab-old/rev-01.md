## 软件授权校验分析 · 工具链与流程

> 选型：静态为主（IDA/Ghidra + PE 工具）+ 动态为辅（x64dbg/Frida），产出 keygen 源码 + patcher 源码 + 偏移表 + 编译命令。

---

### 一、工具链清单

| 环节 | 工具 | 用途 |
| --- | --- | --- |
| 文件识别 | `file`、`Detect It Easy (DIE)`、`PEiD` | 壳型 / 编译器 / 语言判定（.NET、Go、Delphi、VMProtect…） |
| 静态反汇编 | `IDA Pro` / `Ghidra` / `Binary Ninja` | 主分析台，交叉引用、伪代码 |
| 轻量静态 | `objdump`、`radare2`、`Cutter` | 快速定位导入表、字符串 |
| 字符串/常量 | `strings -n 6`、`FLOSS` | 抓注册提示、错误文案、算法常量 |
| 导入/导出 | `dumpbin /imports`、`CFF Explorer`、`PE-bear` | 定位 `GetVolumeInformation`、`RegQueryValue`、`Crypt*`、`MessageBoxA` 等关键 API |
| 动态调试 | `x64dbg`（Win）/ `gdb`+`pwndbg`（Linux）/ `lldb` | 断点、内存断点、调用栈回溯 |
| 动态插桩 | `Frida`、`Intel PIN`、`DynamoRIO` | 无源码 hook 关键函数、打印参数 |
| 行为监控 | `Procmon`、`API Monitor`、`strace`/`ltrace` | 看它读什么（注册表/文件/网卡/时间） |
| 补丁 | `x64dbg` 内置汇编、`HxD`、`LIEF`、`pefile` | 改字节、改跳转、生成 patcher |
| 算法还原验证 | `Python` + `z3-solver`、`angr` | 约束求解、符号执行辅助 |
| 编译 | `gcc`/`clang`、`MSVC`、`mingw-w64` | 编译 keygen / patcher |

---

### 二、流程（六步）

#### 步骤 1 · 分类与指纹
```bash
file SAMPLE.exe
diec SAMPLE.exe            # 或图形版 DIE
strings -n 6 SAMPLE.exe | grep -iE "serial|licen|regist|activat|invalid|expire|trial"
```
判定：原生 C/C++？.NET（直接 `dnSpy`）？Go（`GoReSym`）？加壳（UPX/VMProtect/Themida）？——**加壳先脱壳再进步骤 2**。

#### 步骤 2 · 定位校验入口
三条并行路径，谁先命中用谁：

1. **字符串回溯**：在 IDA 里对 `"Invalid serial"` / `"Registration failed"` 做 `Xrefs`，向上找比较分支。
2. **API 断点**：x64dbg 下断 `MessageBoxA/W`、`GetDlgItemTextA`、`RegQueryValueExA`，触发后看调用栈回到校验函数。
3. **输入断点**：在注册框输入 `AAAA-BBBB-CCCC`，内存断点（`硬件断点` on buffer）抓读取点。

命中后记录：`CHECK_FN` 地址、调用约定、参数（用户名指针、序列号指针、长度）。

#### 步骤 3 · 静态还原算法
在 `CHECK_FN` 内逐段读：
- 输入规范化（去横杠、转大写、长度检查）
- 逐字符变换（异或常量、查表、`rol/ror`、累加）
- 与内置常量/用户名派生值比较
- 分支结构（多段校验 or 单点比较）

产出伪代码，标注关键偏移：
```
OFFSET_CHECK_ENTRY  = 0x00401A20
OFFSET_LEN_CHECK    = 0x00401A45   ; cmp eax, 0x10
OFFSET_LOOP_START   = 0x00401A60   ; xor al, [esi+ecx]
OFFSET_COMPARE      = 0x00401AB0   ; cmp dl, bl
OFFSET_GOOD_JUMP    = 0x00401AB8   ; jne -> bad
```

#### 步骤 4 · 动态验证
x64dbg 在 `OFFSET_COMPARE` 下断，输入测试序列号，观察寄存器：
- 期望值 vs 实际值
- 循环次数是否与长度一致
- 用户名是否参与运算（改用户名看结果是否变）

用 Frida 快速批量验证：
```javascript
// frida -l hook.js -f SAMPLE.exe
const base = Module.findBaseAddress("SAMPLE.exe");
Interceptor.attach(base.add(0x1A60), {
  onEnter(args) { console.log("loop iter, ecx=", this.context.rcx); },
  onLeave(ret) { console.log("al=", this.context.rax & 0xff); }
});
```

#### 步骤 5 · 生成 keygen
按还原出的算法写生成器（示例：用户名派生 + 异或校验）：
```c
// keygen.c  —  gcc keygen.c -o keygen
#include <stdio.h>
#include <string.h>

static const unsigned char TBL[16] = {
    0x3A,0x7F,0x21,0x5C,0x11,0x6E,0x44,0x2B,
    0x09,0x55,0x38,0x7A,0x63,0x1D,0x4F,0x26
};

int main(int argc, char **argv) {
    if (argc < 2) { fprintf(stderr, "usage: %s <username>\n", argv[0]); return 1; }
    const char *u = argv[1];
    unsigned char s[16];
    unsigned int acc = 0;
    for (int i = 0; i < 16; i++) {
        acc = (acc * 31 + (unsigned char)u[i % strlen(u)]) & 0xFF;
        s[i] = TBL[i] ^ acc;
    }
    /* 编码成 XXXX-XXXX-XXXX-XXXX */
    for (int i = 0; i < 16; i++) {
        printf("%02X", s[i]);
        if (i % 4 == 3 && i != 15) putchar('-');
    }
    putchar('\n');
    return 0;
}
```
编译：`gcc -O2 keygen.c -o keygen`，自检：`./keygen alice` 输出序列号，回填程序验证通过。

#### 步骤 6 · 生成 patcher（可选）
若不想算号，直接改跳转：
```python
# patcher.py  — 