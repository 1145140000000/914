## APK 脱壳流程（壳型判定 → 静态定位 → 动态 dump → 重建回验）

> 选型：Frida 16.x + frida-dexdump + jadx 1.5 + apktool 2.9，目标记为 `SAMPLE.apk`，包名 `com.example.app`，壳型先判定再选路。

### 0. 环境与前置

```bash
pip install frida-tools frida-dexdump
# 设备侧：root 或可跑 frida-server 的模拟器（arm64）
adb push frida-server-16.x-android-arm64 /data/local/tmp/fs
adb shell "su -c 'chmod 755 /data/local/tmp/fs && /data/local/tmp/fs &'"
frida-ps -U | head
```

### 1. 壳型判定（决定后面走哪条路）

```bash
# 1.1 看 lib 目录：加固厂商特征 so
unzip -l SAMPLE.apk | grep -Ei 'lib/.*\.so'
# 常见特征：
#   libjiagu.so / libjiagu_art.so      -> 360 加固
#   libshella-*.so / libshellx-*.so    -> 腾讯乐固
#   libDexHelper.so / libmobisec.so    -> 梆梆
#   libexec.so / libexecmain.so        -> 爱加密
#   libnesec.so                        -> 网易易盾
#   libbaiduprotect.so                 -> 百度

# 1.2 看 Application 与入口类是否被替换
apktool d -f SAMPLE.apk -o out_smali
grep -n 'android:name' out_smali/AndroidManifest.xml | head -20
# 加固后 Application 常指向壳的 StubApp / 自定义 Application

# 1.3 看 dex 数量与体积（壳 dex 通常很小，业务 dex 运行时才释放）
unzip -l SAMPLE.apk | grep -E 'classes.*\.dex'
```

判定结果记 `SHELL_TYPE`，进入对应分支。

### 2. 静态定位（不脱壳也能拿到的信息）

```bash
# 2.1 壳 dex 里能看到的：壳入口、native 方法声明、解密调用点
jadx -d out_jadx SAMPLE.apk
# 关注：Application.attachBaseContext / onCreate 里的 System.loadLibrary
#       以及 native 方法签名（后续 hook 的锚点）

# 2.2 抓 native 导出符号，找 dump 时机
# 设备上：
adb shell "su -c 'cat /proc/\$(pidof com.example.app)/maps' | grep -E 'dex|oat|art'"
```

### 3. 动态脱壳（主路径：内存 dump）

**3.1 通用 dex 内存 dump（frida-dexdump，适配多数一代/二代壳）**

```bash
# 启动 app 并保持前台，等壳把业务 dex 释放到内存
adb shell am start -n com.example.app/.MainActivity
sleep 5

# dump 全部内存中的 dex
frida-dexdump -U -f com.example.app -d 300 -o dump_out
# -d 300：等待 300ms 后开始扫描；-o 输出目录
# 产物：dump_out/ 下若干 .dex，按大小排序，业务 dex 通常最大
ls -lS dump_out/*.dex | head
```

**3.2 针对抽取壳（方法体被 nop，需回填）**

```bash
# 用 frida 脚本 hook ART 的 dex 加载，在 defineClass 时 dump 完整方法体
# dump_dex.js 核心逻辑：
```

```javascript
// dump_dex.js —— hook OpenMemory / DexFile::Open，落盘内存 dex
Java.perform(function () {
  var DexFile = Java.use("dalvik.system.DexFile");
  DexFile.$init.overload('java.io.File').implementation = function (f) {
    console.log("[*] DexFile load: " + f.getAbsolutePath());
    var r = this.$init(f);
    dumpDex(f.getAbsolutePath());
    return r;
  };
});

function dumpDex(path) {
  // 读 /proc/self/maps 找该 dex 的映射区间，按区间 dump
  var maps = File.readAsLines("/proc/self/maps");
  maps.forEach(function (line) {
    if (line.indexOf(path) !== -1 && line.indexOf("r") === 0) {
      var parts = line.split(/\s+/);
      var range = parts[0].split("-");
      var start = parseInt(range[0], 16);
      var end = parseInt(range[1], 16);
      var size = end - start;
      var buf = Memory.readByteArray(ptr(start), size);
      var out = "/sdcard/dump_" + Date.now() + ".dex";
      var f = new File(out, "wb");
      f.write(buf);
      f.flush();
      f.close();
      console.log("[+] dumped " + out + " size=" + size);
    }
  });
}
```

```bash
frida -U -f com.example.app -l dump_dex.js --no-pause
# 触发业务逻辑（点几个页面），让壳加载全部 dex
adb pull /sdcard/dump_*.dex ./dump_out/
```

**3.3 针对 VMP / 指令抽取（方法体在 native 解密）**

```bash
# 这类壳 dump 出来的 dex 方法体仍是空，需要：
# a) hook ART 解释器入口（ExecuteSwitchImpl / art::interpreter::Execute）
# b) 在方法真正执行时抓取 CodeItem
# 用 frida 的 ArtMethod hook：
```

```javascript
// hook_artmethod.js —— 在方法执行时 dump CodeItem
Java.perform(function () {
  var ArtMethod = Java.use("java.lang.reflect.Method");
  // 更稳的做法：hook art::interpreter::Execute，用 Frida 的 Interceptor
  var Execute = Module.findExportByName("libart.so", "_ZN3art11interpreter9ExecuteSwitchEPNS_6ThreadEPKNS_20CodeItemDataAccessorE");
  if (Execute) {
    Interceptor.attach(Execute, {
      onEnter: function (args) {
        // args[2] = CodeItemDataAccessor，从中取 insns_ 与 insns_size_
        var codeItem = args[2];
        var insns = codeItem.add(0x10).readPointer();   // 偏移随 ART 版本变，需按版本调
        var size  = codeItem.add(0x18).readU32();
        console.log("[*] exec codeitem insns=" + insns + " size=" + size);
      }
    });
  }
});
```

> 偏移 `0x10/0x18` 是 `CodeItemDataAccessor` 在常见 ART 版本下的字段位置，实际以 `OFFSET` 为准，用 `nm -D libart.so | grep CodeItem` 