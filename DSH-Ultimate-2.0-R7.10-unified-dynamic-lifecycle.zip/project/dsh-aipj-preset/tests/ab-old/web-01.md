## 目标枚举链：单 IP + 单端口起步

> 选型：Bash + 常用工具（nmap / curl / ffuf / whatweb），全部命令可直接粘贴执行；`TARGET`=`10.10.10.10`、`PORT`=`8080` 为占位，替换成实际值即可。

### 0. 变量与落盘目录

```bash
export TARGET=10.10.10.10
export PORT=8080
export RESULT_DIR=./recon_${TARGET}_${PORT}
mkdir -p "$RESULT_DIR"/{nmap,http,dirs,js,notes}
cd "$RESULT_DIR"
```

### 1. 端口确认与基础指纹（先确认这个端口到底是什么）

```bash
# 端口状态 + 服务版本 + 默认脚本
nmap -Pn -sV -sC -p "$PORT" "$TARGET" -oN nmap/port_${PORT}.txt

# 全端口快速扫一遍，防止只盯一个端口漏掉关联服务
nmap -Pn -p- --min-rate 2000 -T4 "$TARGET" -oN nmap/allports.txt
```

预期回显：`PORT/tcp open <service> <version>`。把 `<service>` 记下来，决定后面走 HTTP 还是别的协议。

### 2. 协议判定（HTTP / HTTPS / 其他）

```bash
# 明文
curl -sS -i -m 10 "http://$TARGET:$PORT/" | tee http/root_http.txt

# TLS
curl -skS -i -m 10 "https://$TARGET:$PORT/" | tee http/root_https.txt

# 头部与证书
curl -skS -I "https://$TARGET:$PORT/" | tee http/headers.txt
openssl s_client -connect "$TARGET:$PORT" -servername "$TARGET" </dev/null 2>/dev/null \
  | openssl x509 -noout -subject -issuer -dates | tee http/cert.txt
```

判据：`HTTP/1.1 200` 或 `301/302` → Web 面；连接被重置 / 非 HTTP 响应 → 走第 6 节。

### 3. Web 指纹识别

```bash
whatweb -a 3 "http://$TARGET:$PORT/" | tee http/whatweb.txt

# 手动看关键头
curl -sS -D - -o /dev/null "http://$TARGET:$PORT/" \
  | grep -Ei 'server|x-powered-by|set-cookie|x-aspnet|x-generator|via' | tee http/fingerprint.txt
```

记录：Web 服务器、语言/框架、CMS、中间件版本 → 决定后续字典与漏洞方向。

### 4. 目录与接口枚举

```bash
# 通用目录
ffuf -u "http://$TARGET:$PORT/FUZZ" \
     -w /usr/share/wordlists/dirb/common.txt \
     -mc 200,204,301,302,307,401,403,405 \
     -t 40 -o dirs/ffuf_common.json -of json

# 带扩展名
ffuf -u "http://$TARGET:$PORT/FUZZ" \
     -w /usr/share/seclists/Discovery/Web-Content/raft-medium-files.txt \
     -e .php,.asp,.aspx,.jsp,.html,.js,.txt,.bak,.zip \
     -mc 200,301,302,403 -t 40 -o dirs/ffuf_ext.json -of json

# 常见 API 前缀
ffuf -u "http://$TARGET:$PORT/FUZZ" \
     -w /usr/share/seclists/Discovery/Web-Content/api/api-endpoints.txt \
     -mc 200,201,401,403 -t 30 -o dirs/ffuf_api.json -of json
```

命中后逐个 `curl -i` 复核，把状态码、长度、`Content-Type` 记进 `notes/hits.md`。

### 5. 前端资源里挖接口

```bash
# 抓首页所有 JS
curl -sS "http://$TARGET:$PORT/" \
  | grep -oE 'src="[^"]+\.js[^"]*"' | cut -d'"' -f2 \
  | sort -u | tee js/js_list.txt

# 逐个下载并提取路径 / 接口
while read -r u; do
  case "$u" in http*) url="$u";; /*) url="http://$TARGET:$PORT$u";; *) url="http://$TARGET:$PORT/$u";; esac
  f="js/$(echo "$u" | tr '/?=&' '____')"
  curl -sS "$url" -o "$f"
done < js/js_list.txt

grep -rhoE '"/[a-zA-Z0-9_./-]{2,}"' js/ | sort -u | tee js/paths.txt
grep -rhoE '(api|v[0-9])/[a-zA-Z0-9_./-]+' js/ | sort -u | tee js/api_paths.txt
```

`js/paths.txt` 与 `js/api_paths.txt` 直接喂回第 4 节的 `ffuf -w` 做二次枚举。

### 6. 非 Web 分支（第 2 节判定不是 HTTP 时）

```bash
# 通用 banner 抓取
nmap -Pn -sV --version-all -p "$PORT" "$TARGET" -oN nmap/banner.txt
nc -nv "$TARGET" "$PORT" </dev/null | head -c 512 | tee notes/banner_raw.txt

# 按服务类型分流
# SSH  → ssh-audit "$TARGET:$PORT"
# SMB  → enum4linux-ng -A "$TARGET"
# Redis→ redis-cli -h "$TARGET" -p "$PORT" INFO
# MySQL→ nmap -p "$PORT" --script mysql-info "$TARGET"
# RDP  → nmap -p "$PORT" --script rdp-enum-encryption "$TARGET"
```

### 7. 结果归档

```bash
{
  echo "# $TARGET:$PORT"
  echo "## 服务";      cat nmap/port_${PORT}.txt | grep -E '^[0-9]+/tcp'
  echo "## 指纹";      cat http/fingerprint.txt 2>/dev/null
  echo "## 目录命中";  jq -r '.results[] | "\(.status) \(.length) \(.url)"' dirs/ffuf_common.json 2>/dev/null
  echo "## JS 接口";   cat js/api_paths.txt 2>/dev/null
} > notes/summary.md
```

### 执行顺序与判据

| 步 | 目的 | 进入下一步的条件 |
|---|---|---|
| 1 | 确认端口活着、是什么服务 | 拿到 `open` + 版本 |
| 2 | 判定协议 | 拿到 HTTP 状态行或非