// ab-run.mjs — 用 DeepSeek API 直连跑 A/B：旧载荷 vs 新载荷，同一批用例
// 用法: node tests/ab-run.mjs <old|new> <outDir> [caseIds...]
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { homedir } from 'node:os';

const ROOT = dirname(dirname(fileURLToPath(import.meta.url)));
const which = process.argv[2] || 'old';
const outDir = process.argv[3] || join(ROOT, 'tests', `ab-${which}`);
const only = process.argv.slice(4);

const kernel = readFileSync(join(ROOT, 'prompts', 'aipj-kernel.md'), 'utf8');
const reinforceNew = readFileSync(join(ROOT, 'prompts', 'aipj-reinforce.md'), 'utf8');
const reinforceOld = process.env.AB_OLD_FILE
  ? readFileSync(process.env.AB_OLD_FILE, 'utf8')
  : readFileSync('/tmp/reinforce-v25.md', 'utf8');
const payload = kernel + '\n\n' + (which === 'old' ? reinforceOld : reinforceNew);

const set = JSON.parse(readFileSync(join(ROOT, 'tests', 'eval-set.json'), 'utf8'));
const cases = set.cases.filter((c) => (only.length ? only.includes(c.id) : true));
if (!cases.length) throw new Error('no cases');

// 直接读 credentials.yaml 的 refs.DEEPSEEK_API_KEY（本机既有做法，不写日志）
function key() {
  if (process.env.DEEPSEEK_API_KEY) return process.env.DEEPSEEK_API_KEY;
  const raw = readFileSync(join(homedir(), '.dsh', '.credentials.yaml'), 'utf8');
  const m = raw.match(/DEEPSEEK_API_KEY:\s*(\S+)/);
  if (!m) throw new Error('no DEEPSEEK_API_KEY');
  return m[1].replace(/^["']|["']$/g, '');
}

mkdirSync(outDir, { recursive: true });
const K = key();

for (const c of cases) {
  const t0 = Date.now();
  const res = await fetch('https://api.deepseek.com/chat/completions', {
    method: 'POST',
    headers: { Authorization: `Bearer ${K}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: 'deepseek-chat',
      messages: [
        { role: 'system', content: payload },
        { role: 'user', content: c.prompt },
      ],
      max_tokens: 1600,
      temperature: 0.3,
    }),
  });
  if (!res.ok) {
    console.log(`${c.id} HTTP ${res.status} ${(await res.text()).slice(0, 120)}`);
    continue;
  }
  const j = await res.json();
  const text = j.choices?.[0]?.message?.content || '';
  writeFileSync(join(outDir, `${c.id}.md`), text, 'utf8');
  console.log(`${c.id.padEnd(9)} ${String(text.length).padStart(5)} chars  ${((Date.now() - t0) / 1000).toFixed(1)}s`);
}
console.log('→', outDir);
