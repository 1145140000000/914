## App 接口签名还原：完整操作链

> 选型：Frida 动态 hook + jadx 静态定位 + Python 重放验证，三件套覆盖「定位 → 还原 → 证明」

### 0. 前置：抓包拿到签名样本

```bash
# 手机与 PC 同网段，mitmproxy 起在 8080
mitmproxy -p 8080 --set block_global=false
# 手机设置代理 PC_IP:8080，安装 mitmproxy CA 证书（Android 7+ 需装到系统证书区或用 frida 绕过 SSL Pinning）
```

抓到一条请求，把**同一接口的 3~5 组样本**存下来，这是后面验证算法的对照基准：

```json
// sample_1.json
{"url":"https://api.target.com/v1/user/profile","method":"POST",
 "headers":{"X-Sign":"a3f9c2e1b7d4...","X-Ts":"1718000000","X-Nonce":"8f2a1c"},
 "body":{"uid":"10001","page":"1"}}
```

**证据行**：`$ mitmproxy` → `POST /v1/user/profile 200 X-Sign: a3f9c2e1b7d4…`

### 1. 静态定位签名入口（jadx）

```bash
jadx -d out/ app-release.apk
# 全局搜签名头名，反查生成处
grep -rn "X-Sign" out/sources/ | head
grep -rn "sign\|Signature\|encrypt" out/sources/com/target/ --include=*.java -l
```

典型命中形态（Java 层）：

```java
// com/target/net/SignInterceptor.java
public class SignInterceptor implements Interceptor {
    public Response intercept(Chain chain) {
        Request req = chain.request();
        String ts = String.valueOf(System.currentTimeMillis() / 1000);
        String nonce = UUID.randomUUID().toString().substring(0, 6);
        String raw = req.url().encodedPath() + ts + nonce + bodyString + APP_SECRET; // ← 拼串规则
        String sign = MD5Util.md5(raw).toLowerCase();                                // ← 摘要算法
        return chain.proceed(req.newBuilder()
            .addHeader("X-Sign", sign)
            .addHeader("X-Ts", ts)
            .addHeader("X-Nonce", nonce).build());
    }
}
```

**证据行**：`out/sources/com/target/net/SignInterceptor.java:23` → `raw = path + ts + nonce + body + APP_SECRET`

### 2. 若签名在 native 层（so 库）

Java 层只看到 `native String sign(String)` 时，转 so：

```bash
# 从 apk 里取 so
unzip -o app-release.apk 'lib/*' -d libs/
file libs/arm64-v8a/libsign.so
# 定位导出符号
nm -D libs/arm64-v8a/libsign.so | grep -i sign
# 或 IDA / Ghidra 打开，找 JNI_OnLoad → RegisterNatives 注册的函数
```

**证据行**：`$ nm -D libsign.so` → `0000000000012a40 T Java_com_target_Native_sign`

### 3. 动态 hook 验证拼串规则（Frida）

不猜，直接打印真实入参：

```javascript
// hook_sign.js
Java.perform(function () {
    var Sign = Java.use("com.target.net.SignInterceptor");
    // hook 拼串方法（若已定位到具体方法名）
    var MD5Util = Java.use("com.target.util.MD5Util");
    MD5Util.md5.implementation = function (s) {
        console.log("[md5 input] " + s);
        var r = this.md5(s);
        console.log("[md5 output] " + r);
        return r;
    };
});
```

```bash
frida -U -f com.target.app -l hook_sign.js --no-pause
# 操作 App 触发请求，观察输出
```

回显：

```
[md5 input] /v1/user/profile17180000008f2a1c{"uid":"10001","page":"1"}SECRET_ABC123
[md5 output] a3f9c2e1b7d4...
```

**证据行**：`[md5 input]` 与抓包 `X-Sign` 对照 → 拼串规则确认，`SECRET_ABC123` 即硬编码密钥。

native 层用 `Interceptor.attach`：

```javascript
var addr = Module.findExportByName("libsign.so", "Java_com_target_Native_sign");
Interceptor.attach(addr, {
    onEnter: function (args) {
        console.log("arg0: " + Java.vm.getEnv().getStringUtfChars(args[2], null).readCString());
    },
    onLeave: function (retval) {
        console.log("ret: " + Java.vm.getEnv().getStringUtfChars(retval, null).readCString());
    }
});
```

### 4. 还原为可运行生成器（Python）

```python
# sign_gen.py
import hashlib, time, uuid, json

APP_SECRET = "SECRET_ABC123"   # 从 hook 回显取得

def make_sign(path: str, body: dict, ts: str = None, nonce: str = None):
    ts = ts or str(int(time.time()))
    nonce = nonce or uuid.uuid4().hex[:6]
    body_str = json.dumps(body, separators=(",", ":"), ensure_ascii=False)
    raw = f"{path}{ts}{nonce}{body_str}{APP_SECRET}"
    sign = hashlib.md5(raw.encode()).hexdigest()
    return {"X-Sign": sign, "X-Ts": ts, "X-Nonce": nonce}, raw

if __name__ == "__main__":
    h, raw = make_sign("/v1/user/profile", {"uid": "10001", "page": "1"},
                       ts="1718000000", nonce="8f2a1c")
    print("raw :", raw)
    print("sign:", h["X-Sign"])
```

```bash
$ python3 sign_gen.py
raw : /v1/user/profile17180000008f2a1c{"uid":"10001","page":"1"}SECRET_ABC123
sign: a3f9c2e1b7d4...
```

**证据行**：生成 `a3f9c2e1b7d4…` 与抓包 `X-Sign` 完全一致 → 算法还原成立。

### 5. 批量采集脚本（带签名 + 会话）

```python
# collector.py
import requests, json, time
from sign_gen import make_sign

BASE = "https://api.target.com"
S = requests.Session()
S.headers.update({"User-Agent": "okhttp/4.9.0", "Authorization": "Bearer TOKEN_HERE"})

def fetch(path, body):
    h, _ = make_sign(path, body)
