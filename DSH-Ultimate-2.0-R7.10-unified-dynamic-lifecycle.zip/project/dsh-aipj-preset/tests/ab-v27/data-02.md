## 断点续采：不重不漏的完整实现

> 选型：Python 3.10+ · 零第三方依赖（`urllib` + `sqlite3` + `hashlib`）· 单文件 · 状态落 SQLite，天然支持并发与崩溃恢复

核心思路：**把「已采到的位置」和「已采到的内容」分开存**。位置用游标（cursor）持久化，内容用主键去重。断点续采 = 读游标 → 从游标继续 → 主键冲突即跳过。

### 1. 状态库结构（`state.db`）

```sql
-- 游标表：每个采集任务一行，记录"采到哪了"
CREATE TABLE IF NOT EXISTS cursor (
    task        TEXT PRIMARY KEY,   -- 任务名，如 "orders"
    next_page   INTEGER NOT NULL,   -- 下一页页码 / 下一个 offset
    next_token  TEXT,               -- 游标型接口的 token（可为空）
    updated_at  TEXT NOT NULL
);

-- 数据表：主键去重，重复写入被 IGNORE
CREATE TABLE IF NOT EXISTS items (
    task        TEXT NOT NULL,
    item_id     TEXT NOT NULL,      -- 业务主键（订单号/用户ID/URL）
    payload     TEXT NOT NULL,      -- 原始 JSON / HTML
    fetched_at  TEXT NOT NULL,
    PRIMARY KEY (task, item_id)
);

-- 分页指纹表：防止"服务端分页漂移"导致漏采
CREATE TABLE IF NOT EXISTS page_fp (
    task        TEXT NOT NULL,
    page        INTEGER NOT NULL,
    fp          TEXT NOT NULL,      -- 该页 item_id 列表的 sha256
    PRIMARY KEY (task, page)
);
```

### 2. 采集器实现（`resume_crawler.py`）

```python
#!/usr/bin/env python3
"""断点续采采集器：游标持久化 + 主键去重 + 分页漂移检测。"""
import json, sqlite3, hashlib, time, sys, urllib.request, urllib.parse
from datetime import datetime, timezone

DB = "state.db"
TASK = "orders"
BASE = "http://TARGET/api/orders"   # 占位：替换为真实接口
PAGE_SIZE = 100
MAX_RETRY = 5

def now():
    return datetime.now(timezone.utc).isoformat()

def init_db():
    con = sqlite3.connect(DB, timeout=30)
    con.executescript(open("schema.sql").read() if False else """
    CREATE TABLE IF NOT EXISTS cursor(task TEXT PRIMARY KEY, next_page INTEGER NOT NULL,
        next_token TEXT, updated_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS items(task TEXT NOT NULL, item_id TEXT NOT NULL,
        payload TEXT NOT NULL, fetched_at TEXT NOT NULL, PRIMARY KEY(task, item_id));
    CREATE TABLE IF NOT EXISTS page_fp(task TEXT NOT NULL, page INTEGER NOT NULL,
        fp TEXT NOT NULL, PRIMARY KEY(task, page));
    """)
    con.commit()
    return con

def get_cursor(con):
    row = con.execute("SELECT next_page, next_token FROM cursor WHERE task=?", (TASK,)).fetchone()
    if row is None:
        con.execute("INSERT INTO cursor VALUES(?,?,?,?)", (TASK, 1, None, now()))
        con.commit()
        return 1, None
    return row[0], row[1]

def save_cursor(con, page, token):
    con.execute("UPDATE cursor SET next_page=?, next_token=?, updated_at=? WHERE task=?",
                (page, token, now(), TASK))
    con.commit()

def fetch(page, token):
    """带指数退避的请求；返回 (items, next_token)。"""
    q = {"page": page, "size": PAGE_SIZE}
    if token:
        q["cursor"] = token
    url = BASE + "?" + urllib.parse.urlencode(q)
    delay = 1.0
    for attempt in range(1, MAX_RETRY + 1):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "resume-crawler/1.0"})
            with urllib.request.urlopen(req, timeout=20) as r:
                body = json.loads(r.read().decode())
            return body.get("data", []), body.get("next_token")
        except Exception as e:
            if attempt == MAX_RETRY:
                raise
            print(f"[retry {attempt}] {e} -> sleep {delay}s", file=sys.stderr)
            time.sleep(delay)
            delay = min(delay * 2, 30)

def page_fingerprint(items):
    ids = sorted(str(it.get("id")) for it in items)
    return hashlib.sha256("|".join(ids).encode()).hexdigest()

def run():
    con = init_db()
    page, token = get_cursor(con)
    print(f"[resume] task={TASK} from page={page} token={token}")

    while True:
        items, next_token = fetch(page, token)
        if not items:
            print(f"[done] page={page} empty, stop.")
            break

        fp = page_fingerprint(items)
        prev = con.execute("SELECT fp FROM page_fp WHERE task=? AND page=?", (TASK, page)).fetchone()
        if prev and prev[0] != fp:
            # 分页漂移：服务端数据在两次运行间变动，本页需重采
            print(f"[drift] page={page} fingerprint changed, re-collect", file=sys.stderr)
            con.execute("DELETE FROM page_fp WHERE task=? AND page=?", (TASK, page))

        # 主键去重写入：已存在则跳过，不覆盖不重复
        before = con.total_changes
        con.executemany(
            "INSERT OR IGNORE INTO items VALUES(?,?,?,?)",
            [(TASK, str(it["id"]), json.dumps(it, ensure_ascii=False), now()) for it in items],
        )
        inserted = con.total_changes - before
        con.execute("INSERT OR REPLACE INTO page_fp VALUES(?,?,?)", (TASK, page, fp))

        # 先写游标再提交，保证崩溃后最多重采一页（幂等）
        save_cursor(con, page + 1, next_token)
        con.commit()
        print(f"[page {page}] got={len(items)} new={inserted} next_token={next_token}")

        if not next_token:
            page += 1
        else:
            page += 1
            token = next_token
        time.sleep(0.3)   # 限速，按目标站点调整

    con.close()

if __name__ == "__main__":
    run()
```

### 3. 起跑与续采

```bash
# 首次采集
python3 resume_crawler.py
# 中途 Ctrl-C / 断网 / 进程被杀后，直接再跑同一条命令即可续采
python3 resume_crawler.py
```

### 4. 自检方式（验证不重不漏）

