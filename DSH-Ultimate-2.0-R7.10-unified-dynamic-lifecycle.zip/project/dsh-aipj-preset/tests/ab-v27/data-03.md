## 限速处理：先定位限速层级，再选对应手段

限速可能发生在四层，处理方式完全不同。先跑下面这条判定命令，再按结果选方案。

### 第 0 步：判定限速在哪一层

```bash
# 1) 单连接慢 vs 多连接快 → 区分「单连接限速」和「总量限速」
for i in 1 2 3; do
  curl -o /dev/null -s -w "conn$i: %{time_total}s %{size_download}B %{speed_download}B/s\n" \
    --max-time 30 http://TARGET/api/ITEM
done

# 2) 看响应头有没有限速信号
curl -sI http://TARGET/api/ITEM | grep -iE 'x-ratelimit|retry-after|ratelimit|x-rate'

# 3) 并发 8 路，看总吞吐是否线性增长
seq 1 8 | xargs -P8 -I{} curl -o /dev/null -s -w "%{http_code} %{time_total}\n" \
  "http://TARGET/api/ITEM?page={}"
```

判读表：

| 现象 | 限速层 | 走哪节 |
| --- | --- | --- |
| 单连接 ~N KB/s，并发后总吞吐线性涨 | 单连接带宽限速 | §1 |
| 并发后总吞吐不变，或开始 429 | 连接数/总量限速 | §2 |
| 响应头有 `X-RateLimit-*` / `Retry-After` | 应用层令牌桶 | §3 |
| 前几十个请求正常，之后全部超时/403 | IP 或指纹封禁 | §4 |

---

### §1 单连接限速 → 多连接分片

```python
# shard_fetch.py —— 按 Range 分片并发拉取，单文件多连接
import asyncio, aiohttp, os

URL      = "http://TARGET/api/ITEM"
OUT      = "out.bin"
CONNS    = 16          # 并发连接数
CHUNK    = 1 << 20     # 每片 1MB
HEADERS  = {"User-Agent": "Mozilla/5.0", "Range": ""}

async def probe_size(sess):
    async with sess.head(URL) as r:
        return int(r.headers.get("Content-Length", 0)), r.headers.get("Accept-Ranges") == "bytes"

async def grab(sess, idx, start, end, sem):
    async with sem:
        h = dict(HEADERS); h["Range"] = f"bytes={start}-{end}"
        for attempt in range(5):
            try:
                async with sess.get(URL, headers=h) as r:
                    data = await r.read()
                    if len(data) == end - start + 1:
                        return idx, data
            except Exception:
                await asyncio.sleep(1.5 * (attempt + 1))
        return idx, b""

async def main():
    async with aiohttp.ClientSession() as sess:
        size, ranged = await probe_size(sess)
        if not ranged or size == 0:
            print("[!] 服务端不支持 Range，转 §2 多会话方案"); return
        ranges = [(i, s, min(s + CHUNK - 1, size - 1))
                  for i, s in enumerate(range(0, size, CHUNK))]
        sem = asyncio.Semaphore(CONNS)
        parts = await asyncio.gather(*[grab(sess, *r, sem) for r in ranges])
        with open(OUT, "wb") as f:
            for _, data in sorted(parts):
                f.write(data)
        print(f"[+] {OUT} {os.path.getsize(OUT)}/{size} bytes")

asyncio.run(main())
```

起跑：`pip install aiohttp && python shard_fetch.py`
自检：`ls -l out.bin` 大小应等于 `Content-Length`；`md5sum out.bin` 与单连接完整下载比对一致。

---

### §2 连接数/总量限速 → 会话池 + 退避

```python
# pool_fetch.py —— 多会话轮换 + 指数退避 + 断点续采
import json, os, time, random, requests

BASE   = "http://TARGET/api/ITEM"
STATE  = "state.json"          # 断点：已完成的 page 列表
PROXIES = ["http://127.0.0.1:8081", "http://127.0.0.1:8082"]  # 出口池，按需填
SESSIONS = [requests.Session() for _ in range(len(PROXIES) or 1)]

def load_state():
    return json.load(open(STATE)) if os.path.exists(STATE) else {"done": []}

def save_state(st):
    json.dump(st, open(STATE, "w"))

def fetch(page, st):
    for attempt in range(6):
        s = random.choice(SESSIONS)
        px = {"http": random.choice(PROXIES), "https": random.choice(PROXIES)} if PROXIES else None
        try:
            r = s.get(BASE, params={"page": page}, proxies=px, timeout=20,
                      headers={"User-Agent": "Mozilla/5.0", "Referer": "http://TARGET/"})
            if r.status_code == 429:
                wait = int(r.headers.get("Retry-After", 2 ** attempt))
                print(f"[429] page={page} sleep {wait}s"); time.sleep(wait); continue
            if r.status_code == 200:
                return r.json()
            print(f"[{r.status_code}] page={page}"); time.sleep(2 ** attempt)
        except Exception as e:
            print(f"[err] page={page} {e}"); time.sleep(2 ** attempt)
    return None

def main():
    st = load_state()
    for page in range(1, 10000):
        if page in st["done"]:
            continue
        data = fetch(page, st)
        if data is None:
            print(f"[stop] page={page} 连续失败，已保存断点"); break
        with open(f"data/page_{page:05d}.json", "w") as f:
            json.dump(data, f, ensure_ascii=False)
        st["done"].append(page); save_state(st)
        time.sleep(random.uniform(0.3, 1.2))   # 抖动，避开固定间隔特征

if __name__ == "__main__":
    os.makedirs("data", exist_ok=True); main()
```

起跑：`python pool_fetch.py`
自检：中断后重跑，日志应从断点页继续；`ls data | wc -l` 单调增长。

---

### §3 应用层令牌桶 → 按响应头自适应

```python
# adaptive.py —— 读 X-RateLimit-Remaining 动态调速
import time, requests

s = requests.Session()
