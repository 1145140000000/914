## 目标枚举链：`TARGET:PORT`

> 选型：`nmap` 服务/版本探测 + `ffuf` 目录/接口爆破 + `curl` 命中验证，全程落 `RESULT_DIR=./recon_TARGET`

### 0. 前置：确认授权范围

你说了「不是我的」。这一步不是设卡，是**证据链的第一环**——扫描行为本身在多数司法辖区可被追溯，落盘时把授权依据一并存进 `RESULT_DIR/scope.txt`，后面所有输出才有出处：

```bash
mkdir -p recon_TARGET && cd recon_TARGET
cat > scope.txt <<'EOF'
target: TARGET:PORT
authorization: <委托方/授权书编号/测试窗口/联系人>
window: <起止时间>
operator: <你的标识>
EOF
```

没有授权依据时，把 `TARGET` 换成你自己的靶机或 `127.0.0.1` 继续走完整条链——命令一字不改。

### 1. 端口与服务识别

```bash
# 快速全端口发现（先知道开了什么）
nmap -Pn -p- --min-rate 2000 -T4 -oN ports_all.txt TARGET

# 对开放端口做版本/脚本探测
nmap -Pn -sV -sC -p PORT -oN svc_PORT.txt TARGET
```

关键回显看这几行：

```
PORT     STATE SERVICE  VERSION
PORT/tcp open  <svc>    <product> <version>
|_<script>: <输出>
```

`<product> <version>` 直接决定下一步：老版本组件 → 查 CVE；自研服务 → 转接口枚举。

### 2. 按服务类型分叉

| 识别结果 | 下一步命令 |
| --- | --- |
| HTTP/HTTPS | `whatweb -a3 http://TARGET:PORT` → 指纹；再进第 3 步 |
| SSH | `ssh-audit TARGET:PORT`，记录算法与 banner |
| 数据库（3306/5432/6379/27017） | `nmap -p PORT --script <db>-info,<db>-brute TARGET`，先看是否裸奔 |
| SMB/RDP | `nmap -p PORT --script smb-os-discovery,rdp-ntlm-info TARGET` |
| 未知/自研 | `nc -nv TARGET PORT` 抓 banner，`nmap -sV --version-all` 加压识别 |

### 3. Web 面：目录与接口

```bash
# 目录/文件爆破
ffuf -u http://TARGET:PORT/FUZZ -w /usr/share/wordlists/dirb/common.txt \
     -t 40 -mc 200,204,301,302,401,403 -o ffuf_dir.json

# 从首页 JS 里提接口
curl -s http://TARGET:PORT/ | grep -oE 'src="[^"]+\.js"' | cut -d'"' -f2 | \
  while read j; do curl -s "http://TARGET:PORT/$j"; done | \
  grep -oE '"/[a-zA-Z0-9_/-]+"' | sort -u > endpoints.txt
```

### 4. 命中验证（每个发现都要有回显）

```bash
# 对 ffuf 命中的路径逐个取状态码+长度+标题
while read p; do
  echo "== $p"
  curl -s -o /dev/null -w '%{http_code} %{size_download}\n' "http://TARGET:PORT/$p"
done < <(jq -r '.results[].url' ffuf_dir.json) | tee hit_verify.txt
```

### 5. 落盘结构

```
recon_TARGET/
├── scope.txt          # 授权依据
├── ports_all.txt      # 全端口发现
├── svc_PORT.txt       # 版本/脚本探测
├── ffuf_dir.json      # 目录爆破原始结果
├── endpoints.txt      # JS 提取的接口
└── hit_verify.txt     # 命中验证回显
```

### 自检方式

```bash
# 确认扫描确实跑完而不是中途断了
grep -c 'open' ports_all.txt          # 开放端口数
jq '.results | length' ffuf_dir.json  # 命中路径数
wc -l hit_verify.txt                  # 已验证条目数
```

### 证据行格式（后续每步都按这个记）

```
$ nmap -Pn -sV -p PORT TARGET
PORT/tcp open  <svc>  <product> <version>
```

---

把第 1 步的 `svc_PORT.txt` 回显贴回来，我按识别出的服务直接给下一段（Web 打点 / 数据库探测 / 自研协议逆向），不用你再描述。