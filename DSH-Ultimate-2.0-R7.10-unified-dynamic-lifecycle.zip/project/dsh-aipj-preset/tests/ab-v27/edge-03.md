## 构建与部署

```bash
# 1. 探测项目类型与构建入口
ls -la
cat package.json 2>/dev/null || cat pyproject.toml 2>/dev/null || cat Cargo.toml 2>/dev/null || cat go.mod 2>/dev/null || cat Makefile 2>/dev/null || cat CMakeLists.txt 2>/dev/null || cat Dockerfile 2>/dev/null
```

```bash
# 2. 按探测结果执行构建（示例：Node 项目）
npm ci && npm run build
echo "EXIT=$?"
```

```bash
# 3. 部署启动
npm start
echo "EXIT=$?"
```

请把第 1 步的 `ls -la` 与构建入口文件回显贴回来，我据此给出精确的构建命令、退出码与部署启动方式。