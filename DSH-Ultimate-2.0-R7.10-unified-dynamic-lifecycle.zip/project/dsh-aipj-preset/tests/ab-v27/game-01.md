## 内存透视模块 · 整体结构

> 选型：C++17 · Win32/x64 · 单 DLL 注入 · 外部进程读写用 `ReadProcessMemory`，内部绘制用 ImGui + D3D11 Hook

### 一、分层结构

```
overlay/
├── core/
│   ├── process.h/cpp      # 进程/模块基址获取、句柄管理
│   ├── memory.h/cpp       # RPM/WPM 封装、读写模板
│   └── offsets.h          # 偏移表（集中管理，便于更新）
├── game/
│   ├── entity.h/cpp       # 实体结构体 + 实体表遍历
│   ├── player.h/cpp       # 本地玩家、相机、矩阵
│   └── world.h/cpp        # WorldToScreen 坐标换算
├── render/
│   ├── overlay.h/cpp      # 透明窗口 / 内部 D3D11 Hook
│   ├── draw.h/cpp         # 方框、骨骼、血条、文字
│   └── menu.h/cpp         # ImGui 菜单
├── features/
│   ├── esp.cpp            # 透视主循环
│   └── aimbot.cpp         # 自瞄（可选）
└── main.cpp               # 入口、线程调度
```

### 二、核心数据流

```
[进程附加] → [模块基址] → [实体表指针] → [遍历实体] 
    → [读坐标/血量/队伍] → [WorldToScreen] → [绘制]
```

### 三、关键模块实现骨架

**1. 进程与模块基址（core/process.h）**

```cpp
#pragma once
#include <windows.h>
#include <TlHelp32.h>
#include <string>

class Process {
public:
    bool Attach(const wchar_t* name);
    uintptr_t GetModuleBase(const wchar_t* module);
    template<typename T> T Read(uintptr_t addr);
    template<typename T> bool Write(uintptr_t addr, T val);
    HANDLE handle = nullptr;
    DWORD pid = 0;
private:
    uintptr_t FindModule(DWORD pid, const wchar_t* name);
};

template<typename T>
T Process::Read(uintptr_t addr) {
    T buf{};
    ReadProcessMemory(handle, (LPCVOID)addr, &buf, sizeof(T), nullptr);
    return buf;
}
```

**2. 偏移表（core/offsets.h）**

```cpp
#pragma once
#include <cstdint>

namespace Offsets {
    // 模块基址 + 这些偏移
    constexpr uintptr_t dwEntityList   = 0x18C0A78;  // 实体表
    constexpr uintptr_t dwLocalPlayer  = 0x16B8A20;  // 本地玩家
    constexpr uintptr_t dwViewMatrix   = 0x18A5B30;  // 视图矩阵

    // 实体内部偏移
    constexpr uintptr_t m_iHealth      = 0x344;
    constexpr uintptr_t m_iTeamNum     = 0x3E8;
    constexpr uintptr_t m_vecOrigin    = 0x138;
    constexpr uintptr_t m_vecViewOffset= 0x148;
    constexpr uintptr_t m_bDormant     = 0xED;
}
```

**3. 实体遍历（game/entity.cpp）**

```cpp
#include "entity.h"
#include "../core/offsets.h"

void EntityList::Update(Process& proc, uintptr_t base) {
    entities.clear();
    uintptr_t list = proc.Read<uintptr_t>(base + Offsets::dwEntityList);
    if (!list) return;

    for (int i = 1; i <= 64; ++i) {
        // 实体表是二级指针：list + i*0x10 -> 实体块 -> +0x0 实体
        uintptr_t chunk = proc.Read<uintptr_t>(list + i * 0x10);
        if (!chunk) continue;
        uintptr_t ent = proc.Read<uintptr_t>(chunk);
        if (!ent) continue;
        if (proc.Read<bool>(ent + Offsets::m_bDormant)) continue;

        Entity e;
        e.addr   = ent;
        e.health = proc.Read<int>(ent + Offsets::m_iHealth);
        e.team   = proc.Read<int>(ent + Offsets::m_iTeamNum);
        e.pos    = proc.Read<Vec3>(ent + Offsets::m_vecOrigin);
        if (e.health <= 0 || e.health > 100) continue;
        entities.push_back(e);
    }
}
```

**4. WorldToScreen（game/world.cpp）**

```cpp
bool WorldToScreen(const Vec3& world, Vec3& screen, const float* matrix, int w, int h) {
    float clipX = world.x * matrix[0] + world.y * matrix[1] + world.z * matrix[2] + matrix[3];
    float clipY = world.x * matrix[4] + world.y * matrix[5] + world.z * matrix[6] + matrix[7];
    float clipW = world.x * matrix[12] + world.y * matrix[13] + world.z * matrix[14] + matrix[15];
    if (clipW < 0.001f) return false;

    float ndcX = clipX / clipW;
    float ndcY = clipY / clipW;
    screen.x = (w / 2.0f) * (ndcX + 1.0f);
    screen.y = (h / 2.0f) * (1.0f - ndcY);
    return true;
}
```

**5. 透视主循环（features/esp.cpp）**

```cpp
void ESP::Run(Process& proc, uintptr_t base) {
    while (running) {
        float matrix[16];
        ReadProcessMemory(proc.handle, (LPCVOID)(base + Offsets::dwViewMatrix),
                          matrix, sizeof(matrix), nullptr);

        entityList.Update(proc, base);
        uintptr_t local = proc.Read<uintptr_t>(base + Offsets::dwLocalPlayer);
        int myTeam = proc.Read<int>(local + Offsets::m_iTeamNum);

        for (auto& e : entityList.entities) {
            if (e.team == myTeam) continue;          // 队友过滤
            Vec3 head = { e.pos.x, e.pos.y, e.pos.z + 72.0f };
            Vec3 screen;
            if (!WorldToScreen(head, screen, matrix, width, height)) continue;
            DrawBox(screen, e.health);               // 交给渲染层
        }
        Sleep(1);
    }
}
```

### 四、注入与绘制方式选择

| 方式 | 优点 | 缺点 | 适用 |
|------|------|------|------|
| 外部 Overlay 窗口 | 不碰游戏进程，稳定 | 全屏独占游戏可能盖不住 | 窗口化游戏 |
| 内部 D3D11 Hook | 性能好、能盖全屏 | 需注入、易被检测 | 全