## 世界坐标 → 屏幕坐标（WorldToScreen）

> 选型：C++17 · 单文件头 · 依赖仅 `<cmath>` / `<cstdint>`，可直接并入自瞄模块

### 1. 原理链

```
世界坐标 (X,Y,Z)
  → 减去相机位置，得到相机空间向量
  → 用相机旋转矩阵（3x3）变换到相机局部空间
  → 透视除法：screen = (local.xy / local.z) * (fovScale, fovScale) + (w/2, h/2)
  → 翻转 Y（屏幕 Y 向下）
  → 裁剪：z <= 0 或超出屏幕 → 不可见
```

关键量：`ViewMatrix`（4x4，行主序，游戏里通常 `0x00` 起 16 个 float）、`FOV`、`分辨率`。

### 2. 完整实现

```cpp
// w2s.hpp  —— 世界坐标转屏幕坐标
#pragma once
#include <cmath>
#include <cstdint>

struct Vec3 { float x, y, z; };
struct Vec2 { float x, y; };

// 4x4 视图矩阵，行主序：m[row][col]
struct Mat4 {
    float m[4][4];
};

// 从进程内存读出的视图矩阵（行主序，16 float）
// 常见布局：
//   m[0][0..2] = 右向量
//   m[1][0..2] = 上向量
//   m[2][0..2] = 前向量
//   m[3][0..2] = 相机位置（部分引擎放在这里）
// 若你的游戏是列主序，把下面 m[r][c] 换成 m[c][r] 即可。

struct ScreenInfo {
    int   width;
    int   height;
    float fovScale;   // = 1.0f / tan(fovY * 0.5f)，或引擎直接给的投影缩放
};

// 返回 true 表示在屏幕内可见
inline bool WorldToScreen(const Vec3& world, const Mat4& view,
                          const ScreenInfo& scr, Vec2& out)
{
    // 1) 相机空间：world - camPos
    //    这里假设相机位置在 m[3][0..2]
    const float cx = world.x - view.m[3][0];
    const float cy = world.y - view.m[3][1];
    const float cz = world.z - view.m[3][2];

    // 2) 旋转到相机局部空间（点乘三个基向量）
    //    local.x = dot(right,  d)
    //    local.y = dot(up,     d)
    //    local.z = dot(forward, d)
    const float lx = cx * view.m[0][0] + cy * view.m[0][1] + cz * view.m[0][2];
    const float ly = cx * view.m[1][0] + cy * view.m[1][1] + cz * view.m[1][2];
    const float lz = cx * view.m[2][0] + cy * view.m[2][1] + cz * view.m[2][2];

    // 3) 在相机背后 → 不可见
    if (lz <= 0.001f) return false;

    // 4) 透视除法 + 屏幕映射
    const float invZ = 1.0f / lz;
    const float sx = (lx * invZ) * scr.fovScale;
    const float sy = (ly * invZ) * scr.fovScale;

    out.x = (scr.width  * 0.5f) + (sx * scr.width  * 0.5f);
    out.y = (scr.height * 0.5f) - (sy * scr.height * 0.5f); // Y 翻转

    // 5) 屏幕裁剪
    if (out.x < 0 || out.x > scr.width || out.y < 0 || out.y > scr.height)
        return false;

    return true;
}
```

### 3. 偏移与读取（示例）

```cpp
// 假设已拿到进程句柄 hProc
constexpr uintptr_t VIEW_MATRIX_ADDR = 0x00VIEW_MATRIX; // 占位
constexpr uintptr_t LOCAL_PLAYER_ADDR = 0x00LOCAL_PLAYER;
constexpr uintptr_t ENTITY_LIST_ADDR  = 0x00ENTITY_LIST;
constexpr uintptr_t ENTITY_POS_OFF    = 0x00POS_OFFSET;

Mat4 ReadViewMatrix(HANDLE hProc) {
    Mat4 vm{};
    ReadProcessMemory(hProc, (LPCVOID)VIEW_MATRIX_ADDR, &vm, sizeof(vm), nullptr);
    return vm;
}

Vec3 ReadEntityPos(HANDLE hProc, uintptr_t entity) {
    Vec3 p{};
    ReadProcessMemory(hProc, (LPCVOID)(entity + ENTITY_POS_OFF), &p, sizeof(p), nullptr);
    return p;
}
```

### 4. 自瞄里怎么用

```cpp
// 每帧：
Mat4 vm = ReadViewMatrix(hProc);
ScreenInfo scr{ GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN),
                1.0f / std::tan(DEG2RAD(fovY) * 0.5f) };

Vec2 targetScreen;
if (WorldToScreen(enemyHeadPos, vm, scr, targetScreen)) {
    // 屏幕中心 → 目标屏幕点 的向量
    float dx = targetScreen.x - scr.width  * 0.5f;
    float dy = targetScreen.y - scr.height * 0.5f;
    float dist = std::sqrt(dx*dx + dy*dy);

    // 死区 + 平滑
    if (dist > DEADZONE_PX) {
        float smooth = SMOOTH_FACTOR; // 0.1~0.3
        mouseMove(dx * smooth, dy * smooth);
    }
}
```

### 5. 常见坑与对照

| 现象 | 原因 | 修正 |
| --- | --- | --- |
| 目标左右反了 | 矩阵列主序 | `m[r][c]` → `m[c][r]` |
| 目标上下反了 | Y 轴方向 | 去掉 `-` 号或改 `+` |
| 目标在屏幕外乱飞 | 相机位置不在 `m[3]` | 单独读 `cameraPos`，用 `world - cameraPos` |
| 距离越远越偏 | FOV 缩放不对 | `fovScale = 1/tan(fovY/2)`，或直接用投影矩阵 `m[0][0]`、`m[1][1]` |
| 目标在背后仍显示 | 未做 `lz <= 0` 裁剪 | 加 `if (lz <= 0.001f) return false;` |
| 透视除法后坐标巨大 | `l