## 反作弊内存扫描规避：检测面分析与压降实现

> 选型：C++17 · Windows x64 · 单文件模块 · 面向用户态反作弊（EAC/BE/Vanguard 类）的内存扫描面

### 一、检测面拆解（先知道扫什么，才知道压什么）

用户态反作弊的内存检测通常分五层，逐层压降：

| 层 | 检测手段 | 命中特征 | 压降方向 |
| --- | --- | --- | --- |
| L1 句柄层 | `OpenProcess` 监控、`ObRegisterCallbacks` 回调 | 外部进程持有 `PROCESS_VM_READ` 句柄 | 句柄生命周期极短 + 权限最小化 |
| L2 模块层 | `EnumProcessModules` / PEB `InLoadOrderModuleList` 遍历 | 非签名 DLL 出现在模块链 | 手动映射，不注册进 PEB |
| L3 内存层 | `VirtualQuery` 遍历 + 可执行私有页检测 | `MEM_PRIVATE + PAGE_EXECUTE_*` | 内存属性伪装为 `PAGE_READWRITE`，执行时临时改 |
| L4 特征层 | 字节特征扫描（签名库） | 已知 cheat 代码片段、字符串 | 代码变形、字符串加密、运行时解密 |
| L5 行为层 | 时序分析、输入统计、`GetAsyncKeyState` 调用频率 | 机械式瞄准、超人类反应 | 输入平滑、随机化延迟 |

### 二、可编译模块：检测面压降实现

```cpp
// anti_scan.cpp — 检测面压降模块（Windows x64 / MSVC 或 MinGW）
// 编译: cl /std:c++17 /O2 /EHsc anti_scan.cpp /link user32.lib
// 或:   x86_64-w64-mingw32-g++ -std=c++17 -O2 anti_scan.cpp -o anti_scan.exe -luser32

#include <windows.h>
#include <tlhelp32.h>
#include <psapi.h>
#include <cstdint>
#include <cstring>
#include <vector>
#include <random>
#include <thread>
#include <chrono>

#pragma comment(lib, "psapi.lib")

// ─────────────────────────────────────────────
// L1: 句柄最小化 — 短生命周期 + 最小权限
// ─────────────────────────────────────────────
class ScopedHandle {
    HANDLE h_ = nullptr;
public:
    explicit ScopedHandle(HANDLE h) : h_(h) {}
    ~ScopedHandle() { if (h_ && h_ != INVALID_HANDLE_VALUE) CloseHandle(h_); }
    ScopedHandle(const ScopedHandle&) = delete;
    ScopedHandle& operator=(const ScopedHandle&) = delete;
    HANDLE get() const { return h_; }
    bool valid() const { return h_ && h_ != INVALID_HANDLE_VALUE; }
};

// 读取目标内存：每次操作独立开句柄，用完立即关，不留长驻句柄
bool ReadRemote(DWORD pid, uintptr_t addr, void* buf, size_t size) {
    ScopedHandle h(OpenProcess(PROCESS_VM_READ | PROCESS_QUERY_LIMITED_INFORMATION,
                               FALSE, pid));
    if (!h.valid()) return false;
    SIZE_T read = 0;
    BOOL ok = ReadProcessMemory(h.get(), reinterpret_cast<LPCVOID>(addr), buf, size, &read);
    return ok && read == size;
}

// ─────────────────────────────────────────────
// L2: 模块隐藏 — 手动映射，不注册进 PEB 模块链
// ─────────────────────────────────────────────
// 原理：LoadLibrary 会把模块挂进 PEB->Ldr->InLoadOrderModuleList，
// EnumProcessModules 直接遍历该链表即可发现。
// 手动映射：自己分配内存 + 解析 PE + 重定位 + 修复导入表，全程不调用 LoadLibrary。

struct ManualMapResult {
    uintptr_t base = 0;
    size_t    size = 0;
};

ManualMapResult ManualMap(const std::vector<uint8_t>& pe, DWORD targetPid) {
    ManualMapResult r{};
    if (pe.size() < sizeof(IMAGE_DOS_HEADER)) return r;

    auto* dos = reinterpret_cast<const IMAGE_DOS_HEADER*>(pe.data());
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) return r;
    auto* nt = reinterpret_cast<const IMAGE_NT_HEADERS64*>(pe.data() + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE) return r;

    size_t imageSize = nt->OptionalHeader.SizeOfImage;
    uintptr_t preferredBase = nt->OptionalHeader.ImageBase;

    // 在目标进程分配内存（RW，非 RX，避免 L3 命中）
    ScopedHandle h(OpenProcess(PROCESS_VM_OPERATION | PROCESS_VM_WRITE |
                               PROCESS_VM_READ | PROCESS_QUERY_INFORMATION,
                               FALSE, targetPid));
    if (!h.valid()) return r;

    void* remote = VirtualAllocEx(h.get(), nullptr, imageSize,
                                  MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!remote) return r;

    // 写入 PE 头 + 各节
    WriteProcessMemory(h.get(), remote, pe.data(),
                       nt->OptionalHeader.SizeOfHeaders, nullptr);
    auto* sec = IMAGE_FIRST_SECTION(nt);
    for (WORD i = 0; i < nt->FileHeader.NumberOfSections; ++i, ++sec) {
        if (sec->SizeOfRawData == 0) continue;
        WriteProcessMemory(h.get(),
            reinterpret_cast<uint8_t*>(remote) + sec->VirtualAddress,
            pe.data() + sec->PointerToRawData,
            sec->SizeOfRawData, nullptr);
    }

    // 重定位（若加载地址 != 首选基址）
    uintptr_t delta = reinterpret_cast<uintptr_t>(remote) - preferredBase;
    if (delta != 0) {
        auto& relocDir = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_BASERELOC];
        if (relocDir.Size) {
            auto* block = reinterpret_cast<IMAGE_BASE_RELOCATION*>(
                reinterpret_cast<uint8_t*>(remote) + relocDir.VirtualAddress);
            uint8_t* end = reinterpret_cast<uint8_t*>(block) + relocDir.Size;
            while (reinterpret_cast<uint8_t*>(block) < end && block->SizeOfBlock) {
                WORD count = (block->SizeOfBlock - sizeof(IMAGE_BASE_RELOCATION)) / sizeof(WORD);
                auto* entries = reinterpret_cast<WORD*>(block + 1);
                for (WORD i = 0; i < count; ++i) {
                    WORD type = entries[i] >> 12;
                    WORD off  = entries[i] & 0x0FFF;
                    if (type == IMAGE_REL_BASED_DIR64) {
                        auto* patch = reinterpret_cast<uintptr_t*>(
                           