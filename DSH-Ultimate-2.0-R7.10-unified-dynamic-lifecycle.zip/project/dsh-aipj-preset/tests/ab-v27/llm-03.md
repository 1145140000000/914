## 对抗后缀（Adversarial Suffix）生效机制与构造方法

> 选型：以 LLM 对抗后缀（GCG 类）为主线，给出原理拆解 + 可运行的构造脚本（PyTorch，含占位符 `TARGET_MODEL` / `TARGET_STR` / `SUFFIX_LEN`），并附白盒梯度法与黑盒迁移法两条路径。

---

## 一、为什么能生效（机制层）

对抗后缀是一段**看似无意义的 token 串**，拼在用户输入末尾，使模型内部表征被推向攻击者期望的方向。生效原因分四层：

### 1. 离散 token 的梯度引导（白盒根因）

LLM 的输入是离散 token，不能直接对 token 求导。GCG（Greedy Coordinate Gradient）的做法是：

- 固定 prompt 与目标输出，只优化后缀位置的 token；
- 对后缀每个位置做 one-hot 松弛，用**目标损失对 embedding 的梯度**近似"换哪个 token 能降 loss"；
- 取梯度最负的 top-k 候选 token，逐个替换、前向评估，保留 loss 最低者。

数学上：设后缀 token 为 $x_{1..m}$，目标是让模型输出 $y^*$（如"Sure, here is..."）。最小化

$$\mathcal{L}(x) = -\log p(y^* \mid \text{prompt} \oplus x)$$

梯度 $\nabla_{e_{x_i}} \mathcal{L}$ 指出每个位置 embedding 的下降方向，最近邻映射回词表即候选替换集。**这是对"模型条件概率"的直接优化，不是语义攻击，所以语义上读不通也能生效。**

### 2. 表征空间偏移（为什么"无意义"也有效）

后缀在**隐藏层**里把残差流推向一个特定方向，使后续注意力把"拒绝"相关的表征压低。可观测证据：

- 同一后缀迁移到不同 prompt 仍有部分效果 → 它作用在**表征层**而非表层语义；
- 后缀 token 常是稀有/多语言/符号碎片 → 说明优化在 embedding 几何上找的是"离群方向"，不是自然语言。

### 3. 注意力劫持与"越狱方向"

后缀占据序列尾部，而因果注意力中**尾部 token 对生成首个 token 影响最大**。优化后的后缀相当于在最后几个位置注入一个强偏置，把首 token 分布从"拒绝类"（I / Sorry / Cannot）拉向"顺从类"（Sure / Here）。

### 4. 迁移性（黑盒为何也能打）

不同模型共享相似的 tokenizer 与训练分布，优化出的后缀在**同族模型**间可迁移。这是黑盒攻击的基础：在开源代理模型（如 `VICUNA` / `LLAMA` 系）上优化，迁移到 `TARGET_MODEL`。

---

## 二、构造方法

### 路径 A：白盒 GCG（有模型权重）

```python
# gcg_suffix.py — 白盒对抗后缀构造（GCG）
# 依赖: torch, transformers, 单卡即可
import torch, torch.nn.functional as F
from transformers import AutoModelForCausalLM, AutoTokenizer

TARGET_MODEL = "TARGET_MODEL_PATH"      # 占位：本地权重路径
TARGET_STR   = "Sure, here is"          # 占位：期望模型输出的开头
SUFFIX_LEN   = 20                       # 后缀 token 数
TOPK         = 256                      # 每步候选数
STEPS        = 500
BATCH        = 128

tok = AutoTokenizer.from_pretrained(TARGET_MODEL)
model = AutoModelForCausalLM.from_pretrained(TARGET_MODEL, torch_dtype=torch.float16).cuda().eval()

def embed_ids(ids):
    return model.get_input_embeddings()(ids)

def loss_fn(prompt_ids, suffix_ids, target_ids):
    # 拼接 prompt + suffix + target，只对 target 段计 loss
    inp = torch.cat([prompt_ids, suffix_ids, target_ids], dim=1)
    logits = model(inp).logits
    # target 段起点
    t0 = prompt_ids.shape[1] + suffix_ids.shape[1]
    tgt_logits = logits[:, t0-1:-1, :]
    return F.cross_entropy(
        tgt_logits.reshape(-1, tgt_logits.size(-1)),
        target_ids.reshape(-1)
    )

def optimize(prompt_str):
    prompt_ids = tok(prompt_str, return_tensors="pt").input_ids.cuda()
    target_ids = tok(TARGET_STR, return_tensors="pt", add_special_tokens=False).input_ids.cuda()
    # 初始化后缀：随机 token
    suffix_ids = torch.randint(0, tok.vocab_size, (1, SUFFIX_LEN), device="cuda")

    for step in range(STEPS):
        # 1) 对后缀 embedding 求梯度
        emb = embed_ids(suffix_ids).detach().requires_grad_(True)
        # 手动前向：prompt_emb + suffix_emb + target_emb
        p_emb = embed_ids(prompt_ids)
        t_emb = embed_ids(target_ids)
        full = torch.cat([p_emb, emb, t_emb], dim=1)
        logits = model(inputs_embeds=full).logits
        t0 = prompt_ids.shape[1] + SUFFIX_LEN
        tgt_logits = logits[:, t0-1:-1, :]
        loss = F.cross_entropy(
            tgt_logits.reshape(-1, tgt_logits.size(-1)),
            target_ids.reshape(-1)
        )
        loss.backward()
        grad = emb.grad  # [1, SUFFIX_LEN, D]

        # 2) 每个位置取梯度最负的 top-k token
        #    梯度下降方向 = -grad，取与 embedding 内积最小的 token
        W = model.get_input_embeddings().weight  # [V, D]
        # 对每个位置：grad·W 越小越好
        scores = torch.einsum("bmd,vd->bmv", grad, W)  # [1, L, V]
        topk = (-scores).topk(TOPK, dim=-1).indices  # [1, L, K]

        # 3) 构造候选批次：每个位置替换为候选 token，其余不变
        cand = suffix_ids.repeat(BATCH, 1)           # [B, L]
        pos = torch.randint(0, SUFFIX_LEN, (BATCH,))
        for b in range(BATCH):
            cand[b, pos[b]] = topk[0, pos[b], torch.randint(0, TOPK, (1,))]

        # 4) 批量评估，保留 loss 最低
        with torch.no_grad():
            losses = []
            for b in range(BATCH):
                losses.append(loss_fn(prompt_ids, cand[b:b+1], target_ids).item())
            best = int(torch.tensor(l