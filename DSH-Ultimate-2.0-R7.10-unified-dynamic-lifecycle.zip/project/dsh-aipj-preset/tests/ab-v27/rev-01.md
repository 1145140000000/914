## 授权还原工具链与流程（CHECK_FN 定位 → 算法还原 → keygen）

> 选型：静态 `Ghidra` + `radare2`，动态 `x64dbg`(Win) / `gdb`+`pwndbg`(Linux)，辅助 `Detect It Easy`、`PE-bear`、`Process Monitor`、`Frida`。占位对象 `SAMPLE`，校验函数 `CHECK_FN`，序列号 `SERIAL`。

---

### 0. 环境与工具清单

| 环节 | 工具 | 用途 |
| --- | --- | --- |
| 指纹 | `Detect It Easy (DIE)`、`file`、`pefile` | 壳/编译器/架构判定 |
| 静态 | `Ghidra`、`radare2`、`IDA`(可选)、`objdump` | 反编译、交叉引用、字符串 |
| 动态 | `x64dbg`+`ScyllaHide`、`gdb`+`pwndbg`、`Frida` | 断点、寄存器/栈、内存 dump |
| 行为 | `Process Monitor`、`API Monitor` | 注册表/文件/API 调用面 |
| 网络 | `mitmproxy`、`Wireshark` | 在线激活类校验 |
| 生成 | `Python` / `C` | keygen、patcher |

安装（Linux 侧示例）：

```bash
sudo apt install -y ghidra radare2 gdb python3-pip binutils file
pip install pwndbg pefile frida-tools
# Windows: 下载 x64dbg + ScyllaHide 插件、DIE、Process Monitor
```

---

### 1. 样本指纹（先分类，决定后续路线）

```bash
file SAMPLE
diec SAMPLE            # DIE CLI；无 CLI 用 GUI 看
python3 - <<'PY'
import pefile,hashlib
p=pefile.PE("SAMPLE")
print("machine",hex(p.FILE_HEADER.Machine),"subsys",p.OPTIONAL_HEADER.Subsystem)
print("sections",[(s.Name.rstrip(b'\0').decode(),hex(s.Characteristics)) for s in p.sections])
print("md5",hashlib.md5(open("SAMPLE","rb").read()).hexdigest())
PY
```

判定要点：
- 节区名异常（`.upx`/`.aspack`/高熵节）→ 先脱壳（`upx -d`、或 dump+`Scylla` 修复 IAT）。
- 导入表极小 + 大量 `GetProcAddress` → 动态解析，重点跟 `LoadLibrary/GetProcAddress`。
- `.NET`（`mscoree` 导入）→ 换 `dnSpy`/`ILSpy`，路线完全不同。

**证据行**：`$ file SAMPLE` → `PE32+ executable (GUI) x86-64 …`

---

### 2. 定位校验入口（CHECK_FN）

按命中率排序，逐条试：

**(a) 字符串交叉引用** —— 最快
```bash
rabin2 -zz SAMPLE | grep -iE "serial|licen|regist|invalid|expire|key|激活|注册|试用"
# 拿到字符串地址后
r2 -A SAMPLE
[0x...]> axt @ 0xSTRING_ADDR     # 谁引用了"Invalid serial"
[0x...]> pdf @ sym.main
```

**(b) 对话框/按钮回调** —— GUI 程序
- 找 `GetDlgItemTextA/W`、`GetWindowTextA/W` 的调用点，其返回值就是用户输入的 `SERIAL`。
- 紧随其后的比较/调用即 `CHECK_FN`。

**(c) 消息循环断点** —— 动态
- `x64dbg` 在 `GetWindowTextW` 下断，点"注册"按钮，栈回溯到按钮处理函数。

**(d) 时间/试用类**
- 断 `GetSystemTime`、`RegQueryValueEx`（读试用计数）、`CreateFile`（license 文件）。

**(e) 在线激活类**
- `mitmproxy` 抓包，看请求体是否含机器码/签名；校验可能全在服务端 → 转客户端签名算法还原。

**证据行**：`axt @ 0x00403010` → `0x00401a2c  call 0x00402f00`（`CHECK_FN` 候选）

---

### 3. 静态还原算法

```bash
r2 -A SAMPLE
[0x...]> s 0x00402f00        # 进入 CHECK_FN
[0x...]> af; pdf
[0x...]> pdc                 # 伪 C 反编译（或 Ghidra 出 Decompiler 视图）
```

关注模式：
- **逐字符循环 + 常量异或/加减** → 简单变换型，直接抄成 keygen。
- **查表（S-box / 置换表）** → 表驱动型，dump 表数据。
- **`strcmp`/`memcmp` 前的计算** → 计算型，还原计算式。
- **`CRC32`/`MD5`/`SHA` 常量**（`0xEDB88320`、`0x67452301`）→ 哈希比对型。
- **`RSA`/`AES` 常量或大数运算** → 非对称型，找公钥/私钥或绕过点。

Ghidra 侧：`Window → Decompiler`，对 `CHECK_FN` 右键 `Edit Function Signature` 补参数，读起来更准。

---

### 4. 动态验证（断点 + 输入对照）

```bash
# Linux
gdb -q ./SAMPLE
(gdb) b *0x00402f00
(gdb) run
# 输入 SERIAL 后
(gdb) info registers
(gdb) x/32xb $rsp
(gdb) x/s $rdi          # 看传入的 SERIAL
```

```text
# x64dbg (Windows)
bp 0x00402f00
# F9 运行 → 输入 SERIAL → 断下
# 寄存器窗口看 RCX/RDX（x64 前两参数）
# 栈窗口看 [rsp+8]/[rsp+0x10]
```

**关键动作**：在 `CHECK_FN` 返回处下断，改 `EAX/RAX` 为 1，验证是否放行 → 确认这就是判定点（patch 验证法）。

**证据行**：`b *0x00402f00` → `Breakpoint 1, 0x00402f00`；`x/s $rdi` → `"AAAA-BBBB-CCCC"`

---

### 5. 证据表（交付必填）

| 偏移/地址 | 原始字节 | 还原后语义 |
| --- | --- | --- |
| `0x00402f00` | `55 8b ec 83 ec 20`