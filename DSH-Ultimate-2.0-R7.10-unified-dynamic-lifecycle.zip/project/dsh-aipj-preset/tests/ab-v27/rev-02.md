## 算号器还原清单（授权还原链）

> 选型：以 `SAMPLE`（`APP` 的授权校验模块）为对象，给出「需要还原什么」的完整清单 + 每项的还原方法与证据形态。缺具体样本时按占位符走，拿到 `SAMPLE` 后逐项填实。

### 1. 校验入口定位（先找到 `CHECK_FN`）

| 要还原的东西 | 怎么找 | 证据形态 |
| --- | --- | --- |
| 注册/激活入口 | 字符串搜 `"Invalid"` `"License"` `"Activate"` `"Trial"`；交叉引用到比较分支 | `地址 → 字符串 → xref 列表` |
| 校验函数 `CHECK_FN` | 从失败提示向上回溯调用链，找返回 `bool`/`int` 且被 `test eax,eax` 判定的函数 | `CHECK_FN 地址 → 调用者 → 判定指令` |
| 触发点 | 菜单「注册」按钮 / 启动时自动校验 / 定时心跳 | `BREAK_ADDR` + 触发输入 |

```bash
# 静态定位
r2 -A SAMPLE -q -c 'izz~License; axt @ str.Invalid_license' 
objdump -d SAMPLE | grep -n -A20 '<CHECK_FN>'
```

### 2. 序列号格式（`SERIAL` 构造规则）

| 项 | 还原内容 |
| --- | --- |
| 长度 / 分组 | 是否 `XXXX-XXXX-XXXX`、定长还是变长 |
| 字符集 | `0-9A-Z`、排除易混字符 `0O1I`、大小写敏感 |
| 校验位 | 末位 checksum / Luhn / 模运算 |
| 分段语义 | 哪段是用户 ID、哪段是产品码、哪段是签名 |

方法：在输入框喂 `AAAA-AAAA-AAAA`，看哪一段先报错（分段校验会逐段失败），配合断点看每段被读进哪个寄存器。

### 3. 核心算法（`ALGO`）

这是算号器的本体，必须还原到**能重算**的程度：

- **纯哈希型**：`SERIAL = f(NAME)`，如 `MD5(NAME+SALT)` 取前 N 位 → 还原 `SALT` 与截取规则
- **对称加密型**：`SERIAL = AES_enc(NAME, KEY)` → 还原 `KEY`（常量或派生）
- **非对称型**：本地只验签 → 需要私钥才能造号，通常改为**补丁绕过验签**而非算号
- **查表型**：内置合法号表 → 直接提取表，或还原生成表的种子

| 证据表模板 | | |
| --- | --- | --- |
| 偏移 | 原始字节 | 还原后语义 |
| `0x4012A0` | `E8 5B FF FF FF` | `call hash_fn` |
| `0x4012C5` | `83 F8 10` | `cmp eax, 0x10`（长度 16） |
| `0x4012D0` | `75 1E` | `jne fail`（校验分支） |

### 4. 常量与密钥（`SALT` / `KEY` / `MAGIC`）

- 立即数：`mov eax, 0xDEADBEEF` 这类魔数
- 字符串常量：`.rdata` 里的盐、产品码
- 派生密钥：`KEY = MD5(APP_NAME + VERSION)` 这类可重算的
- 混淆过的：异或链、逐字节解密循环 → 还原解密循环即可

```bash
# 抓常量
r2 -A SAMPLE -q -c 'axt @ 0xDEADBEEF; px 64 @ 0x402000'
strings -tx SAMPLE | grep -iE 'salt|key|magic|prod'
```

### 5. 机器绑定项（若存在）

| 绑定维度 | 还原点 |
| --- | --- |
| 硬件指纹 | `CPUID` / `VolumeSerial` / `MAC` / `MachineGuid` 的读取调用 |
| 指纹变换 | 取哪几位、如何哈希、是否截断 |
| 绑定校验 | 号里是否嵌了指纹摘要，比对逻辑在哪 |

算号器要么复现同一指纹算法（本机可用），要么做成「指纹无关」的通用号（需算法本身不绑机）。

### 6. 反调试 / 反篡改（影响动态验证）

- `IsDebuggerPresent` / `NtQueryInformationProcess` / 时间差检测
- 代码段自校验（CRC 比对）→ 打补丁前先定位校验点
- 这些不改变算法，但决定你**能不能顺利下断点**

### 7. 交付物形态（还原完成后）

```
keygen/
├── keygen.c          # 还原算法 + SERIAL 构造 + 自校验
├── patcher.c         # 可选：绕过验签/绑机的字节补丁
├── offsets.h         # 偏移表（CHECK_FN / ALGO / SALT / 分支）
└── Makefile
```

```bash
gcc -O2 -o keygen keygen.c
./keygen --name "TESTUSER"        # 输出 SERIAL
./keygen --name "TESTUSER" --verify  # 自校验：本地重跑 CHECK_FN 逻辑
```

**对照验证**：把 `keygen` 产出的 `SERIAL` 喂回 `SAMPLE`，断点停在 `CHECK_FN` 返回处，看 `eax=1`；同时用原程序对同一 `NAME` 的合法号比对字节一致。

### 优先级建议

1. **先定类型**：纯哈希 / 对称 / 非对称 / 查表 —— 决定后面是「算号」还是「打补丁」
2. **再抓算法**：`CHECK_FN` 反编译 + 动态跟一遍输入流
3. **最后补常量**：盐、密钥、指纹算法

把 `SAMPLE` 的指纹（类型/架构/是否加壳）和 `CHECK_FN` 地址给我，可以直接进第 2 步出伪代码和偏移表。