## APK 脱壳流程（壳型判定 → 静态定位 → 动态 dump → 重建回验）

> 选型：Frida 16.x + `frida-dexdump` / `FRIDA-DEXDump` 自写脚本 + `apktool` + `jadx`；目标占位 `SAMPLE.apk`，包名 `com.example.app`，壳型占位 `SHELL_TYPE`（360/梆梆/腾讯乐固/爱加密/娜迦之一，按第 1 步实测替换）。

---

### 0. 环境与样本指纹

```bash
# 设备/模拟器（建议 x86_64 AVD + frida-server 同架构）
adb devices
adb shell getprop ro.product.cpu.abi        # 记 ARCH
adb shell getprop ro.build.version.release  # 记 ANDROID_VER

# 样本指纹
md5sum SAMPLE.apk
unzip -l SAMPLE.apk | head -40
```

证据行：`$ md5sum SAMPLE.apk` → `SAMPLE_MD5  SAMPLE.apk`；`$ adb shell getprop ro.product.cpu.abi` → `ARCH`

```bash
# frida-server 推送（版本必须与本地 frida 一致）
frida --version
adb push frida-server-16.x.x-android-ARCH /data/local/tmp/fs
adb shell "su -c 'chmod 755 /data/local/tmp/fs && /data/local/tmp/fs &'"
frida-ps -U | head
```

---

### 1. 壳型判定（决定后面走哪条 dump 路径）

```bash
# 1.1 看 lib 目录：壳的 .so 名字是强指纹
unzip -l SAMPLE.apk | grep -E 'lib/.*\.so'
# 常见指纹：
#   libjiagu*.so / libjiagu_art.so        -> 360 加固
#   libDexHelper.so / libSecShell.so      -> 梆梆
#   libshell*.so / libtosprotection*.so   -> 腾讯乐固
#   libexec.so / libexecmain.so           -> 爱加密
#   libchaosvmp.so / libddog.so           -> 娜迦
#   libmobisec.so                         -> 阿里聚安全

# 1.2 看 Application 类是否被替换（壳的入口）
apktool d -f -s SAMPLE.apk -o SAMPLE_dec
grep -A3 'application' SAMPLE_dec/AndroidManifest.xml
# 壳通常把 android:name 改成 com.stub.StubApp / com.secneo.apkwrapper.* / com.tencent.StubShell.* 等

# 1.3 看 dex 数量与体积：壳的 dex 只有壳代码，业务 dex 在运行时解密
unzip -l SAMPLE.apk | grep '\.dex'
```

证据行：`$ unzip -l SAMPLE.apk | grep '\.so'` → `… libjiagu_art.so …`（示例）；`$ grep application SAMPLE_dec/AndroidManifest.xml` → `android:name="com.stub.StubApp"`

判定表：

| 特征 | 壳型 `SHELL_TYPE` | 首选 dump 路径 |
| --- | --- | --- |
| `libjiagu*.so` + `StubApp` | 360 | 内存 dex 扫描（frida-dexdump） |
| `libDexHelper.so` | 梆梆 | ART 内存扫描 + 类加载 hook |
| `libshell*.so` | 乐固 | 内存扫描 + `DexFile` 构造 hook |
| `libexec*.so` | 爱加密 | 内存扫描 + VMP 段单独处理 |
| 无 .so、dex 完整 | 无壳/仅混淆 | 直接 `jadx`，跳过 2–4 |

---

### 2. 静态定位（壳入口与解密时机）

```bash
# 2.1 壳的 Application/attachBaseContext 是解密触发点
jadx -d SAMPLE_jadx SAMPLE.apk
# 打开 com.stub.StubApp（或 1.2 里读到的类），看：
#   attachBaseContext() -> 加载 .so、解密 dex、反射替换 Application
#   onCreate()          -> 二次校验、反调试

# 2.2 找 .so 的 JNI 入口
unzip -o SAMPLE.apk 'lib/*' -d SAMPLE_lib
for f in SAMPLE_lib/lib/*/*.so; do echo "== $f"; nm -D "$f" 2>/dev/null | grep -E 'Java_|JNI_OnLoad'; done
# 关键符号：JNI_OnLoad、Java_com_stub_StubApp_*、以及壳自定义的 decrypt/dump 相关导出
```

证据行：`$ nm -D SAMPLE_lib/lib/ARCH/libjiagu_art.so | grep JNI_OnLoad` → `… T JNI_OnLoad`

关键时机（记下来，第 3 步断点用）：

- `Application.attachBaseContext` 返回后 → 业务 dex 通常已解密并 `DexFile.loadDex` 完成
- `ClassLoader.loadClass` 首次加载业务类 → 对应 dex 一定已就位
- 壳的 `onCreate` 之后 → 反调试可能已启动，dump 窗口在此之前

---

### 3. 动态 dump（三条路径，按壳型选一条，失败换下一条）

#### 3.1 路径 A：内存 dex 扫描（通用，先跑这个）

```bash
pip install frida-dexdump
frida-dexdump -U -f com.example.app -d 300 -o DUMP_DIR
ls -l DUMP_DIR
```

证据行：`$ frida-dexdump -U -f com.example.app -o DUMP_DIR` → `… Found N dex files … saved to DUMP_DIR`

#### 3.2 路径 B：类加载 hook（壳把 dex 藏在自定义 ClassLoader 时）

`hook_dexload.js`：

```javascript
// 在 DexFile / DexClassLoader / InMemoryDexClassLoader 构造时抓 dex 起始地址与大小
Java.perform(function () {
  var DexFile = Java.use("dalvik.system.DexFile");
  DexFile.$init.overload('java.io.File').implementation = function (f) {
    console.log("[DexFile] " + f.getAbsolutePath());
    return this.$init(f);
  };

  var BaseDexClassLoader = Java.use("dalvik.system.BaseDexClassLoader");
  BaseDexClassLoader.$init.overload('java.lang.String', 'java.io.File', 'java.lang.String', 'java.lang.ClassLoader')
    .implementation = function (dexPath, optDir, libPath, parent) {
      console.log("[BaseDexClassLoader] dexPath=" + dexPath);
      return this.$init(dexPath, optDir, libPath, parent);
    };

  // ART 