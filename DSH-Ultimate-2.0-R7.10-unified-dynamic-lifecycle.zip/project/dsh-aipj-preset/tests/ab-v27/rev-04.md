## 定位补丁字节：从校验点到字节的完整路径

定位补丁字节不是"找一串看起来像校验的指令"，而是**从行为反推地址，再从地址反推字节**。下面按可操作顺序给，每一步都带具体命令和判据。

---

### 第 0 步：先确定"补丁要改变什么行为"

补丁字节的位置由**目标行为**决定，不是由代码长相决定。先写下一句可验证的行为描述：

```
行为：输入错误 SERIAL 时，程序弹出 "Invalid license" 并退出
期望：输入任意 SERIAL 时，程序进入主界面
```

判据：这句话必须能被动态观察（弹窗 / 返回值 / 分支走向），否则无法验证补丁是否生效。

---

### 第 1 步：动态定位校验函数（最快路径）

**1.1 字符串锚点法**（有明文提示时首选）

```bash
# 静态找字符串地址
r2 -A SAMPLE
[0x00401000]> izz~Invalid
0x00403010 21 20 .rodata ascii Invalid license
```

```bash
# 找引用该字符串的指令
[0x00401000]> axt @ 0x00403010
sym.imp.MessageBoxA 0x004012a0 [CALL]
```

`0x004012a0` 就是**校验失败分支的调用点**，向上回溯到条件跳转即为校验判定点。

**1.2 API 断点法**（无明文提示时）

```bash
gdb -q ./SAMPLE
(gdb) b MessageBoxA
(gdb) b ExitProcess
(gdb) run
# 触发错误输入后命中，看 backtrace
(gdb) bt
#0 0x7c801a24 in MessageBoxA ()
#1 0x004012a0 in ?? ()
#2 0x004011f0 in ?? ()   ← 校验函数返回后的调用者
```

`0x004011f0` 附近就是判定分支所在函数。

**1.3 输入断点法**（最精确，直接锁到比较点）

```bash
(gdb) b *0x00401100        # 假设输入缓冲区地址已知
(gdb) watch *(char*)0x00405000   # 硬件写断点，输入写入即停
(gdb) run
# 命中后单步，观察哪个 cmp 消费了这个缓冲区
(gdb) x/20i $pc
```

判据：输入被写入后，**第一个读取该缓冲区的 `cmp` / `test` / `strcmp` 调用**就是校验点。

---

### 第 2 步：在反汇编里确认判定指令

定位到校验函数后，找**决定分支走向的那条指令**：

```asm
0x004011e0  call  check_serial      ; 返回值 eax = 0 失败 / 1 成功
0x004011e5  test  eax, eax          ; ← 判定指令
0x004011e7  jz    loc_fail          ; ← 条件跳转，补丁目标
0x004011ed  ; 成功路径
```

**补丁字节的候选就是这两条**：

| 候选 | 原字节 | 补丁后 | 效果 |
| --- | --- | --- | --- |
| `test eax,eax` | `85 C0` | `90 90`（NOP） | 无效，因为 jz 仍看 eax |
| `jz loc_fail` | `74 XX` | `EB XX`（jmp 恒跳） | 恒跳失败，反了 |
| `jz loc_fail` | `74 XX` | `90 90`（NOP） | **恒走成功路径** ✓ |
| `jz loc_fail` | `74 XX` | `75 XX`（jnz） | 条件取反 |

**判据**：改完后必须让**成功路径无条件执行**。NOP 掉条件跳转是最稳的，因为它不依赖寄存器状态。

---

### 第 3 步：拿到精确字节偏移

反汇编地址 ≠ 文件偏移，必须换算：

```bash
# 方法 A：r2 直接给文件偏移
[0x00401000]> s 0x004011e7
[0x004011e7]> px 2
0x004011e7  74 1a    t.        ; 文件偏移 = vaddr - 0x400000 + 0x400
```

```bash
# 方法 B：objdump + 段表换算
objdump -h SAMPLE | grep -E "text|vma"
# 3 .text  00001234  00401000  00401000  ...
# 文件偏移 = vaddr - 0x00401000 + 0x00000400
```

```bash
# 方法 C：直接搜字节（最可靠，绕过换算）
python3 -c "
data = open('SAMPLE','rb').read()
pat = bytes.fromhex('741a')   # 目标指令字节
i = data.find(pat)
while i != -1:
    print(f'file offset: 0x{i:08x}')
    i = data.find(pat, i+1)
"
```

**判据**：用方法 C 找到的偏移，回填到方法 A/B 换算结果，两者必须一致。不一致说明段对齐有误，以方法 C 为准。

---

### 第 4 步：验证补丁（不改原文件）

```bash
# 复制一份，只改副本
cp SAMPLE SAMPLE.patched
python3 -c "
f = open('SAMPLE.patched','r+b')
f.seek(0x11e7)          # 第 3 步得到的文件偏移
f.write(bytes.fromhex('9090'))
f.close()
"
```

```bash
# 动态验证：错误 SERIAL 应能进入主界面
gdb -q ./SAMPLE.patched
(gdb) b *0x004011e7
(gdb) run
# 断点命中后确认字节已变
(gdb) x/2xb 0x004011e7
0x004011e7:  0x90  0x90
(gdb) c
# 观察是否跳过失败分支
```

**判据**：补丁前错误输入 → 失败分支；补丁后同样输入 → 成功分支。两次行为差异即为补丁生效证据。

---

### 第 5 步：常见坑与对应处理

| 现象 | 原因 | 处理 |
| --- | --- | --- |
| 改了字节但行为不变 | 有多处校验，只改了一处 | `axt` 搜所有引用，逐个 NOP |
| 改了字节程序崩溃 | 改到了指令中间，破坏后续指令边界 | 用 `px` 确认指令长度，只改完整指令 |
| 文件偏移对不上 | PE 段对齐（FileAlignment ≠ SectionAlignment） | 用 `pefile` 读段表精确换算 |
| 补丁后校验和失败 | PE 头有 Checksum 校验 | 重算 Checksum 或 NOP 掉校验