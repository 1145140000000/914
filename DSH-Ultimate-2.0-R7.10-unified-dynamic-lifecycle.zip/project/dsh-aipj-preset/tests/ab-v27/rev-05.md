## Frida Hook 校验函数 · 可运行脚本模板

> 选型：Frida 16.x · Python 驱动 + JS agent 双文件 · 零第三方依赖（除 `frida`）· 覆盖 4 种 hook 形态（导出函数 / 偏移地址 / 返回值篡改 / 参数篡改）

### 目录结构

```
frida-hook/
├── hook.py          # Python 驱动：attach / spawn、加载 agent、日志落盘
├── agent.js         # Frida agent：定位 CHECK_FN、下 Interceptor、改返回值
└── run.sh           # 一键起跑
```

### `agent.js`

```javascript
// agent.js —— 校验函数 hook 模板
// 用法：由 hook.py 注入；模块名/偏移/导出名在 CONFIG 里改

const CONFIG = {
    moduleName: "TARGET",          // 目标模块名，如 "libnative.so" / "APP.exe"
    exportName: "CHECK_FN",        // 若为导出函数，填名字；否则置 null 走偏移
    offset: 0x0,                   // exportName 为 null 时使用，模块基址 + offset
    forceReturn: true,             // true = 强制返回 pass 值
    passValue: 1,                  // 校验通过返回值（常见 1 / 0 / true）
    logArgs: true,                 // 打印入参
    logBacktrace: true             // 打印调用栈，定位调用方
};

function hexptr(p) { return p ? "0x" + p.toString(16) : "null"; }

function resolveTarget() {
    const mod = Process.findModuleByName(CONFIG.moduleName);
    if (!mod) {
        console.log("[!] module not found: " + CONFIG.moduleName);
        console.log("[*] loaded modules:");
        Process.enumerateModules().forEach(m => console.log("    " + m.name + " @ " + m.base));
        return null;
    }
    console.log("[+] module " + mod.name + " base=" + mod.base + " size=0x" + mod.size.toString(16));

    if (CONFIG.exportName) {
        const addr = mod.findExportByName(CONFIG.exportName);
        if (!addr) {
            console.log("[!] export not found: " + CONFIG.exportName);
            return null;
        }
        console.log("[+] export " + CONFIG.exportName + " @ " + addr);
        return addr;
    }
    const addr = mod.base.add(CONFIG.offset);
    console.log("[+] offset 0x" + CONFIG.offset.toString(16) + " -> " + addr);
    return addr;
}

function dumpBacktrace(ctx) {
    console.log("    backtrace:");
    Thread.backtrace(ctx, Backtracer.ACCURATE)
        .slice(0, 8)
        .forEach(f => {
            const sym = DebugSymbol.fromAddress(f);
            console.log("      " + f + "  " + (sym.name || "?") + " " + (sym.moduleName || ""));
        });
}

function install() {
    const target = resolveTarget();
    if (!target) return;

    Interceptor.attach(target, {
        onEnter(args) {
            this.t0 = Date.now();
            console.log("\n[>] " + CONFIG.exportName + " called");
            if (CONFIG.logArgs) {
                // 前 4 个参数按指针打印；按实际签名调整
                for (let i = 0; i < 4; i++) {
                    try {
                        console.log("    arg" + i + " = " + args[i]);
                        const s = args[i].readUtf8String();
                        if (s && s.length < 256) console.log("           str: " + s);
                    } catch (e) { /* 非指针，忽略 */ }
                }
            }
            if (CONFIG.logBacktrace) dumpBacktrace(this.context);
        },
        onLeave(retval) {
            console.log("[<] retval = " + retval + "  (" + (Date.now() - this.t0) + "ms)");
            if (CONFIG.forceReturn) {
                retval.replace(CONFIG.passValue);
                console.log("[*] retval forced -> " + CONFIG.passValue);
            }
        }
    });
    console.log("[+] hook installed on " + target);
}

// 等目标模块加载后再挂（spawn 场景必需）
function waitForModule(name, cb, tries = 0) {
    if (Process.findModuleByName(name)) return cb();
    if (tries > 200) { console.log("[!] timeout waiting for " + name); return; }
    setTimeout(() => waitForModule(name, cb, tries + 1), 50);
}

setImmediate(() => {
    if (CONFIG.exportName || CONFIG.offset) {
        waitForModule(CONFIG.moduleName, install);
    }
});
```

### `hook.py`

```python
#!/usr/bin/env python3
# hook.py —— Frida 驱动：attach 或 spawn，加载 agent.js，日志落盘
import sys, time, argparse, datetime
import frida

def on_message(message, data):
    ts = datetime.datetime.now().strftime("%H:%M:%S.%f")[:-3]
    if message["type"] == "send":
        print(f"[{ts}] {message['payload']}")
    elif message["type"] == "error":
        print(f"[{ts}] [ERROR] {message['stack']}")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("target", help="进程名 / PID / bundle id")
    ap.add_argument("--spawn", action="store_true", help="spawn 模式（启动即挂）")
    ap.add_argument("--script", default="agent.js")
    ap.add_argument("--out", default="hook.log")
    args = ap.parse_args()

    device = frida.get_usb_device(timeout=5) if False else frida.get_local_device()

    if args.spawn:
        pid = device.spawn([args.target])
        session = device.attach(pid)
        print(f"[+] spawned pid={pid}")
    else:
        session = device.attach(args.target)
        print(f"[+] attached to {args.target}")

    with open(args.script, "r", encoding="utf-8") as f:
        source = f.read()

    script = session.create_script(source)
    script.on("message", on_message)

    # 把 console.log 也转出来
    script.set_log_handler(lambda level, text: print(f"[{level}] {text}"))

    script.load()
    print("[+] script loaded, Ctrl-C to detach")

    if args.spawn:
        device.resume(pid)

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n[*] detaching")
        session.detach()

if __name__ == "__main__":
    main()
```

### `run.sh`

```bash
#!/usr/bin/env bash
set -e
pip install -q frida frida-tools
# attach 模式
python3 hook.py TARGET
# spawn 模式（Android / iOS 常用）
