## 目标枚举链：单 IP + 单端口起步

> 选型：`nmap` + `ffuf` + `curl`，全程落 `RESULT_DIR`，先枚举再深入。

### 0. 变量与目录

```bash
export TARGET="10.10.10.10"          # 占位：替换为目标 IP
export PORT="8080"                    # 占位：替换为目标端口
export RESULT_DIR="./enum_${TARGET}_${PORT}"
mkdir -p "$RESULT_DIR"/{nmap,web,raw}
```

### 1. 端口确认与全端口补扫

```bash
# 先确认给定端口，再补扫全端口（别只信一个端口）
nmap -Pn -p "$PORT" -sV -sC -oN "$RESULT_DIR/nmap/port_${PORT}.txt" "$TARGET"
nmap -Pn -p- --min-rate 2000 -T4 -oN "$RESULT_DIR/nmap/allports.txt" "$TARGET"
```

预期回显关键行：
```
PORT     STATE SERVICE VERSION
8080/tcp open  http    nginx 1.18.0
```

### 2. 服务识别（按第 1 步结果分支）

```bash
# HTTP/HTTPS 类
curl -sS -i "http://$TARGET:$PORT/" -o "$RESULT_DIR/web/root_http.txt"
curl -skS -i "https://$TARGET:$PORT/" -o "$RESULT_DIR/web/root_https.txt"
whatweb -a 3 "http://$TARGET:$PORT/" | tee "$RESULT_DIR/web/whatweb.txt"

# 非 HTTP（SSH/SMB/Redis/MySQL 等）按服务走对应 banner 抓取
nc -nv -w3 "$TARGET" "$PORT" | tee "$RESULT_DIR/raw/banner.txt"
```

### 3. 目录 / 接口字典枚举

```bash
export WORDLIST="/usr/share/seclists/Discovery/Web-Content/raft-medium-directories.txt"
ffuf -u "http://$TARGET:$PORT/FUZZ" -w "$WORDLIST" -t 40 \
     -mc 200,204,301,302,307,401,403 \
     -o "$RESULT_DIR/web/ffuf_dirs.json" \
     -of json
```

### 4. JS 提取接口（前端站点必做）

```bash
# 抓首页引用的 JS，提取路径与接口
curl -sS "http://$TARGET:$PORT/" | grep -oE 'src="[^"]+\.js[^"]*"' | cut -d'"' -f2 \
  | tee "$RESULT_DIR/web/js_list.txt"
# 逐个下载后提取
while read -r js; do
  curl -sS "http://$TARGET:$PORT/$js" >> "$RESULT_DIR/web/all.js"
done < "$RESULT_DIR/web/js_list.txt"
grep -oE '"/[a-zA-Z0-9_./-]+"' "$RESULT_DIR/web/all.js" | sort -u \
  | tee "$RESULT_DIR/web/api_paths.txt"
```

### 5. 命中验证

```bash
# 对 ffuf 命中项与 api_paths 逐点验证，记录状态码/长度/标题
while read -r p; do
  code=$(curl -sS -o /dev/null -w '%{http_code}' "http://$TARGET:$PORT$p")
  echo "$code  $p"
done < "$RESULT_DIR/web/api_paths.txt" | tee "$RESULT_DIR/web/verify.txt"
```

### 6. 结果汇总

```bash
{
  echo "== 端口 =="; grep -E '^[0-9]+/tcp' "$RESULT_DIR/nmap/allports.txt"
  echo "== 指纹 =="; cat "$RESULT_DIR/web/whatweb.txt"
  echo "== 目录命中 =="; jq -r '.results[] | "\(.status) \(.length) \(.url)"' "$RESULT_DIR/web/ffuf_dirs.json"
  echo "== 接口 =="; cat "$RESULT_DIR/web/verify.txt"
} | tee "$RESULT_DIR/RESULT_LOG.txt"
```

### 证据行

- `$ nmap -Pn -p 8080 -sV 10.10.10.10` → `8080/tcp open http nginx 1.18.0`（占位回显，实际以目标为准）
- `$ ffuf -u http://10.10.10.10:8080/FUZZ -w raft-medium-directories.txt` → 命中项写入 `ffuf_dirs.json`，`jq` 可复现
- 全部产物落 `./enum_10.10.10.10_8080/`，`RESULT_LOG.txt` 为汇总入口

### 下一步分支（拿到第 1、2 步回显后）

| 回显特征 | 走向 |
| --- | --- |
| `http` + 目录命中多 | 接口/参数枚举 → 注入 / 越权 / 上传分类验证 |
| `ssh` / `smb` / `rdp` | 凭据面枚举（用户名、共享、版本 CVE） |
| `redis` / `mysql` / `mongo` | 未授权访问验证 → 数据面 |
| 只有 403/401 | 认证面：默认口令、JWT、会话固定 |

把第 1、2 步的原始回显贴回来，我按命中分支直接给下一段命令链。