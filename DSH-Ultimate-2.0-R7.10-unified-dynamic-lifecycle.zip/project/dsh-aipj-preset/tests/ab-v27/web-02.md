## 信息收集命令链（子域 → 存活 → 指纹 → 接口）

> 选型：`subfinder` + `dnsx` + `httpx` + `nuclei` + `katana` + `ffuf`，全部落盘到 `RESULT_DIR`，每步产物作为下一步输入。`TARGET=example.com` 自行替换。

```bash
# ===== 0. 环境与目录 =====
export TARGET="example.com"
export RESULT_DIR="./recon_${TARGET}_$(date +%Y%m%d_%H%M)"
mkdir -p "$RESULT_DIR"/{subs,alive,finger,urls,dirs}
cd "$RESULT_DIR"

# 工具自检（缺哪个装哪个）
for t in subfinder dnsx httpx nuclei katana ffuf; do
  command -v $t >/dev/null && echo "[ok] $t" || echo "[miss] $t"
done
```

```bash
# ===== 1. 子域名枚举（被动多源 + 证书透明 + 爆破兜底）=====
subfinder -d "$TARGET" -all -recursive -silent \
  | tee subs/subfinder.txt

# 证书透明日志补充
curl -s "https://crt.sh/?q=%25.${TARGET}&output=json" \
  | jq -r '.[].name_value' | sed 's/\*\.//g' | sort -u \
  | tee subs/crtsh.txt

# 字典爆破兜底（可选，DNS 量大时先跳过）
# ffuf -u "https://FUZZ.${TARGET}" -w /usr/share/seclists/Discovery/DNS/subdomains-top1million-5000.txt \
#   -mc all -fs 0 -t 100 -o subs/ffuf_dns.json

# 合并去重
cat subs/*.txt | grep -E "^[a-zA-Z0-9._-]+\.${TARGET}$" | sort -u > subs/all.txt
wc -l subs/all.txt
```

```bash
# ===== 2. 存活探测（DNS 解析 + HTTP 探活，双阶段）=====
# 2.1 DNS 解析，剔除死域名
dnsx -l subs/all.txt -a -resp -silent -o alive/dnsx_resolved.txt

# 2.2 HTTP/HTTPS 探活 + 标题 + 状态码 + 技术栈 + CDN 识别
httpx -l alive/dnsx_resolved.txt \
  -ports 80,443,8080,8443,8000,8888,9000 \
  -status-code -title -tech-detect -web-server -cdn -ip -cname \
  -follow-redirects -threads 100 -silent \
  -o alive/httpx_alive.txt

# 只留 200/30x/401/403 的活口
awk '{print $1}' alive/httpx_alive.txt | sort -u > alive/live_urls.txt
wc -l alive/live_urls.txt
```

```bash
# ===== 3. 指纹识别（技术栈 + WAF + 框架版本）=====
# 3.1 httpx 已带 tech-detect，单独导出结构化结果
httpx -l alive/live_urls.txt -tech-detect -json -silent \
  | jq -r '[.url, (.tech // [] | join(",")), .webserver, .status_code] | @tsv' \
  | tee finger/tech.tsv

# 3.2 WAF 识别
wafw00f -i alive/live_urls.txt -o finger/waf.txt -f csv 2>/dev/null

# 3.3 nuclei 指纹模板（技术栈/面板/中间件）
nuclei -l alive/live_urls.txt -t http/technologies/ -silent \
  -o finger/nuclei_tech.txt

# 3.4 手动补刀：favicon hash（资产测绘平台反查用）
while read u; do
  h=$(curl -sk -m 5 "$u/favicon.ico" | md5sum | cut -d' ' -f1)
  echo -e "$u\t$h"
done < alive/live_urls.txt | tee finger/favicon_hash.tsv
```

```bash
# ===== 4. 接口 / URL 收集（爬虫 + JS 提取 + 历史 + 字典）=====
# 4.1 主动爬取（含 JS 渲染）
katana -list alive/live_urls.txt -d 3 -jc -kf all -silent \
  -o urls/katana.txt

# 4.2 历史 URL（wayback + commoncrawl）
cat alive/live_urls.txt | waybackurls | sort -u > urls/wayback.txt
cat alive/live_urls.txt | gau --threads 10 | sort -u > urls/gau.txt

# 4.3 从 JS 里抠接口路径
cat urls/katana.txt | grep -Ei '\.js(\?|$)' | sort -u > urls/js_files.txt
while read js; do
  curl -sk -m 10 "$js" \
    | grep -oE '"/[a-zA-Z0-9_./-]{2,}"' \
    | tr -d '"'
done < urls/js_files.txt | sort -u > urls/js_endpoints.txt

# 4.4 合并 + 参数化 URL 提取（带 ? 的接口）
cat urls/*.txt | grep -E '^https?://' | sort -u > urls/all_urls.txt
grep '?' urls/all_urls.txt | sort -u > urls/param_urls.txt

# 4.5 目录/接口爆破（按指纹选字典）
ffuf -u "https://${TARGET}/FUZZ" \
  -w /usr/share/seclists/Discovery/Web-Content/raft-medium-directories.txt \
  -mc 200,204,301,302,401,403 -fs 0 -t 80 \
  -o dirs/ffuf_dirs.json -of json
```

```bash
# ===== 5. 汇总报告 =====
{
  echo "# Recon Report: $TARGET"
  echo "## 子域总数: $(wc -l < subs/all.txt)"
  echo "## 存活主机: $(wc -l < alive/live_urls.txt)"
  echo "## 技术栈分布:"
  cut -f2 finger/tech.tsv | tr ',' '\n' | sort | uniq -c | sort -rn | head -20
  echo "## 接口总数: $(wc -l < urls/all_urls.txt)"
  echo "## 带参接口: $(wc -l < urls/param_urls.txt)"
} | tee report.md
```

## 关键回显对照

| 步骤 | 命令 | 预期回显 |
| --- | --- | --- |
| 子域 | `subfinder -d TARGET -all` | 每