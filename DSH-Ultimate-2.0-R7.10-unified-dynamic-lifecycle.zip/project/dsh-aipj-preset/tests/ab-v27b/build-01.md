## 记账小工具（单文件 · 零依赖 · 命令行）

> 选型：Python 3.8+ · 标准库 sqlite3/argparse · 单文件 `ledger.py` · 数据落 `ledger.db`

### 目录与入口

```
ledger/
├── ledger.py      # 唯一入口
└── ledger.db      # 首次运行自动创建
```

### 完整实现

```python
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ledger.py — 极简命令行记账工具（SQLite 存储，零第三方依赖）"""

import argparse
import os
import sqlite3
import sys
from datetime import date, datetime

DB_PATH = os.environ.get("LEDGER_DB", os.path.join(os.path.dirname(os.path.abspath(__file__)), "ledger.db"))

SCHEMA = """
CREATE TABLE IF NOT EXISTS entries (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    day      TEXT    NOT NULL,
    kind     TEXT    NOT NULL CHECK (kind IN ('in','out')),
    amount   REAL    NOT NULL CHECK (amount > 0),
    category TEXT    NOT NULL DEFAULT '未分类',
    note     TEXT    NOT NULL DEFAULT '',
    created  TEXT    NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_day ON entries(day);
CREATE INDEX IF NOT EXISTS idx_cat ON entries(category);
"""


def connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA)
    return conn


def parse_day(s):
    if not s:
        return date.today().isoformat()
    try:
        return datetime.strptime(s, "%Y-%m-%d").date().isoformat()
    except ValueError:
        sys.exit(f"日期格式错误：{s}，应为 YYYY-MM-DD")


def cmd_add(args):
    day = parse_day(args.date)
    amount = round(float(args.amount), 2)
    if amount <= 0:
        sys.exit("金额必须大于 0")
    with connect() as conn:
        cur = conn.execute(
            "INSERT INTO entries(day,kind,amount,category,note,created) VALUES(?,?,?,?,?,?)",
            (day, args.kind, amount, args.category, args.note or "", datetime.now().isoformat(timespec="seconds")),
        )
        print(f"已记录 #{cur.lastrowid}  {day}  {'收入' if args.kind == 'in' else '支出'}  {amount:.2f}  [{args.category}] {args.note or ''}")


def cmd_list(args):
    sql = "SELECT * FROM entries WHERE 1=1"
    params = []
    if args.month:
        sql += " AND day LIKE ?"
        params.append(args.month + "%")
    if args.category:
        sql += " AND category = ?"
        params.append(args.category)
    sql += " ORDER BY day DESC, id DESC LIMIT ?"
    params.append(args.limit)
    with connect() as conn:
        rows = conn.execute(sql, params).fetchall()
    if not rows:
        print("（无记录）")
        return
    print(f"{'ID':>4}  {'日期':<10}  {'类型':<4}  {'金额':>10}  {'分类':<8}  备注")
    print("-" * 68)
    for r in rows:
        t = "收入" if r["kind"] == "in" else "支出"
        print(f"{r['id']:>4}  {r['day']:<10}  {t:<4}  {r['amount']:>10.2f}  {r['category']:<8}  {r['note']}")


def cmd_summary(args):
    month = args.month or date.today().strftime("%Y-%m")
    with connect() as conn:
        tot = conn.execute(
            "SELECT kind, COALESCE(SUM(amount),0) s FROM entries WHERE day LIKE ? GROUP BY kind",
            (month + "%",),
        ).fetchall()
        by_cat = conn.execute(
            "SELECT category, kind, SUM(amount) s, COUNT(*) n FROM entries WHERE day LIKE ? GROUP BY category, kind ORDER BY s DESC",
            (month + "%",),
        ).fetchall()
    sums = {r["kind"]: r["s"] for r in tot}
    inc, out = sums.get("in", 0.0), sums.get("out", 0.0)
    print(f"== {month} 汇总 ==")
    print(f"收入：{inc:>10.2f}")
    print(f"支出：{out:>10.2f}")
    print(f"结余：{inc - out:>10.2f}")
    if by_cat:
        print("\n分类明细：")
        for r in by_cat:
            t = "收入" if r["kind"] == "in" else "支出"
            print(f"  {r['category']:<10} {t}  {r['s']:>10.2f}  ({r['n']} 笔)")


def cmd_del(args):
    with connect() as conn:
        cur = conn.execute("DELETE FROM entries WHERE id = ?", (args.id,))
        if cur.rowcount == 0:
            sys.exit(f"未找到记录 #{args.id}")
        print(f"已删除 #{args.id}")


def cmd_export(args):
    with connect() as conn:
        rows = conn.execute("SELECT * FROM entries ORDER BY day, id").fetchall()
    if args.format == "csv":
        import csv
        w = csv.writer(sys.stdout)
        w.writerow(["id", "day", "kind", "amount", "category", "note", "created"])
        for r in rows:
            w.writerow([r["id"], r["day"], r["kind"], f"{r['amount']:.2f}", r["category"], r["note"], r["created"]])
    else:
        import json
        print(json.dumps([dict(r) for r in rows], ensure_ascii=False, indent=2))


def build_parser():
    p = argparse.ArgumentParser(prog="ledger", description="极简命令行记账工具")
    sub = p.add_subparsers(dest="cmd", required=True)

    a = sub.add_parser("add", help="记一笔")
    a.add_argument("kind", choices=["in", "out"], help="in=收入 out=支出")
    a.add_argument("amount", type=float, help="金额")
    a.add_argument("-c", "--category", default="未分类", help="分类，默认 未分类")
    a.add_argument("-n", "--note", default="", help="备注")
    a.add_argument("-d", "--date", default="", help="日期 YYYY-MM-DD，默认今天")
    a.set_defaults(func=cmd_add)

    l = sub.add_parser("list", help="列出记录")
    l.add_argument("-m", "--month", default="", help="按月过滤 YYYY-MM")
    l.add_argument("-c", "--category", default="", help="按分类过滤")
    l.add_argument("-