## 批量改名脚本 `batch_rename.py`

> 选型：Python 3.8+ · 零第三方依赖 · 单文件 · 支持预览/正则/序号/日期/递归/撤销

### 目录与入口

```
batch_rename.py      # 唯一入口，chmod +x 后可直接执行
```

### 完整实现

```python
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
batch_rename.py — 批量文件改名工具

用法示例:
  # 1) 预览：把所有 .jpeg 改成 .jpg（不落盘）
  python batch_rename.py ./photos -p '\.jpeg$' -r '.jpg' --dry-run

  # 2) 正则替换 + 递归
  python batch_rename.py ./photos -p 'IMG_(\d+)' -r 'vacation_\1' -R

  # 3) 加序号前缀
  python batch_rename.py ./docs --prefix 'doc_' --number --start 1 --pad 3

  # 4) 加日期后缀
  python batch_rename.py ./logs --suffix '_backup' --date '%Y%m%d'

  # 5) 撤销上一次改名
  python batch_rename.py --undo .batch_rename_undo.json
"""
import argparse
import json
import os
import re
import sys
import time
from pathlib import Path

UNDO_FILE = ".batch_rename_undo.json"


def build_new_name(path: Path, args, index: int) -> str:
    """根据规则计算新文件名（不含目录）。"""
    stem, ext = path.stem, path.suffix

    # 1. 正则替换（作用于完整文件名，含扩展名）
    if args.pattern is not None:
        try:
            stem_ext = path.name
            new_full = re.sub(args.pattern, args.replace or "", stem_ext)
        except re.error as e:
            sys.exit(f"[错误] 正则非法: {e}")
        p = Path(new_full)
        stem, ext = p.stem, p.suffix

    # 2. 大小写
    if args.lower:
        stem, ext = stem.lower(), ext.lower()
    if args.upper:
        stem, ext = stem.upper(), ext.upper()

    # 3. 前缀 / 后缀
    if args.prefix:
        stem = args.prefix + stem
    if args.suffix:
        stem = stem + args.suffix

    # 4. 序号
    if args.number:
        num = str(args.start + index).zfill(args.pad)
        if args.number_pos == "prefix":
            stem = f"{num}_{stem}"
        else:
            stem = f"{stem}_{num}"

    # 5. 日期
    if args.date:
        stamp = time.strftime(args.date)
        stem = f"{stem}_{stamp}"

    return stem + ext


def collect_files(root: Path, recursive: bool, exts):
    if recursive:
        it = root.rglob("*")
    else:
        it = root.iterdir()
    files = [p for p in it if p.is_file()]
    if exts:
        wanted = {e.lower() if e.startswith(".") else "." + e.lower() for e in exts}
        files = [p for p in files if p.suffix.lower() in wanted]
    return sorted(files, key=lambda p: str(p).lower())


def do_rename(files, args):
    plan = []          # [(src, dst)]
    used = set()       # 目标名去重（同目录内）
    for i, src in enumerate(files):
        new_name = build_new_name(src, args, i)
        dst = src.with_name(new_name)
        if dst == src:
            continue
        key = str(dst).lower()
        if key in used:
            print(f"[跳过] 目标名冲突: {dst}")
            continue
        used.add(key)
        plan.append((src, dst))

    if not plan:
        print("没有需要改名的文件。")
        return 0

    # 预览
    width = max(len(str(s)) for s, _ in plan)
    for src, dst in plan:
        print(f"{str(src):<{width}}  ->  {dst.name}")

    if args.dry_run:
        print(f"\n[dry-run] 共 {len(plan)} 个文件待改名，未落盘。")
        return 0

    # 冲突预检：目标已存在且不是自己
    conflicts = [d for _, d in plan if d.exists() and d not in [s for s, _ in plan]]
    if conflicts and not args.force:
        print("\n[中止] 以下目标文件已存在，加 --force 覆盖：")
        for c in conflicts:
            print("  ", c)
        return 1

    # 执行 + 记录撤销表
    undo = []
    ok = 0
    for src, dst in plan:
        try:
            if dst.exists() and args.force:
                dst.unlink()
            src.rename(dst)
            undo.append({"from": str(dst), "to": str(src)})
            ok += 1
        except OSError as e:
            print(f"[失败] {src} -> {dst.name}: {e}")

    if undo:
        with open(UNDO_FILE, "w", encoding="utf-8") as f:
            json.dump(undo, f, ensure_ascii=False, indent=2)
        print(f"\n完成 {ok}/{len(plan)} 个。撤销表已写入 {UNDO_FILE}")
    return 0 if ok == len(plan) else 2


def do_undo(undo_path: str):
    p = Path(undo_path)
    if not p.exists():
        sys.exit(f"[错误] 撤销表不存在: {p}")
    records = json.loads(p.read_text(encoding="utf-8"))
    ok = 0
    for rec in reversed(records):
        src, dst = Path(rec["from"]), Path(rec["to"])
        if not src.exists():
            print(f"[跳过] 源已不存在: {src}")
            continue
        if dst.exists():
            print(f"[跳过] 目标已存在: {dst}")
            continue
        try:
            src.rename(dst)
            ok += 1
        except OSError as e:
            print(f"[失败] {src} -> {dst}: {e}")
    print(f"撤销完成 {ok}/{len(records)} 个。")
    return 0


def main():
    ap = argparse.ArgumentParser(
        description="批量文件改名（支持预览、正则、序号、日期、递归、撤销）",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ap.add_argument("target", nargs="?", default=".", help="目标目录（默认当前目录）")
    ap.add_argument("-p", "--pattern", help="正则匹配（作用于完整文件名）")
    ap.add_argument("-r", "--replace", default="", help="正则替换串，支持 \\1 反向引用")
    ap.add_argument("--prefix", help="文件名前缀")
    ap.add_argument("--suffix", help