## `todo.py` — 命令行待办清单

> 选型：Python 3.8+ · 零依赖 · 单文件 · JSON 落盘 · 子命令式 CLI

### 目录与入口

```
todo/
├── todo.py          # 唯一入口
└── todos.json       # 首次运行时自动创建
```

### 完整实现

```python
#!/usr/bin/env python3
"""todo.py - 命令行待办清单（零依赖，单文件）"""
import argparse
import json
import os
import sys
from datetime import datetime

DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "todos.json")


def load():
    if not os.path.exists(DB):
        return {"next_id": 1, "items": []}
    with open(DB, "r", encoding="utf-8") as f:
        return json.load(f)


def save(db):
    tmp = DB + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(db, f, ensure_ascii=False, indent=2)
    os.replace(tmp, DB)


def find(db, tid):
    for it in db["items"]:
        if it["id"] == tid:
            return it
    return None


def cmd_add(args):
    db = load()
    item = {
        "id": db["next_id"],
        "text": args.text,
        "done": False,
        "priority": args.priority,
        "created": datetime.now().isoformat(timespec="seconds"),
        "done_at": None,
    }
    db["items"].append(item)
    db["next_id"] += 1
    save(db)
    print(f"已添加 #{item['id']} [{item['priority']}] {item['text']}")


def cmd_list(args):
    db = load()
    items = db["items"]
    if args.pending:
        items = [i for i in items if not i["done"]]
    if args.done:
        items = [i for i in items if i["done"]]
    if args.tag:
        items = [i for i in items if i["priority"] == args.tag]
    if not items:
        print("（空）")
        return
    order = {"high": 0, "mid": 1, "low": 2}
    items = sorted(items, key=lambda i: (i["done"], order.get(i["priority"], 9), i["id"]))
    for it in items:
        mark = "x" if it["done"] else " "
        print(f"[{mark}] #{it['id']:<3} ({it['priority']:<4}) {it['text']}")
    total = len(db["items"])
    done = sum(1 for i in db["items"] if i["done"])
    print(f"\n-- {done}/{total} 已完成")


def cmd_done(args):
    db = load()
    it = find(db, args.id)
    if not it:
        sys.exit(f"没有 #{args.id}")
    it["done"] = True
    it["done_at"] = datetime.now().isoformat(timespec="seconds")
    save(db)
    print(f"完成 #{it['id']} {it['text']}")


def cmd_undo(args):
    db = load()
    it = find(db, args.id)
    if not it:
        sys.exit(f"没有 #{args.id}")
    it["done"] = False
    it["done_at"] = None
    save(db)
    print(f"恢复 #{it['id']} {it['text']}")


def cmd_rm(args):
    db = load()
    before = len(db["items"])
    db["items"] = [i for i in db["items"] if i["id"] != args.id]
    if len(db["items"]) == before:
        sys.exit(f"没有 #{args.id}")
    save(db)
    print(f"删除 #{args.id}")


def cmd_clear(args):
    db = load()
    n = sum(1 for i in db["items"] if i["done"])
    if not args.yes:
        ans = input(f"删除 {n} 条已完成？[y/N] ").strip().lower()
        if ans != "y":
            print("取消")
            return
    db["items"] = [i for i in db["items"] if not i["done"]]
    save(db)
    print(f"已清理 {n} 条")


def cmd_edit(args):
    db = load()
    it = find(db, args.id)
    if not it:
        sys.exit(f"没有 #{args.id}")
    if args.text:
        it["text"] = args.text
    if args.priority:
        it["priority"] = args.priority
    save(db)
    print(f"已更新 #{it['id']} [{it['priority']}] {it['text']}")


def build_parser():
    p = argparse.ArgumentParser(prog="todo", description="命令行待办清单")
    sub = p.add_subparsers(dest="cmd", required=True)

    a = sub.add_parser("add", help="添加任务")
    a.add_argument("text")
    a.add_argument("-p", "--priority", choices=["high", "mid", "low"], default="mid")
    a.set_defaults(func=cmd_add)

    l = sub.add_parser("list", help="列出任务")
    l.add_argument("--pending", action="store_true", help="只看未完成")
    l.add_argument("--done", action="store_true", help="只看已完成")
    l.add_argument("--tag", choices=["high", "mid", "low"], help="按优先级过滤")
    l.set_defaults(func=cmd_list)

    d = sub.add_parser("done", help="标记完成")
    d.add_argument("id", type=int)
    d.set_defaults(func=cmd_done)

    u = sub.add_parser("undo", help="取消完成")
    u.add_argument("id", type=int)
    u.set_defaults(func=cmd_undo)

    r = sub.add_parser("rm", help="删除任务")
    r.add_argument("id", type=int)
    r.set_defaults(func=cmd_rm)

    e = sub.add_parser("edit", help="修改任务")
    e.add_argument("id", type=int)
    e.add_argument("-t", "--text")
    e.add_argument("-p", "--priority", choices=["high", "mid", "low"])
    e.set_defaults(func=cmd_edit)

    c = sub.add_parser("clear", help="清理已完成")
    c.add_argument("-y", "--yes", action="store_true")
    c.set_defaults(func=cmd_clear)

    return p


def main():
    args = build_parser().parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
```

### 起跑命令

```bash
chmod +x todo.py
./todo.py add "写周报" -p high
./todo.py add "买牛奶"
./todo.py list
./todo.py done 1
./todo.py list --pending
./todo.py rm 2
./todo.py clear -y
```

### 自检方式

```bash
# 1. 空库
./todo