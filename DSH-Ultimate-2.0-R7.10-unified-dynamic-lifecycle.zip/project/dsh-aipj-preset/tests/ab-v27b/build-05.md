## 爬虫交付：`spider.py`

> 选型：Python 3.10+ · 依赖 `requests` + `beautifulsoup4` · 单文件 · 通用站点爬取（列表页→详情页→落盘 JSONL），含限速、重试、断点续采、robots 检查

### 目录与入口

```
spider/
├── spider.py          # 主程序（入口）
├── requirements.txt   # 依赖
└── out/               # 落盘目录（自动创建）
    ├── items.jsonl    # 采集结果（每行一条 JSON）
    └── state.json     # 断点状态（已完成的 URL 集合）
```

### requirements.txt

```
requests>=2.31
beautifulsoup4>=4.12
```

### spider.py

```python
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
通用爬虫：列表页 -> 详情页 -> JSONL 落盘
用法:
  python spider.py --start https://example.com/list --item-selector "a.item-link" --max-pages 5
  python spider.py --start https://example.com/list --resume
"""
import argparse
import json
import os
import re
import sys
import time
import hashlib
from urllib.parse import urljoin, urlparse
from urllib.robotparser import RobotFileParser

import requests
from bs4 import BeautifulSoup

OUT_DIR = "out"
ITEMS_FILE = os.path.join(OUT_DIR, "items.jsonl")
STATE_FILE = os.path.join(OUT_DIR, "state.json")

DEFAULT_HEADERS = {
    "User-Agent": "Mozilla/5.0 (compatible; Spider/1.0; +https://example.com/bot)",
    "Accept": "text/html,application/xhtml+xml",
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
}


class Spider:
    def __init__(self, args):
        self.args = args
        self.session = requests.Session()
        self.session.headers.update(DEFAULT_HEADERS)
        if args.cookie:
            self.session.headers["Cookie"] = args.cookie
        self.done = self._load_state()
        self.robots = self._load_robots(args.start)
        os.makedirs(OUT_DIR, exist_ok=True)

    # ---------- 状态 ----------
    def _load_state(self):
        if self.args.resume and os.path.exists(STATE_FILE):
            with open(STATE_FILE, "r", encoding="utf-8") as f:
                return set(json.load(f))
        return set()

    def _save_state(self):
        with open(STATE_FILE, "w", encoding="utf-8") as f:
            json.dump(sorted(self.done), f, ensure_ascii=False)

    # ---------- robots ----------
    def _load_robots(self, url):
        if self.args.ignore_robots:
            return None
        try:
            p = urlparse(url)
            rp = RobotFileParser()
            rp.set_url(f"{p.scheme}://{p.netloc}/robots.txt")
            rp.read()
            return rp
        except Exception:
            return None

    def allowed(self, url):
        if self.robots is None:
            return True
        return self.robots.can_fetch(DEFAULT_HEADERS["User-Agent"], url)

    # ---------- 抓取 ----------
    def fetch(self, url):
        for attempt in range(1, self.args.retries + 1):
            try:
                r = self.session.get(url, timeout=self.args.timeout)
                r.raise_for_status()
                r.encoding = r.apparent_encoding or r.encoding
                return r.text
            except Exception as e:
                print(f"[retry {attempt}/{self.args.retries}] {url} -> {e}", file=sys.stderr)
                time.sleep(self.args.delay * attempt)
        return None

    # ---------- 列表页 ----------
    def parse_list(self, html, base_url):
        soup = BeautifulSoup(html, "html.parser")
        links = []
        for a in soup.select(self.args.item_selector):
            href = a.get("href")
            if not href:
                continue
            full = urljoin(base_url, href)
            if full not in links:
                links.append(full)
        # 下一页
        next_url = None
        if self.args.next_selector:
            nxt = soup.select_one(self.args.next_selector)
            if nxt and nxt.get("href"):
                next_url = urljoin(base_url, nxt["href"])
        return links, next_url

    # ---------- 详情页 ----------
    def parse_detail(self, html, url):
        soup = BeautifulSoup(html, "html.parser")
        title = soup.title.get_text(strip=True) if soup.title else ""
        # 正文：优先 article，其次 body 文本
        body_node = soup.select_one("article") or soup.body or soup
        text = re.sub(r"\n{2,}", "\n", body_node.get_text("\n", strip=True))
        return {
            "url": url,
            "title": title,
            "text": text[: self.args.max_text_len],
            "fetched_at": int(time.time()),
            "hash": hashlib.md5(text.encode("utf-8")).hexdigest()[:12],
        }

    # ---------- 主流程 ----------
    def run(self):
        url = self.args.start
        page = 0
        while url and page < self.args.max_pages:
            page += 1
            print(f"[list {page}] {url}")
            if not self.allowed(url):
                print(f"[robots] disallow: {url}", file=sys.stderr)
                break
            html = self.fetch(url)
            if not html:
                break
            links, next_url = self.parse_list(html, url)
            print(f"  found {len(links)} items")

            for link in links:
                if link in self.done:
                    continue
                if not self.allowed(link):
                    continue
                time.sleep(self.args.delay)
                dhtml = self.fetch(link)
                if not dhtml:
                    continue
                item = self.parse_detail(dhtml, link)
                self._write(item)
                self.done.add(link)
                self._save_state()
                print(f"  + {item['title'][:40]}")

            url = next_url
            time.sleep(self.args.delay)

    def _write(self, item):
        with open(ITEMS_FILE, "a", encoding="utf-8") as f:
            f.write(json.dumps(item, ensure_ascii=False) + "\n")


def main():
    ap = argparse.ArgumentParser(description="通用爬虫")
    ap.add_argument("--start", required=True, help="起始列表页 URL")
    ap.add_argument("--item-selector", default="a", help="列表页中详情链接的 CSS 选择器")
    ap.add_argument("--next-selector", default=None, help="下一页链接的 CSS 选择器")
    ap.add_argument("--max-pages", type=int, default=10, help="最多翻页