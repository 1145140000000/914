## 用户表测试数据（SQL）

> 选型：MySQL 8.0 语法 · 单文件 · 50 行用户记录 · 含建表 + 插入 + 校验查询

```sql
-- ============================================================
-- 用户表测试数据
-- 表名: users
-- 生成: 50 条，覆盖正常/边界/异常三类
-- ============================================================

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `username`    VARCHAR(32)     NOT NULL,
  `email`       VARCHAR(128)    NOT NULL,
  `phone`       VARCHAR(20)     DEFAULT NULL,
  `password_hash` CHAR(60)      NOT NULL,
  `nickname`    VARCHAR(64)     DEFAULT NULL,
  `avatar_url`  VARCHAR(255)    DEFAULT NULL,
  `status`      TINYINT         NOT NULL DEFAULT 1 COMMENT '0=禁用 1=正常 2=待验证 3=锁定',
  `role`        VARCHAR(16)     NOT NULL DEFAULT 'user' COMMENT 'user/admin/editor/guest',
  `balance`     DECIMAL(12,2)   NOT NULL DEFAULT 0.00,
  `login_count` INT UNSIGNED    NOT NULL DEFAULT 0,
  `last_login_at` DATETIME      DEFAULT NULL,
  `created_at`  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`),
  UNIQUE KEY `uk_email` (`email`),
  KEY `idx_status` (`status`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- 数据：50 条
-- 密码统一为 bcrypt("Test@123456") 的占位哈希
-- ------------------------------------------------------------
INSERT INTO `users`
(`username`,`email`,`phone`,`password_hash`,`nickname`,`avatar_url`,`status`,`role`,`balance`,`login_count`,`last_login_at`,`created_at`) VALUES
-- 正常用户 30 条
('alice',      'alice@example.com',      '13800000001', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj4J/HS.iK2.', '爱丽丝',   'https://cdn.example.com/a/1.png', 1, 'user',   100.00,  42,  '2024-05-01 09:12:33', '2023-01-05 10:00:00'),
('bob',        'bob@example.com',        '13800000002', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj4J/HS.iK2.', '鲍勃',     'https://cdn.example.com/a/2.png', 1, 'user',   250.50,  18,  '2024-05-02 14:20:11', '2023-01-06 11:30:00'),
('carol',      'carol@example.com',      '13800000003', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj4J/HS.iK2.', '卡罗尔',   NULL,                              1, 'editor', 0.00,    7,   '2024-04-28 08:00:00', '2023-01-07 09:15:00'),
('dave',       'dave@example.com',       '13800000004', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj4J/HS.iK2.', '戴夫',     'https://cdn.example.com/a/4.png', 1, 'user',   88.88,   3,   '2024-03-15 19:45:00', '2023-01-08 16:40:00'),
('eve',        'eve@example.com',        '13800000005', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj4J/HS.iK2.', '伊芙',     NULL,                              0, 'user',   0.00,    0,   NULL,                  '2023-01-09 12:00:00'),
('frank',      'frank@example.com',      '13800000006', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj4J/HS.iK2.', '弗兰克',   'https://cdn.example.com/a/6.png', 1, 'user',   1024.00, 99,  '2024-05-03 07:30:00', '2023-01-10 08:20:00'),
('grace',      'grace@example.com',      '13800000007', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj4J/HS.iK2.', '格蕾丝',   NULL,                              2, 'user',   0.00,    1,   '2024-01-11 10:00:00', '2023-01-11 10:00:00'),
('heidi',      'heidi@example.com',      '13800000008', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj4J/HS.iK2.', '海蒂',     'https://cdn.example.com/a/8.png', 1, 'user',   56.70,   12,  '2024-04-20 21:10:00', '2023-01-12 14:25:00'),
('ivan',       'ivan@example.com',       '13800000009', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj4J/HS.iK2.', '伊万',     NULL,                              3, 'user',   0.00,    5,   '2023-12-01 00:00:00', '2023-01-13 09:00:00'),
('judy',       'judy@example.com',      