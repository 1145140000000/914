## TCP 端口转发服务

> 选型：Go 1.21 · 标准库零依赖 · 单文件 · 支持多组转发规则 + 连接数限制 + 优雅退出

### 目录与入口

```
tcpproxy/
├── go.mod
└── main.go
```

### go.mod

```go
module tcpproxy

go 1.21
```

### main.go

```go
package main

import (
	"context"
	"flag"
	"fmt"
	"io"
	"log"
	"net"
	"os"
	"os/signal"
	"strings"
	"sync"
	"sync/atomic"
	"syscall"
	"time"
)

// Rule 一条转发规则：本地监听 -> 远端目标
type Rule struct {
	Listen string // 例: 0.0.0.0:8080
	Target string // 例: 127.0.0.1:80
}

// ruleList 实现 flag.Value，支持 -L 多次指定
type ruleList []Rule

func (r *ruleList) String() string { return fmt.Sprintf("%v", []Rule(*r)) }

func (r *ruleList) Set(v string) error {
	parts := strings.SplitN(v, "=", 2)
	if len(parts) != 2 || parts[0] == "" || parts[1] == "" {
		return fmt.Errorf("规则格式应为 listen=target，收到: %q", v)
	}
	*r = append(*r, Rule{Listen: parts[0], Target: parts[1]})
	return nil
}

type Proxy struct {
	rule     Rule
	ln       net.Listener
	maxConn  int64
	active   int64
	timeout  time.Duration
	wg       sync.WaitGroup
	shutdown atomic.Bool
}

func NewProxy(rule Rule, maxConn int64, timeout time.Duration) *Proxy {
	return &Proxy{rule: rule, maxConn: maxConn, timeout: timeout}
}

func (p *Proxy) Start(ctx context.Context) error {
	ln, err := net.Listen("tcp", p.rule.Listen)
	if err != nil {
		return fmt.Errorf("监听 %s 失败: %w", p.rule.Listen, err)
	}
	p.ln = ln
	log.Printf("[%s] 监听中 -> %s", p.rule.Listen, p.rule.Target)

	p.wg.Add(1)
	go func() {
		defer p.wg.Done()
		<-ctx.Done()
		p.shutdown.Store(true)
		_ = p.ln.Close()
	}()

	for {
		conn, err := ln.Accept()
		if err != nil {
			if p.shutdown.Load() {
				return nil
			}
			// 临时错误（如 fd 耗尽）退避重试
			if ne, ok := err.(net.Error); ok && ne.Temporary() {
				log.Printf("[%s] Accept 临时错误: %v，100ms 后重试", p.rule.Listen, err)
				time.Sleep(100 * time.Millisecond)
				continue
			}
			return fmt.Errorf("[%s] Accept 失败: %w", p.rule.Listen, err)
		}

		if p.maxConn > 0 && atomic.LoadInt64(&p.active) >= p.maxConn {
			log.Printf("[%s] 连接数达上限 %d，拒绝 %s", p.rule.Listen, p.maxConn, conn.RemoteAddr())
			_ = conn.Close()
			continue
		}

		atomic.AddInt64(&p.active, 1)
		p.wg.Add(1)
		go func(c net.Conn) {
			defer p.wg.Done()
			defer atomic.AddInt64(&p.active, -1)
			p.handle(c)
		}(conn)
	}
}

func (p *Proxy) handle(client net.Conn) {
	defer client.Close()

	upstream, err := net.DialTimeout("tcp", p.rule.Target, p.timeout)
	if err != nil {
		log.Printf("[%s] 连接上游 %s 失败: %v", p.rule.Listen, p.rule.Target, err)
		return
	}
	defer upstream.Close()

	log.Printf("[%s] %s <-> %s 建立", p.rule.Listen, client.RemoteAddr(), p.rule.Target)

	var once sync.Once
	closeBoth := func() {
		once.Do(func() {
			_ = client.Close()
			_ = upstream.Close()
		})
	}

	// 双向拷贝，任一方向结束即关闭两端
	done := make(chan struct{}, 2)
	go func() { _, _ = io.Copy(upstream, client); done <- struct{}{} }()
	go func() { _, _ = io.Copy(client, upstream); done <- struct{}{} }()
	<-done
	closeBoth()
	<-done

	log.Printf("[%s] %s <-> %s 关闭", p.rule.Listen, client.RemoteAddr(), p.rule.Target)
}

func (p *Proxy) Wait() { p.wg.Wait() }

func main() {
	var rules ruleList
	flag.Var(&rules, "L", "转发规则 listen=target，可多次指定，例: -L 0.0.0.0:8080=127.0.0.1:80")
	maxConn := flag.Int64("max-conn", 0, "单规则最大并发连接数，0 表示不限")
	timeout := flag.Duration("dial-timeout", 5*time.Second, "连接上游超时")
	flag.Parse()

	if len(rules) == 0 {
		fmt.Fprintln(os.Stderr, "至少需要一条 -L 规则")
		flag.Usage()
		os.Exit(2)
	}

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)
	go func() {
		s := <-sigCh
		log.Printf("收到信号 %v，开始优雅退出", s)
		cancel()
	}()

	var proxies []*Proxy
	errCh := make(chan error, len(rules))
	for _, r := range rules {
		p := NewProxy(r, *maxConn, *timeout)
		proxies = append(proxies, p)
		go func(px *Proxy) {
			if err := px.Start(ctx); err != nil {
				errCh <- err
				cancel()
			}
		}(p)
	}

	select {
	case err := <-errCh:
		log.Printf("转发服务异常: %v", err)
	case <-ctx.Done():
	}

	for _, p := range proxies {
		p.Wait()
	}
	log.Println("全部转发已停止")
}
```

### 起跑命令

```bash
cd tcpproxy
go mod tidy
go build -o tcpproxy .

# 单条规则：本地 8080 -> 127.0.0.1:80
./tcpproxy -L 0.0.0.0