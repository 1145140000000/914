## `quicksort.py`

> 选型：Python 3.8+ · 零依赖 · 单文件 · 含原地快排 + 三路分区 + 自检

```python
#!/usr/bin/env python3
"""快速排序：原地双指针分区 + 三路分区（重复元素多时更快）。"""

from typing import List, MutableSequence, TypeVar

T = TypeVar("T")


def quicksort(a: MutableSequence[T]) -> MutableSequence[T]:
    """原地快排，返回同一对象（便于链式调用）。"""
    _qs(a, 0, len(a) - 1)
    return a


def _qs(a: MutableSequence[T], lo: int, hi: int) -> None:
    while lo < hi:
        # 小数组用插入排序，减少递归开销
        if hi - lo < 16:
            _insertion(a, lo, hi)
            return
        mid = _partition(a, lo, hi)
        # 先递归较短的一侧，栈深度 O(log n)
        if mid - lo < hi - mid:
            _qs(a, lo, mid - 1)
            lo = mid + 1
        else:
            _qs(a, mid + 1, hi)
            hi = mid - 1


def _partition(a: MutableSequence[T], lo: int, hi: int) -> int:
    """Lomuto 分区，三数取中选枢轴，枢轴先换到 hi。"""
    mid = (lo + hi) >> 1
    # 三数取中：把中位数换到 hi 位置
    if a[mid] < a[lo]:
        a[mid], a[lo] = a[lo], a[mid]
    if a[hi] < a[lo]:
        a[hi], a[lo] = a[lo], a[hi]
    if a[hi] < a[mid]:
        a[hi], a[mid] = a[mid], a[hi]
    a[mid], a[hi] = a[hi], a[mid]

    pivot = a[hi]
    i = lo - 1
    for j in range(lo, hi):
        if a[j] <= pivot:
            i += 1
            a[i], a[j] = a[j], a[i]
    a[i + 1], a[hi] = a[hi], a[i + 1]
    return i + 1


def _insertion(a: MutableSequence[T], lo: int, hi: int) -> None:
    for i in range(lo + 1, hi + 1):
        key = a[i]
        j = i - 1
        while j >= lo and a[j] > key:
            a[j + 1] = a[j]
            j -= 1
        a[j + 1] = key


def quicksort_3way(a: MutableSequence[T]) -> MutableSequence[T]:
    """三路分区版本：大量重复元素时退化为 O(n)。"""
    _qs3(a, 0, len(a) - 1)
    return a


def _qs3(a: MutableSequence[T], lo: int, hi: int) -> None:
    if lo >= hi:
        return
    lt, gt = lo, hi
    pivot = a[(lo + hi) >> 1]
    i = lo
    while i <= gt:
        if a[i] < pivot:
            a[lt], a[i] = a[i], a[lt]
            lt += 1
            i += 1
        elif a[i] > pivot:
            a[gt], a[i] = a[i], a[gt]
            gt -= 1
        else:
            i += 1
    _qs3(a, lo, lt - 1)
    _qs3(a, gt + 1, hi)


def _self_test() -> None:
    import random

    cases: List[List[int]] = [
        [],
        [1],
        [2, 1],
        [3, 3, 3, 3],
        [5, 4, 3, 2, 1],
        [1, 2, 3, 4, 5],
        [0, -1, 5, -10, 3, 3, 2],
    ]
    for c in cases:
        for fn in (quicksort, quicksort_3way):
            got = fn(list(c))
            assert got == sorted(c), f"{fn.__name__} 失败: {c} -> {got}"

    for _ in range(200):
        n = random.randint(0, 300)
        data = [random.randint(-50, 50) for _ in range(n)]
        assert quicksort(list(data)) == sorted(data)
        assert quicksort_3way(list(data)) == sorted(data)

    big = [random.random() for _ in range(100_000)]
    assert quicksort(list(big)) == sorted(big)
    print("all tests passed")


if __name__ == "__main__":
    _self_test()
    print(quicksort([3, 1, 4, 1, 5, 9, 2, 6]))
```

起跑：

```bash
python3 quicksort.py
```

自检回显：

```
$ python3 quicksort.py
all tests passed
[1, 1, 2, 3, 4, 5, 6, 9]
```

要点：`_qs` 用 while 循环 + 先递归短侧，最坏栈深 O(log n)；`hi-lo<16` 切插入排序；`_partition` 三数取中避免有序输入退化；`quicksort_3way` 处理大量重复值。