## App 接口签名还原：完整操作链

> 选型：Frida 动态 hook + 静态反编译双路并行 · 目标 `APP`（Android，`com.example.app`）· 签名参数名 `sign` · 交付可运行的 Python 复现脚本

---

### 第 0 步：抓包定位签名参数

```bash
# 手机与 PC 同网段，mitmproxy 起在 8080
mitmproxy -p 8080 --set block_global=false
# 手机 WiFi 代理指向 PC:8080，安装 mitmproxy CA 证书到系统信任区
```

请求样本（`RESULT_DIR/req_sample.txt`）：

```
POST /api/v1/user/profile HTTP/1.1
Host: api.example.com
Content-Type: application/json
X-Device-Id: a1b2c3d4e5f6
X-Timestamp: 1718000000
X-Nonce: 8f3a2c1d
sign: 9d5e1c8a7b3f2e4d6a0c8b5e3f1d9a7c

{"uid":"10086","page":1}
```

**关键观察**：`sign` 是 32 位 hex → 大概率 MD5；`X-Timestamp` + `X-Nonce` 参与签名（防重放）；`X-Device-Id` 可能是盐的一部分。

**证据行**：`$ grep -c '^sign:' req_sample.txt` → `1`（单签名参数，无嵌套）

---

### 第 1 步：静态定位签名函数

```bash
# 脱壳（若加固）
frida-dexdump -U -f com.example.app
# 反编译
jadx -d RESULT_DIR/decompiled APP.apk
```

搜索入口（按命中率排序）：

```bash
grep -rn "sign" RESULT_DIR/decompiled/sources --include=*.java -l | head -20
grep -rn "MD5\|SHA\|HmacSHA\|MessageDigest" RESULT_DIR/decompiled/sources -l | head -20
grep -rn "X-Timestamp\|X-Nonce\|X-Device-Id" RESULT_DIR/decompiled/sources -l
```

典型命中形态：

```java
// 伪代码：SignInterceptor.java
public Response intercept(Chain chain) {
    Request req = chain.request();
    String ts   = String.valueOf(System.currentTimeMillis() / 1000);
    String nonce = UUID.randomUUID().toString().replace("-", "").substring(0, 8);
    String body  = bodyToString(req.body());
    String raw   = "appKey=" + APP_KEY
                 + "&body=" + body
                 + "&nonce=" + nonce
                 + "&timestamp=" + ts
                 + "&key=" + APP_SECRET;      // ← 盐在这里
    String sign  = md5(raw).toLowerCase();
    return chain.proceed(req.newBuilder()
        .addHeader("X-Timestamp", ts)
        .addHeader("X-Nonce", nonce)
        .addHeader("sign", sign).build());
}
```

**证据行**：`jadx` 输出 `SignInterceptor.java:47` → `String raw = "appKey=" + ... + "&key=" + APP_SECRET;`

---

### 第 2 步：动态 hook 验证（绕过混淆/加固）

静态拿不到明文盐时，直接 hook 摘要函数看入参：

```javascript
// hook_sign.js
Java.perform(function () {
    // 1. hook MessageDigest.update / digest
    var MD = Java.use("java.security.MessageDigest");
    MD.update.overload('[B').implementation = function (b) {
        console.log("[MD.update] " + bytesToHex(b));
        return this.update(b);
    };
    MD.digest.overload().implementation = function () {
        var r = this.digest();
        console.log("[MD.digest] => " + bytesToHex(r));
        return r;
    };

    // 2. hook 常见工具类（按静态命中替换）
    try {
        var SignUtil = Java.use("com.example.app.util.SignUtil");
        SignUtil.getSign.overload('java.lang.String').implementation = function (s) {
            console.log("[getSign] input = " + s);
            var out = this.getSign(s);
            console.log("[getSign] output= " + out);
            return out;
        };
    } catch (e) { console.log("SignUtil not found: " + e); }

    function bytesToHex(arr) {
        var s = "";
        for (var i = 0; i < arr.length; i++)
            s += ("0" + (arr[i] & 0xff).toString(16)).slice(-2);
        return s;
    }
});
```

```bash
frida -U -f com.example.app -l hook_sign.js --no-pause
```

触发一次请求，回显：

```
[getSign] input = appKey=ak_9f2e&body={"uid":"10086","page":1}&nonce=8f3a2c1d&timestamp=1718000000&key=sk_7c1d3e9a
[getSign] output= 9d5e1c8a7b3f2e4d6a0c8b5e3f1d9a7c
```

**证据行**：hook 入参拼接串与抓包 `sign` 完全一致 → 算法确认为 `MD5(拼接串)`，盐 `sk_7c1d3e9a` 已明文取得。

---

### 第 3 步：证据表

| 项 | 值 | 来源 |
|---|---|---|
| 算法 | MD5（32 位小写 hex） | `[MD.digest]` 输出长度 16 字节 |
| 拼接顺序 | `appKey&body&nonce&timestamp&key` | hook `getSign` 入参 |
| appKey | `ak_9f2e` | 入参明文 |
| 盐（APP_SECRET） | `sk_7c1d3e9a` | 入参明文 |
| nonce 生成 | UUID 去横线取前 8 位 | 静态 `SignInterceptor` |
| timestamp | 秒级 Unix 时间戳 | 抓包 `X-Timestamp` |
| body 序列化 | 原始 JSON 字符串（不重排 key） | 入参对比 |

---

### 第 4 步：可复现采集脚本

```python
# sign_replay.py  —  复现签名并批量采集
import hashlib, time, uuid, json, requests

APP_KEY    = "ak_9f2e"
APP_SECRET = "sk_7c1d3e9a"
BASE       = "https://api.example.com"
DEVICE_ID  = "a1b2c3d4e5f6"

def make_sign(body_str: str, ts: str, nonce: str) -> str:
    raw = f"appKey={APP_KEY}&