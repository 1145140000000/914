## 断点续采：不重不漏的完整实现

> 选型：Python 3.10 · 零第三方依赖（仅标准库）· 单文件 · SQLite 做状态库 · 支持并发 + 断点续采 + 去重

### 核心思路（三句话）

1. **先枚举后抓取**：把「待采 ID 全集」先落库，抓取阶段只消费队列——断在哪一步都能从库里接着走。
2. **状态机三态**：`pending / done / failed`，每采完一条立刻 `UPDATE ... done` 并提交事务，进程被杀也不丢进度。
3. **去重靠主键**：`id` 做 `PRIMARY KEY`，重复入队 `INSERT OR IGNORE`，天然不重。

### 目录与入口

```
crawler/
├── resume_crawler.py     # 主程序（单文件）
└── state.db              # 运行后自动生成（SQLite 状态库）
```

### 完整实现

```python
#!/usr/bin/env python3
# resume_crawler.py —— 断点续采爬虫骨架
# 用法:
#   python resume_crawler.py seed          # 阶段1: 枚举待采 ID 入队
#   python resume_crawler.py run           # 阶段2: 消费队列(可反复中断/重启)
#   python resume_crawler.py status        # 查看进度
#   python resume_crawler.py retry         # 把 failed 重置为 pending 再跑

import sqlite3
import sys
import time
import json
import hashlib
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

DB = Path(__file__).parent / "state.db"
OUT_DIR = Path(__file__).parent / "data"
OUT_DIR.mkdir(exist_ok=True)

# ---------------- 配置区（按目标改这里） ----------------
BASE_URL = "http://TARGET/api/item/{id}"   # 占位: 目标接口
TOTAL_IDS = range(1, 10001)                # 占位: 待采 ID 全集
CONCURRENCY = 8                            # 并发数
TIMEOUT = 10
MAX_RETRY = 3
# ------------------------------------------------------

def get_conn():
    # check_same_thread=False 允许跨线程；WAL 提升并发写
    conn = sqlite3.connect(DB, timeout=30, check_same_thread=False)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    return conn

def init_db():
    conn = get_conn()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS tasks (
            id        TEXT PRIMARY KEY,      -- 去重主键
            status    TEXT NOT NULL DEFAULT 'pending',  -- pending/done/failed
            retry     INTEGER NOT NULL DEFAULT 0,
            payload   TEXT,                  -- 抓到的原始数据
            err       TEXT,
            updated   REAL
        )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_status ON tasks(status)")
    conn.commit()
    return conn

# ---------------- 阶段1: 枚举入队 ----------------
def seed():
    conn = init_db()
    now = time.time()
    rows = [(str(i), "pending", 0, now) for i in TOTAL_IDS]
    conn.executemany(
        "INSERT OR IGNORE INTO tasks(id,status,retry,updated) VALUES(?,?,?,?)",
        rows,
    )
    conn.commit()
    n = conn.execute("SELECT COUNT(*) FROM tasks").fetchone()[0]
    print(f"[seed] 队列总数 = {n}")

# ---------------- 阶段2: 消费队列 ----------------
def fetch_one(item_id):
    """真实抓取逻辑: 换成你的 requests / urllib 调用"""
    import urllib.request
    url = BASE_URL.format(id=item_id)
    req = urllib.request.Request(url, headers={"User-Agent": "resume-crawler/1.0"})
    with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
        body = resp.read().decode("utf-8", "replace")
    return body

def worker(item_id, conn, lock):
    try:
        body = fetch_one(item_id)
        digest = hashlib.md5(body.encode()).hexdigest()[:12]
        # 落盘: 每条单独文件, 文件名带 id, 天然不覆盖
        (OUT_DIR / f"{item_id}.json").write_text(body, encoding="utf-8")
        with lock:
            conn.execute(
                "UPDATE tasks SET status='done', payload=?, err=NULL, updated=? WHERE id=?",
                (digest, time.time(), item_id),
            )
            conn.commit()
        return item_id, True, None
    except Exception as e:
        with lock:
            conn.execute(
                "UPDATE tasks SET status='failed', retry=retry+1, err=?, updated=? WHERE id=?",
                (str(e)[:200], time.time(), item_id),
            )
            conn.commit()
        return item_id, False, str(e)

def run():
    conn = init_db()
    lock = threading.Lock()
    # 只取 pending 且未超重试上限的
    pending = [r[0] for r in conn.execute(
        "SELECT id FROM tasks WHERE status='pending' AND retry < ? ORDER BY id",
        (MAX_RETRY,),
    ).fetchall()]
    print(f"[run] 待采 {len(pending)} 条, 并发 {CONCURRENCY}")
    if not pending:
        print("[run] 无待采任务, 退出")
        return

    ok = fail = 0
    with ThreadPoolExecutor(max_workers=CONCURRENCY) as pool:
        futures = {pool.submit(worker, pid, conn, lock): pid for pid in pending}
        try:
            for fut in as_completed(futures):
                pid, success, err = fut.result()
                if success:
                    ok += 1
                else:
                    fail += 1
                    print(f"  [fail] {pid}: {err}")
                if (ok + fail) % 100 == 0:
                    print(f"  进度 {ok+fail}/{len(pending)}  ok={ok} fail={fail}")
        except KeyboardInterrupt:
            print("\n[run] 收到中断, 已完成的进度已落库, 下次 run 自动续采")
            pool.shutdown(wait=False, cancel_futures=True)
            raise
    print(f"[run] 本轮完成 ok={ok} fail={fail}")

# ---------------- 辅助 ----------------
def status():
    conn = init_db()
    rows = conn.execute(
        "SELECT status, COUNT(*) FROM tasks GROUP BY status"
    ).fetchall()
    total = sum(c for _, c in rows)
    print(f"[status] 总数 {total}")
    for s, c in rows:
        print(f"  {s:8s}: {c}")

def retry():
    conn = init_db()
    conn.execute("UPDATE tasks SET status='pending',