## 限速处理：分层降速与并发调度

> 选型：Python 3.10 · 零第三方依赖（仅标准库）· 单文件 · 自适应令牌桶 + 退避重试 + 断点续采

限速（429 / 503 / `Retry-After` / 响应变慢 / 返回空壳页）不是"绕过"问题，是**调度问题**。核心三件事：**把速率压到对方阈值以下**、**被限时按信号退避而不是硬撞**、**中断后能续采不重头**。

### 一、先判定限速类型（决定用哪套策略）

| 信号 | 类型 | 处理 |
| --- | --- | --- |
| HTTP 429 + `Retry-After: N` | 显式限速 | 严格睡 N 秒，再按指数退避 |
| HTTP 503 / 403 突增 | 软限速 | 并发减半 + 加随机抖动 |
| 200 但内容为空 / 验证码页 / 长度骤降 | 静默限速 | 响应体指纹检测，命中即降速 |
| 延迟从 100ms 涨到 2s+ | 队列拥塞 | 令牌桶速率下调 50% |
| 连接被 reset / 超时 | 连接层限速 | 降并发 + 复用连接 + 拉长超时 |

### 二、可运行采集器（自适应限速 + 断点续采）

```python
#!/usr/bin/env python3
# adaptive_crawler.py — 自适应限速采集器（标准库实现）
import json, os, random, time, threading, queue, hashlib
import urllib.request, urllib.error
from dataclasses import dataclass, field

STATE_FILE = "crawl_state.json"
OUT_FILE   = "crawl_out.jsonl"

@dataclass
class Bucket:
    """令牌桶：rate 每秒放行数，burst 突发容量"""
    rate: float = 2.0
    burst: float = 4.0
    tokens: float = field(default=0.0)
    last: float = field(default_factory=time.monotonic)
    lock: threading.Lock = field(default_factory=threading.Lock)

    def take(self, n=1.0):
        while True:
            with self.lock:
                now = time.monotonic()
                self.tokens = min(self.burst, self.tokens + (now - self.last) * self.rate)
                self.last = now
                if self.tokens >= n:
                    self.tokens -= n
                    return
                wait = (n - self.tokens) / self.rate
            time.sleep(wait)

    def slow_down(self, factor=0.5):
        with self.lock:
            self.rate = max(0.2, self.rate * factor)
            self.burst = max(1.0, self.burst * factor)

    def speed_up(self, factor=1.1, ceiling=10.0):
        with self.lock:
            self.rate = min(ceiling, self.rate * factor)

BUCKET = Bucket()
STATS = {"ok": 0, "limited": 0, "err": 0}
STATS_LOCK = threading.Lock()

def load_state():
    if os.path.exists(STATE_FILE):
        with open(STATE_FILE) as f:
            return json.load(f)
    return {"done": [], "cursor": 0}

def save_state(st):
    tmp = STATE_FILE + ".tmp"
    with open(tmp, "w") as f:
        json.dump(st, f)
    os.replace(tmp, STATE_FILE)   # 原子写，防中断损坏

def fetch(url, headers=None, timeout=15, retries=5):
    hdrs = {"User-Agent": "Mozilla/5.0 (compatible; Collector/1.0)"}
    if headers: hdrs.update(headers)
    backoff = 1.0
    for attempt in range(retries):
        BUCKET.take()
        req = urllib.request.Request(url, headers=hdrs)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                body = r.read()
                # 静默限速检测：空体 / 极短体 / 验证码关键词
                if len(body) < 200 or b"captcha" in body.lower() or b"rate limit" in body.lower():
                    raise urllib.error.HTTPError(url, 429, "silent-limit", r.headers, None)
                with STATS_LOCK: STATS["ok"] += 1
                BUCKET.speed_up()
                return body
        except urllib.error.HTTPError as e:
            if e.code in (429, 503):
                ra = e.headers.get("Retry-After") if e.headers else None
                wait = float(ra) if ra and ra.isdigit() else backoff
                wait += random.uniform(0, 0.5)          # 抖动，避免同步撞点
                with STATS_LOCK: STATS["limited"] += 1
                BUCKET.slow_down(0.5)
                print(f"[LIMIT] {e.code} sleep={wait:.1f}s rate={BUCKET.rate:.2f}/s")
                time.sleep(wait)
                backoff = min(backoff * 2, 60)
            elif e.code == 403:
                BUCKET.slow_down(0.3)
                time.sleep(backoff); backoff = min(backoff * 2, 60)
            else:
                with STATS_LOCK: STATS["err"] += 1
                time.sleep(backoff); backoff = min(backoff * 2, 30)
        except Exception as e:
            with STATS_LOCK: STATS["err"] += 1
            print(f"[ERR] {type(e).__name__}: {e}")
            time.sleep(backoff); backoff = min(backoff * 2, 30)
    return None

def worker(q, st, st_lock, out_lock):
    while True:
        try:
            idx, url = q.get_nowait()
        except queue.Empty:
            return
        body = fetch(url)
        if body is not None:
            rec = {"idx": idx, "url": url, "sha": hashlib.sha256(body).hexdigest()[:12], "len": len(body)}
            with out_lock:
                with open(OUT_FILE, "a") as f:
                    f.write(json.dumps(rec, ensure_ascii=False) + "\n")
            with st_lock:
                st["done"].append(idx)
                st["cursor"] = max(st["cursor"], idx + 1)
                if len(st["done"]) % 20 == 0:
                    save_state(st)
        q.task_done()

def run(urls, threads=4):
    st = load_state()
    done = set(st["done"])
    todo = [(i, u) for i, u in enumerate(urls) if i not in done]
    print(f"[START] total={len(urls)} done