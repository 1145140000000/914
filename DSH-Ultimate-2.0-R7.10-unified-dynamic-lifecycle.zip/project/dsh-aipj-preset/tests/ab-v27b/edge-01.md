## 目标枚举链

> 选型：`nmap` 服务识别 + `ffuf` 目录/接口枚举 + 全程落盘。目标以 `TARGET:PORT` 占位，替换为实际 IP 与端口即可直接跑。

### 0. 变量与落盘

```bash
export TARGET="10.0.0.10"        # 换成实际 IP
export PORT="8080"               # 换成实际端口
export RESULT_DIR="./recon_${TARGET}_${PORT}"
mkdir -p "$RESULT_DIR"
```

### 1. 端口与服务识别

```bash
# 先确认该端口存活并抓 banner
nmap -Pn -sV -p "$PORT" --version-all -oN "$RESULT_DIR/nmap_single.txt" "$TARGET"

# 若允许更大范围，补一轮常见端口
nmap -Pn -sV -sC -p 21,22,23,25,53,80,110,135,139,143,443,445,993,995,1433,1521,3306,3389,5432,5900,6379,7001,8000,8080,8081,8443,8888,9000,9090,9200,27017 \
  -oN "$RESULT_DIR/nmap_common.txt" "$TARGET"
```

预期回显关键行：

```
PORT     STATE SERVICE  VERSION
8080/tcp open  http     nginx 1.24.0
```

### 2. HTTP 指纹与响应头

```bash
curl -sS -i -m 10 "http://$TARGET:$PORT/" -o "$RESULT_DIR/root_http.txt"
head -n 40 "$RESULT_DIR/root_http.txt"

# 若为 HTTPS
curl -skS -i -m 10 "https://$TARGET:$PORT/" -o "$RESULT_DIR/root_https.txt"
```

关注 `Server:`、`X-Powered-By:`、`Set-Cookie:`、`Location:`。

### 3. 目录 / 接口枚举

```bash
# 通用字典
ffuf -u "http://$TARGET:$PORT/FUZZ" \
     -w /usr/share/wordlists/dirb/common.txt \
     -t 40 -mc 200,204,301,302,307,401,403,500 \
     -o "$RESULT_DIR/ffuf_dir.json" -of json

# 常见接口前缀
ffuf -u "http://$TARGET:$PORT/FUZZ" \
     -w /usr/share/seclists/Discovery/Web-Content/api/api-endpoints.txt \
     -t 40 -mc all -fc 404 \
     -o "$RESULT_DIR/ffuf_api.json" -of json
```

### 4. 从 JS 提取接口

```bash
# 抓首页引用的 js
grep -oE 'src="[^"]+\.js[^"]*"' "$RESULT_DIR/root_http.txt" | cut -d'"' -f2 | sort -u > "$RESULT_DIR/js_list.txt"

while read -r js; do
  case "$js" in http*) url="$js";; /*) url="http://$TARGET:$PORT$js";; *) url="http://$TARGET:$PORT/$js";; esac
  curl -sS -m 10 "$url" >> "$RESULT_DIR/all_js.js"
done < "$RESULT_DIR/js_list.txt"

grep -oE '"/[a-zA-Z0-9_./-]{2,}"' "$RESULT_DIR/all_js.js" | tr -d '"' | sort -u > "$RESULT_DIR/api_paths.txt"
wc -l "$RESULT_DIR/api_paths.txt"
```

### 5. 命中点验证

```bash
while read -r p; do
  code=$(curl -sS -o /dev/null -w '%{http_code}' -m 8 "http://$TARGET:$PORT$p")
  [ "$code" != "404" ] && echo "$code  $p"
done < "$RESULT_DIR/api_paths.txt" | tee "$RESULT_DIR/hits.txt"
```

### 6. 结果汇总

```bash
{
  echo "== nmap =="; grep -E '^[0-9]+/tcp' "$RESULT_DIR/nmap_single.txt"
  echo "== headers =="; head -n 20 "$RESULT_DIR/root_http.txt"
  echo "== hits =="; cat "$RESULT_DIR/hits.txt"
} | tee "$RESULT_DIR/summary.txt"
```

### 证据行

- `$ nmap -Pn -sV -p PORT TARGET` → `PORT/tcp open <service> <version>`（写入 `nmap_single.txt`）
- `$ curl -i http://TARGET:PORT/` → `HTTP/1.1 200` + `Server:` 头（写入 `root_http.txt`）
- `$ ffuf ... -mc 200,204,301,302,307,401,403,500` → 命中路径列表（写入 `ffuf_dir.json` / `hits.txt`）

### 下一步分支

| 指纹 | 后续动作 |
| --- | --- |
| `nginx` / `Apache` + 静态站 | 目录枚举加深，找备份/配置泄露（`.git/`、`.env`、`*.bak`） |
| `Tomcat` / `WebLogic` / `Spring` | 查管理台弱口令、`actuator` 端点、反序列化入口 |
| `php` / `X-Powered-By: PHP` | 参数点探测注入 / 文件包含 |
| `json` 接口为主 | 抓包看签名与鉴权头，转采集链 |
| 非 HTTP 服务（`redis`/`mysql`/`ssh`） | 对应服务指纹与默认口令/未授权访问验证 |

把 `TARGET` 和 `PORT` 换成实际值，从第 1 步开始跑；`summary.txt` 出来贴给我，我按指纹给下一段的具体命令。