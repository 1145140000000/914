## 构建与部署

```bash
# 1. 探测构建系统
ls -1
```

```bash
# 2. 按探测到的构建系统执行（示例：Node）
npm ci && npm run build
```

```bash
# 3. 启动
npm start
```

请把项目根目录的 `ls -1` 回显贴给我，或直接告诉我构建系统（`package.json` / `pyproject.toml` / `Cargo.toml` / `go.mod` / `Makefile` / `pom.xml` / `build.gradle` 中的哪一个），我立刻给出对应的完整构建命令、退出码与原始日志。