## 内存透视模块 · 整体结构

> 选型：C++17 · Win32 API（OpenProcess/ReadProcessMemory）· 单文件 + 头文件分离 · 外部进程读取（不注入）· 含实体表遍历 + WorldToScreen + 叠加层绘制

### 一、分层结构

```
overlay/
├── main.cpp              # 入口：找窗口 → 建叠加层 → 主循环
├── proc.h / proc.cpp     # 进程附着：PID 定位、句柄、模块基址
├── mem.h  / mem.cpp      # 读写原语：RPM/WPM 模板封装
├── offsets.h             # 偏移表（集中管理，便于版本更新）
├── entity.h/entity.cpp   # 实体结构体 + 实体表遍历
├── math.h                # 向量/矩阵 + WorldToScreen
├── render.h/render.cpp   # D3D11 叠加层：透明窗口 + 绘制
└── config.h              # 开关、颜色、热键
```

### 二、各层职责与关键点

**1. 进程附着层（proc）**
- `FindWindowA` 拿游戏窗口 → `GetWindowThreadProcessId` 得 PID
- `OpenProcess(PROCESS_VM_READ | PROCESS_VM_WRITE | PROCESS_QUERY_INFORMATION)`
- `GetModuleHandle` 走 `CreateToolhelp32Snapshot` 枚举模块拿 `client.dll` 基址
- 关键：句柄只开一次，全程复用；失败要区分"没找到窗口"和"权限不足"

**2. 内存原语层（mem）**
```cpp
template<typename T>
T Read(uintptr_t addr) {
    T buf{};
    ReadProcessMemory(hProc, (LPCVOID)addr, &buf, sizeof(T), nullptr);
    return buf;
}
template<typename T>
bool Write(uintptr_t addr, const T& val) {
    return WriteProcessMemory(hProc, (LPVOID)addr, &val, sizeof(T), nullptr);
}
```
- 所有读取走模板，避免到处写 `ReadProcessMemory`
- 加一层 `ReadChain(base, {off1, off2, off3})` 处理多级指针

**3. 偏移表（offsets）**
```cpp
namespace off {
    constexpr uintptr_t dwLocalPlayer   = 0xDEA964;   // 本地玩家指针
    constexpr uintptr_t dwEntityList    = 0x4DFFF14;  // 实体列表
    constexpr uintptr_t dwViewMatrix    = 0x4DFEFE4;  // 视图矩阵
    constexpr uintptr_t m_iHealth       = 0x100;      // 实体血量
    constexpr uintptr_t m_iTeamNum      = 0xF4;       // 阵营
    constexpr uintptr_t m_vecOrigin     = 0x138;      // 坐标
    constexpr uintptr_t m_vecViewOffset = 0x108;      // 视角偏移
}
```
- 偏移集中一处，游戏更新只改这个文件
- 每个偏移注释来源（`netvar` 名 / 反汇编定位）

**4. 实体层（entity）**
```cpp
struct Entity {
    uintptr_t addr;
    int   health;
    int   team;
    Vec3  origin;
    Vec3  head;
    bool  valid;
};

std::vector<Entity> GetEntities(uintptr_t clientBase, uintptr_t localPlayer) {
    std::vector<Entity> out;
    uintptr_t list = Read<uintptr_t>(clientBase + off::dwEntityList);
    for (int i = 1; i <= 64; ++i) {
        uintptr_t e = Read<uintptr_t>(list + i * 0x10);
        if (!e) continue;
        Entity ent{};
        ent.addr   = e;
        ent.health = Read<int>(e + off::m_iHealth);
        ent.team   = Read<int>(e + off::m_iTeamNum);
        ent.origin = Read<Vec3>(e + off::m_vecOrigin);
        ent.head   = ent.origin + Read<Vec3>(e + off::m_vecViewOffset);
        ent.valid  = ent.health > 0 && ent.health <= 100;
        if (ent.valid) out.push_back(ent);
    }
    return out;
}
```

**5. 数学层（math）**
```cpp
struct Vec3 { float x, y, z; };
struct Vec2 { float x, y; };

bool WorldToScreen(const Vec3& world, Vec2& screen,
                   const float matrix[16], int w, int h) {
    float clipX = world.x * matrix[0] + world.y * matrix[1]
                + world.z * matrix[2]  + matrix[3];
    float clipY = world.x * matrix[4] + world.y * matrix[5]
                + world.z * matrix[6]  + matrix[7];
    float clipW = world.x * matrix[12] + world.y * matrix[13]
                + world.z * matrix[14] + matrix[15];
    if (clipW < 0.001f) return false;
    screen.x = (w / 2.f) * (1.f + clipX / clipW);
    screen.y = (h / 2.f) * (1.f - clipY / clipW);
    return true;
}
```

**6. 渲染层（render）**
- 透明叠加窗口：`WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_TOPMOST`
- `DwmExtendFrameIntoClientArea` 做全透明背景
- D3D11 设备 + `ImGui` 或裸 `DrawLine/DrawRect/DrawText`
- 主循环：`PeekMessage` 处理退出 → 读实体 → W2S → 绘制 → `Present`

**7. 主循环（main）**
```cpp
while (running) {
    if (GetAsyncKeyState(VK_END) & 1) running = false;
    auto ents = GetEntities(clientBase, localPlayer);
    float vm[16];
    ReadProcessMemory(hProc, (LPVOID)(clientBase + off::dwViewMatrix),
                      vm, sizeof(vm), nullptr);
    render.Begin();
    for (auto& e : ents) {
        Vec2 s;
        if (WorldToScreen(e.head, s, vm, width, height))
            render.Box(s, e.health, e.team);
    }
    render.End();
}
```

### 三、数据流

```
PID/基址 ──► 偏移表 ──► ReadChain ──► Entity 列表
                                          │
视图矩阵 ─────────────────────────────────┤
                                          ▼
                                    WorldToScreen
                                          │
                                          ▼
                                    D3D11 叠加层
```

### 四、搭建顺序（建议）

1. **先跑通附着**：打印 PID、`client.dll` 基址，确认能读
2. **再验证偏移**：读本地玩家血量，控制台打印，和游戏内对照
3