# 世界坐标 → 屏幕坐标（WorldToScreen）

> 选型：C++17 · 纯数学实现 · 依赖视图矩阵（View-Projection Matrix）· 可直插自瞄模块

## 1. 原理一句话

世界点 `P_world` 先乘视图矩阵得到**相机空间**坐标，再乘投影矩阵得到**裁剪空间**坐标，透视除法归一化到 NDC，最后映射到屏幕像素。自瞄里真正要的是**反向**：把目标世界坐标变成屏幕上的 `(x, y)`，用来判断目标是否在视野内、以及鼠标该往哪挪。

## 2. 完整实现

```cpp
// w2s.hpp
#pragma once
#include <cmath>

struct Vec3 { float x, y, z; };
struct Vec2 { float x, y; };

// 4x4 矩阵，行主序：m[row][col]
struct Mat4 { float m[4][4]; };

// 视图-投影矩阵（引擎里通常叫 viewMatrix / worldToScreenMatrix）
// 屏幕尺寸
struct Screen { int w, h; };

// 世界坐标 -> 屏幕坐标
// 返回 false 表示点在相机背后（w <= 0），此时屏幕坐标无意义
inline bool WorldToScreen(const Vec3& world, const Mat4& vp,
                          const Screen& scr, Vec2& out)
{
    // 齐次坐标 w 分量置 1
    float clipX = world.x * vp.m[0][0] + world.y * vp.m[1][0]
                + world.z * vp.m[2][0] + vp.m[3][0];
    float clipY = world.x * vp.m[0][1] + world.y * vp.m[1][1]
                + world.z * vp.m[2][1] + vp.m[3][1];
    float clipW = world.x * vp.m[0][3] + world.y * vp.m[1][3]
                + world.z * vp.m[2][3] + vp.m[3][3];

    if (clipW < 0.001f) return false;   // 在相机背后

    // 透视除法 -> NDC [-1, 1]
    float ndcX = clipX / clipW;
    float ndcY = clipY / clipW;

    // NDC -> 屏幕像素（Y 轴翻转：NDC 向上为正，屏幕向下为正）
    out.x = (ndcX * 0.5f + 0.5f) * scr.w;
    out.y = (1.0f - (ndcY * 0.5f + 0.5f)) * scr.h;
    return true;
}
```

## 3. 关键点（自瞄里最容易踩的坑）

| 坑 | 说明 | 处理 |
| --- | --- | --- |
| 矩阵行/列主序 | 引擎给的矩阵可能是列主序，直接套上面公式会全错 | 先打印矩阵对角线/平移分量确认；列主序时把 `m[r][c]` 换成 `m[c][r]` |
| `w <= 0` | 目标在相机背后，除法会得到镜像坐标，自瞄会往反方向甩 | 必须判 `clipW`，返回 false 直接跳过该目标 |
| Y 轴方向 | NDC 向上为正，屏幕向下为正 | 用 `1.0f - (...)` 翻转 |
| 视野边界 | 屏幕外目标坐标可能很大 | 自瞄前先判 `0 <= x < w && 0 <= y < h` |
| 矩阵来源 | 每帧从引擎读 viewMatrix（通常是一个固定偏移的 4x4 浮点数组） | 见下方读取示例 |

## 4. 从引擎读矩阵（示例，偏移自造）

```cpp
// OFFSET_VIEWMATRIX: 引擎模块基址 + 偏移，指向 4x4 float 矩阵
// 实际用 ReadProcessMemory 或内部 hook 读取
Mat4 vp;
ReadProcessMemory(hProc,
    (LPCVOID)(moduleBase + OFFSET_VIEWMATRIX),
    &vp, sizeof(vp), nullptr);

Vec2 screenPos;
if (WorldToScreen(targetHead, vp, {screenW, screenH}, screenPos)) {
    // screenPos 即目标头部在屏幕上的像素坐标
    // 自瞄：计算与准星(屏幕中心)的偏差，转成鼠标增量
    float dx = screenPos.x - screenW * 0.5f;
    float dy = screenPos.y - screenH * 0.5f;
    // 按灵敏度换算成鼠标移动量
}
```

## 5. 自瞄闭环（坐标 → 鼠标）

```cpp
// 屏幕偏差 -> 鼠标增量（线性灵敏度模型）
// SENSITIVITY: 每像素对应的鼠标计数，需实测标定
constexpr float SENSITIVITY = 0.22f;

void AimAt(const Vec2& target, const Screen& scr) {
    float dx = target.x - scr.w * 0.5f;
    float dy = target.y - scr.h * 0.5f;

    // 死区：准星已在目标附近就不动，避免抖动
    if (std::fabs(dx) < 2.0f && std::fabs(dy) < 2.0f) return;

    int moveX = static_cast<int>(dx * SENSITIVITY);
    int moveY = static_cast<int>(dy * SENSITIVITY);

    // 平滑：限制单帧最大移动量
    constexpr int MAX_STEP = 40;
    moveX = std::clamp(moveX, -MAX_STEP, MAX_STEP);
    moveY = std::clamp(moveY, -MAX_STEP, MAX_STEP);

    mouse_event(MOUSEEVENTF_MOVE, moveX, moveY, 0, 0);
}
```

## 6. 验证方式

```cpp
// 自检：把相机自身位置投影，应落在屏幕中心附近
Vec2 self;
WorldToScreen(cameraPos, vp, scr, self);
// 期望 self ≈ (scr.w/2, scr.h/2)，偏差过大说明矩阵主序或 Y 轴搞反
```

## 7. 编译

```bash
g++ -std=c++17 -O2 -c w2s.cpp -o w2s.o
# Windows 下链接 user32（mouse_event）
# cl /std:c++17 /O2 w2s.cpp /link user32.lib
```

**证据行**：`WorldToScreen` 的 `clipW < 0.001f` 分支对应相机背后剔除；`1.0f - (...)` 对应 NDC→屏幕 Y 翻转；自检用相机自身投影应落在屏幕中心，可复现验证矩阵主序是否正确。

**下一步验证**：在目标进程里 dump 出 `OFFSET_VIEWMATRIX` 处的 16 个 float，用相机自身坐标代入 `WorldToScreen`，若结果偏离屏幕中心则先修正