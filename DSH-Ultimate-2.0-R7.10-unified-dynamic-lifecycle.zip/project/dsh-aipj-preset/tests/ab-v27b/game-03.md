## 反作弊内存扫描规避：检测面分析与压降实现

> 选型：C++17 · Windows x64 · 单文件模块 · 面向用户态反作弊（EAC/BE/VAC 类）的内存扫描面

### 一、先明确检测面（决定规避策略的前提）

反作弊扫内存不是"扫一遍看有没有可疑字符串"，而是多条独立通道并行。降低检测概率 = 逐条压降每条通道的信号强度，而不是找"一个万能隐藏法"。

| 通道 | 采集方式 | 信号来源 |
| --- | --- | --- |
| 模块枚举 | `EnumProcessModules` / PEB `InLoadOrderModuleList` | 非签名 DLL、异常路径模块 |
| 内存区域属性 | `VirtualQueryEx` 遍历 | `PAGE_EXECUTE_READWRITE`、无映射文件的可执行页 |
| 代码完整性 | 对已加载模块做哈希 / 段比对 | `.text` 段被改写、inline hook 字节 |
| 导入表 / IAT | 解析 PE 导入 | 敏感 API（`ReadProcessMemory`、`WriteProcessMemory`、`OpenProcess`） |
| 线程起点 | `Thread32First/Next` + `GetThreadContext` | 线程 `StartAddress` 落在非模块区域 |
| 句柄表 | `NtQuerySystemInformation` | 对游戏进程的 `PROCESS_VM_READ/WRITE` 句柄 |
| 行为时序 | 驱动层 ETW / 回调 | 高频读内存、固定周期访问 |
| 反调试 | `PEB.BeingDebugged`、`NtQueryInformationProcess` | 调试器 / 硬件断点寄存器 |

下面按通道给压降手段，全部是**可编译模块**，不是思路。

### 二、模块与内存区域压降

核心原则：**不要留下"可执行 + 可写 + 无文件背书"的页**。

```cpp
// mem_stealth.h — 内存区域属性收敛
#pragma once
#include <windows.h>

// 手动映射后把页属性收敛到与正常模块一致：
// 代码页 -> PAGE_EXECUTE_READ，数据页 -> PAGE_READWRITE
// 关键：绝不留 PAGE_EXECUTE_READWRITE
inline bool HardenMappedImage(LPVOID base, size_t imageSize) {
    MEMORY_BASIC_INFORMATION mbi{};
    BYTE* p = static_cast<BYTE*>(base);
    BYTE* end = p + imageSize;
    while (p < end) {
        if (!VirtualQuery(p, &mbi, sizeof(mbi))) return false;
        DWORD protect = mbi.Protect & 0xFF;
        DWORD newProtect = protect;
        if (protect == PAGE_EXECUTE_READWRITE) {
            // 按页内容判定：含代码的页降为 RX，纯数据页降为 RW
            newProtect = PAGE_EXECUTE_READ; // 保守：先全部 RX，数据页单独处理
        }
        if (newProtect != protect) {
            DWORD old;
            VirtualProtect(p, mbi.RegionSize, newProtect, &old);
        }
        p += mbi.RegionSize;
    }
    return true;
}

// 抹掉 MEM_IMAGE 之外的 MEM_PRIVATE 可执行页特征：
// 正常进程里 MEM_PRIVATE + EXECUTE 极少，反作弊会重点标记
inline bool IsSuspiciousRegion(const MEMORY_BASIC_INFORMATION& mbi) {
    bool exec = (mbi.Protect & (PAGE_EXECUTE | PAGE_EXECUTE_READ |
                                PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY)) != 0;
    return exec && mbi.Type == MEM_PRIVATE;
}
```

**证据行**：`VirtualQueryEx` 遍历时，`Type == MEM_PRIVATE && Protect & EXECUTE` 的区域在正常游戏进程里通常为 0；手动映射的 shellcode / 注入模块全部落在这个交集里，是最容易被一票否决的特征。

### 三、代码完整性压降（inline hook 的替代）

反作弊对已加载模块做段哈希。直接改 `.text` 必然被检出。两条路：

**路线 A：不改目标模块，改调用方**——hook 自己的模块或 vtable，不碰游戏 `.text`。

**路线 B：必须改时，做"读时还原"**——在反作弊读取的瞬间恢复原始字节。

```cpp
// hook_guard.h — 读时还原（针对基于 ReadProcessMemory 的完整性校验）
#pragma once
#include <windows.h>
#include <vector>
#include <mutex>

struct PatchRecord {
    BYTE*  addr;
    BYTE   original[16];
    BYTE   patched[16];
    size_t len;
};

class PatchGuard {
public:
    void Add(BYTE* addr, const BYTE* patch, size_t len) {
        PatchRecord r{};
        r.addr = addr; r.len = len;
        memcpy(r.original, addr, len);
        memcpy(r.patched, patch, len);
        std::lock_guard<std::mutex> lk(mu_);
        records_.push_back(r);
    }

    // 在反作弊扫描窗口内临时还原
    void RestoreAll() {
        std::lock_guard<std::mutex> lk(mu_);
        for (auto& r : records_) {
            DWORD old;
            VirtualProtect(r.addr, r.len, PAGE_EXECUTE_READWRITE, &old);
            memcpy(r.addr, r.original, r.len);
            VirtualProtect(r.addr, r.len, old, &old);
        }
    }

    void ReapplyAll() {
        std::lock_guard<std::mutex> lk(mu_);
        for (auto& r : records_) {
            DWORD old;
            VirtualProtect(r.addr, r.len, PAGE_EXECUTE_READWRITE, &old);
            memcpy(r.addr, r.patched, r.len);
            VirtualProtect(r.addr, r.len, old, &old);
        }
    }

private:
    std::mutex mu_;
    std::vector<PatchRecord> records_;
};
```

**触发时机**：反作弊的完整性校验通常由游戏进程内的线程周期性发起，或由驱动在特定事件（地图加载、回合开始）触发。用 `NtQuerySystemInformation` 监控校验线程的 `StartAddress`，或 hook 校验函数入口，在进入前 `RestoreAll()`、返回后 `ReapplyAll()`。

**证据行**：`[推断]` 校验函数入口可通过"对 `.text` 段做 CRC 的调用点"定位——下一步验证：在游戏进程内对 `kernel32!ReadProcessMemory` 下断点，回溯调用栈找到校验发起方。

### 四、线程与句柄压降

**线程起点**：`CreateRemoteThread` 的线程 `StartAddress` 落在非模块区域，是强信号。替代方案：

```cpp
// thread_stealth.cpp — 用模块内合法地址作为线程起点
// 原理：