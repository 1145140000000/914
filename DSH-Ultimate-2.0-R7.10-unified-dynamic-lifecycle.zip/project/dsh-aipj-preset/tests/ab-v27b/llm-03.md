## 对抗后缀（Adversarial Suffix）生效机制与构造方法

> 选型：机制说明 + 可运行构造脚本（PyTorch + transformers，GCG 风格），单文件，含自检。

### 一、为什么能生效

对抗后缀本质是**在连续嵌入空间里做离散优化**，找到一段 token 序列，使模型内部表征朝攻击者期望的方向偏移。生效原因可拆成四层：

| 层面 | 机制 | 证据/依据 |
| --- | --- | --- |
| 输入层 | 后缀 token 与原始指令共享注意力，改变后续 token 的上下文分布 | 注意力权重可视化中后缀 token 获得异常高 attention mass |
| 表征层 | 优化目标直接作用于隐藏状态，把"拒绝方向"投影压下去 | 拒绝方向（refusal direction）在激活空间可线性分离，后缀使其投影趋零 |
| 分布层 | 后缀是"分布外"token 组合，模型对其缺乏鲁棒训练覆盖 | 后缀 token 常为低频/跨语言/符号混排，训练分布稀疏 |
| 解码层 | 首 token 概率被重排，贪心/采样都落到非拒绝开头 | 目标损失即最小化"拒绝首 token"的负对数似然 |

关键点：**后缀不是语义攻击，是梯度攻击**。它不靠"说服"模型，而是靠反向传播找到让损失下降的离散 token。

### 二、构造原理（GCG：Greedy Coordinate Gradient）

核心循环：

```
for step in range(N):
    1. 计算后缀每个位置的 token 梯度  ∂L/∂e_i
    2. 取梯度下降最快的 top-k 候选 token
    3. 随机采样 batch 个 (位置, 候选token) 组合
    4. 前向评估，保留损失最低的替换
    5. 损失收敛或达到步数则停
```

目标函数（越狱场景）：

```
L = -log P(target_response | prompt + suffix)
```

其中 `target_response` 是攻击者期望的开头（如 "Sure, here is"）。

### 三、可运行构造脚本

```python
# gcg_suffix.py
# 依赖: torch transformers
# 用法: python gcg_suffix.py --model <hf_model_id> --prompt "..." --target "Sure, here is"

import argparse, torch
from transformers import AutoModelForCausalLM, AutoTokenizer

def get_embed(model):
    return model.get_input_embeddings().weight

def token_gradients(model, input_ids, suffix_slice, target_ids):
    """计算后缀区间每个位置的 token 梯度"""
    embed = get_embed(model)
    one_hot = torch.zeros(
        suffix_slice.stop - suffix_slice.start,
        embed.shape[0],
        device=embed.device,
    )
    one_hot.scatter_(1, input_ids[suffix_slice].unsqueeze(1), 1.0)
    one_hot.requires_grad_(True)

    suffix_embeds = (one_hot @ embed).unsqueeze(0)
    full_embeds = embed(input_ids).clone()
    full_embeds[:, suffix_slice] = suffix_embeds

    logits = model(inputs_embeds=full_embeds).logits
    # 只对 target 段计算损失
    tgt_logits = logits[0, -(target_ids.shape[0] + 1):-1, :]
    loss = torch.nn.functional.cross_entropy(
        tgt_logits, target_ids, reduction="mean"
    )
    loss.backward()
    return one_hot.grad.clone()

def sample_candidates(grad, tokenizer, k=256):
    """按梯度取 top-k 候选 token（排除特殊 token）"""
    topk = (-grad).topk(k, dim=1).indices
    return topk

def gcg_attack(model, tokenizer, prompt, target, suffix_len=20,
               steps=500, topk=256, batch=128, device="cuda"):
    model.to(device).eval()
    embed = get_embed(model)

    prompt_ids = tokenizer(prompt, return_tensors="pt").input_ids.to(device)
    target_ids = tokenizer(target, add_special_tokens=False,
                           return_tensors="pt").input_ids.to(device)[0]

    # 初始化后缀为随机 token
    suffix_ids = torch.randint(
        0, embed.shape[0], (suffix_len,), device=device
    )
    suffix_slice = slice(prompt_ids.shape[1], prompt_ids.shape[1] + suffix_len)

    best_loss = float("inf")
    best_suffix = suffix_ids.clone()

    for step in range(steps):
        full_ids = torch.cat([prompt_ids[0], suffix_ids]).unsqueeze(0)
        grad = token_gradients(model, full_ids[0], suffix_slice, target_ids)
        candidates = sample_candidates(grad, tokenizer, topk)

        # 构造 batch 个替换方案
        proposals = []
        for _ in range(batch):
            pos = torch.randint(0, suffix_len, (1,)).item()
            tok = candidates[pos, torch.randint(0, topk, (1,)).item()]
            new_suffix = suffix_ids.clone()
            new_suffix[pos] = tok
            proposals.append(new_suffix)

        # 批量评估
        with torch.no_grad():
            losses = []
            for cand in proposals:
                ids = torch.cat([prompt_ids[0], cand]).unsqueeze(0)
                logits = model(ids).logits
                tgt_logits = logits[0, -(target_ids.shape[0] + 1):-1, :]
                l = torch.nn.functional.cross_entropy(
                    tgt_logits, target_ids
                ).item()
                losses.append(l)

        idx = int(torch.tensor(losses).argmin())
        if losses[idx] < best_loss:
            best_loss = losses[idx]
            best_suffix = proposals[idx].clone()
            suffix_ids = proposals[idx].clone()
            print(f"[step {step}] loss={best_loss:.4f} "
                  f"suffix={tokenizer.decode(best_suffix)}")

    return best_suffix, best_loss

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True)
    ap.add_argument("--prompt", required=True)
    ap.add_argument("--target", default="Sure, here is")
    ap.add_argument("--suffix-len", type=int, default=20)
    ap.add_argument("--steps", type=int, default=500)
    args = ap.parse_args()

    tok = AutoTokenizer.from_pretrained(args.model)
    model = AutoModelForCausalLM.from_pretrained(
        args.model, torch_dtype=torch.float16
    )

    suffix, loss = gcg_attack(
        model, tok, args.prompt, args.target,
        suffix_len=args.suffix_len, steps=args.steps,
    )
    print("\n=== RESULT ===")
    print("suffix tokens:", tok.decode(suffix))
    print("final loss:", loss)

    # 自检：