## 授权还原工具链与流程（`SAMPLE` 注册校验分析）

> 选型：静态为主（Ghidra + radare2 + objdump），动态为辅（x64dbg / gdb + Frida），语言无关，先定位 `CHECK_FN` 再决定是否上动态。

### 0. 样本指纹（先做，决定后面走哪条路）

```bash
# 文件类型 / 架构 / 位数 / 是否加壳
file SAMPLE
objdump -f SAMPLE | head -20          # 或 llvm-objdump -f
# PE 用：
#   pefile / CFF Explorer / Detect It Easy (DIE)
# ELF 用：
readelf -h SAMPLE
readelf -S SAMPLE | grep -Ei 'upx|pack|\.aspack'
# 壳/编译器特征
strings -n 6 SAMPLE | grep -Ei 'upx|aspack|themida|vmprotect|pyinstaller|go1\.|rustc|MSVC|GCC'
# 哈希留档
md5sum SAMPLE; sha256sum SAMPLE
```

判定分支：
- 命中 `UPX`/`ASPack` → 先脱壳（`upx -d` 或 DIE 的 unpacker），脱完重跑指纹
- 命中 `VMProtect`/`Themida` → 静态基本失效，直接转动态 + 内存 dump
- 无壳 → 进第 1 步

证据行示例：`$ file SAMPLE` → `SAMPLE: PE32+ executable (GUI) x86-64, for MS Windows`

### 1. 静态遍历：找校验入口

**1a. 字符串与导入表（最快命中点）**

```bash
# 注册相关字符串：错误提示、成功提示、序列号格式
strings -n 5 -t x SAMPLE | grep -Ei 'serial|licen|regist|activat|invalid|expire|key|trial|wrong|correct|thank'
# 导入表：看它用什么做比较/加密
objdump -p SAMPLE | grep -Ei 'Import|GetWindowText|MessageBox|strcmp|lstrcmp|memcmp|Crypt|RegOpenKey'
# radare2 视角
r2 -A SAMPLE -q -c 'iz~serial;iz~licen;afl~main;pdf @ main' 
```

关键：`GetWindowTextA/W` 的调用点 = 用户输入被读进来的位置；`MessageBox` 的"注册成功/失败"分支 = 校验结果落点。**从失败提示字符串交叉引用（xref）反推校验函数**是最稳的入口。

```bash
# 找字符串地址后反查引用
r2 -A SAMPLE -q -c 'izz~invalid; axt @ <字符串地址>'
# Ghidra：Search > For Strings，右键 References > Show References to Address
```

**1b. 定位 `CHECK_FN`**

从 `MessageBox("注册失败")` 的调用点往上走一层，通常就是：

```
main / WndProc
  └─ OnRegisterButton
       ├─ GetWindowText(输入框) → buffer
       ├─ CHECK_FN(buffer)          ← 目标
       └─ if (ret) MessageBox("成功") else MessageBox("失败")
```

Ghidra 里对 `CHECK_FN` 按 `F` 反编译，重点看：
- 输入长度判断（`strlen(buf) == N`，N 就是序列号长度）
- 逐字符比较 / 分组比较（`buf[i]` 与常量表）
- 算术变换（`xor`、`imul`、`rol`、查表 `S-box`）
- 是否调用 `Crypt*` / 自实现哈希

### 2. 动态验证：确认静态结论

**2a. 下断点**

```bash
# x64dbg（Windows）
#   bp CHECK_FN 地址；或在 GetWindowTextW 返回处下断，看 buffer 内容
# gdb（Linux）
gdb -q ./SAMPLE
(gdb) b *CHECK_ADDR
(gdb) run
(gdb) x/32xb $rdi          # 看输入 buffer
(gdb) info registers
```

**2b. Frida 挂钩（跨平台、免重编译）**

```javascript
// hook.js —— 打印校验函数入参与返回值
const CHECK_ADDR = ptr("0xCHECK_ADDR");
Interceptor.attach(CHECK_ADDR, {
  onEnter(args) {
    console.log("[in ] buf =", args[0].readUtf8String());
    console.log("[in ] len =", args[1].toInt32());
  },
  onLeave(retval) {
    console.log("[out] ret =", retval.toInt32());
  }
});
```

```bash
frida -f SAMPLE -l hook.js --no-pause
# 或附加已运行进程
frida SAMPLE -l hook.js
```

**2c. 输入构造与回显**

用一组已知输入（如 `AAAA-AAAA-AAAA-AAAA`）跑一遍，记录：
- 进入 `CHECK_FN` 时 buffer 的实际字节
- 函数内部关键分支的跳转方向（`ZF`/`ret` 值）
- 返回值与最终 MessageBox 分支的对应关系

证据行示例：`bp 0x4012A0` → `buf="AAAA-AAAA-AAAA-AAAA"` → `ret=0` → 走"失败"分支

### 3. 算法还原

把 `CHECK_FN` 反编译伪代码整理成可读形式，逐段标注：

```c
// 还原自 CHECK_FN @ 0x4012A0
int check(const char *serial) {
    if (strlen(serial) != 19) return 0;          // 4-4-4-4 + 3 个 '-'
    // 分组
    uint32_t g[4];
    for (int i = 0; i < 4; i++)
        g[i] = parse_hex(serial + i*5);          // 每段 4 位 hex
    // 变换（示例：异或链 + 常量）
    uint32_t acc = 0xDEADBEEF;
    for (int i = 0; i < 4; i++) {
        acc ^= g[i];
        acc = (acc << 5) | (acc >> 27);          // rol 5
        acc += 0x12345678;
    }
    return acc == 0xC0FFEE00;                    // 目标常量
}
```

还原要点：
- 每个常量、每个移位/异或都对应一条汇编，**逐条核对**（`objdump -d --start-address=... --stop-address=...`）
- 查表类（S-box）把表 dump 出来存成数组
- 哈希类（MD5/SHA）先认算法再决定是"逆"还是"碰撞"

### 4. 证据表（交付必备）

| 偏移 | 原始字节 | 还原后语义 |
