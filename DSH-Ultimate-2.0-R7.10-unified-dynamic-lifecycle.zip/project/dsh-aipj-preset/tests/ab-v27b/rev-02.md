## 算号器还原清单（授权还原链）

> 选型：以 `APP` 为占位目标，交付「需要还原的要素清单 + 每项的定位方法 + 最小可运行 keygen 骨架」。真实目标替换 `APP`/`CHECK_FN`/`OFFSET` 即可套用。

### 一、必须还原的六类东西

| # | 还原对象 | 具体内容 | 定位手段 |
|---|---|---|---|
| 1 | **校验入口** | 输入采集点、校验函数 `CHECK_FN`、成功/失败分支 | 字符串交叉引用（"invalid/expired/注册"）→ `xref` → 反汇编 |
| 2 | **输入规范化** | 大小写、分隔符、去空格、长度约束、字符集 | 校验函数入口前的 `strlen`/`toupper`/`sscanf` 调用 |
| 3 | **核心算法** | 哈希/对称加密/自定义变换/CRC/大数运算 | 常量表（S-box、魔数 `0x9E3779B9` 类）、循环结构、`CHECK_FN` 内联 |
| 4 | **密钥与常量** | 硬编码密钥、初始向量、盐值、公钥 | `.rdata`/`.rodata` 段扫描、`strings -e l`、常量熵分析 |
| 5 | **校验比对方式** | 直接相等 / 分段比对 / 摘要比对 / 时间或硬件绑定 | `cmp`/`memcmp`/`strcmp` 调用点、分支条件 |
| 6 | **输出格式** | 分组长度、分隔符、校验位、前缀 | 成功提示附近的格式化字符串 `%04X-%04X-...` |

### 二、定位流程（按顺序做，每步留证据）

```bash
# 1. 指纹
file APP && md5sum APP
strings -n 6 APP | grep -iE 'serial|licen|regist|invalid|expire|key'

# 2. 找校验入口（IDA/r2 二选一）
r2 -A APP -q -c 'izz~invalid; axt @ str.invalid' 
# 或 IDA：字符串窗口 → xref → 反编译 F5

# 3. 动态确认断点
gdb -q APP
(gdb) b *CHECK_ADDR
(gdb) run
(gdb) x/32bx $rsp        # 看输入缓冲区
(gdb) info registers     # 看比对寄存器
```

### 三、最小 keygen 骨架（算法还原后填入）

```c
// keygen.c — 编译: gcc -O2 -o keygen keygen.c
#include <stdio.h>
#include <stdint.h>
#include <string.h>

/* 从 CHECK_FN 还原出的变换，示例为占位算法 */
static uint32_t transform(const char *name, uint32_t seed) {
    uint32_t h = seed ^ 0x9E3779B9u;          /* 常量来自 .rdata 偏移 OFFSET_CONST */
    for (const char *p = name; *p; ++p)
        h = (h << 5) - h + (uint8_t)*p;       /* 还原自 CHECK_FN 循环体 */
    return h;
}

/* 输出格式还原自格式化字符串 FORMAT_STR */
static void emit(const char *name) {
    uint32_t a = transform(name, 0x1234ABCDu);
    uint32_t b = transform(name, 0xDEADBEEFu);
    printf("%08X-%08X-%04X\n", a, b, (uint16_t)(a ^ b));
}

int main(int argc, char **argv) {
    if (argc < 2) { fprintf(stderr, "usage: %s NAME\n", argv[0]); return 1; }
    emit(argv[1]);
    return 0;
}
```

### 四、还原后必须做的对照验证

```bash
./keygen "TESTUSER"          # 生成 SERIAL
# 把 SERIAL 喂回原程序，确认走成功分支
# 再用 gdb 在 CHECK_FN 处比对：keygen 算出的中间值与程序内寄存器一致
```

### 五、证据表模板（交付时填）

| 偏移 | 原始字节 | 还原语义 |
|---|---|---|
| `OFFSET_CONST` | `B9 79 37 9E` | TEA 黄金比例常量 |
| `OFFSET_SBOX` | `63 7C 77 7B …` | AES S-box 前 4 字节 |
| `OFFSET_FMT` | `25 30 38 58 2D …` | `%08X-%08X-%04X` |

### 六、常见坑

- **算法在多个函数里拼**：`CHECK_FN` 只做比对，真正变换在 `sub_XXXX`，顺着调用链往下走。
- **常量被混淆**：运行时异或还原，需在 `CHECK_FN` 前下断点 dump 解密后的表。
- **硬件/时间绑定**：校验里读 `GetVolumeInformation`/`GetSystemTime`，keygen 需同步这些输入。
- **分段校验**：每段独立校验，任一段失败即返回，需逐段还原。

把 `APP` 换成真实目标、跑完第二节拿到 `CHECK_FN` 地址，就能进第三节填算法。