## APK 脱壳流程（壳型判定 → 静态定位 → 动态 dump → 重建回验）

> 选型：Frida 16.x + frida-dexdump + jadx 1.5 + apktool 2.9；目标占位 `SAMPLE.apk`，包名 `com.example.app`，进程 `com.example.app`，设备 `127.0.0.1:5555`（adb over TCP，真机/模拟器均可）。

---

### 0. 前置：环境与样本指纹

```bash
# 设备连通
adb connect 127.0.0.1:5555
adb devices -l

# 样本指纹
md5sum SAMPLE.apk
unzip -l SAMPLE.apk | head -40
aapt2 dump badging SAMPLE.apk | grep -E 'package|launchable'
```

证据行示例：
```
$ md5sum SAMPLE.apk
3f9a1c2e7b4d...  SAMPLE.apk
$ aapt2 dump badging SAMPLE.apk | grep package
package: name='com.example.app' versionCode='120' ...
```

---

### 1. 壳型判定（决定后续走哪条 dump 路径）

| 判定点 | 命令 | 判读 |
| --- | --- | --- |
| 特征 so 名 | `unzip -l SAMPLE.apk \| grep -E 'lib/.*\.so'` | `libjiagu*.so`=360加固；`libshella*.so`/`libshellx*.so`=腾讯乐固；`libDexHelper*.so`=阿里；`libexec.so`+`libexecmain.so`=梆梆；`libmobisec*.so`=网易易盾；`libnesec*.so`=通付盾 |
| DEX 数量与大小 | `unzip -l SAMPLE.apk \| grep '\.dex'` | 仅 1 个且 <100KB 且类数极少 → 壳 DEX，业务在内存 |
| 入口 Application | `jadx -d out SAMPLE.apk` 后看 `AndroidManifest.xml` 的 `android:name` | 指向 `com.stub.StubApp` / `com.tencent.StubShell` 等 → 已确认加壳 |
| 字符串特征 | `strings SAMPLE.apk \| grep -iE 'jiagu\|stub\|shell\|dexhelper'` | 命中即壳名 |

```bash
# 一条命令出结论
unzip -l SAMPLE.apk | grep -E '\.so$|\.dex$'
jadx -d jadx_out SAMPLE.apk --show-bad-code 2>/dev/null
grep -rE 'StubApp|StubShell|DexHelper|jiagu' jadx_out/AndroidManifest.xml
```

证据行：
```
$ unzip -l SAMPLE.apk | grep -E '\.so$|\.dex$'
   ...  lib/arm64-v8a/libjiagu_vip.so
   ...  classes.dex            (86 KB)
→ 判定：360 加固（libjiagu_vip.so + 单薄壳 dex）
```

---

### 2. 静态定位（壳外可见部分）

```bash
# 反编译壳 DEX，找 Application 与 attachBaseContext
jadx -d jadx_out SAMPLE.apk
grep -rn "attachBaseContext\|loadLibrary\|System.load" jadx_out/sources/ | head

# 找真实 Application（壳通常把原名藏在 assets 或加密串里）
unzip -o SAMPLE.apk 'assets/*' -d apk_assets
strings apk_assets/* 2>/dev/null | grep -E '^com\..*Application$'
```

关键点：壳的 `StubApp.attachBaseContext()` 里会 `System.loadLibrary("jiagu_vip")` 并调用 native 解密，**业务 DEX 在 `attachBaseContext` 返回后才被释放到内存**——所以 dump 时机必须在 `Application.onCreate` 之后。

---

### 3. 动态 dump（核心步骤）

#### 3.1 起 Frida server

```bash
adb push frida-server-16.x-android-arm64 /data/local/tmp/fs
adb shell "su -c 'chmod 755 /data/local/tmp/fs && /data/local/tmp/fs &'"
frida-ps -U | grep com.example.app
```

#### 3.2 方案 A：frida-dexdump（通用，优先）

```bash
pip install frida-dexdump
# 先启动 App 到主界面，再 dump
adb shell am start -n com.example.app/.MainActivity
sleep 3
frida-dexdump -U -f com.example.app -d
# 产物：com.example.app_<pid>/ 下若干 .dex
```

#### 3.3 方案 B：自写 hook 脚本（壳有反 dump 时用）

`dump_dex.js`：

```javascript
// 在 DEX 加载完成、业务类已 define 后遍历所有 DexFile 并落盘
Java.perform(function () {
    var DexFile = Java.use("dalvik.system.DexFile");
    // 壳常把 DexFile 藏在 BaseDexClassLoader.pathList 里
    Java.enumerateClassLoaders({
        onMatch: function (loader) {
            try {
                var pathList = loader.pathList.value;
                var dexElements = pathList.dexElements.value;
                for (var i = 0; i < dexElements.length; i++) {
                    var dexFile = dexElements[i].dexFile.value;
                    if (dexFile) {
                        var mCookie = dexFile.mCookie.value;
                        console.log("[+] DexFile cookie=" + mCookie + " loader=" + loader);
                        // 交给 native 侧 dump（见 3.4）
                    }
                }
            } catch (e) {}
        },
        onComplete: function () {}
    });
});
```

```bash
frida -U -f com.example.app -l dump_dex.js --no-pause
```

#### 3.4 方案 C：内存扫描兜底（壳抹了 DexFile 结构时）

```bash
# 用 frida 在进程内存里搜 dex magic "dex\n035"
frida -U com.example.app -e '
var m = Process.enumerateRanges("rw-");
m.forEach(function(r){
  var p = Memory.scanSync(r.base, r.size, "64 65 78 0a 30 33 35 00");
  p.forEach(function(h){ console.log("dex@" + h.address + " size~" + r.size); });
});'
```

拿到地址后用 `frida-dump` 或 `dd` 从 `/proc/<pid>/mem` 按 dex header 的 `file_size` 字段截取。

---

### 4. 重建与回验

```bash
# 4.1 合并/修复 dump 出的 dex（多 dex 时）
mkdir fixed && cd fixed
for f in ../com.example.app_*/**.dex; do
  python