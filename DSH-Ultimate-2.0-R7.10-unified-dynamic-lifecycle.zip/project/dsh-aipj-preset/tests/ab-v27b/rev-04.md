## 定位补丁字节：从校验点到字节的完整路径

下面按"先找到校验逻辑 → 再缩小到比较指令 → 最后锁定要改的字节"这条链讲，每一步都给可执行的命令和判据。

---

### 第 1 步：先确定"哪里在判断"

补丁字节永远依附于一条**决定分支走向的指令**。所以第一件事不是找字节，是找判断。

**静态入口（无源码时）**

```bash
# 1. 看字符串，找提示语（"Invalid""Expired""Trial"等）
strings -n 6 SAMPLE | grep -iE 'invalid|expire|licen|trial|serial|key'

# 2. 定位引用该字符串的代码
r2 -A SAMPLE
[0x...]> axt @ str.Invalid_license
# 或 objdump 下找地址
objdump -d SAMPLE | grep -n "Invalid"
```

命中后你会拿到一个**引用地址**，它通常就在校验失败分支里。往上翻，找 `cmp` / `test` / `sub` 后紧跟的 `jz/jnz/jl/jg`——这就是**分支判据**。

**判据长这样：**

```asm
call  check_license      ; 返回 0 = 失败, 1 = 成功
test  eax, eax
jz    loc_fail           ; ← 关键分支：eax==0 就跳失败
```

---

### 第 2 步：确认这条分支确实是"卡点"

别急着改。先用动态验证它是不是真的控制流程。

```bash
gdb -q ./SAMPLE
(gdb) b *0x00401234        # 断在 test eax,eax 处
(gdb) run
(gdb) info registers eax   # 看返回值
(gdb) si                   # 单步过 jz
(gdb) info registers eip   # 看跳没跳
```

判据：
- 输入**错误**序列号 → `eax=0`，`jz` 跳向失败分支 ✅ 这就是卡点
- 输入**正确**序列号 → `eax=1`，不跳 ✅ 确认

如果两个方向都跳/都不跳，说明你找错了分支，回去继续 `axt`。

---

### 第 3 步：把"改逻辑"翻译成"改字节"

确认卡点后，有两条路，选哪条取决于你想改什么。

#### 路线 A：改跳转（最省事，改 1~2 字节）

把条件跳转改成无条件跳转，或改成永远不跳。

| 原指令 | 字节 | 改法 | 新字节 | 效果 |
| --- | --- | --- | --- | --- |
| `jz  rel8` | `74 XX` | → `jmp rel8` | `EB XX` | 永远跳（失败也跳成功） |
| `jz  rel8` | `74 XX` | → `nop nop` | `90 90` | 永不跳（跳过失败分支） |
| `jnz rel8` | `75 XX` | → `jmp rel8` | `EB XX` | 永远跳 |
| `jz  rel32` | `0F 84 XX XX XX XX` | → `nop×6` | `90 90 90 90 90 90` | 永不跳 |

**具体操作：**

```bash
# 1. 拿到指令的虚拟地址和文件偏移
r2 -A SAMPLE
[0x...]> s 0x00401236        # 跳到 jz 那条
[0x00401236]> pd 1
# 输出: 0x00401236  740a  jz 0x00401242
[0x00401236]> iS             # 看段信息，算 file offset
# 或用 rabin2
rabin2 -S SAMPLE | grep -E '\.text'
```

虚拟地址 → 文件偏移的换算（PE 常见）：

```
file_offset = vaddr - section_vaddr + section_raw_offset
```

```bash
# 2. 用 xxd 确认原始字节
xxd -s 0x1236 -l 2 SAMPLE
# 00001236: 740a   t.

# 3. 打补丁（jz → jmp）
printf '\xEB' | dd of=SAMPLE bs=1 seek=$((0x1236)) conv=notrunc
# 或 jz → nop nop
printf '\x90\x90' | dd of=SAMPLE bs=1 seek=$((0x1236)) conv=notrunc

# 4. 验证
xxd -s 0x1236 -l 2 SAMPLE
# 00001236: eb0a   ..
```

#### 路线 B：改返回值（改常量，1 字节）

如果校验函数返回 `0/1`，直接把 `xor eax,eax` 改成 `mov eax,1`，或把 `test` 前的赋值改掉。

```asm
; 原
xor  eax, eax      ; 31 C0  → eax=0
ret

; 改
mov  eax, 1        ; B8 01 00 00 00  （5 字节，可能放不下）
; 或更省
push 1
pop  eax           ; 6A 01 58  （3 字节）
; 或
inc  eax           ; FF C0  （2 字节，若原 eax=0）
```

**判据：** 改完必须保证**指令长度不变**（除非你重排代码），否则后续指令错位，程序直接崩。

---

### 第 4 步：定位"要改的那一个字节"的通用方法

如果不知道改哪，用**差分法**：

```bash
# 1. 准备两份输入：一份失败、一份成功（或已知正确序列号）
# 2. 在两次运行中 dump 关键内存/寄存器
# 3. 对比差异点

# 动态差分（gdb 脚本）
gdb -q ./SAMPLE -ex 'b *0x00401234' -ex 'run < bad.txt' -ex 'info registers' -ex 'quit'
gdb -q ./SAMPLE -ex 'b *0x00401234' -ex 'run < good.txt' -ex 'info registers' -ex 'quit'
# 对比 eax/eflags 差异 → 差异点就是判据
```

**静态差分（二进制对比）：**

```bash
# 如果有原版和"已授权版"两个样本
cmp -l original patched | head -20
# 输出: 字节位置 原值 新值（八进制）
# 转成十六进制看
cmp -l original patched | awk '{printf "%x %s %s\n", $1-1, $2, $3}'
```

差异字节就是补丁点，反查它落在哪条指令上：

```bash
r2 -A original
[0x...]> s 