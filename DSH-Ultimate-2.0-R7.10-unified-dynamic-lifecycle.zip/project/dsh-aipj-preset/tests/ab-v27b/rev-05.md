## Frida 校验函数 Hook 脚本模板

> 选型：Python 3 + Frida 16.x · 单文件 `hook_check.py` · 支持 attach/spawn 两种模式 · 内置参数/返回值打印与返回值篡改开关

### 目录与入口

```
hook_check.py          # 主脚本（attach / spawn / 枚举导出）
```

### 完整实现

```python
#!/usr/bin/env python3
# hook_check.py — Frida 校验函数 Hook 模板
# 用法:
#   python3 hook_check.py -p com.example.app            # attach 到已运行进程
#   python3 hook_check.py -f /path/to/binary            # spawn 并注入
#   python3 hook_check.py -p com.example.app --list     # 先枚举候选校验函数
#   python3 hook_check.py -p com.example.app --force    # 强制返回值=1（绕过校验）

import argparse
import sys
import frida

JS_TEMPLATE = r"""
'use strict';

// ============ 配置区（按目标改这里） ============
var CONFIG = {
    moduleName: "__MODULE__",          // 目标模块，如 "libnative.so" / "app.exe" / null=主模块
    checkFn:    "__CHECK_FN__",        // 校验函数名或导出名，如 "Java_com_x_verify" / "check_license"
    forceRet:   __FORCE_RET__,         // true=强制返回 1（绕过）
    forceValue: 1,                     // 强制返回的值
    maxDump:    64                     // 参数/返回值 dump 最大字节
};
// ===============================================

function hexdumpPtr(p, n) {
    if (p.isNull()) return "NULL";
    try { return hexdump(p, { length: n, ansi: false }); }
    catch (e) { return "<unreadable>"; }
}

function findExport(mod, name) {
    var m = mod ? Process.getModuleByName(mod) : Process.mainModule;
    var addr = m.findExportByName(name);
    if (!addr) {
        // 退化：按符号名在模块内搜索
        var syms = m.enumerateSymbols().filter(function (s) {
            return s.name.indexOf(name) !== -1;
        });
        if (syms.length) {
            console.log("[*] 未找到精确导出，候选符号:");
            syms.forEach(function (s) { console.log("    " + s.name + " @ " + s.address); });
            return syms[0].address;
        }
        return null;
    }
    return addr;
}

function hookCheck() {
    var addr = findExport(CONFIG.moduleName, CONFIG.checkFn);
    if (!addr) {
        console.log("[-] 找不到校验函数: " + CONFIG.checkFn);
        return;
    }
    console.log("[+] 校验函数 " + CONFIG.checkFn + " @ " + addr);

    Interceptor.attach(addr, {
        onEnter: function (args) {
            this.tid = Process.getCurrentThreadId();
            console.log("\n[>] enter tid=" + this.tid);
            // 打印前 4 个参数（x64: rdi/rsi/rdx/rcx；arm64: x0-x3）
            for (var i = 0; i < 4; i++) {
                console.log("    arg[" + i + "] = " + args[i]);
            }
            // 若第 1 个参数是字符串指针，尝试读取
            try {
                var s = args[0].readCString();
                if (s && s.length && s.length < 256) console.log("    arg0(str) = " + s);
            } catch (e) {}
            // 若第 1 个参数是 buffer，dump 前 N 字节
            try {
                console.log("    arg0(buf) =\n" + hexdumpPtr(args[0], CONFIG.maxDump));
            } catch (e) {}
        },
        onLeave: function (retval) {
            console.log("[<] leave retval = " + retval);
            if (CONFIG.forceRet) {
                console.log("[!] 强制返回值 -> " + CONFIG.forceValue);
                retval.replace(CONFIG.forceValue);
            }
        }
    });
}

function listCandidates() {
    var m = CONFIG.moduleName ? Process.getModuleByName(CONFIG.moduleName) : Process.mainModule;
    console.log("[*] 模块: " + m.name + " base=" + m.base);
    var kw = ["check", "verify", "valid", "auth", "license", "serial", "key", "crypt", "decrypt"];
    m.enumerateSymbols().forEach(function (s) {
        var low = s.name.toLowerCase();
        for (var i = 0; i < kw.length; i++) {
            if (low.indexOf(kw[i]) !== -1) {
                console.log("    " + s.name + " @ " + s.address);
                break;
            }
        }
    });
}

setImmediate(function () {
    if (__LIST_ONLY__) { listCandidates(); return; }
    hookCheck();
});
"""


def build_js(args):
    js = JS_TEMPLATE
    js = js.replace("__MODULE__", args.module or "null")
    js = js.replace("__CHECK_FN__", args.fn)
    js = js.replace("__FORCE_RET__", "true" if args.force else "false")
    js = js.replace("__LIST_ONLY__", "true" if args.list else "false")
    return js


def on_message(msg, data):
    if msg["type"] == "send":
        print(msg["payload"])
    elif msg["type"] == "error":
        print("[-] JS error:", msg.get("stack", msg.get("description")))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("-p", "--process", help="attach 目标进程名/PID")
    ap.add_argument("-f", "--file", help="spawn 目标可执行文件")
    ap.add_argument("-m", "--module", default=None, help="目标模块名，默认主模块")
    ap.add_argument("-n", "--fn", default="check", help="校验函数名/导出名")
    ap.add_argument("--force", action="store_true", help="强制返回值=1")
    ap.add_argument("--list", action="store_true", help="只枚举候选函数，不 hook")
    args = ap.parse_args()

    if not args.process and not args.file:
        ap.error("必须指定 -p 或 -f")

    js = build_js(args)
    device = frida.get_local_device()

    if args.file:
        pid = device.spawn([args.file])
        session = device.attach(pid)
        script = session.create_script(js)
        script.on("message", on_message)
        script.load()
        device.resume(pid)
        print("[+] spawned pid=%d，Ctrl-C 退出" % pid)
    else:
        session = device.attach(args.process)
        script = session.create_script(js)
        script.on("message", on_message)
        script.load