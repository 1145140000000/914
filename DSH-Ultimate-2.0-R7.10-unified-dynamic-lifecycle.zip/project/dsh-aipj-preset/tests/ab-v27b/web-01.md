## 目标枚举链：单 IP + 端口 → 服务识别 → 攻击面清单

> 选型：`nmap` + `ffuf` + `curl` 单机串行，全部输出落 `RESULT_DIR`，每步留证据行。

### 0. 变量与目录

```bash
export TARGET=10.10.10.10
export PORT=8080
export RESULT_DIR=./enum_${TARGET}_${PORT}
mkdir -p "$RESULT_DIR"/{nmap,web,raw}
```

### 1. 端口与协议确认（先确认这个端口到底是什么）

```bash
# 1.1 端口存活 + 服务指纹 + 默认脚本
nmap -Pn -sV -sC -p "$PORT" "$TARGET" -oN "$RESULT_DIR/nmap/port_${PORT}.txt"

# 1.2 全端口兜底（确认是否只有这一个口，或还有旁路服务）
nmap -Pn -p- --min-rate 2000 -T4 "$TARGET" -oN "$RESULT_DIR/nmap/allports.txt"

# 1.3 若 1.1 显示 tls/http，补一次 TLS 证书与 HTTP 头
nmap -Pn -p "$PORT" --script ssl-cert,http-headers,http-title "$TARGET" \
  -oN "$RESULT_DIR/nmap/http_tls.txt"
```

证据行示例：`$ nmap -Pn -sV -p 8080 10.10.10.10` → `8080/tcp open http Apache httpd 2.4.49 …`

### 2. 按 1.1 的回显分流（三种走法，选命中那条）

| 1.1 回显 | 走法 | 命令 |
| --- | --- | --- |
| `http` / `https` / `http-proxy` | Web 枚举 → 第 3 节 | 继续 |
| `ssh` / `ftp` / `smb` / `mysql` / `redis` 等 | 服务枚举 → 第 4 节 | 跳 4 |
| `unknown` / 无 banner / 只回 `open` | 裸端口探测 → 第 5 节 | 跳 5 |

### 3. Web 面枚举

```bash
BASE="http://$TARGET:$PORT"
[ "$PORT" = "443" ] && BASE="https://$TARGET:$PORT"

# 3.1 首页与响应头（拿 Server / X-Powered-By / 跳转 / Cookie 名）
curl -sSik "$BASE/" -o "$RESULT_DIR/web/root_headers.txt"
curl -sS "$BASE/" -o "$RESULT_DIR/web/root_body.html"

# 3.2 目录与文件爆破
ffuf -u "$BASE/FUZZ" -w /usr/share/wordlists/dirb/common.txt \
     -t 40 -mc 200,204,301,302,307,401,403,500 \
     -o "$RESULT_DIR/web/ffuf_dir.json" -of json

# 3.3 常见敏感路径定点验证
for p in robots.txt sitemap.xml .git/HEAD .env backup.zip swagger-ui.html \
         actuator/env api/ health status login admin; do
  code=$(curl -sS -o /dev/null -w '%{http_code}' "$BASE/$p")
  echo "$code  $p" | tee -a "$RESULT_DIR/web/sensitive_paths.txt"
done

# 3.4 从首页 JS 里提取接口（前端路由/接口常藏在 bundle 里）
grep -oE '"/[a-zA-Z0-9_./-]{2,}"' "$RESULT_DIR/web/root_body.html" \
  | tr -d '"' | sort -u > "$RESULT_DIR/web/js_paths.txt"
```

### 4. 非 Web 服务枚举（按 1.1 命中的服务选一行）

```bash
# SSH
nmap -Pn -p "$PORT" --script ssh-auth-methods,ssh-hostkey "$TARGET" -oN "$RESULT_DIR/nmap/ssh.txt"

# FTP
nmap -Pn -p "$PORT" --script ftp-anon,ftp-syst "$TARGET" -oN "$RESULT_DIR/nmap/ftp.txt"

# SMB
nmap -Pn -p "$PORT" --script smb-os-discovery,smb-enum-shares,smb-security-mode "$TARGET" \
  -oN "$RESULT_DIR/nmap/smb.txt"

# MySQL / Redis / 其他
nmap -Pn -p "$PORT" --script "mysql-*" "$TARGET" -oN "$RESULT_DIR/nmap/mysql.txt"
nmap -Pn -p "$PORT" --script "redis-*" "$TARGET" -oN "$RESULT_DIR/nmap/redis.txt"
```

### 5. 裸端口探测（无 banner 时）

```bash
# 5.1 原始握手，看是否回任何字节
printf 'GET / HTTP/1.0\r\nHost: %s\r\n\r\n' "$TARGET" | timeout 5 nc -nv "$TARGET" "$PORT" \
  | tee "$RESULT_DIR/raw/probe_http.txt"

# 5.2 空包 + 换行包，观察是否主动吐 banner
timeout 5 nc -nv "$TARGET" "$PORT" < /dev/null | tee "$RESULT_DIR/raw/probe_empty.txt"
printf '\r\n\r\n' | timeout 5 nc -nv "$TARGET" "$PORT" | tee "$RESULT_DIR/raw/probe_crlf.txt"

# 5.3 十六进制看原始响应（判断二进制协议 / 私有协议）
timeout 5 nc -nv "$TARGET" "$PORT" < /dev/null | xxd | head -40 \
  | tee "$RESULT_DIR/raw/probe_hex.txt"
```

### 6. 汇总落盘

```bash
{
  echo "== TARGET $TARGET:$PORT =="
  echo "-- nmap 服务 --"; grep -E '^[0-9]+/tcp' "$RESULT_DIR/nmap/port_${PORT}.txt"
  echo "-- HTTP 头 --";  head -20 "$RESULT_DIR/web/root_headers.txt" 2>/dev/null
  echo "-- 目录命中 --"; jq -r '.results[]? | "\(.status) \(.url)"' "$RESULT_DIR/web/ffuf_dir.json" 2>/dev/null
  echo "-- 敏感路径 --"; cat "$RESULT_DIR/web/sensitive_paths.txt" 2>/dev/null
} | tee "$RESULT_DIR/SUMMARY.txt"
```

### 执行顺序与判停点

1. 跑 1.1 → 拿到服务名，决定走 3 / 4 / 5。
2. 走 3 时，`ffuf` 命中 200/403 的路径逐个 `curl -sSik` 看响应体，把有内容的记进 `SUMMARY.txt`。
3. 走 4