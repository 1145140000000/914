## 站点信息收集命令链

> 选型：`subfinder` + `dnsx` + `httpx` + `nuclei` + `katana` + `ffuf`，全部输出落 `RESULT_DIR`，每步可单独重跑。

```bash
# ===== 0. 环境与目录 =====
export TARGET="example.com"
export RESULT_DIR="./recon_${TARGET}_$(date +%Y%m%d_%H%M)"
mkdir -p "$RESULT_DIR"/{subs,alive,finger,urls,dirs}
cd "$RESULT_DIR"

# 工具自检（缺哪个装哪个）
for t in subfinder dnsx httpx nuclei katana ffuf jq; do
  command -v $t >/dev/null || echo "[MISS] $t"
done
```

```bash
# ===== 1. 子域名枚举（被动多源 + 证书透明日志） =====
subfinder -d "$TARGET" -all -recursive -silent \
  -o subs/subfinder.txt

# 证书透明日志补充（crt.sh）
curl -s "https://crt.sh/?q=%25.${TARGET}&output=json" \
  | jq -r '.[].name_value' | sed 's/\*\.//g' | sort -u \
  > subs/crtsh.txt

# 合并去重
cat subs/subfinder.txt subs/crtsh.txt | sort -u > subs/all.txt
wc -l subs/all.txt
```

```bash
# ===== 2. 存活探测（DNS 解析 + HTTP 探活） =====
# 2.1 DNS 层：过滤掉不解析的
dnsx -l subs/all.txt -a -resp -silent \
  -o alive/dns_resolved.txt

# 2.2 HTTP 层：状态码 / 标题 / 技术栈 / CDN / 证书
httpx -l subs/all.txt \
  -ports 80,443,8080,8443,8000,9000 \
  -status-code -title -tech-detect -web-server -cdn -ip -cname \
  -follow-redirects -threads 100 -silent \
  -o alive/httpx_full.txt

# 只留存活的 URL 列表（后续步骤输入）
awk '{print $1}' alive/httpx_full.txt | sort -u > alive/urls.txt
wc -l alive/urls.txt
```

```bash
# ===== 3. 指纹识别（技术栈 + 框架 + WAF） =====
# 3.1 httpx 已带 tech-detect，这里做汇总统计
awk -F'[][]' '{for(i=2;i<=NF;i+=2) print $i}' alive/httpx_full.txt \
  | tr ',' '\n' | sed 's/^ *//;s/ *$//' | grep -v '^$' \
  | sort | uniq -c | sort -rn > finger/tech_summary.txt
cat finger/tech_summary.txt

# 3.2 WAF 识别
wafw00f -i alive/urls.txt -o finger/waf.txt -f json 2>/dev/null

# 3.3 nuclei 指纹模板（技术/面板/暴露面）
nuclei -l alive/urls.txt -tags tech,panel,exposure -silent \
  -o finger/nuclei_tech.txt
```

```bash
# ===== 4. URL / 接口收集（爬虫 + JS 提取 + 历史） =====
# 4.1 主动爬取
katana -list alive/urls.txt -d 3 -jc -kf all -silent \
  -o urls/katana.txt

# 4.2 历史 URL（wayback + commoncrawl）
cat alive/urls.txt | while read u; do
  echo "$u" | gau --threads 5
done 2>/dev/null | sort -u > urls/gau.txt

# 4.3 JS 文件里的接口/密钥提取
cat urls/katana.txt urls/gau.txt | sort -u \
  | grep -Ei '\.js(\?|$)' > urls/js_files.txt

cat urls/js_files.txt | while read js; do
  curl -s -m 10 "$js" | grep -Eo '"/[a-zA-Z0-9_/.-]{2,}"' 
done 2>/dev/null | tr -d '"' | sort -u > urls/api_from_js.txt

# 4.4 合并全部 URL 并去参归一
cat urls/katana.txt urls/gau.txt urls/api_from_js.txt | sort -u > urls/all_urls.txt
cat urls/all_urls.txt | sed 's/?.*//' | sort -u > urls/all_paths.txt
wc -l urls/all_urls.txt urls/all_paths.txt
```

```bash
# ===== 5. 目录 / 接口爆破 =====
# 5.1 目录爆破（按指纹选字典，这里给通用）
ffuf -u "https://${TARGET}/FUZZ" \
  -w /usr/share/seclists/Discovery/Web-Content/raft-medium-directories.txt \
  -mc 200,204,301,302,307,401,403 -t 80 -rate 150 \
  -o dirs/ffuf_dirs.json -of json

# 5.2 接口路径爆破（用第 4 步收集的路径做种子更准）
ffuf -u "https://${TARGET}/FUZZ" \
  -w urls/all_paths.txt -mc all -t 50 \
  -o dirs/ffuf_paths.json -of json

# 5.3 参数发现（对已知接口）
cat urls/all_urls.txt | grep '=' | head -50 | while read u; do
  echo "$u" | unfurl keys
done | sort -u > dirs/params.txt
```

```bash
# ===== 6. 汇总报告 =====
{
  echo "=== TARGET: $TARGET ==="
  echo "子域总数: $(wc -l < subs/all.txt)"
  echo "存活主机: $(wc -l < alive/urls.txt)"
  echo "URL 总数: $(wc -l < urls/all_urls.txt)"
  echo "唯一路径: $(wc -l < urls/all_paths.txt)"
  echo ""
  echo "--- 技术栈 TOP ---"
  head -20 finger/tech_summary.txt
  echo ""
  echo "--- 存活主机 ---"
  cat alive/httpx_full.txt
} | tee report.txt
```

**分步验证回显**

| 步骤 | 验证命令 | 预期回显 |
| --- | --- | --- |
| 子域 | `wc -l subs/all.txt` | 非 0 行数 |
| 存活 | `head alive/httpx_full.txt` | `https://x.example.com [200] [Title] [Tech]` |
| 指纹 |