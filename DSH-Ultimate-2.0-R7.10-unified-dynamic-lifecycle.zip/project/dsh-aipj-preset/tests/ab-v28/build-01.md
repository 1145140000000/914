## 记账小工具 `ledger.py`

> 选型：Python 3.8+ · 零第三方依赖 · 单文件 · SQLite 落盘 · CLI 交互 + 子命令

### 目录与入口

```
ledger/
├── ledger.py        # 唯一入口，全部逻辑
└── ledger.db        # 首次运行自动创建
```

### 完整实现

```python
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ledger.py — 单文件记账工具（SQLite 落盘，零依赖）

用法:
  python3 ledger.py add  -a 35.5 -c 餐饮 -n "午饭" [-d 2024-05-01]
  python3 ledger.py add  -a 8000 -c 工资 -n "月薪" --income
  python3 ledger.py list [-m 2024-05] [-c 餐饮] [-n 20]
  python3 ledger.py stat [-m 2024-05]
  python3 ledger.py del  <id>
  python3 ledger.py export -o out.csv [-m 2024-05]
"""
import argparse
import csv
import os
import sqlite3
import sys
from datetime import date, datetime

DB_PATH = os.environ.get("LEDGER_DB", os.path.join(os.path.dirname(os.path.abspath(__file__)), "ledger.db"))

SCHEMA = """
CREATE TABLE IF NOT EXISTS records (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    day      TEXT    NOT NULL,              -- YYYY-MM-DD
    amount   REAL    NOT NULL,              -- 正数
    kind     TEXT    NOT NULL CHECK(kind IN ('expense','income')),
    category TEXT    NOT NULL,
    note     TEXT    NOT NULL DEFAULT '',
    created  TEXT    NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_day ON records(day);
CREATE INDEX IF NOT EXISTS idx_cat ON records(category);
"""


def conn():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    c.executescript(SCHEMA)
    return c


def parse_day(s):
    if not s:
        return date.today().isoformat()
    try:
        return datetime.strptime(s, "%Y-%m-%d").date().isoformat()
    except ValueError:
        sys.exit(f"日期格式错误: {s}（应为 YYYY-MM-DD）")


def cmd_add(a):
    day = parse_day(a.date)
    amount = abs(float(a.amount))
    kind = "income" if a.income else "expense"
    with conn() as c:
        cur = c.execute(
            "INSERT INTO records(day,amount,kind,category,note,created) VALUES(?,?,?,?,?,?)",
            (day, amount, kind, a.category, a.note or "", datetime.now().isoformat(timespec="seconds")),
        )
        rid = cur.lastrowid
    sign = "+" if kind == "income" else "-"
    print(f"[OK] #{rid}  {day}  {sign}{amount:.2f}  {a.category}  {a.note or ''}")


def cmd_list(a):
    sql = "SELECT * FROM records WHERE 1=1"
    args = []
    if a.month:
        sql += " AND day LIKE ?"
        args.append(a.month + "%")
    if a.category:
        sql += " AND category = ?"
        args.append(a.category)
    sql += " ORDER BY day DESC, id DESC"
    if a.limit:
        sql += " LIMIT ?"
        args.append(a.limit)
    with conn() as c:
        rows = c.execute(sql, args).fetchall()
    if not rows:
        print("（无记录）")
        return
    print(f"{'ID':>4}  {'日期':<10}  {'类型':<4}  {'金额':>10}  {'分类':<8}  备注")
    print("-" * 68)
    for r in rows:
        sign = "+" if r["kind"] == "income" else "-"
        print(f"{r['id']:>4}  {r['day']:<10}  {r['kind']:<4}  {sign}{r['amount']:>9.2f}  {r['category']:<8}  {r['note']}")


def cmd_stat(a):
    where, args = "", []
    if a.month:
        where = " WHERE day LIKE ?"
        args.append(a.month + "%")
    with conn() as c:
        total = c.execute(
            f"SELECT kind, SUM(amount) s, COUNT(*) n FROM records{where} GROUP BY kind", args
        ).fetchall()
        by_cat = c.execute(
            f"SELECT category, kind, SUM(amount) s, COUNT(*) n FROM records{where} "
            f"GROUP BY category, kind ORDER BY s DESC", args
        ).fetchall()
    inc = next((r["s"] for r in total if r["kind"] == "income"), 0) or 0
    exp = next((r["s"] for r in total if r["kind"] == "expense"), 0) or 0
    scope = a.month or "全部"
    print(f"== 统计 [{scope}] ==")
    print(f"收入: {inc:>10.2f}")
    print(f"支出: {exp:>10.2f}")
    print(f"结余: {inc - exp:>10.2f}")
    if by_cat:
        print("\n-- 分类明细 --")
        for r in by_cat:
            sign = "+" if r["kind"] == "income" else "-"
            print(f"  {r['category']:<10} {sign}{r['s']:>9.2f}  ({r['n']} 笔)")


def cmd_del(a):
    with conn() as c:
        cur = c.execute("DELETE FROM records WHERE id=?", (a.id,))
    if cur.rowcount:
        print(f"[OK] 已删除 #{a.id}")
    else:
        print(f"[!] 未找到 #{a.id}")


def cmd_export(a):
    sql = "SELECT id,day,kind,amount,category,note,created FROM records"
    args = []
    if a.month:
        sql += " WHERE day LIKE ?"
        args.append(a.month + "%")
    sql += " ORDER BY day, id"
    with conn() as c:
        rows = c.execute(sql, args).fetchall()
    with open(a.output, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["id", "日期", "类型", "金额", "分类", "备注", "创建时间"])
        for r in rows:
            w.writerow([r["id"], r["day"], r["kind"], f"{r['amount']:.2f}", r["category"], r["note"], r["created"]])
    print(f"[OK] 已导出 {len(rows)} 条 → {a.output}")


def build_parser():
    p =