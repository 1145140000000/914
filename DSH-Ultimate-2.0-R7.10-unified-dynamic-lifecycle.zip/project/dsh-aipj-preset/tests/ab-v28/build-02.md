## `batch_rename.py` — 批量改文件名脚本

> 选型：Python 3.8+ · 零第三方依赖 · 单文件 · 支持正则替换 / 序号重命名 / 前后缀增删 / 大小写转换 / 递归 / 试运行

### 目录与入口

```
batch_rename.py      # 唯一文件，直接运行
```

### 完整实现

```python
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
batch_rename.py — 批量改文件名

用法示例：
  # 1) 正则替换（默认试运行，不落盘）
  python batch_rename.py ./photos --regex "IMG_(\\d+)" --repl "vacation_\\1"

  # 2) 加前缀 + 转小写，真正执行
  python batch_rename.py ./docs --prefix "2024_" --lower --apply

  # 3) 序号重命名：photo_001.jpg, photo_002.jpg ...
  python batch_rename.py ./imgs --number --pattern "photo_{:03d}" --start 1 --apply

  # 4) 递归处理子目录，只改 .jpg/.png
  python batch_rename.py ./imgs --recursive --ext .jpg .png --suffix "_final" --apply

  # 5) 从清单文件批量改（每行: 旧名<TAB>新名）
  python batch_rename.py ./dir --map rename_list.txt --apply
"""
import argparse
import os
import re
import sys
from pathlib import Path

def collect_files(root: Path, recursive: bool, exts):
    """收集待处理文件，返回 Path 列表（排序保证序号稳定）。"""
    it = root.rglob("*") if recursive else root.glob("*")
    files = [p for p in it if p.is_file()]
    if exts:
        norm = {e.lower() if e.startswith(".") else "." + e.lower() for e in exts}
        files = [p for p in files if p.suffix.lower() in norm]
    return sorted(files, key=lambda p: str(p))

def build_new_name(path: Path, args, index: int) -> str:
    """根据参数计算单个文件的新文件名（不含目录）。"""
    stem, suffix = path.stem, path.suffix

    # 1) 清单映射优先
    if args.map and str(path.name) in args.map:
        return args.map[str(path.name)]

    # 2) 正则替换
    if args.regex is not None:
        stem = re.sub(args.regex, args.repl or "", stem)

    # 3) 大小写
    if args.lower:
        stem = stem.lower()
    if args.upper:
        stem = stem.upper()

    # 4) 前后缀
    if args.prefix:
        stem = args.prefix + stem
    if args.suffix:
        stem = stem + args.suffix

    # 5) 序号重命名（覆盖 stem，保留扩展名）
    if args.number:
        pattern = args.pattern or "{:04d}"
        stem = pattern.format(args.start + index)

    return stem + suffix

def load_map(map_file: Path) -> dict:
    """读取映射清单：每行 旧名<TAB>新名，忽略空行与 # 注释。"""
    mapping = {}
    with map_file.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.rstrip("\n")
            if not line or line.lstrip().startswith("#"):
                continue
            parts = line.split("\t")
            if len(parts) != 2:
                print(f"[warn] 跳过格式错误行: {line!r}", file=sys.stderr)
                continue
            mapping[parts[0]] = parts[1]
    return mapping

def main():
    ap = argparse.ArgumentParser(description="批量改文件名")
    ap.add_argument("target", help="目标目录")
    ap.add_argument("--regex", help="正则表达式（作用于文件名主干，不含扩展名）")
    ap.add_argument("--repl", default="", help="正则替换串，支持 \\1 反向引用")
    ap.add_argument("--prefix", default="", help="加前缀")
    ap.add_argument("--suffix", default="", help="加后缀（在扩展名前）")
    ap.add_argument("--lower", action="store_true", help="转小写")
    ap.add_argument("--upper", action="store_true", help="转大写")
    ap.add_argument("--number", action="store_true", help="按序号重命名")
    ap.add_argument("--pattern", default="{:04d}", help="序号格式，默认 {:04d}")
    ap.add_argument("--start", type=int, default=1, help="序号起始值，默认 1")
    ap.add_argument("--ext", nargs="+", help="只处理这些扩展名，如 .jpg .png")
    ap.add_argument("--recursive", action="store_true", help="递归子目录")
    ap.add_argument("--map", help="映射清单文件（旧名<TAB>新名）")
    ap.add_argument("--apply", action="store_true", help="真正执行（默认试运行）")
    args = ap.parse_args()

    root = Path(args.target)
    if not root.is_dir():
        print(f"[error] 不是目录: {root}", file=sys.stderr)
        return 1

    mapping = load_map(Path(args.map)) if args.map else None
    files = collect_files(root, args.recursive, args.ext)
    if not files:
        print("[info] 没有匹配的文件")
        return 0

    plan = []          # (src, dst)
    seen = set()       # 目标名去重
    for i, src in enumerate(files):
        new_name = build_new_name(src, args, i)
        dst = src.with_name(new_name)
        if dst == src:
            continue
        key = str(dst).lower()
        if key in seen:
            print(f"[warn] 目标名冲突，跳过: {dst}", file=sys.stderr)
            continue
        seen.add(key)
        plan.append((src, dst))

    if not plan:
        print("[info] 无需改名")
        return 0

    # 打印计划
    for src, dst in plan:
        print(f"{src.name}  ->  {dst.name}")

    if not args.apply:
        print(f"\n[试运行] 共 {len(plan)} 项待改。加 --apply 真正执行。")
        return 0

    # 执行：先改到临时名，避免 A->B、B->A 互相覆盖
    tmp_pairs = []
    ok = 0
    for idx, (src, dst) in enumerate(plan):
        tmp = src.with_name(f".__rn_tmp_{idx}__{src.name}")
        try:
            src.rename(tmp)
            tmp_pairs.append((tmp, dst))
        except OSError as e:
            print(f"[error] 临时改名失败 {src}: {e}", file=sys.stderr)

    for tmp, dst in tmp