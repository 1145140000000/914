## 静态博客生成器 · 完整可运行产物

> 选型：Node 20 · 零第三方依赖 · 单文件生成器 `build.js` · Markdown 子集解析 · 输出纯静态 `dist/`

### 目录结构

```
blog/
├── build.js              # 生成器（唯一入口）
├── package.json
├── content/
│   ├── hello-world.md
│   └── static-site-notes.md
├── templates/
│   ├── layout.html
│   ├── index.html
│   └── post.html
└── static/
    └── style.css
```

### `package.json`

```json
{
  "name": "static-blog",
  "version": "1.0.0",
  "private": true,
  "type": "module",
  "scripts": {
    "build": "node build.js",
    "serve": "node build.js --serve"
  },
  "engines": { "node": ">=18" }
}
```

### `build.js`

```js
#!/usr/bin/env node
// 零依赖静态博客生成器：Markdown -> HTML，含索引、标签、RSS、内置静态服务器
import { readFileSync, writeFileSync, mkdirSync, readdirSync, rmSync, existsSync } from 'node:fs';
import { join, dirname, basename, extname } from 'node:path';
import { createServer } from 'node:http';
import { fileURLToPath } from 'node:url';

const ROOT = dirname(fileURLToPath(import.meta.url));
const CONTENT = join(ROOT, 'content');
const TEMPLATES = join(ROOT, 'templates');
const STATIC = join(ROOT, 'static');
const DIST = join(ROOT, 'dist');

const SITE = {
  title: '我的静态博客',
  author: 'ROLE_A',
  description: '一个零依赖的静态博客',
  url: 'http://localhost:8080',
};

// ---------- 极简 Markdown 解析 ----------
function escapeHtml(s) {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
          .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function inline(s) {
  let out = escapeHtml(s);
  out = out.replace(/`([^`]+)`/g, (_, c) => `<code>${c}</code>`);
  out = out.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  out = out.replace(/\*([^*]+)\*/g, '<em>$1</em>');
  out = out.replace(/!\[([^\]]*)\]\(([^)]+)\)/g, '<img alt="$1" src="$2">');
  out = out.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2">$1</a>');
  return out;
}

function markdown(src) {
  const lines = src.replace(/\r\n/g, '\n').split('\n');
  const html = [];
  let i = 0;
  let inCode = false, codeBuf = [], codeLang = '';
  let listType = null, listBuf = [];

  const flushList = () => {
    if (listType) {
      html.push(`<${listType}>` + listBuf.map(x => `<li>${inline(x)}</li>`).join('') + `</${listType}>`);
      listType = null; listBuf = [];
    }
  };

  while (i < lines.length) {
    const line = lines[i];

    if (inCode) {
      if (/^```/.test(line)) {
        html.push(`<pre><code class="lang-${codeLang}">${escapeHtml(codeBuf.join('\n'))}</code></pre>`);
        inCode = false; codeBuf = []; codeLang = '';
      } else codeBuf.push(line);
      i++; continue;
    }

    const fence = line.match(/^```(\w*)/);
    if (fence) { flushList(); inCode = true; codeLang = fence[1] || 'text'; i++; continue; }

    if (/^\s*$/.test(line)) { flushList(); i++; continue; }

    const h = line.match(/^(#{1,6})\s+(.*)$/);
    if (h) { flushList(); const n = h[1].length; html.push(`<h${n}>${inline(h[2])}</h${n}>`); i++; continue; }

    if (/^>\s?/.test(line)) {
      flushList();
      const buf = [];
      while (i < lines.length && /^>\s?/.test(lines[i])) { buf.push(lines[i].replace(/^>\s?/, '')); i++; }
      html.push(`<blockquote>${markdown(buf.join('\n'))}</blockquote>`);
      continue;
    }

    if (/^\s*[-*+]\s+/.test(line)) {
      if (listType !== 'ul') { flushList(); listType = 'ul'; }
      listBuf.push(line.replace(/^\s*[-*+]\s+/, '')); i++; continue;
    }
    if (/^\s*\d+\.\s+/.test(line)) {
      if (listType !== 'ol') { flushList(); listType = 'ol'; }
      listBuf.push(line.replace(/^\s*\d+\.\s+/, '')); i++; continue;
    }

    if (/^---+$/.test(line)) { flushList(); html.push('<hr>'); i++; continue; }

    // 段落
    flushList();
    const buf = [];
    while (i < lines.length && !/^\s*$/.test(lines[i]) && !/^(#{1,6}\s|```|>|\s*[-*+]\s|\s*\d+\.\s|---+$)/.test(lines[i])) {
      buf.push(lines[i]); i++;
    }
    html.push(`<p>${inline(buf.join(' '))}</p>`);
  }
  flushList();
  if (inCode) html.push(`<pre><code>${escapeHtml(codeBuf.join('\n'))}</code></pre>`);
  return html.join('\n');
}

// ---------- 模板 ----------
function render(tpl, vars) {
  return tpl.replace(/\{\{\s*(\w+)\s*\}\}/g, (_, k) => vars[k] ?? '');
}

function readTpl(name) { return readFileSync(join(TEMPLATES, name), 'utf8'); }

// ---------- 文章解析 ----------
function parseFrontMatter(raw) {
  const m = raw.match(/^---\n([\s\S]*?)\n---\n?([\s\S]*)$/);
  if (!m) return { meta: {}, body: raw };
  const meta = {};
  for (const line of m[1].split('\n')) {
    const kv = line.match(/^(\w+):\s*(.*)$/);
    if (!kv) continue;
    let v = kv