## 命令行待办清单 `todo.py`

> 选型：Python 3.8+ · 零第三方依赖 · 单文件 · JSON 落盘 · 支持增删改查/完成/优先级/截止日期/搜索/统计

### 目录与入口

```
todo/
└── todo.py          # 唯一入口，chmod +x 后可直接 ./todo.py
```

数据文件默认 `~/.todo.json`，可用环境变量 `TODO_FILE` 覆盖。

### 完整实现

```python
#!/usr/bin/env python3
"""todo.py — 命令行待办清单（零依赖，单文件）"""

import argparse
import json
import os
import sys
from datetime import datetime, date

DATA_FILE = os.environ.get("TODO_FILE", os.path.expanduser("~/.todo.json"))
PRIORITIES = {"h": "high", "m": "medium", "l": "low"}
PRIORITY_ORDER = {"high": 0, "medium": 1, "low": 2}


# ---------- 存储层 ----------
def load():
    if not os.path.exists(DATA_FILE):
        return {"next_id": 1, "items": []}
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        sys.exit(f"读取数据文件失败: {DATA_FILE}: {e}")
    data.setdefault("next_id", 1)
    data.setdefault("items", [])
    return data


def save(data):
    tmp = DATA_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, DATA_FILE)


# ---------- 业务层 ----------
def add_item(data, text, priority="medium", due=None):
    item = {
        "id": data["next_id"],
        "text": text,
        "priority": priority,
        "due": due,
        "done": False,
        "created": datetime.now().isoformat(timespec="seconds"),
        "completed": None,
    }
    data["next_id"] += 1
    data["items"].append(item)
    return item


def find(data, item_id):
    for it in data["items"]:
        if it["id"] == item_id:
            return it
    return None


def sort_key(it):
    due = it["due"] or "9999-99-99"
    return (it["done"], PRIORITY_ORDER.get(it["priority"], 1), due, it["id"])


def fmt_item(it):
    mark = "x" if it["done"] else " "
    pri = {"high": "!", "medium": "-", "low": "."}.get(it["priority"], "-")
    due = f"  due:{it['due']}" if it["due"] else ""
    return f"[{mark}] #{it['id']:<3} ({pri}) {it['text']}{due}"


def parse_due(s):
    if not s:
        return None
    try:
        return date.fromisoformat(s).isoformat()
    except ValueError:
        sys.exit(f"日期格式错误: {s}（应为 YYYY-MM-DD）")


# ---------- 命令实现 ----------
def cmd_add(args):
    data = load()
    it = add_item(data, args.text, PRIORITIES[args.priority], parse_due(args.due))
    save(data)
    print(f"已添加 {fmt_item(it)}")


def cmd_list(args):
    data = load()
    items = data["items"]
    if args.pending:
        items = [i for i in items if not i["done"]]
    if args.done:
        items = [i for i in items if i["done"]]
    if args.tag:
        items = [i for i in items if args.tag in i["text"]]
    items = sorted(items, key=sort_key)
    if not items:
        print("（无匹配条目）")
        return
    for it in items:
        print(fmt_item(it))
    print(f"\n共 {len(items)} 条")


def cmd_done(args):
    data = load()
    it = find(data, args.id)
    if not it:
        sys.exit(f"未找到 #{args.id}")
    it["done"] = True
    it["completed"] = datetime.now().isoformat(timespec="seconds")
    save(data)
    print(f"已完成 {fmt_item(it)}")


def cmd_undone(args):
    data = load()
    it = find(data, args.id)
    if not it:
        sys.exit(f"未找到 #{args.id}")
    it["done"] = False
    it["completed"] = None
    save(data)
    print(f"已恢复 {fmt_item(it)}")


def cmd_rm(args):
    data = load()
    before = len(data["items"])
    data["items"] = [i for i in data["items"] if i["id"] != args.id]
    if len(data["items"]) == before:
        sys.exit(f"未找到 #{args.id}")
    save(data)
    print(f"已删除 #{args.id}")


def cmd_edit(args):
    data = load()
    it = find(data, args.id)
    if not it:
        sys.exit(f"未找到 #{args.id}")
    if args.text is not None:
        it["text"] = args.text
    if args.priority is not None:
        it["priority"] = PRIORITIES[args.priority]
    if args.due is not None:
        it["due"] = parse_due(args.due) if args.due != "-" else None
    save(data)
    print(f"已更新 {fmt_item(it)}")


def cmd_clear(args):
    data = load()
    if args.done:
        n = sum(1 for i in data["items"] if i["done"])
        data["items"] = [i for i in data["items"] if not i["done"]]
    else:
        n = len(data["items"])
        data["items"] = []
    save(data)
    print(f"已清除 {n} 条")


def cmd_stats(args):
    data = load()
    items = data["items"]
    total = len(items)
    done = sum(1 for i in items if i["done"])
    today = date.today().isoformat()
    overdue = sum(1 for i in items if not i["done"] and i["due"] and i["due"] < today)
    by_pri = {p: sum(1 for i in items if i["priority"] == p and not i["done"])
              for p in PRIORITY_ORDER}
    print(f"总计 {total} | 已完成 {done} | 未完成 {total - done} | 逾期 {overdue}")
    print(f"未完成按优先级: high={by_pri['high']} medium={by_pri['medium']} low={by_pri['low']}")


# ---------- CLI ----------
def build_parser():
    p = argparse.ArgumentParser(prog="todo", description="命令行待办清单")
    sub = p.add_subparsers(dest="cmd", required=True)

