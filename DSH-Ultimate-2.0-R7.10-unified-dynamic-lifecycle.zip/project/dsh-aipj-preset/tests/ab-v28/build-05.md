## 爬虫：`spider.py`

> 选型：Python 3.10+ · 依赖 `requests` + `beautifulsoup4` · 单文件 · 通用站点采集器（列表页 → 详情页 → 落盘 JSONL + 断点续采 + 限速重试）

### 目录与入口

```
spider/
├── spider.py        # 入口，单文件
└── requirements.txt
```

`requirements.txt`：

```
requests>=2.31
beautifulsoup4>=4.12
```

### 完整实现 `spider.py`

```python
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
通用站点采集器
- 列表页翻页 -> 详情页解析 -> JSONL 落盘
- 断点续采（已采 URL 记入 seen.txt，重启跳过）
- 限速 + 指数退避重试 + 自定义 UA
- 选择器通过 CSS Selector 配置，适配不同站点
"""

import argparse
import hashlib
import json
import os
import random
import re
import sys
import time
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup

DEFAULT_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0.0.0 Safari/537.36"
)


class Spider:
    def __init__(self, args):
        self.args = args
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": args.ua or DEFAULT_UA,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
        })
        if args.cookie:
            self.session.headers["Cookie"] = args.cookie

        os.makedirs(args.outdir, exist_ok=True)
        self.out_path = os.path.join(args.outdir, "items.jsonl")
        self.seen_path = os.path.join(args.outdir, "seen.txt")
        self.seen = self._load_seen()
        self.count = 0

    # ---------- 断点续采 ----------
    def _load_seen(self):
        if not os.path.exists(self.seen_path):
            return set()
        with open(self.seen_path, "r", encoding="utf-8") as f:
            return {line.strip() for line in f if line.strip()}

    def _mark_seen(self, url):
        self.seen.add(url)
        with open(self.seen_path, "a", encoding="utf-8") as f:
            f.write(url + "\n")

    # ---------- 请求（限速 + 重试） ----------
    def fetch(self, url):
        for attempt in range(1, self.args.retries + 1):
            try:
                time.sleep(self.args.delay + random.uniform(0, self.args.jitter))
                resp = self.session.get(url, timeout=self.args.timeout)
                resp.raise_for_status()
                resp.encoding = resp.apparent_encoding or resp.encoding
                return resp.text
            except requests.RequestException as e:
                wait = min(2 ** attempt, 30)
                print(f"[retry {attempt}/{self.args.retries}] {url} -> {e}，{wait}s 后重试",
                      file=sys.stderr)
                time.sleep(wait)
        print(f"[fail] {url} 放弃", file=sys.stderr)
        return None

    # ---------- 列表页：抽取详情链接 ----------
    def extract_links(self, html, base_url):
        soup = BeautifulSoup(html, "html.parser")
        links = []
        for a in soup.select(self.args.link_selector):
            href = a.get("href")
            if not href:
                continue
            full = urljoin(base_url, href)
            if self.args.same_domain:
                if urlparse(full).netloc != urlparse(base_url).netloc:
                    continue
            if full not in self.seen:
                links.append(full)
        return links

    # ---------- 详情页：解析字段 ----------
    def parse_detail(self, html, url):
        soup = BeautifulSoup(html, "html.parser")
        item = {"url": url}

        title_el = soup.select_one(self.args.title_selector)
        item["title"] = title_el.get_text(strip=True) if title_el else ""

        content_el = soup.select_one(self.args.content_selector)
        if content_el:
            text = content_el.get_text("\n", strip=True)
            item["content"] = re.sub(r"\n{2,}", "\n", text)
        else:
            item["content"] = ""

        # 额外字段：--field name=selector 可重复
        for spec in self.args.field or []:
            name, _, sel = spec.partition("=")
            el = soup.select_one(sel)
            item[name] = el.get_text(strip=True) if el else ""

        item["fetched_at"] = int(time.time())
        item["hash"] = hashlib.md5(item["content"].encode("utf-8")).hexdigest()[:12]
        return item

    # ---------- 落盘 ----------
    def save(self, item):
        with open(self.out_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(item, ensure_ascii=False) + "\n")
        self.count += 1
        print(f"[{self.count}] {item['title'][:40]}  {item['url']}")

    # ---------- 主流程 ----------
    def run(self):
        start = self.args.start
        page = 1
        while page <= self.args.max_pages:
            if "{page}" in start:
                list_url = start.format(page=page)
            else:
                list_url = start
            print(f"[list] page={page} {list_url}")
            html = self.fetch(list_url)
            if not html:
                break

            links = self.extract_links(html, list_url)
            if not links:
                print("[list] 无新链接，停止翻页")
                break

            for link in links:
                if self.args.limit and self.count >= self.args.limit:
                    print(f"[done] 达到上限 {self.args.limit}")
                    return
                detail_html = self.fetch(link)
                if not detail_html:
                    continue
                item = self.parse_detail(detail_html, link)
                self.save(item)
                self._mark_seen(link)

            if "{page}" not in start:
                break
            page += 1

        print(f"[done] 共采集 {self.count} 条 -> {self.out_path}")


def build_parser():
    p = argparse.ArgumentParser(description="通用站点采集器")
    p.add_argument("--start", required=True,
                   help="列表页起始 URL，含 {page} 占位则自动翻页