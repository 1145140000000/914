## 用户表测试数据

> 选型：MySQL 8.0 语法 · 单文件 SQL · 1000 行用户数据 · 含边界值/脏数据/关联表

### 表结构

```sql
-- schema.sql
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `username`    VARCHAR(32)     NOT NULL,
  `email`       VARCHAR(128)    NOT NULL,
  `phone`       VARCHAR(20)     DEFAULT NULL,
  `password_hash` CHAR(60)      NOT NULL,
  `nickname`    VARCHAR(64)     DEFAULT NULL,
  `avatar_url`  VARCHAR(255)    DEFAULT NULL,
  `gender`      TINYINT         NOT NULL DEFAULT 0 COMMENT '0未知 1男 2女',
  `birthday`    DATE            DEFAULT NULL,
  `status`      TINYINT         NOT NULL DEFAULT 1 COMMENT '0禁用 1正常 2待验证 3注销',
  `balance`     DECIMAL(12,2)   NOT NULL DEFAULT 0.00,
  `login_count` INT UNSIGNED    NOT NULL DEFAULT 0,
  `last_login_at` DATETIME      DEFAULT NULL,
  `created_at`  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`),
  UNIQUE KEY `uk_email` (`email`),
  KEY `idx_status` (`status`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

### 生成脚本（Python，产出 1000 行 INSERT）

```python
# gen_users.py
import random, hashlib, datetime, string

random.seed(20240501)
N = 1000
SURNAME = "赵钱孙李周吴郑王冯陈褚卫蒋沈韩杨朱秦尤许何吕施张孔曹严华金魏陶姜"
GIVEN   = ["伟","芳","娜","敏","静","丽","强","磊","军","洋","勇","艳","杰","娟","涛","明","超","秀英","霞","平"]
DOMAINS = ["example.com","test.local","mail.dev","corp.internal"]
STATUS  = [1]*80 + [0]*8 + [2]*8 + [3]*4   # 80%正常

def bcrypt_like(pw: str) -> str:
    # 占位：真实环境用 bcrypt.hashpw；此处产出 60 字符定长串
    h = hashlib.sha256(pw.encode()).hexdigest()
    return ("$2b$12$" + h)[:60]

def rand_date(start, end):
    d = end - start
    return start + datetime.timedelta(days=random.randint(0, d.days))

rows = []
used_u, used_e = set(), set()

# 1) 边界/脏数据先占位
edge = [
    ("a", "a@example.com", None, 0, None, 0, "0.00", 0, None),
    ("user_with_a_very_long_name_12345", "long" + "x"*60 + "@example.com", "+8613800138000", 1, "2000-02-29", 1, "99999999.99", 999999, "2024-01-01 00:00:00"),
    ("张三", "zhangsan@example.com", "13800138000", 2, "1990-01-01", 1, "0.01", 1, "2024-05-01 12:00:00"),
    ("emoji_user", "emoji@example.com", None, 0, None, 2, "0.00", 0, None),
    ("null_nick", "nullnick@example.com", "", 0, None, 1, "0.00", 0, None),
]
for i, (u, e, ph, g, bd, st, bal, lc, ll) in enumerate(edge):
    used_u.add(u); used_e.add(e)
    rows.append((u, e, ph, bcrypt_like(u), None if i % 2 else "昵称" + str(i),
                 None if i % 3 else "https://cdn.example.com/a/%d.png" % i,
                 g, bd, st, bal, lc, ll))

# 2) 批量随机
while len(rows) < N:
    u = random.choice(SURNAME) + random.choice(GIVEN) + str(random.randint(1, 9999))
    if u in used_u: continue
    e = "%s@%s" % (u.lower().encode("utf-8").hex()[:12], random.choice(DOMAINS))
    if e in used_e: continue
    used_u.add(u); used_e.add(e)
    phone = "1%02d%08d" % (random.randint(30,99), random.randint(0, 99999999)) if random.random() < 0.85 else None
    gender = random.choice([0,1,2])
    bd = rand_date(datetime.date(1950,1,1), datetime.date(2010,12,31)).isoformat() if random.random() < 0.7 else None
    st = random.choice(STATUS)
    bal = "%.2f" % random.choice([0, 0, 0, random.uniform(0, 5000)])
    lc = random.randint(0, 5000)
    ll = (datetime.datetime(2024,1,1) + datetime.timedelta(minutes=random.randint(0, 200000))).strftime("%Y-%m-%d %H:%M:%S") if lc else None
    rows.append((u, e, phone, bcrypt_like(u), random.choice(GIVEN) + "的昵称",
                 None, gender, bd, st, bal, lc, ll))

def esc(v):
    if v is None: return "NULL"
    if isinstance(v, (int, float)): return str(v)
    return "'" + str(v).replace("\\", "\\\\").replace("'", "''") + "'"

with open("users_seed.sql", "w", encoding="utf-8") as f:
    f.write("SET NAMES utf8mb4;\nSTART TRANSACTION;\n")
    f.write("INSERT INTO `users` (`username`,`email`,`phone`,`password_hash`,`nickname`,`avatar_url`,`gender`,`birthday`,`status`,`balance`,`login_count`,`last_login_at`) VALUES\n")
    for i, r in enumerate(rows):
        f.write("(" + ",".join(esc(x) for x in r) + ")" + (",\n" if i < len(rows)-1 else ";\n"))
    f.write("COMMIT;\n")
print("rows:", len(rows