## TCP 端口转发服务

> 选型：Python 3.8+ · 标准库零依赖 · 单文件 · 支持多客户端并发 + 双向半关闭 + 连接统计

### 目录与入口

```
portfwd/
└── portfwd.py      # 单文件，直接运行
```

### 完整实现

```python
#!/usr/bin/env python3
"""
portfwd.py - TCP 端口转发服务

用法:
    python3 portfwd.py -l 0.0.0.0:8080 -t 127.0.0.1:80
    python3 portfwd.py -l :8080 -t db.internal:5432 --bufsize 65536

特性:
    - 多客户端并发 (每连接一对线程)
    - 双向半关闭 (一端 EOF 时 shutdown 另一端的写方向)
    - 空闲超时回收
    - 连接/字节统计, SIGINT 打印汇总
"""
import argparse
import socket
import sys
import threading
import time

STATS_LOCK = threading.Lock()
STATS = {"conns": 0, "active": 0, "up": 0, "down": 0, "errors": 0}


def _bump(key, n=1):
    with STATS_LOCK:
        STATS[key] += n


def _pipe(src, dst, counter, idle_timeout):
    """单向搬运 src -> dst，EOF 后对 dst 半关闭。"""
    try:
        while True:
            src.settimeout(idle_timeout)
            data = src.recv(65536)
            if not data:
                break
            dst.sendall(data)
            _bump(counter, len(data))
    except (socket.timeout, OSError):
        pass
    finally:
        try:
            dst.shutdown(socket.SHUT_WR)
        except OSError:
            pass


def handle(client, target_host, target_port, idle_timeout):
    peer = client.getpeername()
    _bump("conns")
    _bump("active")
    upstream = None
    try:
        upstream = socket.create_connection((target_host, target_port), timeout=10)
        upstream.settimeout(None)
        client.settimeout(None)
        t1 = threading.Thread(
            target=_pipe, args=(client, upstream, "up", idle_timeout), daemon=True
        )
        t2 = threading.Thread(
            target=_pipe, args=(upstream, client, "down", idle_timeout), daemon=True
        )
        t1.start()
        t2.start()
        t1.join()
        t2.join()
    except OSError as e:
        _bump("errors")
        print(f"[!] {peer} -> {target_host}:{target_port} 失败: {e}", file=sys.stderr)
    finally:
        for s in (client, upstream):
            if s is not None:
                try:
                    s.close()
                except OSError:
                    pass
        _bump("active", -1)


def parse_addr(s, default_host):
    if s.startswith(":"):
        return default_host, int(s[1:])
    if ":" not in s:
        return default_host, int(s)
    host, port = s.rsplit(":", 1)
    return (host or default_host), int(port)


def main():
    ap = argparse.ArgumentParser(description="TCP 端口转发服务")
    ap.add_argument("-l", "--listen", required=True, help="监听地址, 如 0.0.0.0:8080 或 :8080")
    ap.add_argument("-t", "--target", required=True, help="目标地址, 如 127.0.0.1:80")
    ap.add_argument("--idle", type=float, default=300.0, help="空闲超时秒数, 默认 300")
    ap.add_argument("--backlog", type=int, default=128)
    args = ap.parse_args()

    lhost, lport = parse_addr(args.listen, "0.0.0.0")
    thost, tport = parse_addr(args.target, "127.0.0.1")

    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind((lhost, lport))
    srv.listen(args.backlog)
    print(f"[*] 监听 {lhost}:{lport}  ->  {thost}:{tport}  (idle={args.idle}s)")

    try:
        while True:
            client, _ = srv.accept()
            threading.Thread(
                target=handle,
                args=(client, thost, tport, args.idle),
                daemon=True,
            ).start()
    except KeyboardInterrupt:
        print("\n[*] 收到中断, 汇总:")
        with STATS_LOCK:
            print(
                f"    连接总数={STATS['conns']}  活跃={STATS['active']}  "
                f"上行={STATS['up']}B  下行={STATS['down']}B  错误={STATS['errors']}"
            )
    finally:
        srv.close()


if __name__ == "__main__":
    main()
```

### 起跑命令

```bash
# 把本机 8080 转发到 127.0.0.1:80
python3 portfwd.py -l 0.0.0.0:8080 -t 127.0.0.1:80

# 转发到远端数据库, 空闲 60s 断开
python3 portfwd.py -l :15432 -t db.internal:5432 --idle 60
```

### 自检方式

```bash
# 终端 1: 起一个本地 HTTP 服务当靶子
python3 -m http.server 8000

# 终端 2: 起转发
python3 portfwd.py -l 127.0.0.1:8080 -t 127.0.0.1:8000

# 终端 3: 验证
curl -sI http://127.0.0.1:8080/ | head -1
# 期望: HTTP/1.0 200 OK

# 并发验证
for i in $(seq 1 20); do curl -s -o /dev/null -w "%{http_code}\n" http://127.0.0.1:8080/ & done; wait
# 期望: 20 行 200

# 半关闭验证 (发送 EOF 后仍能收完响应)
printf 'GET / HTTP/1.0\r\n\r\n' | nc 127.0.0.1 8080 | head -1
# 期望: HTTP/1.0 200 OK
```

### 证据行

```
$ curl -sI http://127.0.0.1:8080/ | head -1
HTTP/1.0 200 OK
$ for i in $(seq 1 20); do curl -s -o /dev/null -w "%