## `quicksort.py`

> 选型：Python 3.8+ · 零依赖 · 单文件 · 含原地快排 + 三路分区 + 自检

```python
#!/usr/bin/env python3
"""快速排序：原地版 + 三路分区版，含自检。"""

import random
import sys


def quicksort(a, lo=0, hi=None):
    """原地快排（Lomuto 分区，尾递归优化）。"""
    if hi is None:
        hi = len(a) - 1
    while lo < hi:
        p = _partition(a, lo, hi)
        # 先递归较短的一侧，栈深度 O(log n)
        if p - lo < hi - p:
            quicksort(a, lo, p - 1)
            lo = p + 1
        else:
            quicksort(a, p + 1, hi)
            hi = p - 1
    return a


def _partition(a, lo, hi):
    mid = (lo + hi) // 2
    # 三数取中，避免有序输入退化
    if a[mid] < a[lo]:
        a[lo], a[mid] = a[mid], a[lo]
    if a[hi] < a[lo]:
        a[lo], a[hi] = a[hi], a[lo]
    if a[hi] < a[mid]:
        a[mid], a[hi] = a[hi], a[mid]
    a[mid], a[hi] = a[hi], a[mid]
    pivot = a[hi]
    i = lo
    for j in range(lo, hi):
        if a[j] < pivot:
            a[i], a[j] = a[j], a[i]
            i += 1
    a[i], a[hi] = a[hi], a[i]
    return i


def quicksort3(a, lo=0, hi=None):
    """三路分区快排，大量重复元素时接近 O(n)。"""
    if hi is None:
        hi = len(a) - 1
    if lo >= hi:
        return a
    lt, gt = _partition3(a, lo, hi)
    quicksort3(a, lo, lt - 1)
    quicksort3(a, gt + 1, hi)
    return a


def _partition3(a, lo, hi):
    pivot = a[lo]
    lt, i, gt = lo, lo + 1, hi
    while i <= gt:
        if a[i] < pivot:
            a[lt], a[i] = a[i], a[lt]
            lt += 1
            i += 1
        elif a[i] > pivot:
            a[i], a[gt] = a[gt], a[i]
            gt -= 1
        else:
            i += 1
    return lt, gt


def _selfcheck():
    cases = [
        [],
        [1],
        [2, 1],
        [5, 4, 3, 2, 1],
        [1, 2, 3, 4, 5],
        [3, 3, 3, 3, 3],
        [0, -1, 5, -1, 3, 0, 2],
        list(range(100, 0, -1)),
    ]
    for _ in range(200):
        cases.append([random.randint(-50, 50) for _ in range(random.randint(0, 60))])

    for fn in (quicksort, quicksort3):
        for c in cases:
            got = fn(list(c))
            want = sorted(c)
            assert got == want, f"{fn.__name__} 失败: {c} -> {got} != {want}"
    print(f"自检通过：{len(cases)} 组用例 × 2 种实现")


if __name__ == "__main__":
    if len(sys.argv) > 1:
        nums = [int(x) for x in sys.argv[1:]]
        print(quicksort(nums))
    else:
        _selfcheck()
        print(quicksort([3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5]))
```

### 起跑命令

```bash
python3 quicksort.py                 # 跑自检 + 示例
python3 quicksort.py 9 3 7 1 5       # 排序命令行参数
```

### 自检方式

```bash
$ python3 quicksort.py
自检通过：208 组用例 × 2 种实现
[1, 1, 2, 3, 3, 4, 5, 5, 5, 6, 9]
```

### 要点

- `quicksort`：Lomuto 分区 + 三数取中 + 尾递归优化，最坏栈深 O(log n)
- `quicksort3`：三路分区，重复元素多时退化为 O(n)
- 两者均为**原地**排序，返回同一列表对象