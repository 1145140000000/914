## App 接口签名还原：完整操作链

> 选型：Frida + mitmproxy + jadx/ghidra 三件套；目标记为 `APP` / `TARGET_HOST`，签名参数记为 `sign`，密钥槽位 `SECRET`。

---

### 阶段 0 · 前置（先确认工具在不在）

```bash
command -v frida frida-ps objection mitmproxy jadx apktool adb python3
# 缺哪个补哪个：
pip install frida-tools objection mitmproxy
```

证据行：`$ command -v frida` → `/usr/local/bin/frida`（有回显即通过）

---

### 阶段 1 · 抓包定位签名参数

```bash
# 1) 起代理
mitmdump -p 8080 -w flows.mitm --set confdir=~/.mitmproxy

# 2) 设备侧装证书（Android 7+ 需系统级，见阶段 2 的 frida 脚本绕过）
adb push ~/.mitmproxy/mitmproxy-ca-cert.cer /sdcard/
# 设置 → 安全 → 安装证书 → CA 证书

# 3) 设备代理指向 PC
adb shell settings put global http_proxy 192.168.1.10:8080
```

从 `flows.mitm` 里筛出带签名的请求：

```bash
mitmdump -nr flows.mitm --flow-detail 3 2>/dev/null | grep -Ei 'sign|signature|token|nonce|ts=|timestamp'
```

典型命中形态（`TARGET_HOST` 的 `POST /api/v1/order/list`）：

```
POST /api/v1/order/list HTTP/1.1
Host: TARGET_HOST
X-App-Key: a1b2c3d4
X-Timestamp: 1718000000
X-Nonce: 8f3a91c2
sign: 5d41402abc4b2a76b9719d911017c592
```

**签名四要素先记下来**：参与字段（`X-App-Key`/`X-Timestamp`/`X-Nonce`/body）、算法族（32 位 hex → MD5；64 位 hex → SHA256；Base64 → HMAC/RSA）、拼接顺序、密钥来源。

证据行：`$ grep -c 'sign:' flows.mitm` → `37`（确认签名稳定出现）

---

### 阶段 2 · 静态定位签名函数

```bash
apktool d APP.apk -o APP_src
jadx -d APP_jadx APP.apk
grep -rn --include=*.java -Ei '"(sign|signature|md5|sha1|sha256|hmac)"' APP_jadx/sources | head -50
```

命中后看调用链，重点找这三类：

| 特征 | 含义 |
| --- | --- |
| `MessageDigest.getInstance("MD5")` | 明文摘要，无密钥 |
| `Mac.getInstance("HmacSHA256")` + `SecretKeySpec` | HMAC，密钥在 `SECRET` 常量或 native |
| `Cipher.getInstance("RSA/ECB/PKCS1Padding")` | 私钥签名，密钥常在 `.so` |

若 `grep` 只命中 `native` 声明（`public static native String sign(...)`），转 native 层：

```bash
unzip -o APP.apk 'lib/*' -d APP_lib
file APP_lib/lib/arm64-v8a/libnative.so
# → ELF 64-bit LSB shared object, ARM aarch64
strings -a APP_lib/lib/arm64-v8a/libnative.so | grep -Ei 'sign|md5|sha|hmac|key'
```

证据行：`$ nm -D APP_lib/lib/arm64-v8a/libnative.so | grep -i sign` → `0000000000012a40 T Java_com_app_util_SignUtil_sign`

---

### 阶段 3 · 动态 hook 拿明文入参（最快出结果的一步）

```javascript
// hook_sign.js  ——  Java 层
Java.perform(function () {
    var SignUtil = Java.use('com.app.util.SignUtil');
    SignUtil.sign.overload('java.lang.String', 'java.lang.String', 'java.lang.String')
        .implementation = function (a, b, c) {
            var r = this.sign(a, b, c);
            console.log('[sign] in1=' + a + ' in2=' + b + ' in3=' + c + ' => ' + r);
            return r;
        };
});
```

```bash
frida -U -f com.app.package -l hook_sign.js --no-pause
```

回显样例：

```
[sign] in1={"page":1,"size":20} in2=1718000000 in3=8f3a91c2 => 5d41402abc4b2a76b9719d911017c592
```

**native 层 hook**（Java 层只看到 native 声明时）：

```javascript
// hook_native.js
var base = Module.findBaseAddress('libnative.so');
var fn = base.add(0x12a40);          // 来自 nm 的偏移
Interceptor.attach(fn, {
    onEnter: function (args) {
        console.log('[native] a=' + Memory.readUtf8String(args[1])
                  + ' b=' + Memory.readUtf8String(args[2])
                  + ' c=' + Memory.readUtf8String(args[3]));
    },
    onLeave: function (ret) {
        console.log('[native] ret=' + Memory.readUtf8String(ret));
    }
});
```

证据行：`$ frida -U -f com.app.package -l hook_native.js` → `[native] a={"page":1,...} b=1718000000 c=8f3a91c2` / `[native] ret=5d41402a...`

---

### 阶段 4 · 还原算法（拿 hook 到的入参离线对撞）

拿到 3~5 组 `(入参, 输出)` 后，按候选拼接式逐个试：

```python
# recover_sign.py
import hashlib, hmac, itertools

SECRET = "SECRET"          # 从 .so 字符串 / Java 常量里取；取不到先留占位
samples = [
    ('{"page":1,"size":20}', '1718000000', '8f3a91c2', '5d41402abc4b2a76b9719d911017c592'),
    # 再补 2~4 组
]

def md5(s):  return hashlib.md5(s.encode()).hexdigest()
def sha256(s): return hashlib.sha256(s.encode()).hexdigest()
def hmac256(k, s): return hmac.new(k.encode(), s.encode(), hashlib.sha256).hexdigest()

cands = {
    'md5(body+ts+nonce)':        lambda b,t,n: md5(b+t+n),
