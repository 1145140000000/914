## 断点续采：不重不漏的完整实现

> 选型：Python 3.10+ · 零第三方依赖（仅标准库）· 单文件 · SQLite 落盘 + 游标续采

核心思路：**用「已采主键集合 + 分页游标」双轨记录进度**，而不是只记页码。页码在数据插入/删除后会漂移，主键集合不会。每批数据先写库、再提交游标，同一事务内完成，断电也不会出现「数据写了但游标没动」或反之。

### 目录与入口

```
crawler/
├── resume_crawler.py     # 主程序
└── state.db              # 运行时自动生成（进度 + 数据同库）
```

### 完整实现

```python
#!/usr/bin/env python3
# resume_crawler.py — 断点续采，不重不漏
import sqlite3, time, json, hashlib, sys
from urllib.request import Request, urlopen
from urllib.parse import urlencode

DB = "state.db"

# ---------- 存储层 ----------
def init_db():
    con = sqlite3.connect(DB)
    con.executescript("""
    CREATE TABLE IF NOT EXISTS items (
        pk        TEXT PRIMARY KEY,      -- 业务主键（去重靠它）
        payload   TEXT NOT NULL,
        fetched_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS cursor (
        task      TEXT PRIMARY KEY,      -- 任务名，支持多任务并存
        next_page INTEGER NOT NULL,      -- 下一页游标
        last_pk   TEXT,                  -- 上一页最后一条主键（游标分页用）
        done      INTEGER NOT NULL DEFAULT 0,
        updated_at INTEGER NOT NULL
    );
    """)
    con.commit()
    return con

def get_cursor(con, task):
    row = con.execute("SELECT next_page,last_pk,done FROM cursor WHERE task=?", (task,)).fetchone()
    if row is None:
        con.execute("INSERT INTO cursor(task,next_page,last_pk,done,updated_at) VALUES(?,?,?,?,?)",
                    (task, 1, None, 0, int(time.time())))
        con.commit()
        return 1, None, 0
    return row

# ---------- 采集层（替换成你的真实接口） ----------
def fetch_page(page, last_pk=None, page_size=100):
    """返回 (items, has_more)。items 每条必须含唯一 pk 字段。"""
    params = {"page": page, "size": page_size}
    if last_pk:                       # 游标分页优先，避免页码漂移
        params["after"] = last_pk
    url = "http://TARGET/api/list?" + urlencode(params)
    req = Request(url, headers={"User-Agent": "resume-crawler/1.0",
                                "Cookie": "SESSION=COOKIE"})
    with urlopen(req, timeout=15) as r:
        data = json.loads(r.read().decode())
    items = data.get("items", [])
    has_more = bool(data.get("has_more", len(items) == page_size))
    return items, has_more

# ---------- 主循环：先落数据，再推游标，同事务 ----------
def run(task="default", max_retry=5):
    con = init_db()
    page, last_pk, done = get_cursor(con, task)
    if done:
        print(f"[{task}] 已完成，跳过"); return

    while True:
        items, has_more = None, False
        for attempt in range(1, max_retry + 1):
            try:
                items, has_more = fetch_page(page, last_pk)
                break
            except Exception as e:
                wait = min(2 ** attempt, 30)
                print(f"[retry {attempt}/{max_retry}] page={page} err={e} sleep={wait}s")
                time.sleep(wait)
        if items is None:
            print(f"[{task}] page={page} 连续失败，保留游标退出，下次从此处续采")
            return

        now = int(time.time())
        new_last = last_pk
        with con:  # 事务：数据 + 游标原子提交
            for it in items:
                pk = str(it["id"])
                con.execute(
                    "INSERT OR IGNORE INTO items(pk,payload,fetched_at) VALUES(?,?,?)",
                    (pk, json.dumps(it, ensure_ascii=False), now))
                new_last = pk
            con.execute(
                "UPDATE cursor SET next_page=?,last_pk=?,done=?,updated_at=? WHERE task=?",
                (page + 1, new_last, 0 if has_more else 1, now, task))

        got = con.execute("SELECT COUNT(*) FROM items").fetchone()[0]
        print(f"[{task}] page={page} 本页={len(items)} 累计={got} has_more={has_more}")
        if not has_more:
            print(f"[{task}] 采集完成"); return
        page += 1
        time.sleep(0.3)   # 限速，按目标承受度调

if __name__ == "__main__":
    run(sys.argv[1] if len(sys.argv) > 1 else "default")
```

### 起跑命令

```bash
python3 resume_crawler.py default
# 中断后原样再跑一次即可续采：
python3 resume_crawler.py default
```

### 自检方式（验证不重不漏）

```bash
# 1. 看进度游标
sqlite3 state.db "SELECT task,next_page,last_pk,done FROM cursor;"

# 2. 主键唯一性自检（应返回 0 行 = 无重复）
sqlite3 state.db "SELECT pk,COUNT(*) c FROM items GROUP BY pk HAVING c>1;"

# 3. 总数核对
sqlite3 state.db "SELECT COUNT(*) FROM items;"
```

### 关键设计点（对应「不重不漏」）

| 风险 | 对策 |
| --- | --- |
| 重复采集 | `items.pk` 主键 + `INSERT OR IGNORE`，天然幂等 |
| 漏采 | 游标 `next_page`/`last_pk` 与数据**同事务**提交，崩溃点前后一致 |
| 页码漂移（数据增删导致翻页错位） | 优先用 `after=last_pk` 游标分页，而非纯页码 |
| 网络抖动 | 指数退避重试，失败保留游标不前进，下次从断点续 |
| 多任务并行 | `cursor.task` 分任务隔离，互不干扰 |

证据行：`state.db` → 三张表结构由 `init_db()` 的 `executescript` 定义，可直接 `sqlite3 state.db ".schema"` 核对。

把 `fetch_page()` 里的 URL、鉴权头、`pk` 字段名换成你目标接口的真实值即可直接跑。