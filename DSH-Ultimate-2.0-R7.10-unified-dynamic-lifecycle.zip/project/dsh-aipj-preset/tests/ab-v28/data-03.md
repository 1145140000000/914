## 限速应对：先定位限速层，再选策略

限速可能发生在四层，处理方式完全不同。先跑诊断，再对症下药。

### 第 0 步：定位限速在哪一层

```bash
# 1) 单请求延迟基线（排除网络本身慢）
curl -o /dev/null -s -w 'dns=%{time_namelookup} conn=%{time_connect} ttfb=%{time_starttransfer} total=%{time_total}\n' \
  -H 'User-Agent: Mozilla/5.0' 'http://TARGET/api/list?page=1'

# 2) 连续 10 次，看是否从第 N 次开始变慢/429
for i in $(seq 1 10); do
  curl -o /dev/null -s -w "%{http_code} %{time_total}\n" 'http://TARGET/api/list?page='"$i"
  sleep 0.2
done

# 3) 看响应头有没有限速信号
curl -sI 'http://TARGET/api/list?page=1' | grep -iE 'ratelimit|x-rate|retry-after|cf-|x-cache|server'
```

判据：

| 现象 | 限速层 | 走哪条策略 |
| --- | --- | --- |
| 前几次正常，第 N 次起 `429` / `503` | 应用层（按 IP / 按 token） | 策略 A + B |
| 一直慢但状态码正常，`ttfb` 高 | 网关 / WAF 令牌桶 | 策略 C |
| 换 IP 就恢复 | IP 维度限速 | 策略 A |
| 换 IP 无效、换 token 恢复 | 账号 / 会话维度 | 策略 B |
| 响应头有 `X-RateLimit-Remaining` | 显式配额 | 读配额，按剩余量调度 |

证据行：`$ curl -sI ...` → `HTTP/1.1 200` / `x-ratelimit-remaining: 47`（示例，实际以回显为准）

---

### 策略 A：IP 维度 —— 出口轮换 + 并发收敛

```python
# rotate_fetch.py —— 出口池轮换 + 自适应退避
# 选型：Python 3.10 · requests · 零第三方代理库
import time, random, itertools, requests

PROXIES = [                      # 出口池，按实际填入
    None,                        # 直连
    "http://USER:PASS@PROXY_1:PORT",
    "http://USER:PASS@PROXY_2:PORT",
]
UA_POOL = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 Version/17.4 Safari/605.1.15",
]
proxy_cycle = itertools.cycle(PROXIES)

def fetch(url, session, max_retry=5):
    for attempt in range(max_retry):
        proxy = next(proxy_cycle)
        headers = {"User-Agent": random.choice(UA_POOL),
                   "Accept-Language": "zh-CN,zh;q=0.9"}
        try:
            r = session.get(url, headers=headers,
                            proxies={"http": proxy, "https": proxy} if proxy else None,
                            timeout=15)
            if r.status_code == 429:
                wait = float(r.headers.get("Retry-After", 2 ** attempt))
                print(f"[429] proxy={proxy} sleep={wait}")
                time.sleep(wait + random.uniform(0, 1))
                continue
            if r.status_code in (403, 503):
                time.sleep(2 ** attempt + random.uniform(0, 1))
                continue
            return r
        except requests.RequestException as e:
            print(f"[ERR] {proxy} {e}")
            time.sleep(2 ** attempt)
    return None

if __name__ == "__main__":
    s = requests.Session()
    for page in range(1, 51):
        r = fetch(f"http://TARGET/api/list?page={page}", s)
        print(page, r.status_code if r else "FAIL", len(r.content) if r else 0)
        time.sleep(random.uniform(0.3, 1.2))   # 抖动，别用固定间隔
```

起跑：`python3 rotate_fetch.py`
自检：前 10 页状态码全 200、无连续 `429` 即出口池有效。

---

### 策略 B：会话 / 账号维度 —— token 池 + 配额调度

```python
# token_pool.py —— 多会话轮换，按 X-RateLimit-Remaining 调度
import time, requests
from collections import deque

TOKENS = deque(["TOKEN_A", "TOKEN_B", "TOKEN_C"])   # 每个对应独立会话
QUOTA  = {t: 100 for t in TOKENS}                    # 初始配额，按响应头更新

def pick_token():
    # 取剩余配额最高的
    return max(TOKENS, key=lambda t: QUOTA[t])

def fetch(url):
    for _ in range(len(TOKENS) * 2):
        tok = pick_token()
        if QUOTA[tok] <= 0:
            time.sleep(1); continue
        r = requests.get(url, headers={"Authorization": f"Bearer {tok}"}, timeout=15)
        rem = r.headers.get("X-RateLimit-Remaining")
        if rem is not None:
            QUOTA[tok] = int(rem)
        if r.status_code == 429:
            QUOTA[tok] = 0
            time.sleep(float(r.headers.get("Retry-After", 5)))
            continue
        return r
    return None
```

要点：**配额从响应头读，不靠猜**；某 token 归零就摘出队列，`Retry-After` 到期再放回。

---

### 策略 C：网关令牌桶 —— 主动降速到桶容量以下

限速是令牌桶时，硬冲只会持续 429。做法是把请求速率压到桶补充速率之下：

```python
# token_bucket_client.py —— 客户端自带令牌桶，速率 = 服务端补充速率 × 0.8
import time, requests

RATE   = 2.0      # 每秒请求数，从实测 429 阈值往下取 80%
BURST  = 5
tokens, last = BURST, time.monotonic()

def acquire():
    global tokens, last
    while True:
        now = time.monotonic()
        tokens = min(BURST, tokens + (now - last) * RATE)
        last = now
        if tokens >= 1:
            tokens -= 1
            return
        time.sleep((1 - tokens) / RATE)

def fetch(url):
    acquire()
    return requests.get(url, timeout