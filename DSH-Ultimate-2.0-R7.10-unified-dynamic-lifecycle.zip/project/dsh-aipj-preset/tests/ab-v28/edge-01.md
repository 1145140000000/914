## 端口与服务枚举

> 目标：`TARGET_IP:PORT`（你未给出具体值，用占位符代入；把真实 IP/端口替换进下面命令即可直接跑）

### 0. 前置：工具可用性探测

```bash
for t in nmap masscan nc curl whatweb ffuf nikto; do
  printf '%-10s ' "$t"; command -v "$t" || echo "MISSING"
done
```

缺 `nmap` 时用 `nc` + `bash /dev/tcp` 兜底；缺 `ffuf` 时用 `gobuster` 或 `curl` 循环。

---

### 1. 快速存活 + 全端口发现（先粗后细）

```bash
# 1a. 主机存活（跳过 ping，防 ICMP 被过滤）
nmap -sn -Pn TARGET_IP

# 1b. 全 65535 端口快速扫（-T4 提速，--min-rate 控制发包）
nmap -Pn -p- --min-rate 2000 -T4 -oN scan_allports.txt TARGET_IP

# 1c. 已知端口先做服务指纹
nmap -Pn -sV -sC -p PORT -oN scan_port.txt TARGET_IP
```

**预期回显关键行**：
```
PORT     STATE SERVICE  VERSION
PORT/tcp open  <svc>    <banner/version>
```

---

### 2. 服务识别（按端口分类处理）

| 端口类型 | 识别命令 | 关注点 |
| --- | --- | --- |
| HTTP/HTTPS | `curl -sI http://TARGET_IP:PORT` + `whatweb -a 3 http://TARGET_IP:PORT` | Server 头、框架、CMS、跳转 |
| SSH | `nc -nv TARGET_IP PORT` | banner 版本（`SSH-2.0-OpenSSH_x.x`） |
| MySQL/Redis/Mongo | `nmap -sV -p PORT --script=*-info TARGET_IP` | 是否免认证、版本 |
| 自定义 TCP | `nc -nv TARGET_IP PORT` 手动发探针 | 协议特征、是否回显 |
| RDP/SMB | `nmap -p PORT --script=rdp-enum-encryption,smb-os-discovery TARGET_IP` | 系统版本、域信息 |

```bash
# HTTP 类通用指纹
curl -sI http://TARGET_IP:PORT
whatweb -a 3 http://TARGET_IP:PORT

# 非 HTTP 类 banner 抓取
nc -nv -w 3 TARGET_IP PORT
```

---

### 3. 若为 Web：目录/接口枚举

```bash
# 目录爆破（ffuf）
ffuf -u http://TARGET_IP:PORT/FUZZ -w /usr/share/wordlists/dirb/common.txt -t 40 -mc 200,301,302,403 -o ffuf_dir.json

# 从首页 JS 提取接口
curl -s http://TARGET_IP:PORT | grep -oE '(/[a-zA-Z0-9_\-/]+\.(js|json|php|api))' | sort -u
```

**预期回显**：`200/301/403` 状态码 + 路径列表，落 `ffuf_dir.json`。

---

### 4. 结果落盘与台账

```bash
mkdir -p RESULT_DIR && mv scan_*.txt ffuf_dir.json RESULT_DIR/
```

台账条目（六字段，缺一不可）：

| 主机 | 端口/协议 | 服务/版本 | 证据（命令+回显） | 时间戳 | 来源工具 |
| --- | --- | --- | --- | --- | --- |
| TARGET_IP | PORT/tcp | `<svc> <ver>` | `nmap -sV` → `PORT/tcp open <svc> <ver>` | `date -u` | nmap |

---

### 5. 下一步分支（拿到服务后）

- **Web 服务** → 指纹识别 → 目录/接口枚举 → 参数点验证（注入/越权/上传）
- **数据库暴露** → 免认证探测 → 弱口令 → 数据面确认
- **SSH/RDP** → 版本漏洞比对 → 弱口令（授权范围内）
- **自定义协议** → 抓包分析协议结构 → 构造探针

---

**把真实 `TARGET_IP` 和 `PORT` 填进去，或直接告诉我端口号，我给你对应的精确识别命令和预期回显。** 当前命令链可直接复制执行，结果落 `RESULT_DIR`。