## 构建与部署

先探构建入口，再执行。

```bash
# 1. 定位项目根与构建清单
ls -la
find . -maxdepth 2 \( -name package.json -o -name pyproject.toml -o -name setup.py -o -name Cargo.toml -o -name go.mod -o -name Makefile -o -name CMakeLists.txt -o -name '*.csproj' -o -name '*.sln' -o -name build.gradle -o -name pom.xml -o -name Dockerfile \) -not -path '*/node_modules/*' 2>/dev/null
```

```bash
# 2. 按清单类型执行构建（命中哪条跑哪条）
# Node
npm ci && npm run build
# Python
python3 -m venv .venv && . .venv/bin/activate && pip install -r requirements.txt
# Go
go build -o app ./...
# Rust
cargo build --release
# Make / CMake
make -j"$(nproc)"   # 或 cmake -S . -B build && cmake --build build -j
# Java
mvn -q -DskipTests package   # 或 ./gradlew build
# .NET
dotnet build -c Release
# Docker
docker build -t app:local .
```

```bash
# 3. 起跑
# 容器
docker run -d --name app -p 8080:8080 app:local
# 裸进程（按产物路径替换）
./app &   # 或 npm start / python3 -m <pkg> / java -jar target/*.jar
```

```bash
# 4. 自检
curl -sS -o /dev/null -w '%{http_code}\n' http://127.0.0.1:8080/ ; docker ps --filter name=app --format '{{.Status}}'
```

把上面第 1 步的 `ls` 与 `find` 回显贴给我，我按实际清单把第 2–4 步替换成确定命令并跑完，回你退出码与原始日志。