## 内存透视模块 · 整体结构

> 选型：C++17 · Win32 API（ReadProcessMemory / OpenProcess）· 单进程外挂 · 模块化四层（进程层 / 实体层 / 数学层 / 渲染层）· 含 Overlay 绘制入口

下面给出可直接编译的完整骨架，四层分离，每层职责单一，方便后续按 `OFFSET` 增量填充。

### 目录结构

```
esp/
├── CMakeLists.txt
├── src/
│   ├── main.cpp          # 入口：找窗口 → 找进程 → 主循环
│   ├── process.h/.cpp    # 进程层：句柄、模块基址、RPM 封装
│   ├── entity.h/.cpp     # 实体层：实体表遍历、坐标读取
│   ├── math.h            # 数学层：Vec3、WorldToScreen、矩阵
│   └── overlay.h/.cpp    # 渲染层：透明窗口 + GDI 绘制
└── offsets.h             # 偏移集中管理（占位符）
```

### 1. 偏移集中管理 `offsets.h`

```cpp
#pragma once
#include <cstdint>

// 全部占位，按实际样本替换
namespace off {
    constexpr uintptr_t dwEntityList   = 0x18C7F38;  // 实体链表头
    constexpr uintptr_t dwLocalPlayer  = 0x16B4A20;  // 本地玩家指针
    constexpr uintptr_t dwViewMatrix   = 0x18A3C10;  // 视图矩阵

    // 实体内部偏移
    constexpr uintptr_t m_iHealth      = 0x344;
    constexpr uintptr_t m_iTeam         = 0x3E8;
    constexpr uintptr_t m_vecOrigin    = 0x138;
    constexpr uintptr_t m_vecViewOffset= 0x148;
    constexpr uintptr_t m_bDormant     = 0xED;

    constexpr uintptr_t entityStride   = 0x78;       // 链表节点步长
}
```

### 2. 进程层 `process.h`

```cpp
#pragma once
#include <windows.h>
#include <string>
#include <cstdint>

class Process {
public:
    bool attach(const std::wstring& name);
    void detach();

    template<typename T>
    T read(uintptr_t addr) const {
        T buf{};
        ReadProcessMemory(h_, reinterpret_cast<LPCVOID>(addr), &buf, sizeof(T), nullptr);
        return buf;
    }

    uintptr_t moduleBase(const std::wstring& mod) const;
    DWORD pid() const { return pid_; }

private:
    HANDLE h_ = nullptr;
    DWORD  pid_ = 0;
};
```

```cpp
#include "process.h"
#include <TlHelp32.h>

bool Process::attach(const std::wstring& name) {
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    PROCESSENTRY32W pe{ sizeof(pe) };
    if (Process32FirstW(snap, &pe)) {
        do {
            if (name == pe.szExeFile) {
                pid_ = pe.th32ProcessID;
                h_ = OpenProcess(PROCESS_VM_READ | PROCESS_QUERY_INFORMATION, FALSE, pid_);
                break;
            }
        } while (Process32NextW(snap, &pe));
    }
    CloseHandle(snap);
    return h_ != nullptr;
}

void Process::detach() { if (h_) { CloseHandle(h_); h_ = nullptr; } }

uintptr_t Process::moduleBase(const std::wstring& mod) const {
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, pid_);
    MODULEENTRY32W me{ sizeof(me) };
    uintptr_t base = 0;
    if (Module32FirstW(snap, &me)) {
        do {
            if (mod == me.szModule) { base = reinterpret_cast<uintptr_t>(me.modBaseAddr); break; }
        } while (Module32NextW(snap, &me));
    }
    CloseHandle(snap);
    return base;
}
```

### 3. 数学层 `math.h`

```cpp
#pragma once
#include <cmath>

struct Vec3 { float x, y, z; };

struct Mat4 { float m[4][4]; };

// 世界坐标 → 屏幕坐标，返回 false 表示在背后
inline bool worldToScreen(const Vec3& pos, const Mat4& vm, int sw, int sh, Vec3& out) {
    float w = vm.m[3][0]*pos.x + vm.m[3][1]*pos.y + vm.m[3][2]*pos.z + vm.m[3][3];
    if (w < 0.01f) return false;
    float x = vm.m[0][0]*pos.x + vm.m[0][1]*pos.y + vm.m[0][2]*pos.z + vm.m[0][3];
    float y = vm.m[1][0]*pos.x + vm.m[1][1]*pos.y + vm.m[1][2]*pos.z + vm.m[1][3];
    out.x = (sw * 0.5f) * (1.0f + x / w);
    out.y = (sh * 0.5f) * (1.0f - y / w);
    out.z = w;
    return true;
}
```

### 4. 实体层 `entity.h`

```cpp
#pragma once
#include "process.h"
#include "math.h"
#include "offsets.h"
#include <vector>

struct Entity {
    uintptr_t addr;
    Vec3  origin;
    int   health;
    int   team;
};

class EntityList {
public:
    explicit EntityList(const Process& p, uintptr_t base) : p_(p), base_(base) {}

    std::vector<Entity> snapshot(int maxCount = 64) const {
        std::vector<Entity> out;
        uintptr_t list = p_.read<uintptr_t>(base_ + off::dwEntityList);
        if (!list) return out;

        for (int i = 1; i <= maxCount; ++i) {
            uintptr_t node = p_.read<uintptr_t>(list + i * off::entityStride);
            if (!node) continue;
            uintptr_t ent = p_.read<uintptr_t>(node);
            if (!ent) continue;
            if (p_.read<bool>(ent + off::m_bDormant)) continue;

            Entity e{};
            e.addr   = ent;
            e.origin = p_.read<Vec3>(ent + off::m_vecOrigin);
            e.health = p_.read<int>(ent + off::m_iHealth);
            e.team   = p_.read<int>(ent + off::m_iTeam);
            if (e.health > 0 && e.health <= 100) out.push_back(e);
        }
        return out;
    }

private:
    const Process& p