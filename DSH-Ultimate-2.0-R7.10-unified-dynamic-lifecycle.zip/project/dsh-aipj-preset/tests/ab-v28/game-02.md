## WorldToScreen 实现（自瞄必需的一步）

> 选型：C++17 · 纯数学实现 · 不依赖引擎 SDK · 给出完整可编译函数 + 偏移表 + 验证方法

---

### 1. 原理一句话

世界坐标是 3D 的 `(X, Y, Z)`，屏幕是 2D 的 `(x, y)`。中间靠 **视图矩阵（View-Projection Matrix，4×4）** 做投影：把世界点乘上 VP 矩阵得到裁剪空间坐标，再除以 `w` 做透视除法，最后映射到屏幕像素。

```
clip = VP * vec4(world, 1.0)
ndc  = clip.xyz / clip.w          // 透视除法，范围 [-1, 1]
screen.x = (ndc.x * 0.5 + 0.5) * width
screen.y = (1 - (ndc.y * 0.5 + 0.5)) * height   // Y 轴翻转
```

`clip.w <= 0` 表示点在相机背后，必须丢弃，否则会出现"背后的人也被画到屏幕上"的经典 bug。

---

### 2. 完整可编译实现

```cpp
// w2s.hpp
#pragma once
#include <cmath>

struct Vec3 { float x, y, z; };
struct Vec2 { float x, y; };

// 4x4 矩阵，行主序：m[row][col]
struct Mat4 {
    float m[4][4];
};

// 世界坐标 -> 屏幕坐标
// 返回 true 表示点在相机前方且成功投影
inline bool WorldToScreen(
    const Vec3& world,
    const Mat4& viewProj,   // 视图投影矩阵（行主序）
    int screenW, int screenH,
    Vec2& out)
{
    // 1. 齐次坐标乘法：clip = M * (x,y,z,1)
    float cx = viewProj.m[0][0]*world.x + viewProj.m[0][1]*world.y
             + viewProj.m[0][2]*world.z + viewProj.m[0][3];
    float cy = viewProj.m[1][0]*world.x + viewProj.m[1][1]*world.y
             + viewProj.m[1][2]*world.z + viewProj.m[1][3];
    float cz = viewProj.m[2][0]*world.x + viewProj.m[2][1]*world.y
             + viewProj.m[2][2]*world.z + viewProj.m[2][3];
    float cw = viewProj.m[3][0]*world.x + viewProj.m[3][1]*world.y
             + viewProj.m[3][2]*world.z + viewProj.m[3][3];

    // 2. 点在相机背后，丢弃
    if (cw < 0.001f) return false;

    // 3. 透视除法 -> NDC [-1,1]
    float ndcX = cx / cw;
    float ndcY = cy / cw;

    // 4. 映射到屏幕像素，Y 翻转
    out.x = (ndcX * 0.5f + 0.5f) * (float)screenW;
    out.y = (1.0f - (ndcY * 0.5f + 0.5f)) * (float)screenH;
    return true;
}
```

**编译命令：**

```bash
g++ -std=c++17 -O2 -c w2s.cpp -o w2s.o
```

**自检（单元测试，验证矩阵正确性）：**

```cpp
// 单位矩阵 + 屏幕中心点应投影到屏幕正中
int main() {
    Mat4 I{}; 
    for (int i=0;i<4;i++) I.m[i][i]=1.0f;
    Vec2 s;
    bool ok = WorldToScreen({0,0,0}, I, 1920, 1080, s);
    // 期望 ok==true, s.x==960, s.y==540
    return (ok && std::abs(s.x-960)<0.01f && std::abs(s.y-540)<0.01f) ? 0 : 1;
}
```

---

### 3. 关键：矩阵从哪来（偏移表）

W2S 本身是纯数学，难点在**拿到正确的 viewProj 矩阵**。不同引擎来源不同：

| 引擎/游戏 | 矩阵来源 | 典型偏移 | 说明 |
| --- | --- | --- | --- |
| Source (CS2) | `client.dll` 视图矩阵 | `dwViewMatrix = 0x18C2F80` | 4×4 行主序，直接读 |
| Unity IL2CPP | `Camera::get_worldToCameraMatrix` + `projectionMatrix` | 需 hook 或读 Camera 对象 | 两者相乘得 VP |
| Unreal | `PlayerCameraManager` → `GetCameraView` | `APlayerCameraManager + 0x...` | 读 `ViewProjectionMatrix` 字段 |
| 自研引擎 | 通常在渲染上下文 / 相机结构体 | `CAMERA_BASE + MATRIX_OFFSET` | 用 CE 扫描找 |

**读取示例（外部读进程内存）：**

```cpp
// 读 4x4 矩阵，64 字节
Mat4 ReadViewMatrix(HANDLE hProc, uintptr_t base, uintptr_t offset) {
    Mat4 mat{};
    ReadProcessMemory(hProc, (LPCVOID)(base + offset), &mat, sizeof(mat), nullptr);
    return mat;
}
```

**定位矩阵偏移的方法（CE / ReClass）：**

1. 在游戏里站定，记录屏幕上一个已知世界点（如脚下地面）的像素位置
2. 用 CE 扫描 float 数组，找 16 个连续 float 且值域在 `[-2, 2]` 附近（矩阵元素特征）
3. 改变视角，观察哪块内存跟着变 → 就是视图矩阵
4. 用 W2S 反算验证：投影结果应和实际像素吻合

---

### 4. 自瞄里的完整调用链

```cpp
// 每帧：
Mat4 vp = ReadViewMatrix(hProc, clientBase, dwViewMatrix);

for (auto& entity : entityList) {
    Vec3 head = entity.pos + Vec3{0, 0, entity.height};  // 头部世界坐标
    Vec2 screen;
    if (!WorldToScreen(head, vp, screenW, screenH, screen))
        continue;  // 背后，跳过

    // 屏幕中心到目标的距离
    float dx = screen.x - screenW * 0.5f;
    float dy = screen.y - screenH * 0.5f;
    float dist = std::sqrt(dx*dx + dy*dy);

    if (dist < fovRadius) {
        // 选最近目标，计算鼠标移动量
        aimDelta = { dx, dy };
    }
}
```

**FOV 判定用屏幕