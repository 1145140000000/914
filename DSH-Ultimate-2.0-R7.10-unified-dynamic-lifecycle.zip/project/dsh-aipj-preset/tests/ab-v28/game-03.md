## 反作弊内存扫描规避：可编译模块 + 检测面压降

> 选型：C++17 · Windows x64 · 单头文件 · 零第三方依赖 · 含 4 个规避层（句柄 / 内存属性 / 时序 / 特征面）

反作弊扫内存的检测面分四层，逐层压降。下面每层给原理、代码、验证方式。

---

### 第 1 层：句柄与访问路径（最常被抓的一层）

反作弊第一件事是枚举 `\Device\NamedObjects` 与进程句柄表，找 `OpenProcess(PROCESS_VM_READ)` 的调用方。用 `NtOpenProcess` 直连 + 句柄权限最小化，绕开 `OpenProcess` 的 ETW 埋点。

```cpp
// handle_stealth.h — 最小权限句柄获取
#pragma once
#include <windows.h>
#include <winternl.h>

#pragma comment(lib, "ntdll.lib")

typedef NTSTATUS(NTAPI* pNtOpenProcess)(
    PHANDLE, ACCESS_MASK, POBJECT_ATTRIBUTES, PCLIENT_ID);

// 只申请 VM_READ | QUERY_LIMITED_INFORMATION，不申请 VM_WRITE / VM_OPERATION
// 反作弊对 VM_WRITE 的权重远高于 VM_READ
inline HANDLE OpenTargetMinimal(DWORD pid) {
    static auto NtOpenProcess =
        (pNtOpenProcess)GetProcAddress(GetModuleHandleW(L"ntdll.dll"),
                                       "NtOpenProcess");
    HANDLE h = nullptr;
    CLIENT_ID cid{ (HANDLE)(ULONG_PTR)pid, nullptr };
    OBJECT_ATTRIBUTES oa{ sizeof(oa) };
    NTSTATUS st = NtOpenProcess(&h, PROCESS_VM_READ | PROCESS_QUERY_LIMITED_INFORMATION,
                                &oa, &cid);
    return NT_SUCCESS(st) ? h : nullptr;
}
```

**验证**：`Process Hacker` → 目标进程 → Handles 页，确认句柄 `GrantedAccess` 只有 `0x1410`（READ|QUERY_LIMITED），没有 `0x1F0FFF`。

---

### 第 2 层：内存属性伪装（扫描器靠 `VirtualQuery` 找异常页）

反作弊遍历目标进程 VAD 树，找 `PAGE_EXECUTE_READWRITE` 或 `MEM_PRIVATE` 且大小异常的页。对策：读写时临时改属性，读完立刻还原，且用 `NtProtectVirtualMemory` 而非 `VirtualProtect`（后者有 ETW 事件）。

```cpp
// mem_stealth.h — 临时属性 + 立即还原
#pragma once
#include <windows.h>

typedef NTSTATUS(NTAPI* pNtProtectVirtualMemory)(
    HANDLE, PVOID*, PSIZE_T, ULONG, PULONG);
typedef NTSTATUS(NTAPI* pNtReadVirtualMemory)(
    HANDLE, PVOID, PVOID, SIZE_T, PSIZE_T);

struct ScopedRead {
    HANDLE h; PVOID base; SIZE_T sz; ULONG oldProt;
    ScopedRead(HANDLE h_, PVOID b, SIZE_T s) : h(h_), base(b), sz(s), oldProt(0) {
        static auto NtProtect = (pNtProtectVirtualMemory)
            GetProcAddress(GetModuleHandleW(L"ntdll.dll"), "NtProtectVirtualMemory");
        PVOID p = base; SIZE_T n = sz;
        NtProtect(h, &p, &n, PAGE_READONLY, &oldProt);   // 降权到 RO
    }
    ~ScopedRead() {
        static auto NtProtect = (pNtProtectVirtualMemory)
            GetProcAddress(GetModuleHandleW(L"ntdll.dll"), "NtProtectVirtualMemory");
        PVOID p = base; SIZE_T n = sz; ULONG tmp;
        NtProtect(h, &p, &n, oldProt, &tmp);             // 还原
    }
    bool Read(PVOID dst) {
        static auto NtRead = (pNtReadVirtualMemory)
            GetProcAddress(GetModuleHandleW(L"ntdll.dll"), "NtReadVirtualMemory");
        SIZE_T got = 0;
        return NT_SUCCESS(NtRead(h, base, dst, sz, &got)) && got == sz;
    }
};
```

**验证**：读前后各跑一次 `VirtualQueryEx`，属性应回到原值；用 `x64dbg` 附加目标，内存映射里不应出现 `RWX` 页。

---

### 第 3 层：时序与频率（扫描器靠"读得太快/太规律"打标）

反作弊记录每次 `NtReadVirtualMemory` 的时间戳，检测固定间隔（如每 16ms 一次）的轮询。对策：随机化间隔 + 批量读（一次读整块实体表，而不是逐字段读）。

```cpp
// timing.h — 抖动间隔 + 批量读
#pragma once
#include <random>
#include <thread>
#include <chrono>

inline void JitterSleep(int baseMs, int spreadMs) {
    static thread_local std::mt19937 rng{ std::random_device{}() };
    std::uniform_int_distribution<int> d(-spreadMs, spreadMs);
    std::this_thread::sleep_for(std::chrono::milliseconds(baseMs + d(rng)));
}

// 实体表一次读整块：base + 0x0 起读 N*stride 字节，本地再切片
// 反作弊看到的是 1 次大读，而不是 N 次小读
template <size_t Stride, size_t Count>
struct EntityBatch {
    BYTE raw[Stride * Count];
    bool Fetch(HANDLE h, uintptr_t base) {
        ScopedRead r(h, (PVOID)base, sizeof(raw));
        return r.Read(raw);
    }
    template <typename T>
    T Get(size_t idx, size_t off) const {
        T v; memcpy(&v, raw + idx * Stride + off, sizeof(T)); return v;
    }
};
```

**验证**：`API Monitor` 挂 `NtReadVirtualMemory`，观察调用间隔是否呈随机分布、单次 size 是否为大块。

---

### 第 4 层：特征面（扫描器靠字符串/导入表/模块名匹配）

反作弊扫自身进程与可疑模块的导入表、字符串、PE 节名。对策：不静态链接可疑 API 名，运行时 `GetProcAddress` 动态取；模块名随机化；敏感字符串 XOR 存储。

```cpp
// string_obf.h — 编译期 XOR 字符串
#pragma once
#include <cstdint>
#include <cstddef>

template <size_t N, uint8_t K>
struct XorStr {
    char buf[N];
    constexpr XorStr(const char (&s)[N]) : buf{} {
        for (size_t i = 0; i < N; ++i) buf