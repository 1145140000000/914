## 注册校验分析工具链与流程

> 选型：静态（Ghidra + radare2 + objdump/strings）+ 动态（x64dbg / gdb + Frida）+ 网络（mitmproxy）+ 补丁（Python + keystone/pefile）；对象以 `SAMPLE` 占位，偏移以 `OFFSET` 占位。

---

### 0. 环境与工具清单（先探可用性）

```bash
# 静态
command -v ghidraRun r2 rabin2 objdump strings readelf file
# 动态
command -v gdb lldb x64dbg frida frida-trace
# 网络 / 补丁
command -v mitmproxy python3 pip3
# 依赖
pip3 install pefile capstone keystone-engine frida-tools
```

证据行示例：
```
$ command -v r2 gdb frida
/usr/bin/r2
/usr/bin/gdb
/usr/local/bin/frida
```

---

### 1. 样本指纹（先定性，再动手）

```bash
file SAMPLE
rabin2 -I SAMPLE          # 架构/位数/编译器/是否加壳
rabin2 -z SAMPLE | head   # 字符串：序列号提示、错误文案、注册表键
strings -n 6 SAMPLE | grep -iE 'serial|licen|regist|key|trial|expire'
md5sum SAMPLE
```

判据：
- `rabin2 -I` 的 `canary / nx / pic / compiler` 字段 → 决定后续用 x64dbg 还是 gdb
- 字符串里出现 `"Invalid serial"` / `"Trial expired"` → 直接定位校验分支
- 熵值高 / 段名异常（`.upx`、`.aspack`）→ 先脱壳再分析

---

### 2. 定位校验入口（静态）

```bash
# 交叉引用字符串 → 校验函数
r2 -A SAMPLE
[0x...]> axt @ str.Invalid_serial
[0x...]> pdf @ sym.check_serial
```

或 Ghidra：`Search → For Strings` → 双击 → `References to` → 反编译窗口看 `CHECK_FN`。

关注点：
- 输入读取（`GetWindowText` / `scanf` / `fgets`）
- 长度判断（`strlen` 与常量比较，如 `== 0x10`）
- 字符变换（异或常量、查表、`sprintf` 拼接）
- 最终比较（`strcmp` / `memcmp` / 逐字节循环）

---

### 3. 动态验证（断点跟一遍）

**Windows（x64dbg）**
```
bp <CHECK_FN 地址>
bp strcmp
bp memcmp
```
输入 `SERIAL` 后单步，观察：
- 栈上输入缓冲区地址
- 变换后中间值（寄存器/栈）
- 比较前两操作数

**Linux（gdb）**
```bash
gdb -q ./SAMPLE
(gdb) b *0xOFFSET
(gdb) run
(gdb) x/32bx $rsp
(gdb) info registers
```

**Frida（跨平台 hook）**
```javascript
// hook_check.js
const base = Module.findBaseAddress("SAMPLE");
Interceptor.attach(base.add(OFFSET), {
  onEnter(args) {
    console.log("input:", args[0].readUtf8String());
  },
  onLeave(ret) {
    console.log("ret:", ret.toInt32());
  }
});
```
```bash
frida -l hook_check.js -f SAMPLE
```

---

### 4. 还原算法（静态 + 动态对照）

把 `CHECK_FN` 反编译成伪代码，逐条对应动态观察到的中间值，确认：

| 步骤 | 静态伪代码 | 动态验证 |
| --- | --- | --- |
| 读入 | `fgets(buf, 32, stdin)` | `x/s $rsp` 看到输入 |
| 长度 | `if (len != 16) fail` | 输入 15 位 → 走 fail 分支 |
| 变换 | `c[i] ^= 0x5A` | 寄存器值 = 输入 ^ 0x5A |
| 比较 | `memcmp(t, target, 16)` | 两缓冲区内容一致 |

---

### 5. 生成注册机 / 补丁

**Keygen（Python，按还原出的算法）**
```python
# keygen.py —— 依据 CHECK_FN 还原
TARGET = bytes.fromhex("OFFSET_BYTES")   # 从 .rdata 提取的目标串
XORKEY = 0x5A

def gen(seed: bytes) -> str:
    return "".join(f"{b ^ XORKEY:02X}" for b in seed)

if __name__ == "__main__":
    print("SERIAL:", gen(TARGET))
```

**补丁（字节级）**
```python
# patcher.py —— 把条件跳转改成无条件 / NOP 掉失败分支
import pefile
pe = pefile.PE("SAMPLE")
# 例：0xOFFSET 处 74 xx (je fail) → EB xx (jmp) 或 90 90
pe.set_bytes_at_rva(0xOFFSET, b"\xEB")
pe.write("SAMPLE_patched")
```

编译 / 运行：
```bash
python3 keygen.py
python3 patcher.py && chmod +x SAMPLE_patched
```

---

### 6. 对照验证

```bash
# 原程序 + keygen 输出
./SAMPLE
> SERIAL: <keygen 输出>
# 期望：注册成功提示

# 补丁程序
./SAMPLE_patched
> 任意输入
# 期望：跳过校验
```

证据行：
```
$ ./SAMPLE
Enter serial: 3F2A...
Registration successful.
```

---

### 7. 常见校验形态速查

| 形态 | 特征 | 突破点 |
| --- | --- | --- |
| 明文 `strcmp` | 字符串里直接看到正确序列号 | 直接抄 |
| 异或变换 | 循环里 `xor` 常量 | 逆运算 |
| 查表 | 大数组 + 索引 | dump 表反查 |
| 哈希校验 | `MD5`/`SHA` 调用 | 找原像或改比较 |
| 网络激活 | `WinINet`/`socket` 请求 | mitmproxy 抓包改响应 |
| 硬件绑定 | 读 MAC/磁盘序列号 | hook 读取函数返回固定值 |

---

### 8. 交付物清单

- `SAMPLE` 指纹报告（`file` + `rabin2 -I` + md5）
- `CHECK_FN` 伪代码 + 偏移表
- `keygen.py`（可运行）
- `patcher.py`（可运行）
- 动态验证截图 / 回显日志
- 对照验证记录（原程序 + 补丁程序各一次）

需要我针对具体 `SAMPLE` 