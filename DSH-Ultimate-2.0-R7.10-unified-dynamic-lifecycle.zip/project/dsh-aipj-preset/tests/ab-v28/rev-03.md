## APK 脱壳流程（壳型判定 → 静态定位 → 动态 dump → 重建回验）

> 选型：Frida 16 + frida-dexdump + jadx 1.5 + apktool 2.9，全流程在 `SAMPLE.apk` 上跑，`TARGET_PKG` 为包名占位。

---

### 阶段 0 · 前置与指纹

```bash
# 环境自检
command -v frida && frida --version
command -v jadx && jadx --version
command -v apktool && apktool --version
pip show frida-dexdump 2>/dev/null | head -2

# 样本指纹
md5sum SAMPLE.apk
unzip -l SAMPLE.apk | head -40
aapt dump badging SAMPLE.apk | grep -E 'package|application-label'
```

壳型判定依据（看 `lib/` 与 `assets/`）：

| 特征 | 壳 |
| --- | --- |
| `lib/armeabi-v7a/libjiagu*.so`、`assets/ijiami.dat` | 360 加固 |
| `lib/libDexHelper.so`、`assets/dexopt/` | 腾讯乐固 |
| `lib/libshella-*.so`、`assets/*.bin` | 梆梆 |
| `lib/libmobisec.so`、`assets/mobisec*.dat` | 阿里聚安全 |
| `lib/libexec.so`、`lib/libexecmain.so` | 娜迦 |
| `classes.dex` 极小 + `Application` 指向壳类 | 通用判定 |

```bash
# 壳类定位：AndroidManifest 里的 Application
apktool d -f -s SAMPLE.apk -o SAMPLE_dec
grep -A2 'application' SAMPLE_dec/AndroidManifest.xml | head -10
```

证据行示例：`$ unzip -l SAMPLE.apk | grep libjiagu` → `... lib/armeabi-v7a/libjiagu.so`（命中 360 加固）。

---

### 阶段 1 · 静态定位（壳入口与真实 Application）

```bash
# 壳 Application 类名
grep -oE 'android:name="[^"]*"' SAMPLE_dec/AndroidManifest.xml | head

# 壳 dex 里能看到什么（通常只有壳 stub）
jadx -d SAMPLE_jadx --show-bad-code SAMPLE.apk
ls SAMPLE_jadx/sources/ | head
```

关键点：壳的 `Application.attachBaseContext` 里做解密 + `DexClassLoader` 加载真实 dex。真实业务类在**运行时**才出现在内存里，静态阶段只能拿到壳 stub。

```bash
# 找壳的加载点（字符串线索）
grep -rE 'DexClassLoader|InMemoryDexClassLoader|loadDex|openDexFile' SAMPLE_jadx/sources/ | head
```

证据行：`$ grep -r DexClassLoader SAMPLE_jadx/sources/` → `com/stub/StubApp.java: ... new DexClassLoader(...)`。

---

### 阶段 2 · 动态 dump（核心）

**2.1 起 frida-server（root 设备 / 模拟器）**

```bash
adb root && adb push frida-server-16.x-android-arm64 /data/local/tmp/fs
adb shell "chmod 755 /data/local/tmp/fs && /data/local/tmp/fs &"
frida-ps -U | grep TARGET_PKG
```

**2.2 方案 A：frida-dexdump 一把梭（多数壳够用）**

```bash
pip install frida-dexdump
frida-dexdump -U -f TARGET_PKG -d   # -d 深度搜索，慢但全
# 产物：./TARGET_PKG/ 下若干 classes.dex
ls -lh ./TARGET_PKG/
```

**2.3 方案 B：自写 hook 脚本（壳有反 dump 时用）**

`dump.js`：

```javascript
// 在壳解密完成后、业务类加载前 dump
Java.perform(function () {
  var DexFile = Java.use("dalvik.system.DexFile");
  // hook 构造函数，拿到每个加载的 dex 的路径/内存
  DexFile.$init.overload('java.io.File').implementation = function (f) {
    console.log("[DexFile] " + f.getAbsolutePath());
    return this.$init(f);
  };

  // 内存 dex：InMemoryDexClassLoader
  try {
    var IMDCL = Java.use("dalvik.system.InMemoryDexClassLoader");
    IMDCL.$init.overload('java.nio.ByteBuffer', 'java.lang.ClassLoader').implementation = function (buf, cl) {
      console.log("[InMemoryDex] size=" + buf.capacity());
      dumpBuffer(buf);
      return this.$init(buf, cl);
    };
  } catch (e) { console.log("no InMemoryDexClassLoader"); }
});

function dumpBuffer(buf) {
  var ByteBuffer = Java.use("java.nio.ByteBuffer");
  var arr = Java.array('byte', new Array(buf.capacity()).fill(0));
  buf.position(0);
  buf.get(arr);
  var File = Java.use("java.io.FileOutputStream");
  var path = "/data/local/tmp/dump_" + Date.now() + ".dex";
  var fos = File.$new(path);
  fos.write(arr);
  fos.close();
  console.log("[dump] -> " + path);
}
```

```bash
frida -U -f TARGET_PKG -l dump.js --no-pause
# 触发业务界面后，adb pull 出 dump_*.dex
adb shell "ls -l /data/local/tmp/dump_*.dex"
adb pull /data/local/tmp/dump_1699999999.dex ./
```

**2.4 方案 C：内存扫描（壳把 dex 抹了头时）**

```bash
# 在 /proc/PID/maps 找 dex 段，用 dd 从 /proc/PID/mem 抠
adb shell "cat /proc/$(pidof TARGET_PKG)/maps | grep -E 'dex|dalvik'"
# 或用 frida 脚本遍历 maps + 扫 'dex\n035' magic
```

`scan.js` 关键片段：

```javascript
var ranges = Process.enumerateRanges('r--');
ranges.forEach(function (r) {
  try {
    var m = Memory.scanSync(r.base, r.size, "64 65 78 0a 30 33 35 00"); // dex\n035\0
    m.forEach(function (hit) {
      console.log("[dex magic] " + hit.address + " in " + r.base);
      // 从 hit.address 起按 dex header 的 file_size 字段读长度后 dump
    });
  } catch (e) {}
});
```

证据行：`$ frida -U -f TARGET_PKG -l dump.js` → `[InMemoryDex] size=4823040` / `[dump]