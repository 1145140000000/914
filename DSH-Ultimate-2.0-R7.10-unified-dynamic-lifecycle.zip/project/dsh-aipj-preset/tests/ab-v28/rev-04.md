# 定位需打补丁字节的具体方法

## 一、先明确"补丁点"的三种类型

| 类型 | 特征 | 定位手段 |
| --- | --- | --- |
| **条件跳转** | `jz/jnz/jg/jl` 决定成败分支 | 找校验函数里的条件跳转，翻转或 NOP |
| **函数返回** | `call CHECK_FN` 后 `test eax,eax` | 把 `call` 换成 `mov eax,1; ret` 或改返回值 |
| **常量/魔数比较** | `cmp eax, 0xDEADBEEF` | 改立即数或改比较对象 |

## 二、静态定位流程（以 IDA / Ghidra / objdump 为例）

### 1. 从字符串交叉引用切入

```
$ strings -tx SAMPLE | grep -iE "invalid|expired|serial|licen|trial|注册|授权"
  4a1c0 invalid serial number
  4a220 license expired
```

拿到字符串地址 `0x4a1c0`，在 IDA 里 `X` 看交叉引用，落到引用它的函数 `CHECK_FN`。

### 2. 从 API 导入表切入

```
$ objdump -T SAMPLE | grep -iE "RegQueryValue|GetVolumeInformation|GetSystemTime|MessageBox"
```

授权类程序常调 `RegQueryValueExA` 读注册表、`GetVolumeInformationA` 取磁盘序列号、`GetLocalTime` 判过期。对这些 API 下交叉引用，回溯到校验函数。

### 3. 从失败提示的调用点反推

```
.text:004012A0  call    ds:MessageBoxA      ; "Invalid serial"
.text:004012A5  ...
```

往上翻，找到决定是否走到这里的条件跳转：

```
.text:00401280  call    CHECK_FN
.text:00401285  test    eax, eax
.text:00401287  jz      short loc_4012A0    ; ← 补丁点：jz → jmp 或 NOP
```

### 4. 记录候选偏移

```
$ objdump -d SAMPLE | grep -A2 "call.*CHECK_FN"
  401280:  e8 7b 00 00 00   call   401300 <CHECK_FN>
  401285:  85 c0            test   eax,eax
  401287:  74 17            je     4012a0 <fail>
```

补丁点 = 文件偏移 `0x1287`（假设 `.text` 文件偏移 = 虚拟地址 - 0x400000 + 0x400），原始字节 `74 17`，改为 `90 90`（NOP）或 `eb 17`（jmp）。

## 三、动态定位流程（gdb / x64dbg / Frida）

### 1. 在失败提示处下断点

```
(gdb) b *0x4012a0
(gdb) r
```

触发后看栈回溯：

```
(gdb) bt
#0  0x004012a0 in fail_msg ()
#1  0x0040128c in main ()
```

回到 `main` 的 `0x401287`，就是那个跳转。

### 2. 在 API 上下断点，回溯调用者

```
(gdb) b MessageBoxA
(gdb) r
(gdb) bt
```

从 `bt` 里找到调用 `MessageBoxA` 的返回地址，再往上就是校验逻辑。

### 3. 用 Frida 动态 hook 校验函数

```javascript
// hook.js
const CHECK_FN = ptr("0x401300");
Interceptor.attach(CHECK_FN, {
    onEnter(args) {
        console.log("[*] CHECK_FN called, arg0=", args[0]);
    },
    onLeave(retval) {
        console.log("[*] CHECK_FN returned:", retval);
        retval.replace(ptr(1));   // 强制返回成功，验证补丁点是否有效
    }
});
```

```
$ frida -l hook.js -f SAMPLE
[*] CHECK_FN called, arg0=0x...
[*] CHECK_FN returned: 0x0
```

如果 `retval.replace(1)` 后程序放行，说明 `CHECK_FN` 的返回值就是判定依据，补丁点确认在调用它的 `test eax,eax` 之后。

## 四、定位到字节后的验证闭环

### 1. 计算文件偏移

```
文件偏移 = 虚拟地址 - 节虚拟地址 + 节文件偏移
```

用 `readelf -S SAMPLE` 或 `objdump -h SAMPLE` 查 `.text` 节：

```
$ objdump -h SAMPLE | grep .text
  1 .text  00001234  00401000  00401000  00001000  ...
```

`.text` 虚拟地址 `0x401000`，文件偏移 `0x1000`。则 `0x401287` → 文件偏移 `0x1287`。

### 2. 确认原始字节

```
$ xxd -s 0x1287 -l 2 SAMPLE
00001287: 7417                                     t.
```

### 3. 打补丁

```python
# patch.py
import shutil
shutil.copy("SAMPLE", "SAMPLE.patched")
with open("SAMPLE.patched", "r+b") as f:
    f.seek(0x1287)
    f.write(b"\x90\x90")   # NOP NOP
print("[+] patched at 0x1287: 74 17 -> 90 90")
```

```
$ python3 patch.py
[+] patched at 0x1287: 74 17 -> 90 90
$ xxd -s 0x1287 -l 2 SAMPLE.patched
00001287: 9090                                     ..
```

### 4. 运行验证

```
$ ./SAMPLE.patched
[+] License accepted
```

## 五、常见坑与对策

| 现象 | 原因 | 对策 |
| --- | --- | --- |
| 改了跳转仍失败 | 有多处校验 | 搜所有 `call CHECK_FN` 的交叉引用，逐个打 |
| 改了字节程序崩溃 | 改到了指令中间 | 用反汇编器确认指令边界，只改完整指令 |
| 补丁后校验和失败 | 程序自校验 | 找 CRC/哈希校验函数一并 NOP，或改校验值 |
| 动态 hook 成功、静态补丁失败 | 有反调试/完整性检查 | 先过反调试，再打补丁 |
| 文件偏移算错 | 节对齐 ≠ 文件对齐 | 用 `objdump -h` 核对 `VMA` 与 `File off` |

## 六、证据表模板

| 偏移 | 原始字节 | 补丁后 | 语义 |
| --- | --- | --- | --- |
| `0x1287` | `74 17` | `90 90` | `je fail` →