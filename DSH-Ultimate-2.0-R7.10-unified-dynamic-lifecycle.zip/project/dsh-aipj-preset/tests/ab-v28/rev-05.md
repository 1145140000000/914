## Frida Hook 校验函数 · 可运行脚本模板

> 选型：Python 3 + `frida` / `frida-tools`（`pip install frida frida-tools`）· 单文件 JS agent + 单文件 Python 启动器 · 覆盖 Native（C/C++）与 Java（Android）两条路径

### 目录结构

```
frida-hook/
├── agent.js          # Frida agent：hook 逻辑
├── run.py            # 启动器：attach/spawn + 加载 agent + 收消息
└── config.json       # 目标进程 / 模块 / 偏移 / 函数名
```

### config.json

```json
{
  "target": "APP",
  "mode": "attach",
  "platform": "native",
  "module": "libtarget.so",
  "symbol": "check_license",
  "offset": "0x1234",
  "java_class": "com.example.app.LicenseManager",
  "java_method": "verify"
}
```

### agent.js

```javascript
'use strict';

const CONFIG = JSON.parse(Process.getModuleByName ? '{}' : '{}'); // 占位，实际由 run.py 注入
let CFG = {};

// ---------- 通用工具 ----------
function log(tag, obj) {
  send({ tag: tag, data: obj });
}

function hexdumpBuf(ptr, len) {
  try { return hexdump(ptr, { length: len, ansi: false }); }
  catch (e) { return '<hexdump failed: ' + e + '>'; }
}

function readCStringSafe(ptr) {
  try { return ptr.readCString(); } catch (e) { return null; }
}

// ---------- Native hook ----------
function hookNative(cfg) {
  const mod = Process.findModuleByName(cfg.module);
  if (!mod) {
    log('error', { msg: 'module not found', module: cfg.module });
    return;
  }
  log('module', { name: mod.name, base: mod.base.toString(), size: mod.size });

  let target = null;
  if (cfg.symbol) {
    target = Module.findExportByName(cfg.module, cfg.symbol);
  }
  if (!target && cfg.offset) {
    target = mod.base.add(ptr(cfg.offset));
  }
  if (!target) {
    log('error', { msg: 'target not resolved', symbol: cfg.symbol, offset: cfg.offset });
    return;
  }
  log('target', { addr: target.toString() });

  Interceptor.attach(target, {
    onEnter(args) {
      this.args = [];
      for (let i = 0; i < 4; i++) {
        const a = args[i];
        this.args.push({
          idx: i,
          ptr: a.toString(),
          int: (() => { try { return a.toInt32(); } catch (e) { return null; } })(),
          str: readCStringSafe(a)
        });
      }
      log('enter', { fn: cfg.symbol || cfg.offset, args: this.args });
    },
    onLeave(retval) {
      log('leave', {
        fn: cfg.symbol || cfg.offset,
        retval_ptr: retval.toString(),
        retval_int: (() => { try { return retval.toInt32(); } catch (e) { return null; } })()
      });
      // 强制返回成功（按需启用）
      // retval.replace(ptr(1));
    }
  });
}

// ---------- Java hook ----------
function hookJava(cfg) {
  if (!Java.available) {
    log('error', { msg: 'Java VM not available' });
    return;
  }
  Java.perform(function () {
    let Cls;
    try {
      Cls = Java.use(cfg.java_class);
    } catch (e) {
      log('error', { msg: 'class not found', cls: cfg.java_class, err: String(e) });
      return;
    }
    const method = cfg.java_method;
    if (!Cls[method]) {
      log('error', { msg: 'method not found', cls: cfg.java_class, method: method });
      return;
    }

    const overloads = Cls[method].overloads;
    overloads.forEach(function (ov) {
      ov.implementation = function () {
        const argsDump = [];
        for (let i = 0; i < arguments.length; i++) {
          let v = arguments[i];
          let s;
          try { s = String(v); } catch (e) { s = '<unprintable>'; }
          argsDump.push({ idx: i, type: ov.argumentTypes[i].className, value: s });
        }
        log('java_enter', { cls: cfg.java_class, method: method, args: argsDump });

        const ret = ov.apply(this, arguments);

        log('java_leave', {
          cls: cfg.java_class,
          method: method,
          retval: (() => { try { return String(ret); } catch (e) { return '<unprintable>'; } })()
        });

        // 强制返回 true（按需启用）
        // return true;
        return ret;
      };
    });
    log('java_hooked', { cls: cfg.java_class, method: method, overloads: overloads.length });
  });
}

// ---------- 入口 ----------
rpc.exports = {
  init: function (cfg) {
    CFG = cfg;
    log('init', { platform: cfg.platform, target: cfg.target });
    if (cfg.platform === 'java') {
      hookJava(cfg);
    } else {
      hookNative(cfg);
    }
    return true;
  }
};
```

### run.py

```python
#!/usr/bin/env python3
import json, sys, time, frida

def load_cfg(path="config.json"):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def on_message(msg, data):
    if msg.get("type") == "send":
        payload = msg.get("payload", {})
        tag = payload.get("tag")
        print(f"[{tag}] {json.dumps(payload.get('data'), ensure_ascii=False)}")
    elif msg.get("type") == "error":
        print(f"[error] {msg.get('description')}\n{msg.get('stack', '')}")
    else:
        print(f"[msg] {msg}")

def main():
    cfg = load_cfg()
    device = frida.get_local_device() if cfg.get("device", "local") == "local" \
             else frida.get_usb_device(timeout=5)

    if cfg["mode"] == "spawn":
        pid = device.spawn([cfg["target"]])
        session = device.attach(pid)
        script = session.create_script(open("agent.js", "r", encoding="utf-8").read())
        script.on("message", on_message)
        script.load()
        script.exports_sync.init(cfg)
        device.resume(pid)
    else:
        session = device.attach(cfg["target"])
        script = session.create_script(open("agent.js", "r", encoding="utf-8").read())
        script.on("message",