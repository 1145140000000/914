## 目标枚举链（仅 IP + 端口）

> 选型：`nmap` 做端口/服务识别 → `whatweb`/`curl` 指纹 → `ffuf` 目录与接口爆破 → 命中点逐条验证；全程落 `RESULT_DIR`，每条结论带命令 + 回显。

### 阶段 0 · preflight

```bash
export TARGET=10.10.10.10
export PORT=8080
export RESULT_DIR=./recon_$TARGET
mkdir -p $RESULT_DIR/{nmap,web,ffuf,evidence}
export WORDLIST=/usr/share/seclists/Discovery/Web-Content/raft-medium-directories.txt
export THREADS=40
command -v nmap whatweb ffuf curl jq | tee $RESULT_DIR/tools.txt
```

判据：`tools.txt` 里四个工具都在；缺哪个就换等效替代（`whatweb` 缺 → `curl -I` + `nmap -sV` 指纹；`ffuf` 缺 → `gobuster`/`feroxbuster`），并把替代写进证据行。

### 阶段 1 · 端口与服务识别

```bash
# 先确认端口活着，再上服务识别
nmap -Pn -p $PORT --reason $TARGET -oN $RESULT_DIR/nmap/port.txt
nmap -Pn -p $PORT -sV -sC --version-all $TARGET -oN $RESULT_DIR/nmap/svc.txt
```

- `port.txt` 看 `STATE` 是 `open` 还是 `filtered`——`filtered` 说明有防火墙，后续换 `-sS`/`--scanflags` 或加 `-T2` 降速。
- `svc.txt` 拿 `SERVICE` / `VERSION` / `ssl-cert` 脚本回显，这是后续选字典和载荷的唯一依据。

### 阶段 2 · Web 指纹（若端口是 HTTP/HTTPS）

```bash
PROTO=http   # 若 svc.txt 显示 ssl/http 则改 https
whatweb -a 3 $PROTO://$TARGET:$PORT -v | tee $RESULT_DIR/web/whatweb.txt
curl -sS -D $RESULT_DIR/web/headers.txt -o $RESULT_DIR/web/index.html $PROTO://$TARGET:$PORT/
curl -sS $PROTO://$TARGET:$PORT/robots.txt $RESULT_DIR/web/robots.txt
curl -sS $PROTO://$TARGET:$PORT/sitemap.xml $RESULT_DIR/web/sitemap.xml
```

从 `headers.txt` 抓 `Server` / `X-Powered-By` / `Set-Cookie`（框架指纹），从 `index.html` 抓 `<title>`、`<script src>`、`/api/` 字样。

### 阶段 3 · 目录与接口枚举

```bash
ffuf -u $PROTO://$TARGET:$PORT/FUZZ -w $WORDLIST -t $THREADS \
     -mc 200,204,301,302,307,401,403 -of json -o $RESULT_DIR/ffuf/dirs.json

# 从首页 JS 里提接口路径，再单独跑一遍
grep -oE '"/[a-zA-Z0-9_/.-]+"' $RESULT_DIR/web/index.html | tr -d '"' | sort -u > $RESULT_DIR/ffuf/js_paths.txt
ffuf -u $PROTO://$TARGET:$PORT/FUZZ -w $RESULT_DIR/ffuf/js_paths.txt -t $THREADS \
     -mc all -of json -o $RESULT_DIR/ffuf/api.json
```

- `-mc` 里保留 `401/403`：这两个状态码本身就是"存在但受限"的证据，比 200 更有价值。
- 对 `dirs.json` 里每个 200/301 的路径，追加扩展名爆破：`-e .php,.bak,.zip,.git,.env,.json`。

### 阶段 4 · 命中点验证

对阶段 3 每个非 404 命中，逐条记录：

```bash
for p in $(jq -r '.results[] | select(.status!=404) | .url' $RESULT_DIR/ffuf/dirs.json); do
  echo "=== $p" >> $RESULT_DIR/evidence/hits.txt
  curl -sS -o /dev/null -w "%{http_code} %{size_download} %{content_type}\n" "$p" >> $RESULT_DIR/evidence/hits.txt
done
```

分类判读：
- `200` + 大 `size_download` → 真实页面，抓内容看功能
- `301/302` → 跟 `Location`，可能是后台入口
- `401/403` → 认证/权限边界，记下来作为后续越权测试点
- `.git/`、`.env`、`*.bak` 命中 → 直接拉取，这是最高优先级证据

### 台账（每条命中六字段，缺一不可）

| 主机 | 端口/协议 | 服务/版本 | 证据（命令 + 关键回显） | 时间戳 | 来源工具 |
| --- | --- | --- | --- | --- | --- |
| `TARGET` | `PORT/tcp` | `SERVICE VERSION` | `nmap -sV` → `8080/tcp open http Apache 2.4.49` | `2025-…` | nmap |
| `TARGET` | `PORT/http` | `Apache 2.4.49` | `curl -I` → `Server: Apache/2.4.49` | `2025-…` | curl |
| `TARGET` | `PORT/http` | — | `ffuf` → `/admin 301`、`/.git/HEAD 200` | `2025-…` | ffuf |

### 自检清单

1. 每个结论都有命令 + 回显？→ 阶段 1–4 全部 `tee`/`-o` 落盘，可复现。
2. `[推断]` 有没有混进已验证？→ 版本号可疑（如 `Apache 2.4.49` 是否真可利用）一律标 `[推断]`，下一步验证动作写在同一行。
3. 台账六字段齐？→ 上表模板，每条命中补一行。
4. 失败分支写了？→ `filtered` 端口、`403` 路径、`ffuf` 全 404 都要在 `evidence/` 里留一行"为什么没打进去"。
5. 报告给的是路径/命令/哈希？→ 全部落 `RESULT_DIR`，最终 `tar czf recon_$TARGET.tgz $RESULT_DIR` 打包交付。

### 下一步分叉（拿到阶段 1–3 回显后选一条）

- 端口是 `22/445/3306/6379` 等非 Web → 转服务专项枚举（`ssh-audit`、`smbclient -L`、`