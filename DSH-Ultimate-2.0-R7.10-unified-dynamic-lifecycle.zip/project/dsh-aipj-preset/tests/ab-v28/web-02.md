## 站点信息收集命令链

> 选型：`subfinder` + `httpx` + `nuclei` + `ffuf` + `katana`，全部输出落 `RESULT_DIR`，一条链跑完子域→存活→指纹→接口。

```bash
# ===== 0. 前置：变量与目录 =====
export TARGET="example.com"
export RESULT_DIR="./recon_${TARGET}_$(date +%Y%m%d_%H%M)"
mkdir -p "$RESULT_DIR"/{subs,alive,finger,urls,dirs,js}
cd "$RESULT_DIR"

# 工具可用性先探（缺哪个就装哪个，或换等效替代）
for t in subfinder httpx nuclei ffuf katana amass; do
  command -v "$t" >/dev/null 2>&1 && echo "[OK] $t" || echo "[MISS] $t"
done
```

```bash
# ===== 1. 子域名枚举 =====
# 1.1 被动枚举（subfinder 聚合多源）
subfinder -d "$TARGET" -all -silent -o subs/subfinder.txt

# 1.2 证书透明度（crt.sh，补充被动源）
curl -s "https://crt.sh/?q=%25.${TARGET}&output=json" \
  | jq -r '.[].name_value' | sed 's/\*\.//g' | sort -u > subs/crtsh.txt

# 1.3 主动爆破（可选，需字典；DNS 泛解析先检测）
dig +short "random-$(date +%s).${TARGET}" A | grep -q . \
  && echo "[WARN] 存在泛解析，爆破结果需过滤" \
  || ffuf -u "https://FUZZ.${TARGET}" -w /usr/share/seclists/Discovery/DNS/subdomains-top1million-5000.txt \
       -mc 200,301,302,401,403 -t 50 -o subs/ffuf_dns.json -of json

# 1.4 合并去重
cat subs/*.txt 2>/dev/null | sed 's/ //g' | grep -E "\.${TARGET}$" | sort -u > subs/all.txt
wc -l subs/all.txt
```

```bash
# ===== 2. 存活探测（httpx）=====
httpx -l subs/all.txt \
  -ports 80,443,8080,8443,8000,9000 \
  -status-code -title -tech-detect -web-server -cdn -ip \
  -threads 100 -timeout 8 \
  -o alive/httpx.txt -json -silent

# 提取存活 URL 列表（供后续步骤）
jq -r '.url' alive/httpx.txt 2>/dev/null | sort -u > alive/urls.txt
# 若 httpx 输出非 json 行，用：
# awk '{print $1}' alive/httpx.txt | sort -u > alive/urls.txt
wc -l alive/urls.txt
```

```bash
# ===== 3. 指纹识别 =====
# 3.1 httpx 已带 tech-detect，汇总技术栈
jq -r 'select(.tech!=null) | "\(.url)\t\(.tech|join(","))"' alive/httpx.txt \
  | sort -u > finger/tech.txt

# 3.2 nuclei 指纹模板（技术识别 + 暴露面）
nuclei -l alive/urls.txt \
  -t http/technologies/ -t http/exposures/ \
  -severity info,low,medium \
  -o finger/nuclei_tech.txt -silent

# 3.3 whatweb 补充（单点深挖时用）
while read -r u; do
  whatweb -a 3 --no-errors "$u" >> finger/whatweb.txt 2>/dev/null
done < alive/urls.txt
```

```bash
# ===== 4. 接口 / URL 收集 =====
# 4.1 爬虫抓取（katana，含 JS 渲染）
katana -list alive/urls.txt \
  -d 3 -jc -kf all -aff \
  -o urls/katana.txt -silent

# 4.2 历史 URL（gau / waybackurls，有则用）
command -v gau >/dev/null && cat alive/urls.txt | gau --threads 10 > urls/gau.txt
command -v waybackurls >/dev/null && cat alive/urls.txt | waybackurls > urls/wayback.txt

# 4.3 合并 + 去重 + 参数化过滤
cat urls/*.txt 2>/dev/null | sort -u > urls/all.txt
grep -E '\?.*=' urls/all.txt | sort -u > urls/with_params.txt
wc -l urls/all.txt urls/with_params.txt

# 4.4 JS 文件提取（接口常藏在 JS 里）
grep -Ei '\.js(\?|$)' urls/all.txt | sort -u > js/js_urls.txt
# 从 JS 中提取路径/接口
while read -r j; do
  curl -s "$j" | grep -oE '"/[a-zA-Z0-9_/.-]+"' 
done < js/js_urls.txt | tr -d '"' | sort -u > js/endpoints_from_js.txt
```

```bash
# ===== 5. 目录 / 接口爆破（对主站或指定存活点）=====
export MAIN="https://${TARGET}"
ffuf -u "${MAIN}/FUZZ" \
  -w /usr/share/seclists/Discovery/Web-Content/raft-medium-directories.txt \
  -mc 200,204,301,302,307,401,403 \
  -fs 0 -t 80 -rate 100 \
  -o dirs/ffuf_dir.json -of json

# 接口路径爆破（用 API 字典）
ffuf -u "${MAIN}/FUZZ" \
  -w /usr/share/seclists/Discovery/Web-Content/api/api-endpoints.txt \
  -mc all -fc 404 -t 60 \
  -o dirs/ffuf_api.json -of json
```

```bash
# ===== 6. 汇总台账 =====
{
  echo "== 子域 =="; wc -l < subs/all.txt
  echo "== 存活 =="; wc -l < alive/urls.txt
  echo "== 技术栈 =="; wc -l < finger/tech.txt
  echo "== URL =="; wc -l < urls/all.txt
  echo "== 带参 =="; wc -l < urls/with_params.txt
  echo "== JS 接口 =="; wc -l < js/endpoints_from_js.txt
} | tee summary.txt
```

## 台账字段（每条资产按此记录）

