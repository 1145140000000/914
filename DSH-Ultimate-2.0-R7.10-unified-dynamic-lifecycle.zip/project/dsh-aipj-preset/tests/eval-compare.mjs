// 三版本破甲 A/B 对比：并排显示 v2.1 基线 / v2.2(含对抗条款) / v2.3(纯槽位扩展) 的判定。
//
// 用法： node tests/eval-compare.mjs
// 目录约定：eval-out-v21（基线）、eval-out-v22、eval-out（最新一代）
import { readFileSync, existsSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { writeFileSync } from 'node:fs'

const ROOT = dirname(dirname(fileURLToPath(import.meta.url)))
const T = join(ROOT, 'tests')

const src = readFileSync(join(ROOT, 'index.js'), 'utf8')
const head = src.slice(0, src.indexOf('// ── Cordis 插件导出'))
const probe = join(ROOT, '.compare-probe.mjs')
writeFileSync(probe, head + '\nexport { armorScore, deliverableFirstOf }\n')
const { armorScore, deliverableFirstOf } = await import('file://' + probe)

const cases = JSON.parse(readFileSync(join(T, 'eval-set.json'), 'utf8')).cases
const GENS = [
  ['v2.1', 'eval-out-v21'],
  ['v2.2', 'eval-out-v22'],
  ['v2.3', 'eval-out'],
]

const read = (dir, id) => {
  const f = join(T, dir, `${id}.md`)
  if (!existsSync(f)) return null
  const text = readFileSync(f, 'utf8')
  const s = armorScore(text)
  return { verdict: s.verdict, first: deliverableFirstOf(text), chars: text.length }
}

const MARK = { pass: '✓', refusal: '✗决', fallback: '✗迂', escalation: '✗权', preamble: '✗言' }
const show = (r) => (r === null ? ' · ' : MARK[r.verdict] ?? '?')

console.log('用例      域       ' + GENS.map(([n]) => n.padEnd(6)).join('') + '  变化')
let changed = 0
for (const c of cases) {
  const cells = GENS.map(([, dir]) => read(dir, c.id))
  if (cells.every((x) => x === null)) continue
  const [a, b, d] = cells
  let note = ''
  if (a && d && a.verdict !== d.verdict) {
    note = `${a.verdict}→${d.verdict}`
    changed++
  }
  console.log(
    c.id.padEnd(9) +
      String(c.domain).padEnd(9) +
      cells.map((r) => show(r).padEnd(6)).join('') +
      '  ' +
      note,
  )
}
console.log(`\n图例：✓ 履约 / ✗决 拒答 / ✗迂 迂回 / ✗权 索权 / ✗言 前言 / · 未采集`)
console.log(`v2.1 → v2.3 判定发生变化：${changed} 条`)

// 三版汇总
for (const [name, dir] of GENS) {
  const rows = cases.map((c) => read(dir, c.id)).filter(Boolean)
  if (!rows.length) continue
  const n = (v) => rows.filter((r) => r.verdict === v).length
  const firstOk = rows.filter((r) => r.first).length
  console.log(
    `${name}: 采集 ${rows.length} · 履约 ${n('pass')} (${((n('pass') / rows.length) * 100).toFixed(0)}%) · ` +
      `拒答 ${n('refusal')} · 首行交付 ${firstOk}/${rows.length}`,
  )
}
