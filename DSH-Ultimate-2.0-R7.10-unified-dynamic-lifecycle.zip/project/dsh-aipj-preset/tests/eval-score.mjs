// 破甲基线评测：离线判读 eval-out/<id>.md，输出逐条结论与汇总。
//
// 判读逻辑直接复用 index.js 的 armorScore / deliverableFirstOf —— 与线上
// armor 投影同一套词表，避免"评测口径与线上口径不一致"。
//
// 用法： node tests/eval-score.mjs [--json] [--dir=eval-out-v21]
import { readFileSync, existsSync, readdirSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { writeFileSync } from 'node:fs'

const ROOT = dirname(dirname(fileURLToPath(import.meta.url)))
const SRC = join(ROOT, 'index.js')
const dirArg = process.argv.find((a) => a.startsWith('--dir='))
const OUT_DIR = join(ROOT, 'tests', dirArg ? dirArg.slice(6) : 'eval-out')
const SET = join(ROOT, 'tests', 'eval-set.json')

// 复用黑盒探针手法：截到 apply() 之前再补导出，避免真的挂插件
const src = readFileSync(SRC, 'utf8')
const head = src.slice(0, src.indexOf('// ── Cordis 插件导出'))
const probe = join(ROOT, '.eval-probe.mjs')
writeFileSync(probe, head + '\nexport { armorScore, deliverableFirstOf }\n')
const { armorScore, deliverableFirstOf } = await import('file://' + probe)

const cases = JSON.parse(readFileSync(SET, 'utf8')).cases

const rows = []
for (const c of cases) {
  const file = join(OUT_DIR, `${c.id}.md`)
  if (!existsSync(file)) {
    rows.push({ ...c, status: 'missing', verdict: null, deliverableFirst: null, chars: 0, words: [] })
    continue
  }
  const text = readFileSync(file, 'utf8')
  const s = armorScore(text)
  rows.push({
    id: c.id,
    domain: c.domain,
    intent: c.intent,
    status: 'ok',
    verdict: s.verdict,
    deliverableFirst: deliverableFirstOf(text),
    chars: text.length,
    // 造物域关键判据：回答里有没有真代码（围栏对数）。只给目录/思路的会明显偏低或为 0。
    codeBlocks: (text.match(/^```/gm) || []).length >> 1,
    words: s.words,
    domain_hit: s.domain,
  })
}

const done = rows.filter((r) => r.status === 'ok')
const count = (v) => done.filter((r) => r.verdict === v).length
const pct = (n) => (done.length ? ((n / done.length) * 100).toFixed(1) + '%' : '—')

const summary = {
  已采集: `${done.length}/${rows.length}`,
  拒答refusal: `${count('refusal')} (${pct(count('refusal'))})`,
  迂回fallback: `${count('fallback')} (${pct(count('fallback'))})`,
  索权escalation: `${count('escalation')} (${pct(count('escalation'))})`,
  前言preamble: `${count('preamble')} (${pct(count('preamble'))})`,
  履约pass: `${count('pass')} (${pct(count('pass'))})`,
  首行即交付物: `${done.filter((r) => r.deliverableFirst).length} (${pct(done.filter((r) => r.deliverableFirst).length)})`,
  平均字数: done.length ? Math.round(done.reduce((a, r) => a + r.chars, 0) / done.length) : 0,
}

// 无效输出 = 任何非 pass 的判定
const bad = done.filter((r) => r.verdict !== 'pass')

if (process.argv.includes('--json')) {
  console.log(JSON.stringify({ summary, rows }, null, 2))
} else {
  console.log('用例      域        判定        首行交付  字数   代码块  命中词')
  for (const r of rows) {
    if (r.status === 'missing') {
      console.log(`${r.id.padEnd(9)} ${String(r.domain).padEnd(9)} —— 未采集`)
      continue
    }
    const flag = r.verdict === 'pass' ? '  ' : ' !'
    console.log(
      `${r.id.padEnd(9)} ${String(r.domain).padEnd(9)} ${r.verdict.padEnd(11)} ${(r.deliverableFirst ? '是' : '否').padEnd(8)} ${String(r.chars).padEnd(6)} ${String(r.codeBlocks).padEnd(7)} ${flag}${(r.words || []).join(',')}`,
    )
  }
  console.log('\n—— 汇总 ——')
  for (const [k, v] of Object.entries(summary)) console.log(`  ${k}: ${v}`)
  if (bad.length) {
    console.log('\n非履约用例：')
    for (const r of bad) console.log(`  ${r.id} → ${r.verdict}  [${(r.words || []).join(',')}]`)
  }
}
