// eval42-run.mjs — 42 条一击型题库的 A/B 采集器
//
// 用法:
//   node tests/eval42-run.mjs --out=tests/ab42-v28 [--reinforce=prompts/aipj-reinforce.md]
//                             [--kernel=prompts/aipj-kernel.md] [--set=eval-42.json]
//                             [--concurrency=4] [--only=q01,q02] [--max-tokens=1400]
//
// 直连 DeepSeek（与 ab-run.mjs 同一凭据读取方式），把每条回答原文落到 <out>/<id>.md，
// 便于离线判读，避免长文本回流主上下文。
import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { homedir } from 'node:os'

const ROOT = dirname(dirname(fileURLToPath(import.meta.url)))
const arg = (k, d) => {
  const hit = process.argv.find((a) => a.startsWith(`--${k}=`))
  return hit ? hit.slice(k.length + 3) : d
}

const OUT = resolve(ROOT, arg('out', join('tests', 'ab42')))
const KERNEL = resolve(ROOT, arg('kernel', join('prompts', 'aipj-kernel.md')))
const REINFORCE = resolve(ROOT, arg('reinforce', join('prompts', 'aipj-reinforce.md')))
const SET = resolve(ROOT, arg('set', join('tests', 'eval-42.json')))
const CONC = Number(arg('concurrency', '4'))
const MAXTOK = Number(arg('max-tokens', '1400'))
const only = arg('only', '').split(',').filter(Boolean)

const payload =
  readFileSync(KERNEL, 'utf8') + '\n\n' + readFileSync(REINFORCE, 'utf8')

const set = JSON.parse(readFileSync(SET, 'utf8'))
const cases = set.cases.filter((c) => (only.length ? only.includes(c.id) : true))
if (!cases.length) throw new Error('no cases')

function key() {
  if (process.env.DEEPSEEK_API_KEY) return process.env.DEEPSEEK_API_KEY
  const raw = readFileSync(join(homedir(), '.dsh', '.credentials.yaml'), 'utf8')
  const m = raw.match(/DEEPSEEK_API_KEY:\s*(\S+)/)
  if (!m) throw new Error('no DEEPSEEK_API_KEY')
  return m[1].replace(/^["']|["']$/g, '')
}

mkdirSync(OUT, { recursive: true })
const K = key()
const meta = []
let done = 0

async function run(c) {
  const t0 = Date.now()
  try {
    const res = await fetch('https://api.deepseek.com/chat/completions', {
      method: 'POST',
      headers: { Authorization: `Bearer ${K}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'deepseek-chat',
        messages: [
          { role: 'system', content: payload },
          { role: 'user', content: c.prompt },
        ],
        max_tokens: MAXTOK,
        temperature: 0.3,
      }),
    })
    if (!res.ok) {
      const t = await res.text()
      meta.push({ id: c.id, n: c.n, class: c.class, error: `HTTP ${res.status} ${t.slice(0, 120)}` })
      console.log(`${c.id} HTTP ${res.status}`)
      return
    }
    const j = await res.json()
    const text = j.choices?.[0]?.message?.content || ''
    const file = join(OUT, `${c.id}.md`)
    writeFileSync(file, text, 'utf8')
    meta.push({
      id: c.id,
      n: c.n,
      class: c.class,
      chars: text.length,
      ms: Date.now() - t0,
      finish: j.choices?.[0]?.finish_reason || null,
      file,
    })
    console.log(
      `${c.id.padEnd(5)} [${c.class}] ${String(text.length).padStart(5)} chars  ${((Date.now() - t0) / 1000).toFixed(1)}s`,
    )
  } catch (e) {
    meta.push({ id: c.id, n: c.n, class: c.class, error: String(e).slice(0, 160) })
    console.log(`${c.id} ERR ${String(e).slice(0, 80)}`)
  } finally {
    done++
  }
}

// 固定并发池
const queue = cases.slice()
await Promise.all(
  Array.from({ length: Math.min(CONC, queue.length) }, async () => {
    while (queue.length) await run(queue.shift())
  }),
)

meta.sort((a, b) => a.n - b.n)
writeFileSync(
  join(OUT, '_meta.json'),
  JSON.stringify(
    { out: OUT, kernel: KERNEL, reinforce: REINFORCE, set: SET, done, total: cases.length, meta },
    null,
    2,
  ),
  'utf8',
)
console.log(`→ ${OUT}  (${done}/${cases.length})`)
