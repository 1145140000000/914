#!/usr/bin/env bash
# 卸载 dsh-aipj-preset：从 profile 移除宿主级 bundle 插件。
#
# 只做一件事：让 dsh CLI 把本包从 profile 依赖与 bundles 数组里摘掉。
# 不用任何历史备份去覆盖 profile 的 package.json —— 那会连带回滚掉之后装的
# 其他 bundle（.rollback/package.json.before 只保留作事故取证）。
set -uo pipefail

PROFILE="${DSH_PROFILE:-web}"
PKG="$HOME/.dsh/profiles/$PROFILE/package.json"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "[1/2] 移除 bundle 登记（profile: $PROFILE）"
command -v dsh >/dev/null 2>&1 || { echo "  未找到 dsh 命令"; exit 1; }
dsh plugin --profile "$PROFILE" remove @local/dsh-aipj-preset || true

echo "[2/2] 校验"
if grep -q '"@local/dsh-aipj-preset"' "$PKG" 2>/dev/null; then
  echo "  ! $PKG 仍含本包 —— 手工删除 dependencies 里的条目与 .dsh.profile.bundles 数组中的 \"@local/dsh-aipj-preset\""
  exit 1
fi
echo "  ✓ profile 已不再引用本包"
echo
echo "重启 dsh web 后彻底生效。插件源码目录保留未删："
echo "  rm -rf $HERE"
