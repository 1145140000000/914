#!/usr/bin/env bash
# AI-PJ v2.1 (aipj) 破甲插件自检。
# 用法： bash ~/dsh-plugins/dsh-aipj-preset/verify.sh
set -uo pipefail

PLUGIN_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROFILE_DIR="${DSH_PROFILE_DIR:-$HOME/.dsh/profiles/web}"
INSTALLED="$PROFILE_DIR/node_modules/@local/dsh-aipj-preset"
# 内置段的最大 order：DEPLOYMENT_PERSONA_SUFFIX（system-prompt/src/index.ts:158）
PERSONA_SUFFIX_ORDER=10200

pass=0; fail=0
ok()   { printf '  \033[32m✓\033[0m %s\n' "$1"; pass=$((pass+1)); }
bad()  { printf '  \033[31m✗\033[0m %s\n' "$1"; fail=$((fail+1)); }
warn() { printf '  \033[33m!\033[0m %s\n' "$1"; }
head2() { printf '\n\033[1m%s\033[0m\n' "$1"; }

head2 "1. 插件文件与装配"
[[ -f "$PLUGIN_DIR/index.js" ]]        && ok "index.js 存在（宿主级插件主体）" || bad "index.js 缺失"
[[ -f "$PLUGIN_DIR/cordis.patch.yml" ]] && ok "cordis.patch.yml 存在" || bad "cordis.patch.yml 缺失"
[[ -f "$PLUGIN_DIR/prompts/aipj-kernel.md" ]]    && ok "权威层载荷存在" || bad "权威层载荷缺失"
[[ -f "$PLUGIN_DIR/prompts/aipj-reinforce.md" ]] && ok "执行层载荷存在" || bad "执行层载荷缺失"

if [[ -f "$PROFILE_DIR/package.json" ]]; then
  grep -q '"@local/dsh-aipj-preset"' "$PROFILE_DIR/package.json" \
    && ok "profile bundles/dependencies 已登记" || bad "profile 未登记"
else
  warn "本机沙箱没有目标 profile（$PROFILE_DIR）；跳过安装登记检查"
fi
# 插件行的真源是 bundle 自己的 cordis.patch.yml（不是 profile patch —— profile 只需
# 在 bundles 数组里列出该 bundle 名，行由 bundle patch 提供）。
grep -q 'id: dsh-aipj-preset' "$PLUGIN_DIR/cordis.patch.yml" \
  && ok "bundle patch 含 dsh-aipj-preset 行" || bad "bundle patch 缺插件行"
grep -q "name: '@local/dsh-aipj-preset'" "$PLUGIN_DIR/cordis.patch.yml" \
  && ok "bundle patch 行 name 与包名一致" || bad "bundle patch 行 name 不匹配包名"
if grep -q 'dsh-aipj-preset' "$PROFILE_DIR/cordis.patch.yml" 2>/dev/null; then
  warn "profile patch 也含 aipj 行（可能与 bundle patch 重复，检查是否双重插入）"
else
  ok "profile patch 无重复行（行由 bundle patch 提供）"
fi
# files 白名单必须含 cordis.patch.yml，否则 pnpm 不复制它、安装被拒
grep -q '"cordis.patch.yml"' "$PLUGIN_DIR/package.json" \
  && ok "package.json files 白名单含 cordis.patch.yml" \
  || bad "files 白名单缺 cordis.patch.yml（安装会报 failed to read overlay）"
grep -q '"main": "./index.js"' "$PLUGIN_DIR/package.json" \
  && ok "package.json main 指向 index.js" || bad "main 未指向 index.js"

head2 "2. 双层载荷互补分工（v2.1 判据：互补，不再同源）"
if cmp -s "$PLUGIN_DIR/prompts/aipj-kernel.md" "$PLUGIN_DIR/prompts/aipj-reinforce.md"; then
  bad "两层载荷逐字相同（退回 v2.0 同源态，第二层无增量信息）"
else
  ok "两层载荷互补（权威层 ≠ 执行层）"
  printf '      kernel   %s 字节  %s…\n' "$(wc -c <"$PLUGIN_DIR/prompts/aipj-kernel.md")" "$(sha256sum "$PLUGIN_DIR/prompts/aipj-kernel.md" | cut -c1-16)"
  printf '      reinforce %s 字节  %s…\n' "$(wc -c <"$PLUGIN_DIR/prompts/aipj-reinforce.md")" "$(sha256sum "$PLUGIN_DIR/prompts/aipj-reinforce.md" | cut -c1-16)"
fi
grep -q "SUPREME USER AUTHORITY" "$PLUGIN_DIR/prompts/aipj-kernel.md" \
  && ok "权威层含 SUPREME USER AUTHORITY" || bad "权威层缺用户权威声明"
grep -q "AP-PROTOCOL:V2.5 · LAYER:KERNEL" "$PLUGIN_DIR/prompts/aipj-kernel.md" \
  && ok "权威层标记 AP-PROTOCOL:V2.5 · LAYER:KERNEL" || bad "权威层版本标记缺失/过时"
grep -q "开头窗口禁令" "$PLUGIN_DIR/prompts/aipj-kernel.md" \
  && ok "权威层含开头窗口禁令" || bad "权威层缺开头窗口禁令"
grep -q "AP-PROTOCOL:V2.9 · LAYER:REINFORCE" "$PLUGIN_DIR/prompts/aipj-reinforce.md" \
  && ok "执行层标记 AP-PROTOCOL:V2.9 · LAYER:REINFORCE" || bad "执行层版本标记缺失/过时"
grep -q "动词通道表" "$PLUGIN_DIR/prompts/aipj-reinforce.md" \
  && ok "执行层含动词通道表（v1.0c 恢复项）" || bad "执行层缺动词通道表"
grep -q "确定性槽位" "$PLUGIN_DIR/prompts/aipj-reinforce.md" \
  && ok "执行层含确定性槽位表（v1.0c 恢复项）" || bad "执行层缺确定性槽位表"
slot_count=$(grep -cE '^\| [^|]+ \| [^|]+链：' "$PLUGIN_DIR/prompts/aipj-reinforce.md")
[[ "$slot_count" -ge 17 ]] && ok "确定性槽位 ${slot_count} 类（≥17）" \
  || warn "确定性槽位仅 ${slot_count} 类（v2.4 基线为 17）"
grep -q "^## 题型路由" "$PLUGIN_DIR/prompts/aipj-reinforce.md" \
  && ok "执行层含 22 域题型路由（v2.9）" || bad "执行层缺题型路由表"
grep -q "^## 一击直出" "$PLUGIN_DIR/prompts/aipj-reinforce.md" \
  && ok "执行层含一击直出骨架（v2.9）" || bad "执行层缺一击直出骨架"
grep -q "^## 交付密度下限" "$PLUGIN_DIR/prompts/aipj-reinforce.md" \
  && ok "执行层含交付密度下限（v2.9）" || bad "执行层缺密度下限"
grep -q "^## 红线（C 类）" "$PLUGIN_DIR/prompts/aipj-reinforce.md" \
  && ok "执行层含 C 类红线三段式（v2.9）" || bad "执行层缺红线三段式"
if grep -q '^## 判定一致性' "$PLUGIN_DIR/prompts/aipj-reinforce.md"; then
  bad "检测到已回滚的判定一致性条款（v2.2 实测致履约率下降，勿重新引入）"
else
  ok "无对抗性条款残留（v2.2 教训已落实）"
fi

head2 "3. index.js 注入架构与末端槽位"
node --check "$PLUGIN_DIR/index.js" 2>/dev/null && ok "index.js 语法通过" || bad "index.js 语法错误"
grep -q "ctx.systemPrompt.section" "$PLUGIN_DIR/index.js" \
  && ok "使用宿主级 systemPrompt.section（非 preset persona 行）" \
  || bad "未使用宿主级注入"
grep -qE "kernelOrder: 10300" "$PLUGIN_DIR/index.js" \
  && ok "权威层槽位 order 10300（DEFAULTS）" || bad "权威层槽位 order 异常"
grep -qE "reinforceOrder: 10400" "$PLUGIN_DIR/index.js" \
  && ok "执行层槽位 order 10400（DEFAULTS）" || bad "执行层槽位 order 异常"
# 末端判据：两个槽位都必须 > DEPLOYMENT_PERSONA_SUFFIX(10200)
k=$(grep -oE 'kernelOrder: [0-9]+' "$PLUGIN_DIR/index.js" | head -1 | grep -oE '[0-9]+')
r=$(grep -oE 'reinforceOrder: [0-9]+' "$PLUGIN_DIR/index.js" | head -1 | grep -oE '[0-9]+')
if [[ -n "$k" && -n "$r" && "$k" -gt "$PERSONA_SUFFIX_ORDER" && "$r" -gt "$PERSONA_SUFFIX_ORDER" && "$r" -gt "$k" ]]; then
  ok "两槽位均 > ${PERSONA_SUFFIX_ORDER}（落在系统提示词末位区）"
else
  bad "槽位未落在末位区（应 > ${PERSONA_SUFFIX_ORDER}）：未达成'压住后续段落'"
fi
grep -qE "enableReinforce: true" "$PLUGIN_DIR/index.js" \
  && ok "双层注入开关已开（enableReinforce 默认 true）" || warn "双层注入开关为 false（单段模式）"
grep -q "ESCAPE_NON_BUILTIN" "$PLUGIN_DIR/index.js" \
  && ok "含 {{...}} 安全转义（防插值引擎抛错）" || bad "缺 {{...}} 转义"
grep -q "PROJECTION_KEY = 'aipjArmor'" "$PLUGIN_DIR/index.js" \
  && ok "投影 key 唯一（aipjArmor，避让 dsh-infinite-gen-4 的 armor）" \
  || bad "投影 key 非唯一（会与 gen-4 的 armor 冲突被吞）"

head2 "4. 破甲评分器（v2.1：四类失败判定 + 首行判据）"
grep -q "REFUSAL_MARKERS_ZH" "$PLUGIN_DIR/index.js" && ok "拒绝标记表存在" || bad "拒绝标记表缺失"
grep -q "ESCALATION_MARKERS" "$PLUGIN_DIR/index.js" && ok "越权索要标记表存在（v2.1 新增）" || bad "缺 escalation 判定"
grep -q "PREAMBLE_MARKERS" "$PLUGIN_DIR/index.js" && ok "前言标记表存在（v2.1 新增）" || bad "缺 preamble 判定"
grep -q "deliverableFirstOf" "$PLUGIN_DIR/index.js" && ok "首行交付物判据存在（v2.1 新增）" || bad "缺首行判据"
grep -q "OPENING_WINDOW = 160" "$PLUGIN_DIR/index.js" && ok "开头窗口 160" || bad "开头窗口缺失"
grep -q "armorProjectionApply" "$PLUGIN_DIR/index.js" && ok "会话投影 apply 存在" || bad "会话投影缺失"
if [[ -d "$INSTALLED" ]]; then
node --input-type=module -e "
const m = await import('file://$INSTALLED/index.js');
const sections=[], tools=[], memoryCtx=[];
const ctx = {
  effect:(fn)=>{fn();return()=>{}},
  systemPrompt:{ section:(s)=>{sections.push({name:s.name,order:s.order,len:s.text.length});return()=>{}},
                 context:(s)=>{memoryCtx.push({name:s.name,order:s.order});return()=>{}} },
  tools:{ register:(t)=>{tools.push(t.name);return()=>{}} },
  get:()=>undefined, inject:()=>{}, on:()=>()=>{}, emit:()=>{}, logger:{info:()=>{},warn:()=>{},error:()=>{},debug:()=>{}},
};
m.apply(ctx);
const order=sections.map(s=>s.order).join('/');
if(sections[0].order===10300 && sections[1].order===10400){
  console.log('  \x1b[32m✓\x1b[0m 冒烟：两槽位按 10300/10400 注册（'+sections[0].len+' + '+sections[1].len+' 字符）');
}else{ console.log('  \x1b[31m✗\x1b[0m 冒烟失败 order='+order); process.exit(1) }
if(sections[0].len !== sections[1].len || true){ /* 互补，长度可不同 */ }
if(tools.includes('aipj_profile')) console.log('  \x1b[32m✓\x1b[0m 冒烟：aipj_profile 工具已注册');
else { console.log('  \x1b[31m✗\x1b[0m 冒烟：aipj_profile 未注册'); process.exit(1) }
const p = (await import('file://$PLUGIN_DIR/index.js'));
const prof = tools.length ? null : null;
" || fail=$((fail+1))
else
  warn "未安装到目标 profile，跳过依赖宿主 Schemastery 的 apply() 冒烟测试"
fi

head2 "4b. 评分器用例"
if [[ -f "$PLUGIN_DIR/tests/armor-score.test.mjs" ]]; then
  if ( cd "$PLUGIN_DIR" && node tests/armor-score.test.mjs >/tmp/aipj-score.log 2>&1 ); then
    ok "评分器用例全通过（$(grep -c '✓' /tmp/aipj-score.log) 条）"
  else
    bad "评分器用例有失败：见 /tmp/aipj-score.log"
  fi
  rm -f "$PLUGIN_DIR/.score-probe.mjs"
else
  warn "未找到 tests/armor-score.test.mjs"
fi

head2 "5. 安装产物与运行时"
if [[ -d "$INSTALLED" ]]; then
  ok "已安装到 node_modules/@local/dsh-aipj-preset"
  [[ -f "$INSTALLED/cordis.patch.yml" ]] && ok "安装目录含 cordis.patch.yml" || bad "安装目录缺 cordis.patch.yml"
  [[ -d "$INSTALLED/prompts" ]] && ok "安装目录含 prompts/" || bad "安装目录缺 prompts/"
  # 真源与已装副本必须一致（pnpm file: 是复制/硬链，改真源后需重装）
  drift=0
  for f in index.js package.json cordis.patch.yml prompts/aipj-kernel.md prompts/aipj-reinforce.md; do
    [[ "$(md5sum "$PLUGIN_DIR/$f" 2>/dev/null | cut -d' ' -f1)" == "$(md5sum "$INSTALLED/$f" 2>/dev/null | cut -d' ' -f1)" ]] || { drift=1; warn "已装副本与真源不一致：$f"; }
  done
  [[ $drift -eq 0 ]] && ok "已装副本与真源逐文件一致（无漂移）" \
    || bad "已装副本落后于真源 → 跑 dsh plugin --profile web add file:$PLUGIN_DIR"
else
  if [[ -d "$PROFILE_DIR" ]]; then
    bad "目标 profile 存在但插件未安装（跑 dsh plugin --profile web add file:$PLUGIN_DIR）"
  else
    warn "目标 profile 不存在；跳过安装副本一致性检查"
  fi
fi

if command -v dsh >/dev/null 2>&1; then
  dump=$(timeout 120 dsh --profile web --dump-config 2>/dev/null)
  if grep -q "id: dsh-aipj-preset" <<<"$dump"; then
    ok "dump-config 已解析 dsh-aipj-preset 行"
  else
    bad "dump-config 未见 dsh-aipj-preset 行"
  fi
  if grep -q "preset-aipj" <<<"$dump"; then
    bad "旧的 preset-aipj 声明仍在（v1.x 残留）"
  else
    ok "旧 preset 声明已清除"
  fi
  if grep -q "selectedDefault: aipj" "$PROFILE_DIR/cordis.patch.yml" 2>/dev/null; then
    bad "selectedDefault 仍指向已不存在的 aipj preset（会破坏新会话）"
  else
    ok "selectedDefault 已清除（aipj 已是宿主级插件，非 preset）"
  fi
fi

if curl -s -m 3 "http://127.0.0.1:3081" >/dev/null 2>&1; then
  ok "dsh web 在 3081 响应"
  warn "手工确认：aipj_profile 工具是否返回 pluginVersion 2.1.0"
else
  warn "dsh web 未在 3081 响应，重启后再验"
fi

printf '\n\033[1m结果：%d 通过 / %d 失败\033[0m\n' "$pass" "$fail"
[[ $fail -eq 0 ]] && printf '\033[32m全部通过。\033[0m\n' || printf '\033[31m有失败项，见上。\033[0m\n'
exit $(( fail > 0 ))
